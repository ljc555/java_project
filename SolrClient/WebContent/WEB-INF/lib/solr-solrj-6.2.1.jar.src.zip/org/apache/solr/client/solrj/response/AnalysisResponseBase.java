/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalysisResponseBase
/*     */   extends SolrResponseBase
/*     */ {
/*     */   protected List<AnalysisPhase> buildPhases(NamedList<List<NamedList<Object>>> phaseNL)
/*     */   {
/*  65 */     List<AnalysisPhase> phases = new ArrayList(phaseNL.size());
/*  66 */     for (Map.Entry<String, List<NamedList<Object>>> phaseEntry : phaseNL) {
/*  67 */       AnalysisPhase phase = new AnalysisPhase((String)phaseEntry.getKey());
/*  68 */       List<NamedList<Object>> tokens = (List)phaseEntry.getValue();
/*  69 */       for (NamedList<Object> token : tokens) {
/*  70 */         TokenInfo tokenInfo = buildTokenInfo(token);
/*  71 */         phase.addTokenInfo(tokenInfo);
/*     */       }
/*  73 */       phases.add(phase);
/*     */     }
/*  75 */     return phases;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TokenInfo buildTokenInfo(NamedList<Object> tokenNL)
/*     */   {
/*  98 */     String text = (String)tokenNL.get("text");
/*  99 */     String rawText = (String)tokenNL.get("rawText");
/* 100 */     String type = (String)tokenNL.get("type");
/* 101 */     int start = ((Integer)tokenNL.get("start")).intValue();
/* 102 */     int end = ((Integer)tokenNL.get("end")).intValue();
/* 103 */     int position = ((Integer)tokenNL.get("position")).intValue();
/* 104 */     Boolean match = (Boolean)tokenNL.get("match");
/* 105 */     return new TokenInfo(text, rawText, type, start, end, position, match == null ? false : match.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AnalysisPhase
/*     */   {
/*     */     private final String className;
/*     */     
/*     */ 
/*     */ 
/* 118 */     private List<AnalysisResponseBase.TokenInfo> tokens = new ArrayList();
/*     */     
/*     */     AnalysisPhase(String className) {
/* 121 */       this.className = className;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getClassName()
/*     */     {
/* 130 */       return this.className;
/*     */     }
/*     */     
/*     */     private void addTokenInfo(AnalysisResponseBase.TokenInfo tokenInfo) {
/* 134 */       this.tokens.add(tokenInfo);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<AnalysisResponseBase.TokenInfo> getTokens()
/*     */     {
/* 143 */       return this.tokens;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class TokenInfo
/*     */   {
/*     */     private final String text;
/*     */     
/*     */ 
/*     */     private final String rawText;
/*     */     
/*     */ 
/*     */     private final String type;
/*     */     
/*     */ 
/*     */     private final int start;
/*     */     
/*     */ 
/*     */     private final int end;
/*     */     
/*     */ 
/*     */     private final int position;
/*     */     
/*     */ 
/*     */     private final boolean match;
/*     */     
/*     */ 
/*     */ 
/*     */     TokenInfo(String text, String rawText, String type, int start, int end, int position, boolean match)
/*     */     {
/* 176 */       this.text = text;
/* 177 */       this.rawText = rawText;
/* 178 */       this.type = type;
/* 179 */       this.start = start;
/* 180 */       this.end = end;
/* 181 */       this.position = position;
/* 182 */       this.match = match;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getText()
/*     */     {
/* 191 */       return this.text;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getRawText()
/*     */     {
/* 201 */       return this.rawText;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getType()
/*     */     {
/* 211 */       return this.type;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStart()
/*     */     {
/* 220 */       return this.start;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEnd()
/*     */     {
/* 229 */       return this.end;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getPosition()
/*     */     {
/* 238 */       return this.position;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isMatch()
/*     */     {
/* 247 */       return this.match;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\AnalysisResponseBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */