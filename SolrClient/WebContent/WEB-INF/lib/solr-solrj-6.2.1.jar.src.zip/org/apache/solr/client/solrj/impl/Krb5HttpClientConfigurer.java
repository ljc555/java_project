/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.IOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpEntityEnclosingRequest;
/*     */ import org.apache.http.HttpException;
/*     */ import org.apache.http.HttpRequest;
/*     */ import org.apache.http.HttpRequestInterceptor;
/*     */ import org.apache.http.auth.AuthSchemeRegistry;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.Credentials;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.cookie.CookieSpecRegistry;
/*     */ import org.apache.http.entity.BufferedHttpEntity;
/*     */ import org.apache.http.impl.auth.SPNegoSchemeFactory;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Krb5HttpClientConfigurer
/*     */   extends HttpClientConfigurer
/*     */ {
/*     */   public static final String LOGIN_CONFIG_PROP = "java.security.auth.login.config";
/*  55 */   private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*  57 */   private static Configuration jaasConfig = new SolrJaasConfiguration();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @VisibleForTesting
/*     */   public static void regenerateJaasConfiguration()
/*     */   {
/*  65 */     jaasConfig = new SolrJaasConfiguration();
/*     */   }
/*     */   
/*     */   public void configure(DefaultHttpClient httpClient, SolrParams config) {
/*  69 */     super.configure(httpClient, config);
/*     */     
/*  71 */     if (System.getProperty("java.security.auth.login.config") != null) {
/*  72 */       String configValue = System.getProperty("java.security.auth.login.config");
/*     */       
/*  74 */       if (configValue != null) {
/*  75 */         logger.info("Setting up SPNego auth with config: " + configValue);
/*  76 */         String useSubjectCredsProp = "javax.security.auth.useSubjectCredsOnly";
/*  77 */         String useSubjectCredsVal = System.getProperty("javax.security.auth.useSubjectCredsOnly");
/*     */         
/*     */ 
/*     */ 
/*  81 */         if (useSubjectCredsVal == null) {
/*  82 */           System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
/*     */         }
/*  84 */         else if (!useSubjectCredsVal.toLowerCase(Locale.ROOT).equals("false"))
/*     */         {
/*     */ 
/*  87 */           logger.warn("System Property: javax.security.auth.useSubjectCredsOnly set to: " + useSubjectCredsVal + " not false.  SPNego authentication may not be successful.");
/*     */         }
/*     */         
/*     */ 
/*  91 */         Configuration.setConfiguration(jaasConfig);
/*     */         
/*  93 */         AuthSchemeRegistry registry = new AuthSchemeRegistry();
/*  94 */         registry.register("Negotiate", new SPNegoSchemeFactory(true, false));
/*  95 */         httpClient.setAuthSchemes(registry);
/*     */         
/*  97 */         Credentials useJaasCreds = new Credentials() {
/*     */           public String getPassword() {
/*  99 */             return null;
/*     */           }
/*     */           
/* 102 */           public Principal getUserPrincipal() { return null;
/*     */           }
/*     */ 
/* 105 */         };
/* 106 */         SolrPortAwareCookieSpecFactory cookieFactory = new SolrPortAwareCookieSpecFactory();
/* 107 */         httpClient.getCookieSpecs().register("solr-portaware", cookieFactory);
/* 108 */         httpClient.getParams().setParameter("http.protocol.cookie-policy", "solr-portaware");
/*     */         
/* 110 */         httpClient.getCredentialsProvider().setCredentials(AuthScope.ANY, useJaasCreds);
/*     */         
/* 112 */         httpClient.addRequestInterceptor(this.bufferedEntityInterceptor);
/*     */       } else {
/* 114 */         httpClient.getCredentialsProvider().clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 120 */   private HttpRequestInterceptor bufferedEntityInterceptor = new HttpRequestInterceptor()
/*     */   {
/*     */     public void process(HttpRequest request, HttpContext context) throws HttpException, IOException
/*     */     {
/* 124 */       if ((request instanceof HttpEntityEnclosingRequest)) {
/* 125 */         HttpEntityEnclosingRequest enclosingRequest = (HttpEntityEnclosingRequest)request;
/* 126 */         HttpEntity requestEntity = enclosingRequest.getEntity();
/* 127 */         enclosingRequest.setEntity(new BufferedHttpEntity(requestEntity));
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   private static class SolrJaasConfiguration
/*     */     extends Configuration
/*     */   {
/*     */     private Configuration baseConfig;
/* 137 */     private Set<String> initiateAppNames = new HashSet(
/* 138 */       Arrays.asList(new String[] { "com.sun.security.jgss.krb5.initiate", "com.sun.security.jgss.initiate" }));
/*     */     
/*     */     public SolrJaasConfiguration()
/*     */     {
/*     */       try {
/* 143 */         this.baseConfig = Configuration.getConfiguration();
/*     */       } catch (SecurityException e) {
/* 145 */         this.baseConfig = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public AppConfigurationEntry[] getAppConfigurationEntry(String appName)
/*     */     {
/* 151 */       if (this.baseConfig == null) { return null;
/*     */       }
/* 153 */       Krb5HttpClientConfigurer.logger.debug("Login prop: " + System.getProperty("java.security.auth.login.config"));
/*     */       
/* 155 */       String clientAppName = System.getProperty("solr.kerberos.jaas.appname", "Client");
/* 156 */       if (this.initiateAppNames.contains(appName)) {
/* 157 */         Krb5HttpClientConfigurer.logger.debug("Using AppConfigurationEntry for appName '" + clientAppName + "' instead of: " + appName);
/* 158 */         return this.baseConfig.getAppConfigurationEntry(clientAppName);
/*     */       }
/* 160 */       return this.baseConfig.getAppConfigurationEntry(appName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\Krb5HttpClientConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */