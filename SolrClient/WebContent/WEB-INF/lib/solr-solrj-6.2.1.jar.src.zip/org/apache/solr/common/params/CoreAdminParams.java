/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CoreAdminParams
/*     */ {
/*     */   public static final String CORE = "core";
/*     */   public static final String INDEX_INFO = "indexInfo";
/*     */   public static final String NAME = "name";
/*     */   public static final String DATA_DIR = "dataDir";
/*     */   public static final String ULOG_DIR = "ulogDir";
/*     */   public static final String OTHER = "other";
/*     */   public static final String ACTION = "action";
/*     */   public static final String SCHEMA = "schema";
/*     */   public static final String CONFIGSET = "configSet";
/*     */   public static final String CONFIG = "config";
/*     */   public static final String INSTANCE_DIR = "instanceDir";
/*     */   public static final String FILE = "file";
/*     */   public static final String INDEX_DIR = "indexDir";
/*     */   public static final String SRC_CORE = "srcCore";
/*     */   public static final String COLLECTION = "collection";
/*     */   public static final String REPLICA = "replica";
/*     */   public static final String SHARD = "shard";
/*     */   public static final String TARGET_CORE = "targetCore";
/*     */   public static final String RANGES = "ranges";
/*     */   public static final String ROLES = "roles";
/*     */   public static final String REQUESTID = "requestid";
/*     */   public static final String CORE_NODE_NAME = "coreNodeName";
/*     */   public static final String PROPERTY_PREFIX = "property.";
/*     */   public static final String DELETE_INDEX = "deleteIndex";
/*     */   public static final String DELETE_DATA_DIR = "deleteDataDir";
/*     */   public static final String DELETE_INSTANCE_DIR = "deleteInstanceDir";
/*     */   public static final String LOAD_ON_STARTUP = "loadOnStartup";
/*     */   public static final String TRANSIENT = "transient";
/*     */   public static final String NODE = "node";
/*     */   public static final String BACKUP_REPOSITORY = "repository";
/*     */   public static final String BACKUP_LOCATION = "location";
/*     */   public static final String COMMIT_NAME = "commitName";
/*     */   
/*     */   public static enum CoreAdminAction
/*     */   {
/* 127 */     STATUS(true), 
/* 128 */     UNLOAD, 
/* 129 */     RELOAD, 
/* 130 */     CREATE, 
/* 131 */     SWAP, 
/* 132 */     RENAME, 
/* 133 */     MERGEINDEXES, 
/* 134 */     SPLIT, 
/* 135 */     PREPRECOVERY, 
/* 136 */     REQUESTRECOVERY, 
/* 137 */     REQUESTSYNCSHARD, 
/* 138 */     DELETEALIAS, 
/* 139 */     REQUESTBUFFERUPDATES, 
/* 140 */     REQUESTAPPLYUPDATES, 
/* 141 */     OVERSEEROP, 
/* 142 */     REQUESTSTATUS(true), 
/* 143 */     REJOINLEADERELECTION, 
/*     */     
/* 145 */     FORCEPREPAREFORLEADERSHIP, 
/* 146 */     INVOKE, 
/*     */     
/* 148 */     BACKUPCORE, 
/* 149 */     RESTORECORE, 
/* 150 */     CREATESNAPSHOT, 
/* 151 */     DELETESNAPSHOT, 
/* 152 */     LISTSNAPSHOTS;
/*     */     
/*     */     public final boolean isRead;
/*     */     
/*     */     private CoreAdminAction(boolean isRead) {
/* 157 */       this.isRead = isRead;
/*     */     }
/*     */     
/*     */     private CoreAdminAction() {
/* 161 */       this.isRead = false;
/*     */     }
/*     */     
/*     */     public static CoreAdminAction get(String p) {
/* 165 */       if (p != null) {
/*     */         try {
/* 167 */           return valueOf(p.toUpperCase(Locale.ROOT));
/*     */         } catch (IllegalArgumentException e) {
/* 169 */           throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Wrong core admin action");
/*     */         }
/*     */       }
/* 172 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\CoreAdminParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */