/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastOutputStream
/*     */   extends OutputStream
/*     */   implements DataOutput
/*     */ {
/*     */   protected final OutputStream out;
/*     */   protected byte[] buf;
/*     */   protected long written;
/*     */   protected int pos;
/*     */   
/*     */   public FastOutputStream(OutputStream w)
/*     */   {
/*  33 */     this(w, new byte[' '], 0);
/*     */   }
/*     */   
/*     */   public FastOutputStream(OutputStream sink, byte[] tempBuffer, int start) {
/*  37 */     this.out = sink;
/*  38 */     this.buf = tempBuffer;
/*  39 */     this.pos = start;
/*     */   }
/*     */   
/*     */   public static FastOutputStream wrap(OutputStream sink)
/*     */   {
/*  44 */     return (sink instanceof FastOutputStream) ? (FastOutputStream)sink : new FastOutputStream(sink);
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException
/*     */   {
/*  49 */     write((byte)b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b) throws IOException
/*     */   {
/*  54 */     write(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public void write(byte b) throws IOException {
/*  58 */     if (this.pos >= this.buf.length) {
/*  59 */       this.written += this.pos;
/*  60 */       flush(this.buf, 0, this.buf.length);
/*  61 */       this.pos = 0;
/*     */     }
/*  63 */     this.buf[(this.pos++)] = b;
/*     */   }
/*     */   
/*     */   public void write(byte[] arr, int off, int len) throws IOException
/*     */   {
/*     */     for (;;)
/*     */     {
/*  70 */       int space = this.buf.length - this.pos;
/*     */       
/*  72 */       if (len <= space) {
/*  73 */         System.arraycopy(arr, off, this.buf, this.pos, len);
/*  74 */         this.pos += len;
/*  75 */         return; }
/*  76 */       if (len > this.buf.length) {
/*  77 */         if (this.pos > 0) {
/*  78 */           flush(this.buf, 0, this.pos);
/*  79 */           this.written += this.pos;
/*  80 */           this.pos = 0;
/*     */         }
/*     */         
/*  83 */         flush(arr, off, len);
/*  84 */         this.written += len;
/*  85 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */       System.arraycopy(arr, off, this.buf, this.pos, space);
/*  93 */       this.written += this.buf.length;
/*  94 */       flush(this.buf, 0, this.buf.length);
/*  95 */       this.pos = 0;
/*  96 */       off += space;
/*  97 */       len -= space;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reserve(int len)
/*     */     throws IOException
/*     */   {
/* 106 */     if (len > this.buf.length - this.pos) {
/* 107 */       flushBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException
/*     */   {
/* 113 */     write(v ? 1 : 0);
/*     */   }
/*     */   
/*     */   public void writeByte(int v) throws IOException
/*     */   {
/* 118 */     write((byte)v);
/*     */   }
/*     */   
/*     */   public void writeShort(int v) throws IOException
/*     */   {
/* 123 */     write((byte)(v >>> 8));
/* 124 */     write((byte)v);
/*     */   }
/*     */   
/*     */   public void writeChar(int v) throws IOException
/*     */   {
/* 129 */     writeShort(v);
/*     */   }
/*     */   
/*     */   public void writeInt(int v) throws IOException
/*     */   {
/* 134 */     reserve(4);
/* 135 */     this.buf[this.pos] = ((byte)(v >>> 24));
/* 136 */     this.buf[(this.pos + 1)] = ((byte)(v >>> 16));
/* 137 */     this.buf[(this.pos + 2)] = ((byte)(v >>> 8));
/* 138 */     this.buf[(this.pos + 3)] = ((byte)v);
/* 139 */     this.pos += 4;
/*     */   }
/*     */   
/*     */   public void writeLong(long v) throws IOException
/*     */   {
/* 144 */     reserve(8);
/* 145 */     this.buf[this.pos] = ((byte)(int)(v >>> 56));
/* 146 */     this.buf[(this.pos + 1)] = ((byte)(int)(v >>> 48));
/* 147 */     this.buf[(this.pos + 2)] = ((byte)(int)(v >>> 40));
/* 148 */     this.buf[(this.pos + 3)] = ((byte)(int)(v >>> 32));
/* 149 */     this.buf[(this.pos + 4)] = ((byte)(int)(v >>> 24));
/* 150 */     this.buf[(this.pos + 5)] = ((byte)(int)(v >>> 16));
/* 151 */     this.buf[(this.pos + 6)] = ((byte)(int)(v >>> 8));
/* 152 */     this.buf[(this.pos + 7)] = ((byte)(int)v);
/* 153 */     this.pos += 8;
/*     */   }
/*     */   
/*     */   public void writeFloat(float v) throws IOException
/*     */   {
/* 158 */     writeInt(Float.floatToRawIntBits(v));
/*     */   }
/*     */   
/*     */   public void writeDouble(double v) throws IOException
/*     */   {
/* 163 */     writeLong(Double.doubleToRawLongBits(v));
/*     */   }
/*     */   
/*     */   public void writeBytes(String s)
/*     */     throws IOException
/*     */   {
/* 169 */     for (int i = 0; i < s.length(); i++) {
/* 170 */       write((byte)s.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeChars(String s) throws IOException
/*     */   {
/* 176 */     for (int i = 0; i < s.length(); i++) {
/* 177 */       writeChar(s.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUTF(String s) throws IOException
/*     */   {
/* 183 */     DataOutputStream daos = new DataOutputStream(this);
/* 184 */     daos.writeUTF(s);
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 190 */     flushBuffer();
/* 191 */     if (this.out != null) this.out.flush();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 196 */     flushBuffer();
/* 197 */     if (this.out != null) { this.out.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void flushBuffer()
/*     */     throws IOException
/*     */   {
/* 204 */     if (this.pos > 0) {
/* 205 */       this.written += this.pos;
/* 206 */       flush(this.buf, 0, this.pos);
/* 207 */       this.pos = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush(byte[] buf, int offset, int len) throws IOException
/*     */   {
/* 213 */     this.out.write(buf, offset, len);
/*     */   }
/*     */   
/*     */   public long size() {
/* 217 */     return this.written + this.pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long written()
/*     */   {
/* 224 */     return this.written;
/*     */   }
/*     */   
/*     */   public void setWritten(long written)
/*     */   {
/* 229 */     this.written = written;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\FastOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */