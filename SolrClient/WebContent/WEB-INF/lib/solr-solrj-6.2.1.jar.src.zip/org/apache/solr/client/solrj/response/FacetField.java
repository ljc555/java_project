/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.util.ClientUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FacetField
/*     */   implements Serializable
/*     */ {
/*     */   public static class Count
/*     */     implements Serializable
/*     */   {
/*  36 */     private String _name = null;
/*  37 */     private long _count = 0L;
/*     */     
/*  39 */     private FacetField _ff = null;
/*     */     
/*     */     public Count(FacetField ff, String n, long c)
/*     */     {
/*  43 */       this._name = n;
/*  44 */       this._count = c;
/*  45 */       this._ff = ff;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  49 */       return this._name;
/*     */     }
/*     */     
/*     */     public void setName(String n)
/*     */     {
/*  54 */       this._name = n;
/*     */     }
/*     */     
/*     */     public long getCount() {
/*  58 */       return this._count;
/*     */     }
/*     */     
/*     */     public void setCount(long c)
/*     */     {
/*  63 */       this._count = c;
/*     */     }
/*     */     
/*     */     public FacetField getFacetField() {
/*  67 */       return this._ff;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  73 */       return this._name + " (" + this._count + ")";
/*     */     }
/*     */     
/*     */     public String getAsFilterQuery() {
/*  77 */       if (this._ff.getName().equals("facet_queries")) {
/*  78 */         return this._name;
/*     */       }
/*  80 */       return 
/*     */       
/*  82 */         ClientUtils.escapeQueryChars(this._ff._name) + ":" + ClientUtils.escapeQueryChars(this._name);
/*     */     }
/*     */   }
/*     */   
/*  86 */   private String _name = null;
/*  87 */   private List<Count> _values = null;
/*     */   
/*     */   public FacetField(String n)
/*     */   {
/*  91 */     this._name = n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(String name, long cnt)
/*     */   {
/*  99 */     if (this._values == null) {
/* 100 */       this._values = new ArrayList(30);
/*     */     }
/* 102 */     this._values.add(new Count(this, name, cnt));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(String name, long cnt)
/*     */   {
/* 110 */     if (this._values == null) {
/* 111 */       this._values = new ArrayList(30);
/*     */     }
/* 113 */     this._values.add(0, new Count(this, name, cnt));
/*     */   }
/*     */   
/*     */   public String getName() {
/* 117 */     return this._name;
/*     */   }
/*     */   
/*     */   public List<Count> getValues() {
/* 121 */     return this._values == null ? Collections.emptyList() : this._values;
/*     */   }
/*     */   
/*     */   public int getValueCount()
/*     */   {
/* 126 */     return this._values == null ? 0 : this._values.size();
/*     */   }
/*     */   
/*     */   public FacetField getLimitingFields(long max)
/*     */   {
/* 131 */     FacetField ff = new FacetField(this._name);
/* 132 */     if (this._values != null) {
/* 133 */       ff._values = new ArrayList(this._values.size());
/* 134 */       for (Count c : this._values) {
/* 135 */         if (c._count < max) {
/* 136 */           ff._values.add(c);
/*     */         }
/*     */       }
/*     */     }
/* 140 */     return ff;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 146 */     return this._name + ":" + this._values;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\FacetField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */