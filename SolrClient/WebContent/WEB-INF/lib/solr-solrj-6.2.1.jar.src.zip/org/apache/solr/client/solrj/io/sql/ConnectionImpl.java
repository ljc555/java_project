/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.NClob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Struct;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectionImpl
/*     */   implements Connection
/*     */ {
/*     */   private final String url;
/*  46 */   private final SolrClientCache solrClientCache = new SolrClientCache();
/*     */   private final CloudSolrClient client;
/*     */   private final Properties properties;
/*     */   private final DatabaseMetaData databaseMetaData;
/*     */   private final Statement connectionStatement;
/*     */   private String collection;
/*     */   private boolean closed;
/*     */   private SQLWarning currentWarning;
/*     */   
/*     */   ConnectionImpl(String url, String zkHost, String collection, Properties properties) throws SQLException {
/*  56 */     this.url = url;
/*  57 */     this.client = this.solrClientCache.getCloudSolrClient(zkHost);
/*  58 */     this.collection = collection;
/*  59 */     this.properties = properties;
/*  60 */     this.connectionStatement = createStatement();
/*  61 */     this.databaseMetaData = new DatabaseMetaDataImpl(this, this.connectionStatement);
/*     */   }
/*     */   
/*     */   String getUrl() {
/*  65 */     return this.url;
/*     */   }
/*     */   
/*     */   CloudSolrClient getClient() {
/*  69 */     return this.client;
/*     */   }
/*     */   
/*     */   String getCollection() {
/*  73 */     return this.collection;
/*     */   }
/*     */   
/*     */   Properties getProperties() {
/*  77 */     return this.properties;
/*     */   }
/*     */   
/*     */   SolrClientCache getSolrClientCache() {
/*  81 */     return this.solrClientCache;
/*     */   }
/*     */   
/*     */   public Statement createStatement() throws SQLException
/*     */   {
/*  86 */     return new StatementImpl(this);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLException
/*     */   {
/*  91 */     return new PreparedStatementImpl(this, sql);
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String sql) throws SQLException
/*     */   {
/*  96 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String nativeSQL(String sql) throws SQLException
/*     */   {
/* 101 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 111 */     return false;
/*     */   }
/*     */   
/*     */   public void commit()
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public void rollback()
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   /* Error */
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 21	org/apache/solr/client/solrj/io/sql/ConnectionImpl:closed	Z
/*     */     //   4: ifeq +4 -> 8
/*     */     //   7: return
/*     */     //   8: aload_0
/*     */     //   9: iconst_1
/*     */     //   10: putfield 21	org/apache/solr/client/solrj/io/sql/ConnectionImpl:closed	Z
/*     */     //   13: aload_0
/*     */     //   14: getfield 11	org/apache/solr/client/solrj/io/sql/ConnectionImpl:connectionStatement	Ljava/sql/Statement;
/*     */     //   17: ifnull +12 -> 29
/*     */     //   20: aload_0
/*     */     //   21: getfield 11	org/apache/solr/client/solrj/io/sql/ConnectionImpl:connectionStatement	Ljava/sql/Statement;
/*     */     //   24: invokeinterface 22 1 0
/*     */     //   29: aload_0
/*     */     //   30: getfield 4	org/apache/solr/client/solrj/io/sql/ConnectionImpl:solrClientCache	Lorg/apache/solr/client/solrj/io/SolrClientCache;
/*     */     //   33: ifnull +30 -> 63
/*     */     //   36: aload_0
/*     */     //   37: getfield 4	org/apache/solr/client/solrj/io/sql/ConnectionImpl:solrClientCache	Lorg/apache/solr/client/solrj/io/SolrClientCache;
/*     */     //   40: invokevirtual 23	org/apache/solr/client/solrj/io/SolrClientCache:close	()V
/*     */     //   43: goto +20 -> 63
/*     */     //   46: astore_1
/*     */     //   47: aload_0
/*     */     //   48: getfield 4	org/apache/solr/client/solrj/io/sql/ConnectionImpl:solrClientCache	Lorg/apache/solr/client/solrj/io/SolrClientCache;
/*     */     //   51: ifnull +10 -> 61
/*     */     //   54: aload_0
/*     */     //   55: getfield 4	org/apache/solr/client/solrj/io/sql/ConnectionImpl:solrClientCache	Lorg/apache/solr/client/solrj/io/SolrClientCache;
/*     */     //   58: invokevirtual 23	org/apache/solr/client/solrj/io/SolrClientCache:close	()V
/*     */     //   61: aload_1
/*     */     //   62: athrow
/*     */     //   63: return
/*     */     // Line number table:
/*     */     //   Java source line #126	-> byte code offset #0
/*     */     //   Java source line #127	-> byte code offset #7
/*     */     //   Java source line #130	-> byte code offset #8
/*     */     //   Java source line #133	-> byte code offset #13
/*     */     //   Java source line #134	-> byte code offset #20
/*     */     //   Java source line #137	-> byte code offset #29
/*     */     //   Java source line #138	-> byte code offset #36
/*     */     //   Java source line #137	-> byte code offset #46
/*     */     //   Java source line #138	-> byte code offset #54
/*     */     //   Java source line #141	-> byte code offset #63
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	64	0	this	ConnectionImpl
/*     */     //   46	16	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   13	29	46	finally
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 145 */     return this.closed;
/*     */   }
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLException
/*     */   {
/* 150 */     return this.databaseMetaData;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 160 */     return true;
/*     */   }
/*     */   
/*     */   public void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 170 */     return this.client.getZkHost();
/*     */   }
/*     */   
/*     */   public void setTransactionIsolation(int level) throws SQLException
/*     */   {
/* 175 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getTransactionIsolation() throws SQLException
/*     */   {
/* 180 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException
/*     */   {
/* 185 */     if (isClosed()) {
/* 186 */       throw new SQLException("Connection is closed.");
/*     */     }
/*     */     
/* 189 */     return this.currentWarning;
/*     */   }
/*     */   
/*     */   public void clearWarnings() throws SQLException
/*     */   {
/* 194 */     if (isClosed()) {
/* 195 */       throw new SQLException("Connection is closed.");
/*     */     }
/*     */     
/* 198 */     this.currentWarning = null;
/*     */   }
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException
/*     */   {
/* 203 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
/*     */   {
/* 208 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException
/*     */   {
/* 213 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLException
/*     */   {
/* 218 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException
/*     */   {
/* 223 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setHoldability(int holdability) throws SQLException
/*     */   {
/* 228 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getHoldability() throws SQLException
/*     */   {
/* 233 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint() throws SQLException
/*     */   {
/* 238 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint(String name) throws SQLException
/*     */   {
/* 243 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void rollback(Savepoint savepoint) throws SQLException
/*     */   {
/* 248 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void releaseSavepoint(Savepoint savepoint) throws SQLException
/*     */   {
/* 253 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*     */   {
/* 258 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*     */   {
/* 263 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*     */   {
/* 268 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 273 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 278 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 283 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Clob createClob() throws SQLException
/*     */   {
/* 288 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Blob createBlob() throws SQLException
/*     */   {
/* 293 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public NClob createNClob() throws SQLException
/*     */   {
/* 298 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public SQLXML createSQLXML() throws SQLException
/*     */   {
/* 303 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isValid(int timeout) throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 310 */       if (!isClosed()) {
/* 311 */         this.client.connect(timeout, TimeUnit.SECONDS);
/* 312 */         return true;
/*     */       }
/*     */     }
/*     */     catch (InterruptedException|TimeoutException localInterruptedException) {}
/*     */     
/* 317 */     return false;
/*     */   }
/*     */   
/*     */   public void setClientInfo(String name, String value) throws SQLClientInfoException
/*     */   {
/* 322 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setClientInfo(Properties properties) throws SQLClientInfoException
/*     */   {
/* 327 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String getClientInfo(String name) throws SQLException
/*     */   {
/* 332 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Properties getClientInfo() throws SQLException
/*     */   {
/* 337 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException
/*     */   {
/* 342 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException
/*     */   {
/* 347 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setSchema(String schema)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public String getSchema()
/*     */     throws SQLException
/*     */   {
/* 357 */     return null;
/*     */   }
/*     */   
/*     */   public void abort(Executor executor) throws SQLException
/*     */   {
/* 362 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException
/*     */   {
/* 367 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getNetworkTimeout() throws SQLException
/*     */   {
/* 372 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException
/*     */   {
/* 377 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*     */   {
/* 382 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\ConnectionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */