/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxMetric
/*    */   extends Metric
/*    */ {
/* 28 */   private long longMax = Long.MIN_VALUE;
/* 29 */   private double doubleMax = -1.7976931348623157E308D;
/*    */   private String columnName;
/*    */   
/*    */   public MaxMetric(String columnName) {
/* 33 */     init("max", columnName);
/*    */   }
/*    */   
/*    */   public MaxMetric(StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 38 */     String functionName = expression.getFunctionName();
/* 39 */     String columnName = factory.getValueOperand(expression, 0);
/*    */     
/*    */ 
/* 42 */     if (null == columnName) {
/* 43 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expected %s(columnName)", new Object[] { expression, functionName }));
/*    */     }
/* 45 */     if (1 != expression.getParameters().size()) {
/* 46 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*    */     }
/*    */     
/* 49 */     init(functionName, columnName);
/*    */   }
/*    */   
/*    */   private void init(String functionName, String columnName) {
/* 53 */     this.columnName = columnName;
/* 54 */     setFunctionName(functionName);
/* 55 */     setIdentifier(new String[] { functionName, "(", columnName, ")" });
/*    */   }
/*    */   
/*    */   public Number getValue() {
/* 59 */     if (this.longMax == Long.MIN_VALUE) {
/* 60 */       return Double.valueOf(this.doubleMax);
/*    */     }
/* 62 */     return Long.valueOf(this.longMax);
/*    */   }
/*    */   
/*    */   public String[] getColumns()
/*    */   {
/* 67 */     return new String[] { this.columnName };
/*    */   }
/*    */   
/*    */   public void update(Tuple tuple) {
/* 71 */     Object o = tuple.get(this.columnName);
/* 72 */     if ((o instanceof Double)) {
/* 73 */       double d = ((Double)o).doubleValue();
/* 74 */       if (d > this.doubleMax) {
/* 75 */         this.doubleMax = d;
/*    */       }
/*    */     } else {
/* 78 */       long l = ((Long)o).longValue();
/* 79 */       if (l > this.longMax) {
/* 80 */         this.longMax = l;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Metric newInstance() {
/* 86 */     return new MaxMetric(this.columnName);
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*    */   {
/* 91 */     return new StreamExpression(getFunctionName()).withParameter(this.columnName);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\MaxMetric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */