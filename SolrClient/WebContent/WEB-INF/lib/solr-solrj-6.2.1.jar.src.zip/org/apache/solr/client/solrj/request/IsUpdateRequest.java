package org.apache.solr.client.solrj.request;

public abstract interface IsUpdateRequest {}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\IsUpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */