/*    */ package org.apache.solr.client.solrj.request.schema;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import org.apache.solr.client.solrj.SolrRequest;
/*    */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*    */ import org.apache.solr.client.solrj.SolrResponse;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ import org.apache.solr.common.util.ContentStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSchemaRequest<T extends SolrResponse>
/*    */   extends SolrRequest<T>
/*    */ {
/* 28 */   private SolrParams params = null;
/*    */   
/*    */   public AbstractSchemaRequest(SolrRequest.METHOD m, String path) {
/* 31 */     super(m, path);
/*    */   }
/*    */   
/*    */   public AbstractSchemaRequest(SolrRequest.METHOD m, String path, SolrParams params) {
/* 35 */     this(m, path);
/*    */   }
/*    */   
/*    */ 
/*    */   public SolrParams getParams()
/*    */   {
/* 41 */     return this.params;
/*    */   }
/*    */   
/*    */   public Collection<ContentStream> getContentStreams() throws IOException
/*    */   {
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\schema\AbstractSchemaRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */