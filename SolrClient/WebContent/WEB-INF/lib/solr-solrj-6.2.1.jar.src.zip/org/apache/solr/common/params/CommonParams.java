/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface CommonParams
/*     */ {
/*     */   public static final String NOW = "NOW";
/*     */   public static final String TZ = "TZ";
/*     */   public static final String QT = "qt";
/*     */   public static final String WT = "wt";
/*     */   public static final String Q = "q";
/*     */   public static final String RQ = "rq";
/*     */   public static final String DISTRIB = "distrib";
/*     */   public static final String SORT = "sort";
/*     */   public static final String FQ = "fq";
/*     */   public static final String START = "start";
/*     */   public static final int START_DEFAULT = 0;
/*     */   public static final String ROWS = "rows";
/*     */   public static final int ROWS_DEFAULT = 10;
/*     */   public static final String PING_HANDLER = "/admin/ping";
/*     */   public static final String ACTION = "action";
/*     */   public static final String DISABLE = "disable";
/*     */   public static final String ENABLE = "enable";
/*     */   public static final String PING = "ping";
/*     */   public static final String XSL = "xsl";
/*     */   public static final String VERSION = "version";
/*     */   public static final String FL = "fl";
/*     */   public static final String DF = "df";
/*     */   public static final String TR = "tr";
/*     */   public static final String DEBUG_QUERY = "debugQuery";
/*     */   public static final String DEBUG = "debug";
/*     */   public static final String TIMING = "timing";
/*     */   public static final String RESULTS = "results";
/*     */   public static final String QUERY = "query";
/*     */   public static final String TRACK = "track";
/*     */   public static final String EXPLAIN_STRUCT = "debug.explain.structured";
/*     */   public static final String EXPLAIN_OTHER = "explainOther";
/*     */   public static final String STREAM_URL = "stream.url";
/*     */   public static final String STREAM_FILE = "stream.file";
/*     */   public static final String STREAM_BODY = "stream.body";
/*     */   public static final String STREAM_CONTENTTYPE = "stream.contentType";
/*     */   public static final String SEGMENT_TERMINATE_EARLY = "segmentTerminateEarly";
/*     */   public static final boolean SEGMENT_TERMINATE_EARLY_DEFAULT = false;
/*     */   public static final String TIME_ALLOWED = "timeAllowed";
/*     */   public static final String HEADER_ECHO_HANDLER = "echoHandler";
/*     */   public static final String HEADER_ECHO_PARAMS = "echoParams";
/*     */   public static final String OMIT_HEADER = "omitHeader";
/*     */   public static final String CORES_HANDLER_PATH = "/admin/cores";
/*     */   public static final String COLLECTIONS_HANDLER_PATH = "/admin/collections";
/*     */   public static final String INFO_HANDLER_PATH = "/admin/info";
/*     */   public static final String CONFIGSETS_HANDLER_PATH = "/admin/configs";
/*     */   public static final String AUTHZ_PATH = "/admin/authorization";
/*     */   public static final String AUTHC_PATH = "/admin/authentication";
/*     */   public static final String ZK_PATH = "/admin/zookeeper";
/* 184 */   public static final Set<String> ADMIN_PATHS = new HashSet(Arrays.asList(new String[] { "/admin/cores", "/admin/collections", "/admin/configs", "/admin/authentication", "/admin/authorization" }));
/*     */   
/*     */   public static final String LOG_PARAMS_LIST = "logParamsList";
/*     */   public static final String EXCLUDE = "ex";
/*     */   public static final String TAG = "tag";
/*     */   public static final String TERMS = "terms";
/*     */   
/*     */   public static enum EchoParamStyle
/*     */   {
/* 193 */     EXPLICIT, 
/* 194 */     ALL, 
/* 195 */     NONE;
/*     */     
/*     */     private EchoParamStyle() {}
/* 198 */     public static EchoParamStyle get(String v) { if (v != null) {
/* 199 */         v = v.toUpperCase(Locale.ROOT);
/* 200 */         if (v.equals("EXPLICIT")) {
/* 201 */           return EXPLICIT;
/*     */         }
/* 203 */         if (v.equals("ALL")) {
/* 204 */           return ALL;
/*     */         }
/* 206 */         if (v.equals("NONE")) {
/* 207 */           return NONE;
/*     */         }
/*     */       }
/* 210 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String OUTPUT_KEY = "key";
/*     */   
/*     */   public static final String FIELD = "f";
/*     */   
/*     */   public static final String VALUE = "v";
/*     */   
/*     */   public static final String THREADS = "threads";
/*     */   
/* 224 */   public static final String TRUE = Boolean.TRUE.toString();
/* 225 */   public static final String FALSE = Boolean.FALSE.toString();
/*     */   public static final String CACHE = "cache";
/*     */   public static final String COST = "cost";
/*     */   public static final String REQUEST_ID = "rid";
/*     */   public static final String REQUEST_PURPOSE = "requestPurpose";
/*     */   public static final String PREFER_LOCAL_SHARDS = "preferLocalShards";
/*     */   public static final String JAVABIN = "javabin";
/*     */   public static final String JSON = "json";
/*     */   public static final String PATH = "path";
/*     */   public static final String NAME = "name";
/*     */   public static final String VALUE_LONG = "val";
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\CommonParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */