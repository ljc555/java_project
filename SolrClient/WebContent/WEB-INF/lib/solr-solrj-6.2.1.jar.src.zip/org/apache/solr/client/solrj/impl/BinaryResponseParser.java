/*    */ package org.apache.solr.client.solrj.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.apache.solr.client.solrj.ResponseParser;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.util.JavaBinCodec;
/*    */ import org.apache.solr.common.util.JavaBinCodec.StringCache;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryResponseParser
/*    */   extends ResponseParser
/*    */ {
/*    */   public static final String BINARY_CONTENT_TYPE = "application/octet-stream";
/*    */   private JavaBinCodec.StringCache stringCache;
/*    */   
/*    */   public BinaryResponseParser setStringCache(JavaBinCodec.StringCache cache)
/*    */   {
/* 38 */     this.stringCache = cache;
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public String getWriterType()
/*    */   {
/* 44 */     return "javabin";
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(InputStream body, String encoding)
/*    */   {
/*    */     try {
/* 50 */       return (NamedList)new JavaBinCodec(null, this.stringCache).unmarshal(body);
/*    */     } catch (IOException e) {
/* 52 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getContentType()
/*    */   {
/* 59 */     return "application/octet-stream";
/*    */   }
/*    */   
/*    */   public String getVersion()
/*    */   {
/* 64 */     return "2";
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(Reader reader)
/*    */   {
/* 69 */     throw new RuntimeException("Cannot handle character stream");
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\BinaryResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */