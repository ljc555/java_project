/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.impl.NoOpResponseParser;
/*     */ import org.apache.solr.client.solrj.response.DelegationTokenResponse;
/*     */ import org.apache.solr.client.solrj.response.DelegationTokenResponse.Cancel;
/*     */ import org.apache.solr.client.solrj.response.DelegationTokenResponse.Get;
/*     */ import org.apache.solr.client.solrj.response.DelegationTokenResponse.JsonMapResponseParser;
/*     */ import org.apache.solr.client.solrj.response.DelegationTokenResponse.Renew;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DelegationTokenRequest<Q extends DelegationTokenRequest<Q, R>, R extends DelegationTokenResponse>
/*     */   extends SolrRequest<R>
/*     */ {
/*     */   protected static final String OP_KEY = "op";
/*     */   protected static final String TOKEN_KEY = "token";
/*     */   
/*     */   public DelegationTokenRequest(SolrRequest.METHOD m)
/*     */   {
/*  51 */     super(m, "/admin/collections");
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract Q getThis();
/*     */   
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */     throws IOException
/*     */   {
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   protected abstract R createResponse(SolrClient paramSolrClient);
/*     */   
/*     */   public static class Get extends DelegationTokenRequest<Get, DelegationTokenResponse.Get>
/*     */   {
/*     */     protected String renewer;
/*     */     
/*     */     public Get() {
/*  71 */       this(null);
/*     */     }
/*     */     
/*     */     public Get(String renewer) {
/*  75 */       super();
/*  76 */       this.renewer = renewer;
/*  77 */       setResponseParser(new DelegationTokenResponse.JsonMapResponseParser());
/*  78 */       setQueryParams(new TreeSet(Arrays.asList(new String[] { "op" })));
/*     */     }
/*     */     
/*     */     protected Get getThis()
/*     */     {
/*  83 */       return this;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/*  88 */       ModifiableSolrParams params = new ModifiableSolrParams();
/*  89 */       params.set("op", new String[] { "GETDELEGATIONTOKEN" });
/*  90 */       if (this.renewer != null) params.set("renewer", new String[] { this.renewer });
/*  91 */       return params;
/*     */     }
/*     */     
/*     */     public DelegationTokenResponse.Get createResponse(SolrClient client) {
/*  95 */       return new DelegationTokenResponse.Get();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Renew extends DelegationTokenRequest<Renew, DelegationTokenResponse.Renew> {
/*     */     protected String token;
/*     */     
/*     */     protected Renew getThis() {
/* 103 */       return this;
/*     */     }
/*     */     
/*     */     public Renew(String token) {
/* 107 */       super();
/* 108 */       this.token = token;
/* 109 */       setResponseParser(new DelegationTokenResponse.JsonMapResponseParser());
/* 110 */       setQueryParams(new TreeSet(Arrays.asList(new String[] { "op", "token" })));
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 115 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 116 */       params.set("op", new String[] { "RENEWDELEGATIONTOKEN" });
/* 117 */       params.set("token", new String[] { this.token });
/* 118 */       return params;
/*     */     }
/*     */     
/*     */ 
/* 122 */     public DelegationTokenResponse.Renew createResponse(SolrClient client) { return new DelegationTokenResponse.Renew(); }
/*     */   }
/*     */   
/*     */   public static class Cancel extends DelegationTokenRequest<Cancel, DelegationTokenResponse.Cancel> {
/*     */     protected String token;
/*     */     
/*     */     public Cancel(String token) {
/* 129 */       super();
/* 130 */       this.token = token;
/* 131 */       setResponseParser(new NoOpResponseParser());
/* 132 */       Set<String> queryParams = new TreeSet();
/* 133 */       setQueryParams(new TreeSet(Arrays.asList(new String[] { "op", "token" })));
/*     */     }
/*     */     
/*     */     protected Cancel getThis()
/*     */     {
/* 138 */       return this;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 143 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 144 */       params.set("op", new String[] { "CANCELDELEGATIONTOKEN" });
/* 145 */       params.set("token", new String[] { this.token });
/* 146 */       return params;
/*     */     }
/*     */     
/*     */     public DelegationTokenResponse.Cancel createResponse(SolrClient client) {
/* 150 */       return new DelegationTokenResponse.Cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\DelegationTokenRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */