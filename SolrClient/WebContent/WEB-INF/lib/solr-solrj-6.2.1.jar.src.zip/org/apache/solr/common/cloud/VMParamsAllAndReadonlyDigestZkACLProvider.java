/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.solr.common.StringUtils;
/*     */ import org.apache.zookeeper.ZooDefs.Ids;
/*     */ import org.apache.zookeeper.data.ACL;
/*     */ import org.apache.zookeeper.data.Id;
/*     */ import org.apache.zookeeper.server.auth.DigestAuthenticationProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VMParamsAllAndReadonlyDigestZkACLProvider
/*     */   extends SecurityAwareZkACLProvider
/*     */ {
/*     */   public static final String DEFAULT_DIGEST_READONLY_USERNAME_VM_PARAM_NAME = "zkDigestReadonlyUsername";
/*     */   public static final String DEFAULT_DIGEST_READONLY_PASSWORD_VM_PARAM_NAME = "zkDigestReadonlyPassword";
/*     */   final String zkDigestAllUsernameVMParamName;
/*     */   final String zkDigestAllPasswordVMParamName;
/*     */   final String zkDigestReadonlyUsernameVMParamName;
/*     */   final String zkDigestReadonlyPasswordVMParamName;
/*     */   
/*     */   public VMParamsAllAndReadonlyDigestZkACLProvider()
/*     */   {
/*  41 */     this("zkDigestUsername", "zkDigestPassword", "zkDigestReadonlyUsername", "zkDigestReadonlyPassword");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VMParamsAllAndReadonlyDigestZkACLProvider(String zkDigestAllUsernameVMParamName, String zkDigestAllPasswordVMParamName, String zkDigestReadonlyUsernameVMParamName, String zkDigestReadonlyPasswordVMParamName)
/*     */   {
/*  51 */     this.zkDigestAllUsernameVMParamName = zkDigestAllUsernameVMParamName;
/*  52 */     this.zkDigestAllPasswordVMParamName = zkDigestAllPasswordVMParamName;
/*  53 */     this.zkDigestReadonlyUsernameVMParamName = zkDigestReadonlyUsernameVMParamName;
/*  54 */     this.zkDigestReadonlyPasswordVMParamName = zkDigestReadonlyPasswordVMParamName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<ACL> createNonSecurityACLsToAdd()
/*     */   {
/*  62 */     return createACLsToAdd(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<ACL> createSecurityACLsToAdd()
/*     */   {
/*  70 */     return createACLsToAdd(false);
/*     */   }
/*     */   
/*     */   protected List<ACL> createACLsToAdd(boolean includeReadOnly) {
/*  74 */     String digestAllUsername = System.getProperty(this.zkDigestAllUsernameVMParamName);
/*  75 */     String digestAllPassword = System.getProperty(this.zkDigestAllPasswordVMParamName);
/*  76 */     String digestReadonlyUsername = System.getProperty(this.zkDigestReadonlyUsernameVMParamName);
/*  77 */     String digestReadonlyPassword = System.getProperty(this.zkDigestReadonlyPasswordVMParamName);
/*     */     
/*  79 */     return createACLsToAdd(includeReadOnly, digestAllUsername, digestAllPassword, digestReadonlyUsername, digestReadonlyPassword);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @VisibleForTesting
/*     */   protected List<ACL> createACLsToAdd(boolean includeReadOnly, String digestAllUsername, String digestAllPassword, String digestReadonlyUsername, String digestReadonlyPassword)
/*     */   {
/*     */     try
/*     */     {
/*  90 */       List<ACL> result = new ArrayList();
/*     */       
/*     */ 
/*     */ 
/*  94 */       if ((!StringUtils.isEmpty(digestAllUsername)) && (!StringUtils.isEmpty(digestAllPassword))) {
/*  95 */         result.add(new ACL(31, new Id("digest", DigestAuthenticationProvider.generateDigest(digestAllUsername + ":" + digestAllPassword))));
/*     */       }
/*     */       
/*  98 */       if (includeReadOnly)
/*     */       {
/* 100 */         if ((!StringUtils.isEmpty(digestReadonlyUsername)) && (!StringUtils.isEmpty(digestReadonlyPassword))) {
/* 101 */           result.add(new ACL(1, new Id("digest", DigestAuthenticationProvider.generateDigest(digestReadonlyUsername + ":" + digestReadonlyPassword))));
/*     */         }
/*     */       }
/*     */       
/* 105 */       if (result.isEmpty()) {}
/* 106 */       return ZooDefs.Ids.OPEN_ACL_UNSAFE;
/*     */ 
/*     */     }
/*     */     catch (NoSuchAlgorithmException e)
/*     */     {
/* 111 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\VMParamsAllAndReadonlyDigestZkACLProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */