/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.UpdateResponse;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUpdateRequest
/*     */   extends SolrRequest<UpdateResponse>
/*     */   implements IsUpdateRequest
/*     */ {
/*     */   protected ModifiableSolrParams params;
/*  31 */   protected int commitWithin = -1;
/*     */   
/*     */   public static enum ACTION {
/*  34 */     COMMIT, 
/*  35 */     OPTIMIZE;
/*     */     
/*     */     private ACTION() {} }
/*     */   
/*  39 */   public AbstractUpdateRequest(SolrRequest.METHOD m, String path) { super(m, path); }
/*     */   
/*     */ 
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher)
/*     */   {
/*  44 */     return setAction(action, waitFlush, waitSearcher, 1);
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, boolean softCommit) {
/*  48 */     return setAction(action, waitFlush, waitSearcher, softCommit, 1);
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, int maxSegments) {
/*  52 */     return setAction(action, waitFlush, waitSearcher, false, maxSegments);
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, boolean softCommit, int maxSegments) {
/*  56 */     if (this.params == null) {
/*  57 */       this.params = new ModifiableSolrParams();
/*     */     }
/*  59 */     if (action == ACTION.OPTIMIZE) {
/*  60 */       this.params.set("optimize", new String[] { "true" });
/*  61 */       this.params.set("maxSegments", maxSegments);
/*     */     }
/*  63 */     else if (action == ACTION.COMMIT) {
/*  64 */       this.params.set("commit", new String[] { "true" });
/*  65 */       this.params.set("softCommit", new String[] { String.valueOf(softCommit) });
/*     */     }
/*  67 */     this.params.set("waitSearcher", new String[] { String.valueOf(waitSearcher) });
/*  68 */     return this;
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, int maxSegments, boolean softCommit, boolean expungeDeletes) {
/*  72 */     setAction(action, waitFlush, waitSearcher, softCommit, maxSegments);
/*  73 */     this.params.set("expungeDeletes", new String[] { String.valueOf(expungeDeletes) });
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, int maxSegments, boolean expungeDeletes) {
/*  78 */     return setAction(action, waitFlush, waitSearcher, maxSegments, false, expungeDeletes);
/*     */   }
/*     */   
/*     */   public AbstractUpdateRequest setAction(ACTION action, boolean waitFlush, boolean waitSearcher, int maxSegments, boolean softCommit, boolean expungeDeletes, boolean openSearcher) {
/*  82 */     setAction(action, waitFlush, waitSearcher, maxSegments, softCommit, expungeDeletes);
/*  83 */     this.params.set("openSearcher", new String[] { String.valueOf(openSearcher) });
/*  84 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AbstractUpdateRequest rollback()
/*     */   {
/*  91 */     if (this.params == null) {
/*  92 */       this.params = new ModifiableSolrParams();
/*     */     }
/*  94 */     this.params.set("rollback", new String[] { "true" });
/*  95 */     return this;
/*     */   }
/*     */   
/*     */   public void setParam(String param, String value) {
/*  99 */     if (this.params == null)
/* 100 */       this.params = new ModifiableSolrParams();
/* 101 */     this.params.set(param, new String[] { value });
/*     */   }
/*     */   
/*     */   public void setParams(ModifiableSolrParams params)
/*     */   {
/* 106 */     this.params = params;
/*     */   }
/*     */   
/*     */   public ModifiableSolrParams getParams()
/*     */   {
/* 111 */     return this.params;
/*     */   }
/*     */   
/*     */   protected UpdateResponse createResponse(SolrClient client)
/*     */   {
/* 116 */     return new UpdateResponse();
/*     */   }
/*     */   
/*     */   public boolean isWaitSearcher() {
/* 120 */     return (this.params != null) && (this.params.getBool("waitSearcher", false));
/*     */   }
/*     */   
/*     */   public ACTION getAction() {
/* 124 */     if (this.params == null) return null;
/* 125 */     if (this.params.getBool("commit", false)) return ACTION.COMMIT;
/* 126 */     if (this.params.getBool("optimize", false)) return ACTION.OPTIMIZE;
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   public void setWaitSearcher(boolean waitSearcher) {
/* 131 */     setParam("waitSearcher", waitSearcher + "");
/*     */   }
/*     */   
/*     */   public int getCommitWithin() {
/* 135 */     return this.commitWithin;
/*     */   }
/*     */   
/*     */   public void setCommitWithin(int commitWithin) {
/* 139 */     this.commitWithin = commitWithin;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\AbstractUpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */