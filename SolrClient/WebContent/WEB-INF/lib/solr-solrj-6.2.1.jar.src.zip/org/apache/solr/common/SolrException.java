/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.MDC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrException
/*     */   extends RuntimeException
/*     */ {
/*     */   public static final String ROOT_ERROR_CLASS = "root-error-class";
/*     */   public static final String ERROR_CLASS = "error-class";
/*     */   private final Map mdcContext;
/*     */   
/*     */   public static enum ErrorCode
/*     */   {
/*  45 */     BAD_REQUEST(400), 
/*  46 */     UNAUTHORIZED(401), 
/*  47 */     FORBIDDEN(403), 
/*  48 */     NOT_FOUND(404), 
/*  49 */     CONFLICT(409), 
/*  50 */     UNSUPPORTED_MEDIA_TYPE(415), 
/*  51 */     SERVER_ERROR(500), 
/*  52 */     SERVICE_UNAVAILABLE(503), 
/*  53 */     INVALID_STATE(510), 
/*  54 */     UNKNOWN(0);
/*     */     
/*     */ 
/*     */     public final int code;
/*     */     
/*  59 */     private ErrorCode(int c) { this.code = c; }
/*     */     
/*     */     public static ErrorCode getErrorCode(int c) {
/*  62 */       for (ErrorCode err : ) {
/*  63 */         if (err.code == c) return err;
/*     */       }
/*  65 */       return UNKNOWN;
/*     */     }
/*     */   }
/*     */   
/*     */   public SolrException(ErrorCode code, String msg) {
/*  70 */     super(msg);
/*  71 */     this.code = code.code;
/*  72 */     this.mdcContext = MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*  75 */   public SolrException(ErrorCode code, String msg, Throwable th) { super(msg, th);
/*  76 */     this.code = code.code;
/*  77 */     this.mdcContext = MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*     */   public SolrException(ErrorCode code, Throwable th) {
/*  81 */     super(th);
/*  82 */     this.code = code.code;
/*  83 */     this.mdcContext = MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SolrException(int code, String msg, Throwable th)
/*     */   {
/*  92 */     super(msg, th);
/*  93 */     this.code = code;
/*  94 */     this.mdcContext = MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*  97 */   int code = 0;
/*     */   
/*     */ 
/*     */   protected NamedList<String> metadata;
/*     */   
/*     */ 
/*     */   public static Set<String> ignorePatterns;
/*     */   
/*     */ 
/*     */ 
/*     */   public int code()
/*     */   {
/* 109 */     return this.code;
/*     */   }
/*     */   
/* 112 */   public void setMetadata(NamedList<String> metadata) { this.metadata = metadata; }
/*     */   
/*     */   public NamedList<String> getMetadata()
/*     */   {
/* 116 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public String getMetadata(String key) {
/* 120 */     return (this.metadata != null) && (key != null) ? (String)this.metadata.get(key) : null;
/*     */   }
/*     */   
/*     */   public void setMetadata(String key, String value) {
/* 124 */     if ((key == null) || (value == null)) {
/* 125 */       throw new IllegalArgumentException("Exception metadata cannot be null!");
/*     */     }
/* 127 */     if (this.metadata == null)
/* 128 */       this.metadata = new NamedList();
/* 129 */     this.metadata.add(key, value);
/*     */   }
/*     */   
/*     */   public String getThrowable() {
/* 133 */     return getMetadata("error-class");
/*     */   }
/*     */   
/*     */   public String getRootThrowable() {
/* 137 */     return getMetadata("root-error-class");
/*     */   }
/*     */   
/* 140 */   public void log(Logger log) { log(log, this); }
/*     */   
/* 142 */   public static void log(Logger log, Throwable e) { String stackTrace = toStr(e);
/* 143 */     String ignore = doIgnore(e, stackTrace);
/* 144 */     if (ignore != null) {
/* 145 */       log.info(ignore);
/* 146 */       return;
/*     */     }
/* 148 */     log.error(stackTrace);
/*     */   }
/*     */   
/*     */   public static void log(Logger log, String msg, Throwable e)
/*     */   {
/* 153 */     String stackTrace = msg + ':' + toStr(e);
/* 154 */     String ignore = doIgnore(e, stackTrace);
/* 155 */     if (ignore != null) {
/* 156 */       log.info(ignore);
/* 157 */       return;
/*     */     }
/* 159 */     log.error(stackTrace);
/*     */   }
/*     */   
/*     */   public static void log(Logger log, String msg) {
/* 163 */     String stackTrace = msg;
/* 164 */     String ignore = doIgnore(null, stackTrace);
/* 165 */     if (ignore != null) {
/* 166 */       log.info(ignore);
/* 167 */       return;
/*     */     }
/* 169 */     log.error(stackTrace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 174 */   public String toString() { return super.toString(); }
/*     */   
/*     */   public static String toStr(Throwable e) {
/* 177 */     CharArrayWriter cw = new CharArrayWriter();
/* 178 */     PrintWriter pw = new PrintWriter(cw);
/* 179 */     e.printStackTrace(pw);
/* 180 */     pw.flush();
/* 181 */     return cw.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String doIgnore(Throwable t, String m)
/*     */   {
/* 199 */     if ((ignorePatterns == null) || (m == null)) return null;
/* 200 */     if ((t != null) && ((t instanceof AssertionError))) { return null;
/*     */     }
/* 202 */     for (String regex : ignorePatterns) {
/* 203 */       Pattern pattern = Pattern.compile(regex);
/* 204 */       Matcher matcher = pattern.matcher(m);
/*     */       
/* 206 */       if (matcher.find()) { return "Ignoring exception matching " + regex;
/*     */       }
/*     */     }
/* 209 */     return null;
/*     */   }
/*     */   
/*     */   public static Throwable getRootCause(Throwable t) {
/*     */     for (;;) {
/* 214 */       Throwable cause = t.getCause();
/* 215 */       if (cause == null) break;
/* 216 */       t = cause;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 221 */     return t;
/*     */   }
/*     */   
/*     */   public void logInfoWithMdc(Logger logger, String msg) {
/* 225 */     Map previousMdcContext = MDC.getCopyOfContextMap();
/* 226 */     MDC.setContextMap(this.mdcContext);
/*     */     try {
/* 228 */       logger.info(msg);
/*     */     } finally {
/* 230 */       MDC.setContextMap(previousMdcContext);
/*     */     }
/*     */   }
/*     */   
/*     */   public void logDebugWithMdc(Logger logger, String msg) {
/* 235 */     Map previousMdcContext = MDC.getCopyOfContextMap();
/* 236 */     MDC.setContextMap(this.mdcContext);
/*     */     try {
/* 238 */       logger.debug(msg);
/*     */     } finally {
/* 240 */       MDC.setContextMap(previousMdcContext);
/*     */     }
/*     */   }
/*     */   
/*     */   public void logWarnWithMdc(Logger logger, String msg) {
/* 245 */     Map previousMdcContext = MDC.getCopyOfContextMap();
/* 246 */     MDC.setContextMap(this.mdcContext);
/*     */     try {
/* 248 */       logger.warn(msg);
/*     */     } finally {
/* 250 */       MDC.setContextMap(previousMdcContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */