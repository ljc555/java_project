/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigSetAdminResponse
/*    */   extends SolrResponseBase
/*    */ {
/*    */   public NamedList<String> getErrorMessages()
/*    */   {
/* 29 */     return (NamedList)getResponse().get("exceptions");
/*    */   }
/*    */   
/*    */   public static class List extends ConfigSetAdminResponse {
/*    */     public List<String> getConfigSets() {
/* 34 */       return (List)getResponse().get("configSets");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\ConfigSetAdminResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */