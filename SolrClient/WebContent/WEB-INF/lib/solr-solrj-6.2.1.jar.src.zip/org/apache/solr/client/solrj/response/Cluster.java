/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cluster
/*    */ {
/*    */   private List<String> labels;
/*    */   private double score;
/*    */   private List<String> docIds;
/*    */   
/*    */   public Cluster(List<String> labels, double score, List<String> docIds)
/*    */   {
/* 38 */     this.labels = labels;
/* 39 */     this.score = score;
/* 40 */     this.docIds = docIds;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 45 */     if (this == o) return true;
/* 46 */     if (!(o instanceof Cluster)) { return false;
/*    */     }
/* 48 */     Cluster cluster = (Cluster)o;
/*    */     
/* 50 */     if (Double.compare(cluster.score, this.score) != 0) return false;
/* 51 */     if (!this.docIds.equals(cluster.docIds)) return false;
/* 52 */     if (!this.labels.equals(cluster.labels)) { return false;
/*    */     }
/* 54 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 61 */     int result = this.labels.hashCode();
/* 62 */     long temp = Double.doubleToLongBits(this.score);
/* 63 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 64 */     result = 31 * result + this.docIds.hashCode();
/* 65 */     return result;
/*    */   }
/*    */   
/*    */   public List<String> getLabels() {
/* 69 */     return this.labels;
/*    */   }
/*    */   
/*    */   public void setLabels(List<String> labels) {
/* 73 */     this.labels = labels;
/*    */   }
/*    */   
/*    */   public double getScore() {
/* 77 */     return this.score;
/*    */   }
/*    */   
/*    */   public void setScore(double score) {
/* 81 */     this.score = score;
/*    */   }
/*    */   
/*    */   public List<String> getDocs() {
/* 85 */     return this.docIds;
/*    */   }
/*    */   
/*    */   public void setDocs(List<String> docIds) {
/* 89 */     this.docIds = docIds;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\Cluster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */