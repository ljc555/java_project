/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountMetric
/*    */   extends Metric
/*    */ {
/*    */   private long count;
/*    */   
/*    */   public CountMetric()
/*    */   {
/* 30 */     init("count");
/*    */   }
/*    */   
/*    */   public CountMetric(StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 35 */     String functionName = expression.getFunctionName();
/* 36 */     String columnName = factory.getValueOperand(expression, 0);
/*    */     
/*    */ 
/* 39 */     if (!"*".equals(columnName)) {
/* 40 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expected %s(*)", new Object[] { expression, functionName }));
/*    */     }
/* 42 */     if (1 != expression.getParameters().size()) {
/* 43 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*    */     }
/*    */     
/* 46 */     init(functionName);
/*    */   }
/*    */   
/*    */   public String[] getColumns()
/*    */   {
/* 51 */     return new String[0];
/*    */   }
/*    */   
/*    */   private void init(String functionName) {
/* 55 */     setFunctionName(functionName);
/* 56 */     setIdentifier(new String[] { functionName, "(*)" });
/*    */   }
/*    */   
/*    */   public void update(Tuple tuple) {
/* 60 */     this.count += 1L;
/*    */   }
/*    */   
/*    */   public Long getValue() {
/* 64 */     return Long.valueOf(this.count);
/*    */   }
/*    */   
/*    */   public Metric newInstance() {
/* 68 */     return new CountMetric();
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException {
/* 72 */     return new StreamExpression(getFunctionName()).withParameter("*");
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\CountMetric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */