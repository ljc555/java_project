package org.apache.solr.client.solrj.io.eq;

import java.io.Serializable;
import org.apache.solr.client.solrj.io.Tuple;
import org.apache.solr.client.solrj.io.comp.StreamComparator;
import org.apache.solr.client.solrj.io.stream.expr.Expressible;

public abstract interface StreamEqualitor
  extends Equalitor<Tuple>, Expressible, Serializable
{
  public abstract boolean isDerivedFrom(StreamEqualitor paramStreamEqualitor);
  
  public abstract boolean isDerivedFrom(StreamComparator paramStreamComparator);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\eq\StreamEqualitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */