/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.apache.http.cookie.Cookie;
/*     */ import org.apache.http.cookie.CookieOrigin;
/*     */ import org.apache.http.cookie.CookieSpec;
/*     */ import org.apache.http.cookie.CookieSpecFactory;
/*     */ import org.apache.http.cookie.CookieSpecProvider;
/*     */ import org.apache.http.cookie.MalformedCookieException;
/*     */ import org.apache.http.impl.cookie.NetscapeDomainHandler;
/*     */ import org.apache.http.impl.cookie.NetscapeDraftSpec;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrPortAwareCookieSpecFactory
/*     */   implements CookieSpecFactory, CookieSpecProvider
/*     */ {
/*     */   public static final String POLICY_NAME = "solr-portaware";
/*     */   private final CookieSpec cookieSpec;
/*     */   
/*     */   public SolrPortAwareCookieSpecFactory(String[] datepatterns)
/*     */   {
/*  41 */     this.cookieSpec = new PortAwareCookieSpec(datepatterns);
/*     */   }
/*     */   
/*     */   public SolrPortAwareCookieSpecFactory() {
/*  45 */     this(null);
/*     */   }
/*     */   
/*     */   public CookieSpec newInstance(HttpParams params)
/*     */   {
/*  50 */     if (params != null) {
/*  51 */       String[] patterns = null;
/*  52 */       Collection<?> param = (Collection)params.getParameter("http.protocol.cookie-datepatterns");
/*     */       
/*  54 */       if (param != null) {
/*  55 */         patterns = new String[param.size()];
/*  56 */         patterns = (String[])param.toArray(patterns);
/*     */       }
/*  58 */       return new PortAwareCookieSpec(patterns);
/*     */     }
/*  60 */     return new PortAwareCookieSpec(null);
/*     */   }
/*     */   
/*     */ 
/*     */   public CookieSpec create(HttpContext context)
/*     */   {
/*  66 */     return this.cookieSpec;
/*     */   }
/*     */   
/*     */   public static class PortAwareCookieSpec extends NetscapeDraftSpec {
/*     */     public PortAwareCookieSpec(String[] patterns) {
/*  71 */       super();
/*  72 */       super.registerAttribHandler("domain", new SolrPortAwareCookieSpecFactory.PortAwareDomainHandler());
/*     */     }
/*     */     
/*     */     public PortAwareCookieSpec() {
/*  76 */       this(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class PortAwareDomainHandler
/*     */     extends NetscapeDomainHandler
/*     */   {
/*     */     public void validate(Cookie cookie, CookieOrigin origin)
/*     */       throws MalformedCookieException
/*     */     {
/*  89 */       if ((origin != null) && (origin.getHost() != null) && (cookie != null)) {
/*  90 */         String hostPort = origin.getHost() + ":" + origin.getPort();
/*  91 */         String domain = cookie.getDomain();
/*     */         
/*  93 */         if (hostPort.equals(domain)) {
/*  94 */           return;
/*     */         }
/*     */       }
/*  97 */       super.validate(cookie, origin);
/*     */     }
/*     */     
/*     */     public boolean match(Cookie cookie, CookieOrigin origin)
/*     */     {
/* 102 */       if ((origin != null) && (origin.getHost() != null) && (cookie != null)) {
/* 103 */         String hostPort = origin.getHost() + ":" + origin.getPort();
/* 104 */         String domain = cookie.getDomain();
/* 105 */         if (hostPort.equals(domain)) {
/* 106 */           return true;
/*     */         }
/*     */       }
/* 109 */       return super.match(cookie, origin);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\SolrPortAwareCookieSpecFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */