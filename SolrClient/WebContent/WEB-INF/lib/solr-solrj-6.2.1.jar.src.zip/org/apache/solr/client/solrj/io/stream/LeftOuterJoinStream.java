/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LeftOuterJoinStream
/*     */   extends BiJoinStream
/*     */   implements Expressible
/*     */ {
/*  36 */   private LinkedList<Tuple> joinedTuples = new LinkedList();
/*  37 */   private LinkedList<Tuple> leftTupleGroup = new LinkedList();
/*  38 */   private LinkedList<Tuple> rightTupleGroup = new LinkedList();
/*     */   
/*     */   public LeftOuterJoinStream(TupleStream leftStream, TupleStream rightStream, StreamEqualitor eq) throws IOException {
/*  41 */     super(leftStream, rightStream, eq);
/*     */   }
/*     */   
/*     */   public LeftOuterJoinStream(StreamExpression expression, StreamFactory factory) throws IOException {
/*  45 */     super(expression, factory);
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*  50 */     if (this.joinedTuples.size() > 0) {
/*  51 */       return (Tuple)this.joinedTuples.removeFirst();
/*     */     }
/*     */     for (;;)
/*     */     {
/*     */       Tuple firstMember;
/*  56 */       if (0 == this.leftTupleGroup.size()) {
/*  57 */         firstMember = loadEqualTupleGroup(this.leftStream, this.leftTupleGroup, this.leftStreamComparator);
/*     */         
/*     */ 
/*  60 */         if (firstMember.EOF) {
/*  61 */           return firstMember;
/*     */         }
/*     */       }
/*     */       
/*  65 */       if (0 == this.rightTupleGroup.size())
/*     */       {
/*  67 */         loadEqualTupleGroup(this.rightStream, this.rightTupleGroup, this.rightStreamComparator);
/*     */       }
/*     */       
/*     */ 
/*  71 */       if ((0 == this.rightTupleGroup.size()) || (((Tuple)this.rightTupleGroup.get(0)).EOF)) {
/*  72 */         return (Tuple)this.leftTupleGroup.removeFirst();
/*     */       }
/*     */       
/*     */ 
/*  76 */       if (this.eq.test(this.leftTupleGroup.get(0), this.rightTupleGroup.get(0)))
/*     */       {
/*  78 */         for (firstMember = this.leftTupleGroup.iterator(); firstMember.hasNext();) { left = (Tuple)firstMember.next();
/*  79 */           for (Tuple right : this.rightTupleGroup) {
/*  80 */             Tuple clone = left.clone();
/*  81 */             clone.merge(right);
/*  82 */             this.joinedTuples.add(clone);
/*     */           }
/*     */         }
/*     */         
/*     */         Tuple left;
/*  87 */         this.leftTupleGroup.clear();
/*  88 */         this.rightTupleGroup.clear();
/*     */         
/*  90 */         return (Tuple)this.joinedTuples.removeFirst();
/*     */       }
/*  92 */       int c = this.iterationComparator.compare(this.leftTupleGroup.get(0), this.rightTupleGroup.get(0));
/*  93 */       if (c < 0)
/*     */       {
/*     */ 
/*  96 */         return (Tuple)this.leftTupleGroup.removeFirst();
/*     */       }
/*     */       
/*  99 */       this.rightTupleGroup.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 107 */     return this.iterationComparator;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\LeftOuterJoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */