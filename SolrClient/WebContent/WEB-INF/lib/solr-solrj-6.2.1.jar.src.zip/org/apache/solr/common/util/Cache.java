package org.apache.solr.common.util;

public abstract interface Cache<K, V>
{
  public abstract V put(K paramK, V paramV);
  
  public abstract V get(K paramK);
  
  public abstract V remove(K paramK);
  
  public abstract void clear();
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\Cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */