/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EnumFieldValue
/*     */   implements Serializable, Comparable<EnumFieldValue>
/*     */ {
/*     */   private final Integer intValue;
/*     */   private final String stringValue;
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  32 */     int result = this.intValue != null ? this.intValue.hashCode() : 0;
/*  33 */     result = 31 * result + (this.stringValue != null ? this.stringValue.hashCode() : 0);
/*  34 */     return result;
/*     */   }
/*     */   
/*     */   public EnumFieldValue(Integer intValue, String stringValue) {
/*  38 */     this.intValue = intValue;
/*  39 */     this.stringValue = stringValue;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  44 */     if (obj == null)
/*  45 */       return false;
/*  46 */     if (!(obj instanceof EnumFieldValue)) {
/*  47 */       return false;
/*     */     }
/*  49 */     EnumFieldValue otherEnumFieldValue = (EnumFieldValue)obj;
/*  50 */     return (equalsIntegers(this.intValue, otherEnumFieldValue.intValue)) && (equalStrings(this.stringValue, otherEnumFieldValue.stringValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  58 */     return this.stringValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer toInt()
/*     */   {
/*  65 */     return this.intValue;
/*     */   }
/*     */   
/*     */   public int compareTo(EnumFieldValue o)
/*     */   {
/*  70 */     if (o == null)
/*  71 */       return 1;
/*  72 */     return compareIntegers(this.intValue, o.intValue);
/*     */   }
/*     */   
/*     */   private boolean equalStrings(String str1, String str2) {
/*  76 */     if ((str1 == null) && (str2 == null)) {
/*  77 */       return true;
/*     */     }
/*  79 */     if (str1 == null) {
/*  80 */       return false;
/*     */     }
/*  82 */     if (str2 == null) {
/*  83 */       return false;
/*     */     }
/*  85 */     return str1.equals(str2);
/*     */   }
/*     */   
/*     */   private boolean equalsIntegers(Integer int1, Integer int2) {
/*  89 */     if ((int1 == null) && (int2 == null)) {
/*  90 */       return true;
/*     */     }
/*  92 */     if (int1 == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     if (int2 == null) {
/*  96 */       return false;
/*     */     }
/*  98 */     return int1.equals(int2);
/*     */   }
/*     */   
/*     */   private int compareIntegers(Integer int1, Integer int2) {
/* 102 */     if ((int1 == null) && (int2 == null)) {
/* 103 */       return 0;
/*     */     }
/* 105 */     if (int1 == null) {
/* 106 */       return -1;
/*     */     }
/* 108 */     if (int2 == null) {
/* 109 */       return 1;
/*     */     }
/* 111 */     return int1.compareTo(int2);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\EnumFieldValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */