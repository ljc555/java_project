/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreAdminResponse
/*    */   extends SolrResponseBase
/*    */ {
/*    */   public NamedList<NamedList<Object>> getCoreStatus()
/*    */   {
/* 32 */     return (NamedList)getResponse().get("status");
/*    */   }
/*    */   
/*    */   public NamedList<Object> getCoreStatus(String core)
/*    */   {
/* 37 */     return (NamedList)getCoreStatus().get(core);
/*    */   }
/*    */   
/*    */   public Date getStartTime(String core)
/*    */   {
/* 42 */     NamedList<Object> v = getCoreStatus(core);
/* 43 */     if (v == null) {
/* 44 */       return null;
/*    */     }
/* 46 */     return (Date)v.get("startTime");
/*    */   }
/*    */   
/*    */   public Long getUptime(String core)
/*    */   {
/* 51 */     NamedList<Object> v = getCoreStatus(core);
/* 52 */     if (v == null) {
/* 53 */       return null;
/*    */     }
/* 55 */     return (Long)v.get("uptime");
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\CoreAdminResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */