/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterStateUtil
/*     */ {
/*  32 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int TIMEOUT_POLL_MS = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean waitForAllActiveAndLiveReplicas(ZkStateReader zkStateReader, int timeoutInMs)
/*     */   {
/*  46 */     return waitForAllActiveAndLiveReplicas(zkStateReader, null, timeoutInMs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean waitForAllActiveAndLiveReplicas(ZkStateReader zkStateReader, String collection, int timeoutInMs)
/*     */   {
/*  62 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutInMs, TimeUnit.MILLISECONDS);
/*  63 */     boolean success = false;
/*  64 */     while ((!success) && (System.nanoTime() < timeout)) {
/*  65 */       success = true;
/*  66 */       ClusterState clusterState = zkStateReader.getClusterState();
/*  67 */       if (clusterState != null) {
/*  68 */         Map<String, DocCollection> collections = null;
/*  69 */         if (collection != null) {
/*  70 */           collections = Collections.singletonMap(collection, clusterState.getCollection(collection));
/*     */         } else {
/*  72 */           collections = clusterState.getCollectionsMap();
/*     */         }
/*  74 */         for (Map.Entry<String, DocCollection> entry : collections.entrySet()) {
/*  75 */           DocCollection docCollection = (DocCollection)entry.getValue();
/*  76 */           Collection<Slice> slices = docCollection.getSlices();
/*  77 */           for (Slice slice : slices)
/*     */           {
/*  79 */             if (slice.getState() == Slice.State.ACTIVE) {
/*  80 */               Collection<Replica> replicas = slice.getReplicas();
/*  81 */               for (Replica replica : replicas)
/*     */               {
/*  83 */                 boolean live = clusterState.liveNodesContain(replica.getNodeName());
/*  84 */                 boolean isActive = replica.getState() == Replica.State.ACTIVE;
/*  85 */                 if ((!live) || (!isActive))
/*     */                 {
/*  87 */                   success = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*  93 */         if (!success) {
/*     */           try {
/*  95 */             Thread.sleep(1000L);
/*     */           } catch (InterruptedException e) {
/*  97 */             Thread.currentThread().interrupt();
/*  98 */             throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Interrupted");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 104 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean waitToSeeLiveReplica(ZkStateReader zkStateReader, String collection, String coreNodeName, String baseUrl, int timeoutInMs)
/*     */   {
/* 127 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutInMs, TimeUnit.MILLISECONDS);
/*     */     
/* 129 */     while (System.nanoTime() < timeout) {
/* 130 */       log.debug("waiting to see replica just created live collection={} replica={} baseUrl={}", new Object[] { collection, coreNodeName, baseUrl });
/*     */       
/* 132 */       ClusterState clusterState = zkStateReader.getClusterState();
/* 133 */       if (clusterState != null) {
/* 134 */         DocCollection docCollection = clusterState.getCollection(collection);
/* 135 */         Collection<Slice> slices = docCollection.getSlices();
/* 136 */         for (Slice slice : slices)
/*     */         {
/* 138 */           if (slice.getState() == Slice.State.ACTIVE) {
/* 139 */             Collection<Replica> replicas = slice.getReplicas();
/* 140 */             for (Replica replica : replicas)
/*     */             {
/* 142 */               boolean live = clusterState.liveNodesContain(replica.getNodeName());
/* 143 */               String rcoreNodeName = replica.getName();
/* 144 */               String rbaseUrl = replica.getStr("base_url");
/* 145 */               if ((live) && (coreNodeName.equals(rcoreNodeName)) && 
/* 146 */                 (baseUrl.equals(rbaseUrl)))
/*     */               {
/* 148 */                 return true;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         try {
/* 154 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException e) {
/* 156 */           Thread.currentThread().interrupt();
/* 157 */           throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Interrupted");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 162 */     log.error("Timed out waiting to see replica just created in cluster state. Continuing...");
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean waitForAllReplicasNotLive(ZkStateReader zkStateReader, int timeoutInMs) {
/* 167 */     return waitForAllReplicasNotLive(zkStateReader, null, timeoutInMs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean waitForAllReplicasNotLive(ZkStateReader zkStateReader, String collection, int timeoutInMs)
/*     */   {
/* 174 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutInMs, TimeUnit.MILLISECONDS);
/* 175 */     boolean success = false;
/* 176 */     while ((!success) && (System.nanoTime() < timeout)) {
/* 177 */       success = true;
/* 178 */       ClusterState clusterState = zkStateReader.getClusterState();
/* 179 */       if (clusterState != null) {
/* 180 */         Map<String, DocCollection> collections = null;
/* 181 */         if (collection != null) {
/* 182 */           collections = Collections.singletonMap(collection, clusterState.getCollection(collection));
/*     */         } else {
/* 184 */           collections = clusterState.getCollectionsMap();
/*     */         }
/* 186 */         for (Map.Entry<String, DocCollection> entry : collections.entrySet()) {
/* 187 */           DocCollection docCollection = (DocCollection)entry.getValue();
/* 188 */           Collection<Slice> slices = docCollection.getSlices();
/* 189 */           for (Slice slice : slices)
/*     */           {
/* 191 */             if (slice.getState() == Slice.State.ACTIVE) {
/* 192 */               Collection<Replica> replicas = slice.getReplicas();
/* 193 */               for (Replica replica : replicas)
/*     */               {
/* 195 */                 boolean live = clusterState.liveNodesContain(replica
/* 196 */                   .getNodeName());
/* 197 */                 if (live)
/*     */                 {
/* 199 */                   success = false;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 205 */         if (!success) {
/*     */           try {
/* 207 */             Thread.sleep(1000L);
/*     */           } catch (InterruptedException e) {
/* 209 */             Thread.currentThread().interrupt();
/* 210 */             throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Interrupted");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 216 */     return success;
/*     */   }
/*     */   
/*     */   public static int getLiveAndActiveReplicaCount(ZkStateReader zkStateReader, String collection)
/*     */   {
/* 221 */     Collection<Slice> slices = zkStateReader.getClusterState().getActiveSlices(collection);
/* 222 */     int liveAndActive = 0;
/* 223 */     for (Slice slice : slices) {
/* 224 */       for (Replica replica : slice.getReplicas()) {
/* 225 */         boolean live = zkStateReader.getClusterState().liveNodesContain(replica.getNodeName());
/* 226 */         boolean active = replica.getState() == Replica.State.ACTIVE;
/* 227 */         if ((live) && (active)) {
/* 228 */           liveAndActive++;
/*     */         }
/*     */       }
/*     */     }
/* 232 */     return liveAndActive;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean waitForLiveAndActiveReplicaCount(ZkStateReader zkStateReader, String collection, int replicaCount, int timeoutInMs)
/*     */   {
/* 238 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutInMs, TimeUnit.MILLISECONDS);
/* 239 */     boolean success = false;
/* 240 */     while ((!success) && (System.nanoTime() < timeout)) {
/* 241 */       success = getLiveAndActiveReplicaCount(zkStateReader, collection) == replicaCount;
/*     */       
/* 243 */       if (!success) {
/*     */         try {
/* 245 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException e) {
/* 247 */           Thread.currentThread().interrupt();
/* 248 */           throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Interrupted");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 254 */     return success;
/*     */   }
/*     */   
/*     */   public static boolean isAutoAddReplicas(ZkStateReader reader, String collection) {
/* 258 */     ClusterState clusterState = reader.getClusterState();
/* 259 */     if (clusterState != null) {
/* 260 */       DocCollection docCollection = clusterState.getCollectionOrNull(collection);
/* 261 */       if (docCollection != null) {
/* 262 */         return docCollection.getAutoAddReplicas();
/*     */       }
/*     */     }
/* 265 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ClusterStateUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */