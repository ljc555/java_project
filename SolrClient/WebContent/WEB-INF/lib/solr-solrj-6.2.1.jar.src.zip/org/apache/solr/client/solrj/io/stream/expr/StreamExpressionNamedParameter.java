/*     */ package org.apache.solr.client.solrj.io.stream.expr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamExpressionNamedParameter
/*     */   implements StreamExpressionParameter
/*     */ {
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StreamExpressionParameter parameter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  28 */   public StreamExpressionNamedParameter(String name) { this.name = name; }
/*     */   
/*     */   public StreamExpressionNamedParameter(String name, String parameter) {
/*  31 */     this.name = name;
/*  32 */     setParameter(parameter);
/*     */   }
/*     */   
/*  35 */   public StreamExpressionNamedParameter(String name, StreamExpressionParameter parameter) { this.name = name;
/*  36 */     setParameter(parameter);
/*     */   }
/*     */   
/*     */ 
/*  40 */   public String getName() { return this.name; }
/*     */   
/*     */   public void setName(String name) {
/*  43 */     if ((null == name) || (0 == name.length())) {
/*  44 */       throw new IllegalArgumentException("Null or empty name is not allowed is not allowed.");
/*     */     }
/*     */     
/*  47 */     this.name = name;
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter getParameter() {
/*  51 */     return this.parameter;
/*     */   }
/*     */   
/*  54 */   public void setParameter(StreamExpressionParameter parameter) { this.parameter = parameter; }
/*     */   
/*     */   public StreamExpressionNamedParameter withParameter(StreamExpressionParameter parameter) {
/*  57 */     setParameter(parameter);
/*  58 */     return this;
/*     */   }
/*     */   
/*  61 */   public void setParameter(String parameter) { this.parameter = new StreamExpressionValue(parameter); }
/*     */   
/*     */   public StreamExpressionNamedParameter withParameter(String parameter) {
/*  64 */     setParameter(parameter);
/*  65 */     return this;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  70 */     StringBuilder sb = new StringBuilder(this.name);
/*  71 */     sb.append("=");
/*     */     
/*     */ 
/*  74 */     boolean requiresQuote = false;
/*  75 */     if ((this.parameter instanceof StreamExpressionValue)) {
/*  76 */       String value = ((StreamExpressionValue)this.parameter).getValue();
/*  77 */       requiresQuote = !StreamExpressionParser.wordToken(value);
/*     */     }
/*     */     
/*  80 */     if (requiresQuote) sb.append("\"");
/*  81 */     sb.append(this.parameter.toString());
/*  82 */     if (requiresQuote) { sb.append("\"");
/*     */     }
/*  84 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other)
/*     */   {
/*  89 */     if (other.getClass() != StreamExpressionNamedParameter.class) {
/*  90 */       return false;
/*     */     }
/*     */     
/*  93 */     StreamExpressionNamedParameter check = (StreamExpressionNamedParameter)other;
/*     */     
/*  95 */     if ((null == this.name) && (null != check.name)) {
/*  96 */       return false;
/*     */     }
/*  98 */     if ((null != this.name) && (null == check.name)) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     if ((null != this.name) && (null != check.name) && (!this.name.equals(check.name))) {
/* 103 */       return false;
/*     */     }
/*     */     
/* 106 */     return this.parameter.equals(check.parameter);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamExpressionNamedParameter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */