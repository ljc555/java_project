package org.apache.solr.common.params;

public abstract interface CommonAdminParams
{
  public static final String ASYNC = "async";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\CommonAdminParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */