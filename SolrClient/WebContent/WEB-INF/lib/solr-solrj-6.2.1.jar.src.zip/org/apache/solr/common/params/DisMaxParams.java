package org.apache.solr.common.params;

public abstract interface DisMaxParams
{
  public static final String TIE = "tie";
  public static final String QF = "qf";
  public static final String PF = "pf";
  public static final String PF2 = "pf2";
  public static final String PF3 = "pf3";
  public static final String MM = "mm";
  public static final String MM_AUTORELAX = "mm.autoRelax";
  public static final String PS = "ps";
  public static final String PS2 = "ps2";
  public static final String PS3 = "ps3";
  public static final String QS = "qs";
  public static final String BQ = "bq";
  public static final String BF = "bf";
  public static final String ALTQ = "q.alt";
  public static final String GEN = "gen";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\DisMaxParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */