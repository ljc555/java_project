/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HeaderElement;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpException;
/*     */ import org.apache.http.HttpRequest;
/*     */ import org.apache.http.HttpRequestInterceptor;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.HttpResponseInterceptor;
/*     */ import org.apache.http.auth.AuthScope;
/*     */ import org.apache.http.auth.UsernamePasswordCredentials;
/*     */ import org.apache.http.client.CredentialsProvider;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.params.ClientParamBean;
/*     */ import org.apache.http.conn.ClientConnectionManager;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*     */ import org.apache.http.conn.ssl.X509HostnameVerifier;
/*     */ import org.apache.http.entity.HttpEntityWrapper;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
/*     */ import org.apache.http.impl.client.SystemDefaultHttpClient;
/*     */ import org.apache.http.impl.conn.PoolingClientConnectionManager;
/*     */ import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
/*     */ import org.apache.http.params.HttpConnectionParams;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.IOUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpClientUtil
/*     */ {
/*     */   public static final String PROP_SO_TIMEOUT = "socketTimeout";
/*     */   public static final String PROP_CONNECTION_TIMEOUT = "connTimeout";
/*     */   public static final String PROP_MAX_CONNECTIONS_PER_HOST = "maxConnectionsPerHost";
/*     */   public static final String PROP_MAX_CONNECTIONS = "maxConnections";
/*     */   public static final String PROP_USE_RETRY = "retry";
/*     */   public static final String PROP_ALLOW_COMPRESSION = "allowCompression";
/*     */   public static final String PROP_FOLLOW_REDIRECTS = "followRedirects";
/*     */   public static final String PROP_BASIC_AUTH_USER = "httpBasicAuthUser";
/*     */   public static final String PROP_BASIC_AUTH_PASS = "httpBasicAuthPassword";
/*     */   public static final String SYS_PROP_CHECK_PEER_NAME = "solr.ssl.checkPeerName";
/*  91 */   private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*  93 */   static final DefaultHttpRequestRetryHandler NO_RETRY = new DefaultHttpRequestRetryHandler(0, false);
/*     */   
/*     */ 
/*  96 */   private static HttpClientConfigurer configurer = new HttpClientConfigurer();
/*     */   
/*  98 */   private static final List<HttpRequestInterceptor> interceptors = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setConfigurer(HttpClientConfigurer newConfigurer)
/*     */   {
/* 105 */     configurer = newConfigurer;
/*     */   }
/*     */   
/*     */   public static HttpClientConfigurer getConfigurer() {
/* 109 */     return configurer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CloseableHttpClient createClient(SolrParams params)
/*     */   {
/* 120 */     ModifiableSolrParams config = new ModifiableSolrParams(params);
/* 121 */     if (logger.isDebugEnabled()) {
/* 122 */       logger.debug("Creating new http client, config:" + config);
/*     */     }
/* 124 */     DefaultHttpClient httpClient = HttpClientFactory.createHttpClient();
/* 125 */     configureClient(httpClient, config);
/* 126 */     return httpClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CloseableHttpClient createClient(SolrParams params, ClientConnectionManager cm)
/*     */   {
/* 134 */     ModifiableSolrParams config = new ModifiableSolrParams(params);
/* 135 */     if (logger.isDebugEnabled()) {
/* 136 */       logger.debug("Creating new http client, config:" + config);
/*     */     }
/* 138 */     DefaultHttpClient httpClient = HttpClientFactory.createHttpClient(cm);
/* 139 */     configureClient(httpClient, config);
/* 140 */     return httpClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void configureClient(DefaultHttpClient httpClient, SolrParams config)
/*     */   {
/* 149 */     configurer.configure(httpClient, config);
/* 150 */     synchronized (interceptors) {
/* 151 */       for (HttpRequestInterceptor interceptor : interceptors) {
/* 152 */         httpClient.addRequestInterceptor(interceptor);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void close(HttpClient httpClient) {
/* 158 */     if ((httpClient instanceof CloseableHttpClient)) {
/* 159 */       IOUtils.closeQuietly((CloseableHttpClient)httpClient);
/*     */     } else {
/* 161 */       httpClient.getConnectionManager().shutdown();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addRequestInterceptor(HttpRequestInterceptor interceptor) {
/* 166 */     interceptors.add(interceptor);
/*     */   }
/*     */   
/*     */   public static void removeRequestInterceptor(HttpRequestInterceptor interceptor) {
/* 170 */     interceptors.remove(interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setAllowCompression(DefaultHttpClient httpClient, boolean allowCompression)
/*     */   {
/* 183 */     httpClient.removeRequestInterceptorByClass(UseCompressionRequestInterceptor.class);
/* 184 */     httpClient
/* 185 */       .removeResponseInterceptorByClass(UseCompressionResponseInterceptor.class);
/* 186 */     if (allowCompression) {
/* 187 */       httpClient.addRequestInterceptor(new UseCompressionRequestInterceptor(null));
/* 188 */       httpClient
/* 189 */         .addResponseInterceptor(new UseCompressionResponseInterceptor(null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setBasicAuth(DefaultHttpClient httpClient, String basicAuthUser, String basicAuthPass)
/*     */   {
/* 201 */     if ((basicAuthUser != null) && (basicAuthPass != null)) {
/* 202 */       httpClient.getCredentialsProvider().setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(basicAuthUser, basicAuthPass));
/*     */     }
/*     */     else {
/* 205 */       httpClient.getCredentialsProvider().clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setMaxConnectionsPerHost(HttpClient httpClient, int max)
/*     */   {
/* 217 */     if ((httpClient.getConnectionManager() instanceof ThreadSafeClientConnManager)) {
/* 218 */       ThreadSafeClientConnManager mgr = (ThreadSafeClientConnManager)httpClient.getConnectionManager();
/* 219 */       mgr.setDefaultMaxPerRoute(max);
/* 220 */     } else if ((httpClient.getConnectionManager() instanceof PoolingClientConnectionManager)) {
/* 221 */       PoolingClientConnectionManager mgr = (PoolingClientConnectionManager)httpClient.getConnectionManager();
/* 222 */       mgr.setDefaultMaxPerRoute(max);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setMaxConnections(HttpClient httpClient, int max)
/*     */   {
/* 234 */     if ((httpClient.getConnectionManager() instanceof ThreadSafeClientConnManager)) {
/* 235 */       ThreadSafeClientConnManager mgr = (ThreadSafeClientConnManager)httpClient.getConnectionManager();
/* 236 */       mgr.setMaxTotal(max);
/* 237 */     } else if ((httpClient.getConnectionManager() instanceof PoolingClientConnectionManager)) {
/* 238 */       PoolingClientConnectionManager mgr = (PoolingClientConnectionManager)httpClient.getConnectionManager();
/* 239 */       mgr.setMaxTotal(max);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setSoTimeout(HttpClient httpClient, int timeout)
/*     */   {
/* 251 */     HttpConnectionParams.setSoTimeout(httpClient.getParams(), timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setUseRetry(DefaultHttpClient httpClient, boolean useRetry)
/*     */   {
/* 261 */     if (!useRetry) {
/* 262 */       httpClient.setHttpRequestRetryHandler(NO_RETRY);
/*     */     }
/*     */     else
/*     */     {
/* 266 */       httpClient.setHttpRequestRetryHandler(new SolrHttpRequestRetryHandler(3));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setConnectionTimeout(HttpClient httpClient, int timeout)
/*     */   {
/* 279 */     HttpConnectionParams.setConnectionTimeout(httpClient.getParams(), timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setFollowRedirects(HttpClient httpClient, boolean followRedirects)
/*     */   {
/* 290 */     new ClientParamBean(httpClient.getParams()).setHandleRedirects(followRedirects);
/*     */   }
/*     */   
/*     */   public static void setHostNameVerifier(DefaultHttpClient httpClient, X509HostnameVerifier hostNameVerifier)
/*     */   {
/* 295 */     Scheme httpsScheme = httpClient.getConnectionManager().getSchemeRegistry().get("https");
/* 296 */     if (httpsScheme != null) {
/* 297 */       SSLSocketFactory sslSocketFactory = (SSLSocketFactory)httpsScheme.getSchemeSocketFactory();
/* 298 */       sslSocketFactory.setHostnameVerifier(hostNameVerifier);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setStaleCheckingEnabled(HttpClient httpClient, boolean enabled) {
/* 303 */     HttpConnectionParams.setStaleCheckingEnabled(httpClient.getParams(), enabled);
/*     */   }
/*     */   
/*     */   public static void setTcpNoDelay(HttpClient httpClient, boolean tcpNoDelay) {
/* 307 */     HttpConnectionParams.setTcpNoDelay(httpClient.getParams(), tcpNoDelay);
/*     */   }
/*     */   
/*     */   private static class UseCompressionRequestInterceptor
/*     */     implements HttpRequestInterceptor
/*     */   {
/*     */     public void process(HttpRequest request, HttpContext context)
/*     */       throws HttpException, IOException
/*     */     {
/* 316 */       if (!request.containsHeader("Accept-Encoding")) {
/* 317 */         request.addHeader("Accept-Encoding", "gzip, deflate");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class UseCompressionResponseInterceptor
/*     */     implements HttpResponseInterceptor
/*     */   {
/*     */     public void process(HttpResponse response, HttpContext context)
/*     */       throws HttpException, IOException
/*     */     {
/* 329 */       HttpEntity entity = response.getEntity();
/* 330 */       Header ceheader = entity.getContentEncoding();
/* 331 */       if (ceheader != null) {
/* 332 */         HeaderElement[] codecs = ceheader.getElements();
/* 333 */         for (int i = 0; i < codecs.length; i++) {
/* 334 */           if (codecs[i].getName().equalsIgnoreCase("gzip"))
/*     */           {
/* 336 */             response.setEntity(new HttpClientUtil.GzipDecompressingEntity(response.getEntity()));
/* 337 */             return;
/*     */           }
/* 339 */           if (codecs[i].getName().equalsIgnoreCase("deflate")) {
/* 340 */             response.setEntity(new HttpClientUtil.DeflateDecompressingEntity(response
/* 341 */               .getEntity()));
/* 342 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GzipDecompressingEntity extends HttpEntityWrapper {
/*     */     public GzipDecompressingEntity(HttpEntity entity) {
/* 351 */       super();
/*     */     }
/*     */     
/*     */     public InputStream getContent() throws IOException, IllegalStateException
/*     */     {
/* 356 */       return new GZIPInputStream(this.wrappedEntity.getContent());
/*     */     }
/*     */     
/*     */     public long getContentLength()
/*     */     {
/* 361 */       return -1L;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DeflateDecompressingEntity extends HttpClientUtil.GzipDecompressingEntity
/*     */   {
/*     */     public DeflateDecompressingEntity(HttpEntity entity) {
/* 368 */       super();
/*     */     }
/*     */     
/*     */     public InputStream getContent() throws IOException, IllegalStateException
/*     */     {
/* 373 */       return new InflaterInputStream(this.wrappedEntity.getContent());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class HttpClientFactory {
/* 378 */     private static Class<? extends DefaultHttpClient> defaultHttpClientClass = DefaultHttpClient.class;
/* 379 */     private static Class<? extends SystemDefaultHttpClient> systemDefaultHttpClientClass = SystemDefaultHttpClient.class;
/*     */     
/*     */     public static SystemDefaultHttpClient createHttpClient()
/*     */     {
/*     */       try
/*     */       {
/* 385 */         Constructor<? extends SystemDefaultHttpClient> constructor = systemDefaultHttpClientClass.getDeclaredConstructor(new Class[0]);
/* 386 */         return (SystemDefaultHttpClient)constructor.newInstance(new Object[0]);
/*     */       } catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
/* 388 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Unable to create HttpClient instance. ", e);
/*     */       }
/*     */     }
/*     */     
/*     */     public static DefaultHttpClient createHttpClient(ClientConnectionManager cm)
/*     */     {
/*     */       try {
/* 395 */         Constructor<? extends DefaultHttpClient> constructor = defaultHttpClientClass.getDeclaredConstructor(new Class[] { ClientConnectionManager.class });
/* 396 */         return (DefaultHttpClient)constructor.newInstance(new Object[] { cm });
/*     */       } catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
/* 398 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Unable to create HttpClient instance, registered class is: " + defaultHttpClientClass, e);
/*     */       }
/*     */     }
/*     */     
/*     */     public static void setHttpClientImpl(Class<? extends DefaultHttpClient> defaultHttpClient, Class<? extends SystemDefaultHttpClient> systemDefaultHttpClient) {
/* 403 */       defaultHttpClientClass = defaultHttpClient;
/* 404 */       systemDefaultHttpClientClass = systemDefaultHttpClient;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\HttpClientUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */