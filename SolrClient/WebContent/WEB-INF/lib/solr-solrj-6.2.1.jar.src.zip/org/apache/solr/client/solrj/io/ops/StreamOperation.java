package org.apache.solr.client.solrj.io.ops;

import java.io.Serializable;
import org.apache.solr.client.solrj.io.Tuple;
import org.apache.solr.client.solrj.io.stream.expr.Expressible;

public abstract interface StreamOperation
  extends Expressible, Serializable
{
  public abstract void operate(Tuple paramTuple);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\StreamOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */