/*    */ package org.apache.solr.client.solrj.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.StringWriter;
/*    */ import org.apache.commons.io.IOUtils;
/*    */ import org.apache.solr.client.solrj.ResponseParser;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoOpResponseParser
/*    */   extends ResponseParser
/*    */ {
/* 35 */   private String writerType = "xml";
/*    */   
/*    */   public NoOpResponseParser() {}
/*    */   
/*    */   public NoOpResponseParser(String writerType)
/*    */   {
/* 41 */     this.writerType = writerType;
/*    */   }
/*    */   
/*    */   public String getWriterType()
/*    */   {
/* 46 */     return this.writerType;
/*    */   }
/*    */   
/*    */   public void setWriterType(String writerType) {
/* 50 */     this.writerType = writerType;
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(Reader reader)
/*    */   {
/*    */     try {
/* 56 */       StringWriter writer = new StringWriter();
/* 57 */       IOUtils.copy(reader, writer);
/* 58 */       String output = writer.toString();
/* 59 */       NamedList<Object> list = new NamedList();
/* 60 */       list.add("response", output);
/* 61 */       return list;
/*    */     } catch (IOException e) {
/* 63 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*    */     }
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(InputStream body, String encoding)
/*    */   {
/*    */     try {
/* 70 */       StringWriter writer = new StringWriter();
/* 71 */       IOUtils.copy(body, writer, encoding);
/* 72 */       String output = writer.toString();
/* 73 */       NamedList<Object> list = new NamedList();
/* 74 */       list.add("response", output);
/* 75 */       return list;
/*    */     } catch (IOException e) {
/* 77 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\NoOpResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */