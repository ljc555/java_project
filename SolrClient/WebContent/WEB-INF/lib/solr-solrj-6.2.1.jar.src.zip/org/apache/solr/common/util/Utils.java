/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.noggit.CharArr;
/*     */ import org.noggit.JSONParser;
/*     */ import org.noggit.JSONWriter;
/*     */ import org.noggit.ObjectBuilder;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*  51 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   public static Map getDeepCopy(Map map, int maxDepth) {
/*  54 */     return getDeepCopy(map, maxDepth, true);
/*     */   }
/*     */   
/*     */   public static Map getDeepCopy(Map map, int maxDepth, boolean mutable) {
/*  58 */     if (map == null) return null;
/*  59 */     if (maxDepth < 1) return map;
/*  60 */     Map copy = new LinkedHashMap();
/*  61 */     for (Object o : map.entrySet()) {
/*  62 */       Map.Entry e = (Map.Entry)o;
/*  63 */       Object v = e.getValue();
/*  64 */       if ((v instanceof Map)) { v = getDeepCopy((Map)v, maxDepth - 1, mutable);
/*  65 */       } else if ((v instanceof Collection)) v = getDeepCopy((Collection)v, maxDepth - 1, mutable);
/*  66 */       copy.put(e.getKey(), v);
/*     */     }
/*  68 */     return mutable ? copy : Collections.unmodifiableMap(copy);
/*     */   }
/*     */   
/*     */   public static Collection getDeepCopy(Collection c, int maxDepth, boolean mutable) {
/*  72 */     if ((c == null) || (maxDepth < 1)) return c;
/*  73 */     Collection result = (c instanceof Set) ? new HashSet() : new ArrayList();
/*  74 */     for (Object o : c) {
/*  75 */       if ((o instanceof Map)) {
/*  76 */         o = getDeepCopy((Map)o, maxDepth - 1, mutable);
/*     */       }
/*  78 */       result.add(o);
/*     */     }
/*  80 */     return (result instanceof Set) ? Collections.unmodifiableSet((Set)result) : mutable ? result : Collections.unmodifiableList((List)result);
/*     */   }
/*     */   
/*     */   public static byte[] toJSON(Object o) {
/*  84 */     if (o == null) return new byte[0];
/*  85 */     CharArr out = new CharArr();
/*  86 */     new JSONWriter(out, 2).write(o);
/*  87 */     return toUTF8(out);
/*     */   }
/*     */   
/*     */   public static String toJSONString(Object o) {
/*  91 */     return new String(toJSON(o), StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public static byte[] toUTF8(CharArr out) {
/*  95 */     byte[] arr = new byte[out.size() * 3];
/*  96 */     int nBytes = ByteUtils.UTF16toUTF8(out, 0, out.size(), arr, 0);
/*  97 */     return Arrays.copyOf(arr, nBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object fromJSON(byte[] utf8)
/*     */   {
/* 104 */     CharArr chars = new CharArr();
/* 105 */     ByteUtils.UTF8toUTF16(utf8, 0, utf8.length, chars);
/* 106 */     JSONParser parser = new JSONParser(chars.getArray(), chars.getStart(), chars.length());
/*     */     try {
/* 108 */       return ObjectBuilder.getVal(parser);
/*     */     } catch (IOException e) {
/* 110 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<String, Object> makeMap(Object... keyVals) {
/* 115 */     if ((keyVals.length & 0x1) != 0) {
/* 116 */       throw new IllegalArgumentException("arguments should be key,value");
/*     */     }
/* 118 */     Map<String, Object> propMap = new LinkedHashMap(keyVals.length >> 1);
/* 119 */     for (int i = 0; i < keyVals.length; i += 2) {
/* 120 */       propMap.put(keyVals[i].toString(), keyVals[(i + 1)]);
/*     */     }
/* 122 */     return propMap;
/*     */   }
/*     */   
/*     */   public static Object fromJSON(InputStream is) {
/*     */     try {
/* 127 */       return new ObjectBuilder(new JSONParser(new InputStreamReader(is, StandardCharsets.UTF_8))).getObject();
/*     */     } catch (IOException e) {
/* 129 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Parse error", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object fromJSONResource(String resourceName) {
/* 134 */     return fromJSON(Thread.currentThread()
/* 135 */       .getContextClassLoader().getResourceAsStream(resourceName));
/*     */   }
/*     */   
/*     */   public static Object fromJSONString(String json)
/*     */   {
/*     */     try {
/* 141 */       return 
/* 142 */         new ObjectBuilder(new JSONParser(new StringReader(json))).getObject();
/*     */     } catch (IOException e) {
/* 144 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Parse error", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object getObjectByPath(Map root, boolean onlyPrimitive, String hierarchy) {
/* 149 */     return getObjectByPath(root, onlyPrimitive, StrUtils.splitSmart(hierarchy, '/'));
/*     */   }
/*     */   
/*     */   public static Object getObjectByPath(Map root, boolean onlyPrimitive, List<String> hierarchy) {
/* 153 */     Map obj = root;
/* 154 */     for (int i = 0; i < hierarchy.size(); i++) {
/* 155 */       int idx = -1;
/* 156 */       String s = (String)hierarchy.get(i);
/* 157 */       if (s.endsWith("]")) {
/* 158 */         Matcher matcher = ARRAY_ELEMENT_INDEX.matcher(s);
/* 159 */         if (matcher.find()) {
/* 160 */           s = matcher.group(1);
/* 161 */           idx = Integer.parseInt(matcher.group(2));
/*     */         }
/*     */       }
/* 164 */       if (i < hierarchy.size() - 1) {
/* 165 */         Object o = obj.get(s);
/* 166 */         if (o == null) return null;
/* 167 */         if (idx > -1) {
/* 168 */           List l = (List)o;
/* 169 */           o = idx < l.size() ? l.get(idx) : null;
/*     */         }
/* 171 */         if (!(o instanceof Map)) return null;
/* 172 */         obj = (Map)o;
/*     */       } else {
/* 174 */         Object val = obj.get(s);
/* 175 */         if (idx > -1) {
/* 176 */           List l = (List)val;
/* 177 */           val = idx < l.size() ? l.get(idx) : null;
/*     */         }
/* 179 */         if ((onlyPrimitive) && ((val instanceof Map))) {
/* 180 */           return null;
/*     */         }
/* 182 */         return val;
/*     */       }
/*     */     }
/*     */     
/* 186 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void consumeFully(org.apache.http.HttpEntity entity)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnull +42 -> 43
/*     */     //   4: aload_0
/*     */     //   5: invokeinterface 84 1 0
/*     */     //   10: invokestatic 85	org/apache/solr/common/util/Utils:readFully	(Ljava/io/InputStream;)V
/*     */     //   13: aload_0
/*     */     //   14: invokestatic 86	org/apache/http/util/EntityUtils:consumeQuietly	(Lorg/apache/http/HttpEntity;)V
/*     */     //   17: goto +26 -> 43
/*     */     //   20: astore_1
/*     */     //   21: aload_0
/*     */     //   22: invokestatic 86	org/apache/http/util/EntityUtils:consumeQuietly	(Lorg/apache/http/HttpEntity;)V
/*     */     //   25: goto +18 -> 43
/*     */     //   28: astore_1
/*     */     //   29: aload_0
/*     */     //   30: invokestatic 86	org/apache/http/util/EntityUtils:consumeQuietly	(Lorg/apache/http/HttpEntity;)V
/*     */     //   33: goto +10 -> 43
/*     */     //   36: astore_2
/*     */     //   37: aload_0
/*     */     //   38: invokestatic 86	org/apache/http/util/EntityUtils:consumeQuietly	(Lorg/apache/http/HttpEntity;)V
/*     */     //   41: aload_2
/*     */     //   42: athrow
/*     */     //   43: return
/*     */     // Line number table:
/*     */     //   Java source line #196	-> byte code offset #0
/*     */     //   Java source line #199	-> byte code offset #4
/*     */     //   Java source line #206	-> byte code offset #13
/*     */     //   Java source line #207	-> byte code offset #17
/*     */     //   Java source line #200	-> byte code offset #20
/*     */     //   Java source line #206	-> byte code offset #21
/*     */     //   Java source line #207	-> byte code offset #25
/*     */     //   Java source line #202	-> byte code offset #28
/*     */     //   Java source line #206	-> byte code offset #29
/*     */     //   Java source line #207	-> byte code offset #33
/*     */     //   Java source line #206	-> byte code offset #36
/*     */     //   Java source line #209	-> byte code offset #43
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	44	0	entity	org.apache.http.HttpEntity
/*     */     //   20	1	1	localUnsupportedOperationException	UnsupportedOperationException
/*     */     //   28	1	1	localIOException	IOException
/*     */     //   36	6	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	13	20	java/lang/UnsupportedOperationException
/*     */     //   4	13	28	java/io/IOException
/*     */     //   4	13	36	finally
/*     */   }
/*     */   
/*     */   private static void readFully(InputStream is)
/*     */     throws IOException
/*     */   {
/* 218 */     is.skip(is.available());
/* 219 */     while (is.read() != -1) {}
/*     */   }
/*     */   
/*     */ 
/* 223 */   public static final Pattern ARRAY_ELEMENT_INDEX = Pattern.compile("(\\S*?)\\[(\\d+)\\]");
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */