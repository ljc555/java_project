/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldStatsInfo
/*     */   implements Serializable
/*     */ {
/*     */   final String name;
/*     */   Object min;
/*     */   Object max;
/*     */   Object sum;
/*     */   Long count;
/*     */   Long countDistinct;
/*     */   Collection<Object> distinctValues;
/*     */   Long missing;
/*  45 */   Object mean = null;
/*  46 */   Double sumOfSquares = null;
/*  47 */   Double stddev = null;
/*  48 */   Long cardinality = null;
/*     */   
/*     */   Map<String, List<FieldStatsInfo>> facets;
/*     */   
/*     */   Map<Double, Double> percentiles;
/*     */   
/*     */   public FieldStatsInfo(NamedList<Object> nl, String fname)
/*     */   {
/*  56 */     this.name = fname;
/*     */     
/*  58 */     for (Map.Entry<String, Object> entry : nl) {
/*  59 */       if ("min".equals(entry.getKey())) {
/*  60 */         this.min = entry.getValue();
/*     */       }
/*  62 */       else if ("max".equals(entry.getKey())) {
/*  63 */         this.max = entry.getValue();
/*     */       }
/*  65 */       else if ("sum".equals(entry.getKey())) {
/*  66 */         this.sum = entry.getValue();
/*     */       }
/*  68 */       else if ("count".equals(entry.getKey())) {
/*  69 */         this.count = ((Long)entry.getValue());
/*     */       }
/*  71 */       else if ("countDistinct".equals(entry.getKey())) {
/*  72 */         this.countDistinct = ((Long)entry.getValue());
/*     */       }
/*  74 */       else if ("distinctValues".equals(entry.getKey())) {
/*  75 */         this.distinctValues = ((Collection)entry.getValue());
/*     */       }
/*  77 */       else if ("missing".equals(entry.getKey())) {
/*  78 */         this.missing = ((Long)entry.getValue());
/*     */       }
/*  80 */       else if ("mean".equals(entry.getKey())) {
/*  81 */         this.mean = entry.getValue();
/*     */       }
/*  83 */       else if ("sumOfSquares".equals(entry.getKey())) {
/*  84 */         this.sumOfSquares = ((Double)entry.getValue());
/*     */       }
/*  86 */       else if ("stddev".equals(entry.getKey())) {
/*  87 */         this.stddev = ((Double)entry.getValue());
/*     */       }
/*  89 */       else if ("facets".equals(entry.getKey()))
/*     */       {
/*  91 */         NamedList<Object> fields = (NamedList)entry.getValue();
/*  92 */         this.facets = new HashMap();
/*  93 */         for (Map.Entry<String, Object> ev : fields) {
/*  94 */           List<FieldStatsInfo> vals = new ArrayList();
/*  95 */           this.facets.put(ev.getKey(), vals);
/*     */           
/*  97 */           NamedList<NamedList<Object>> vnl = (NamedList)ev.getValue();
/*  98 */           for (int i = 0; i < vnl.size(); i++) {
/*  99 */             String n = vnl.getName(i);
/* 100 */             vals.add(new FieldStatsInfo((NamedList)vnl.getVal(i), n));
/*     */           }
/*     */         }
/* 103 */       } else if ("percentiles".equals(entry.getKey()))
/*     */       {
/* 105 */         NamedList<Object> fields = (NamedList)entry.getValue();
/* 106 */         this.percentiles = new LinkedHashMap();
/* 107 */         for (Map.Entry<String, Object> ev : fields) {
/* 108 */           this.percentiles.put(Double.valueOf(Double.parseDouble((String)ev.getKey())), (Double)ev.getValue());
/*     */         }
/* 110 */       } else if ("cardinality".equals(entry.getKey())) {
/* 111 */         this.cardinality = ((Long)entry.getValue());
/*     */       }
/*     */       else {
/* 114 */         throw new RuntimeException("unknown key: " + (String)entry.getKey() + " [" + entry.getValue() + "]");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 122 */     StringBuilder sb = new StringBuilder();
/* 123 */     sb.append(this.name);
/* 124 */     sb.append(": {");
/* 125 */     if (this.min != null) {
/* 126 */       sb.append(" min:").append(this.min);
/*     */     }
/* 128 */     if (this.max != null) {
/* 129 */       sb.append(" max:").append(this.max);
/*     */     }
/* 131 */     if (this.sum != null) {
/* 132 */       sb.append(" sum:").append(this.sum);
/*     */     }
/* 134 */     if (this.count != null) {
/* 135 */       sb.append(" count:").append(this.count);
/*     */     }
/* 137 */     if (this.countDistinct != null) {
/* 138 */       sb.append(" countDistinct:").append(this.countDistinct);
/*     */     }
/* 140 */     if (this.distinctValues != null) {
/* 141 */       sb.append(" distinctValues:").append(this.distinctValues);
/*     */     }
/* 143 */     if (this.missing != null) {
/* 144 */       sb.append(" missing:").append(this.missing);
/*     */     }
/* 146 */     if (this.mean != null) {
/* 147 */       sb.append(" mean:").append(this.mean);
/*     */     }
/* 149 */     if (this.stddev != null) {
/* 150 */       sb.append(" stddev:").append(this.stddev);
/*     */     }
/* 152 */     if (this.percentiles != null) {
/* 153 */       sb.append(" percentiles:").append(this.percentiles);
/*     */     }
/* 155 */     if (this.cardinality != null) {
/* 156 */       sb.append(" cardinality:").append(this.cardinality);
/*     */     }
/*     */     
/* 159 */     sb.append(" }");
/* 160 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 164 */     return this.name;
/*     */   }
/*     */   
/*     */   public Object getMin() {
/* 168 */     return this.min;
/*     */   }
/*     */   
/*     */   public Object getMax() {
/* 172 */     return this.max;
/*     */   }
/*     */   
/*     */   public Object getSum() {
/* 176 */     return this.sum;
/*     */   }
/*     */   
/*     */   public Long getCount() {
/* 180 */     return this.count;
/*     */   }
/*     */   
/*     */   public Long getCountDistinct()
/*     */   {
/* 185 */     return this.countDistinct;
/*     */   }
/*     */   
/*     */   public Collection<Object> getDistinctValues() {
/* 189 */     return this.distinctValues;
/*     */   }
/*     */   
/*     */   public Long getMissing() {
/* 193 */     return this.missing;
/*     */   }
/*     */   
/*     */   public Object getMean() {
/* 197 */     return this.mean;
/*     */   }
/*     */   
/*     */   public Double getStddev() {
/* 201 */     return this.stddev;
/*     */   }
/*     */   
/*     */   public Double getSumOfSquares() {
/* 205 */     return this.sumOfSquares;
/*     */   }
/*     */   
/*     */   public Map<String, List<FieldStatsInfo>> getFacets() {
/* 209 */     return this.facets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Double, Double> getPercentiles()
/*     */   {
/* 217 */     return this.percentiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Long getCardinality()
/*     */   {
/* 225 */     return this.cardinality;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\FieldStatsInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */