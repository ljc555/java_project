package org.apache.solr.common.params;

public abstract interface TermVectorParams
{
  public static final String TV_PREFIX = "tv.";
  public static final String TF = "tv.tf";
  public static final String POSITIONS = "tv.positions";
  public static final String PAYLOADS = "tv.payloads";
  public static final String OFFSETS = "tv.offsets";
  public static final String DF = "tv.df";
  public static final String TF_IDF = "tv.tf_idf";
  public static final String ALL = "tv.all";
  public static final String FIELDS = "tv.fl";
  public static final String DOC_IDS = "tv.docIds";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\TermVectorParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */