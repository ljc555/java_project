/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.solr.common.util.SuppressForbidden;
/*    */ import org.noggit.JSONUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoutingRule
/*    */   extends ZkNodeProps
/*    */ {
/*    */   private final List<DocRouter.Range> routeRanges;
/*    */   private final String routeRangesStr;
/*    */   private final String targetCollectionName;
/*    */   private final Long expireAt;
/*    */   
/*    */   public RoutingRule(String routeKey, Map<String, Object> propMap)
/*    */   {
/* 36 */     super(propMap);
/* 37 */     this.routeRangesStr = ((String)propMap.get("routeRanges"));
/* 38 */     String[] rangesArr = this.routeRangesStr.split(",");
/* 39 */     if ((rangesArr != null) && (rangesArr.length > 0)) {
/* 40 */       this.routeRanges = new ArrayList();
/* 41 */       for (String r : rangesArr) {
/* 42 */         this.routeRanges.add(DocRouter.DEFAULT.fromString(r));
/*    */       }
/*    */     } else {
/* 45 */       this.routeRanges = null;
/*    */     }
/* 47 */     this.targetCollectionName = ((String)propMap.get("targetCollection"));
/* 48 */     this.expireAt = Long.valueOf(Long.parseLong((String)propMap.get("expireAt")));
/*    */   }
/*    */   
/*    */   public List<DocRouter.Range> getRouteRanges() {
/* 52 */     return this.routeRanges;
/*    */   }
/*    */   
/*    */   public String getTargetCollectionName() {
/* 56 */     return this.targetCollectionName;
/*    */   }
/*    */   
/*    */   @SuppressForbidden(reason="For currentTimeMillis, expiry time depends on external data (should it?)")
/*    */   public static String makeExpiryAt(long timeMsFromNow) {
/* 61 */     return String.valueOf(System.currentTimeMillis() + timeMsFromNow);
/*    */   }
/*    */   
/*    */   @SuppressForbidden(reason="For currentTimeMillis, expiry time depends on external data (should it?)")
/*    */   public boolean isExpired() {
/* 66 */     return this.expireAt.longValue() < System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public String getRouteRangesStr() {
/* 70 */     return this.routeRangesStr;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 75 */     return JSONUtil.toJSON(this.propMap, -1);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\RoutingRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */