/*     */ package org.apache.solr.client.solrj.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.SolrInputField;
/*     */ import org.apache.solr.common.cloud.Slice;
/*     */ import org.apache.solr.common.util.Base64;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ import org.apache.solr.common.util.ContentStreamBase;
/*     */ import org.apache.solr.common.util.ContentStreamBase.StringStream;
/*     */ import org.apache.solr.common.util.XML;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientUtils
/*     */ {
/*     */   public static final String TEXT_XML = "application/xml; charset=UTF-8";
/*     */   
/*     */   public static Collection<ContentStream> toContentStreams(String str, String contentType)
/*     */   {
/*  52 */     if (str == null) {
/*  53 */       return null;
/*     */     }
/*  55 */     ArrayList<ContentStream> streams = new ArrayList(1);
/*  56 */     ContentStreamBase ccc = new ContentStreamBase.StringStream(str);
/*  57 */     ccc.setContentType(contentType);
/*  58 */     streams.add(ccc);
/*  59 */     return streams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeXML(SolrInputDocument doc, Writer writer)
/*     */     throws IOException
/*     */   {
/*  67 */     writer.write("<doc boost=\"" + doc.getDocumentBoost() + "\">");
/*     */     
/*  69 */     for (SolrInputField field : doc) {
/*  70 */       boost = field.getBoost();
/*  71 */       name = field.getName();
/*     */       
/*  73 */       for (Object v : field) {
/*  74 */         String update = null;
/*     */         
/*  76 */         if ((v instanceof Map))
/*     */         {
/*  78 */           for (Map.Entry<Object, Object> entry : ((Map)v).entrySet()) {
/*  79 */             update = entry.getKey().toString();
/*  80 */             v = entry.getValue();
/*  81 */             if ((v instanceof Collection)) {
/*  82 */               Collection values = (Collection)v;
/*  83 */               for (Object value : values) {
/*  84 */                 writeVal(writer, boost, name, value, update);
/*  85 */                 boost = 1.0F;
/*     */               }
/*     */             } else {
/*  88 */               writeVal(writer, boost, name, v, update);
/*  89 */               boost = 1.0F;
/*     */             }
/*     */           }
/*     */         } else {
/*  93 */           writeVal(writer, boost, name, v, update);
/*     */           
/*     */ 
/*  96 */           boost = 1.0F;
/*     */         }
/*     */       } }
/*     */     float boost;
/*     */     String name;
/* 101 */     if (doc.hasChildDocuments()) {
/* 102 */       for (SolrInputDocument childDocument : doc.getChildDocuments()) {
/* 103 */         writeXML(childDocument, writer);
/*     */       }
/*     */     }
/*     */     
/* 107 */     writer.write("</doc>");
/*     */   }
/*     */   
/*     */   private static void writeVal(Writer writer, float boost, String name, Object v, String update) throws IOException {
/* 111 */     if ((v instanceof Date)) {
/* 112 */       v = ((Date)v).toInstant().toString();
/* 113 */     } else if ((v instanceof byte[])) {
/* 114 */       byte[] bytes = (byte[])v;
/* 115 */       v = Base64.byteArrayToBase64(bytes, 0, bytes.length);
/* 116 */     } else if ((v instanceof ByteBuffer)) {
/* 117 */       ByteBuffer bytes = (ByteBuffer)v;
/* 118 */       v = Base64.byteArrayToBase64(bytes.array(), bytes.position(), bytes.limit() - bytes.position());
/*     */     }
/*     */     
/* 121 */     if (update == null) {
/* 122 */       if (boost != 1.0F) {
/* 123 */         XML.writeXML(writer, "field", v.toString(), new Object[] { "name", name, "boost", Float.valueOf(boost) });
/* 124 */       } else if (v != null) {
/* 125 */         XML.writeXML(writer, "field", v.toString(), new Object[] { "name", name });
/*     */       }
/*     */     }
/* 128 */     else if (boost != 1.0F) {
/* 129 */       XML.writeXML(writer, "field", v.toString(), new Object[] { "name", name, "boost", Float.valueOf(boost), "update", update });
/*     */     }
/* 131 */     else if (v == null) {
/* 132 */       XML.writeXML(writer, "field", null, new Object[] { "name", name, "update", update, "null", Boolean.valueOf(true) });
/*     */     } else {
/* 134 */       XML.writeXML(writer, "field", v.toString(), new Object[] { "name", name, "update", update });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toXML(SolrInputDocument doc)
/*     */   {
/* 143 */     StringWriter str = new StringWriter();
/*     */     try {
/* 145 */       writeXML(doc, str);
/*     */     }
/*     */     catch (Exception localException) {}
/* 148 */     return str.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeQueryChars(String s)
/*     */   {
/* 159 */     StringBuilder sb = new StringBuilder();
/* 160 */     for (int i = 0; i < s.length(); i++) {
/* 161 */       char c = s.charAt(i);
/*     */       
/* 163 */       if ((c == '\\') || (c == '+') || (c == '-') || (c == '!') || (c == '(') || (c == ')') || (c == ':') || (c == '^') || (c == '[') || (c == ']') || (c == '"') || (c == '{') || (c == '}') || (c == '~') || (c == '*') || (c == '?') || (c == '|') || (c == '&') || (c == ';') || (c == '/') || 
/*     */       
/*     */ 
/* 166 */         (Character.isWhitespace(c))) {
/* 167 */         sb.append('\\');
/*     */       }
/* 169 */       sb.append(c);
/*     */     }
/* 171 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static void addSlices(Map<String, Slice> target, String collectionName, Collection<Slice> slices, boolean multiCollection)
/*     */   {
/* 176 */     for (Slice slice : slices) {
/* 177 */       String key = slice.getName();
/* 178 */       if (multiCollection) key = collectionName + "_" + key;
/* 179 */       target.put(key, slice);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\util\ClientUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */