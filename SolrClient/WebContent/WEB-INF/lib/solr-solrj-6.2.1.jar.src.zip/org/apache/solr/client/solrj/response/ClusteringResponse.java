/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClusteringResponse
/*    */ {
/*    */   private static final String LABELS_NODE = "labels";
/*    */   private static final String DOCS_NODE = "docs";
/*    */   private static final String SCORE_NODE = "score";
/* 31 */   private List<Cluster> clusters = new LinkedList();
/*    */   
/*    */   public ClusteringResponse(List<NamedList<Object>> clusterInfo) {
/* 34 */     for (NamedList<Object> clusterNode : clusterInfo)
/*    */     {
/*    */ 
/* 37 */       List<String> labelList = (List)clusterNode.get("labels");
/* 38 */       double score = ((Double)clusterNode.get("score")).doubleValue();
/* 39 */       List<String> docIdList = (List)clusterNode.get("docs");
/* 40 */       Cluster currentCluster = new Cluster(labelList, score, docIdList);
/* 41 */       this.clusters.add(currentCluster);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<Cluster> getClusters() {
/* 46 */     return this.clusters;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\ClusteringResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */