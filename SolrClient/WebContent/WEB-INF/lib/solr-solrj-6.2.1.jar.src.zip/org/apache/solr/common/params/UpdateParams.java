package org.apache.solr.common.params;

public abstract interface UpdateParams
{
  public static final String OPEN_SEARCHER = "openSearcher";
  public static final String WAIT_SEARCHER = "waitSearcher";
  public static final String SOFT_COMMIT = "softCommit";
  public static final String OVERWRITE = "overwrite";
  public static final String COMMIT = "commit";
  public static final String COMMIT_WITHIN = "commitWithin";
  public static final String OPTIMIZE = "optimize";
  public static final String PREPARE_COMMIT = "prepareCommit";
  public static final String ROLLBACK = "rollback";
  public static final String COLLECTION = "collection";
  public static final String UPDATE_CHAIN = "update.chain";
  public static final String ASSUME_CONTENT_TYPE = "update.contentType";
  public static final String MAX_OPTIMIZE_SEGMENTS = "maxSegments";
  public static final String EXPUNGE_DELETES = "expungeDeletes";
  public static final String VERSIONS = "versions";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\UpdateParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */