/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiMapSolrParams
/*     */   extends SolrParams
/*     */ {
/*     */   protected final Map<String, String[]> map;
/*     */   
/*     */   public static void addParam(String name, String val, Map<String, String[]> map)
/*     */   {
/*  30 */     String[] arr = (String[])map.get(name);
/*  31 */     if (arr == null) {
/*  32 */       arr = new String[] { val };
/*     */     } else {
/*  34 */       String[] newarr = new String[arr.length + 1];
/*  35 */       System.arraycopy(arr, 0, newarr, 0, arr.length);
/*  36 */       newarr[arr.length] = val;
/*  37 */       arr = newarr;
/*     */     }
/*  39 */     map.put(name, arr);
/*     */   }
/*     */   
/*     */   public static void addParam(String name, String[] vals, Map<String, String[]> map) {
/*  43 */     String[] arr = (String[])map.put(name, vals);
/*  44 */     if (arr == null) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     String[] newarr = new String[arr.length + vals.length];
/*  49 */     System.arraycopy(arr, 0, newarr, 0, arr.length);
/*  50 */     System.arraycopy(vals, 0, newarr, arr.length, vals.length);
/*  51 */     arr = newarr;
/*     */     
/*  53 */     map.put(name, arr);
/*     */   }
/*     */   
/*     */   public MultiMapSolrParams(Map<String, String[]> map)
/*     */   {
/*  58 */     this.map = map;
/*     */   }
/*     */   
/*     */   public String get(String name)
/*     */   {
/*  63 */     String[] arr = (String[])this.map.get(name);
/*  64 */     return arr == null ? null : arr[0];
/*     */   }
/*     */   
/*     */   public String[] getParams(String name)
/*     */   {
/*  69 */     return (String[])this.map.get(name);
/*     */   }
/*     */   
/*     */   public Iterator<String> getParameterNamesIterator()
/*     */   {
/*  74 */     return this.map.keySet().iterator();
/*     */   }
/*     */   
/*  77 */   public Map<String, String[]> getMap() { return this.map; }
/*     */   
/*     */   public static Map<String, String[]> asMultiMap(SolrParams params)
/*     */   {
/*  81 */     return asMultiMap(params, false);
/*     */   }
/*     */   
/*     */   public static Map<String, String[]> asMultiMap(SolrParams params, boolean newCopy)
/*     */   {
/*  86 */     if ((params instanceof MultiMapSolrParams)) {
/*  87 */       Map<String, String[]> map = ((MultiMapSolrParams)params).getMap();
/*  88 */       if (newCopy) {
/*  89 */         return new HashMap(map);
/*     */       }
/*  91 */       return map; }
/*  92 */     if ((params instanceof ModifiableSolrParams)) {
/*  93 */       Map<String, String[]> map = ((ModifiableSolrParams)params).getMap();
/*  94 */       if (newCopy) {
/*  95 */         return new HashMap(map);
/*     */       }
/*  97 */       return map;
/*     */     }
/*  99 */     Map<String, String[]> map = new HashMap();
/* 100 */     Iterator<String> iterator = params.getParameterNamesIterator();
/* 101 */     while (iterator.hasNext()) {
/* 102 */       String name = (String)iterator.next();
/* 103 */       map.put(name, params.getParams(name));
/*     */     }
/* 105 */     return map;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\MultiMapSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */