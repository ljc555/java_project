/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContentStreamBase
/*     */   implements ContentStream
/*     */ {
/*  41 */   public static final String DEFAULT_CHARSET = StandardCharsets.UTF_8.name();
/*     */   
/*     */   protected String name;
/*     */   
/*     */   protected String sourceInfo;
/*     */   
/*     */   protected String contentType;
/*     */   
/*     */   protected Long size;
/*     */   
/*     */   public static String getCharsetFromContentType(String contentType)
/*     */   {
/*  53 */     if (contentType != null) {
/*  54 */       int idx = contentType.toLowerCase(Locale.ROOT).indexOf("charset=");
/*  55 */       if (idx > 0) {
/*  56 */         return contentType.substring(idx + "charset=".length()).trim();
/*     */       }
/*     */     }
/*  59 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class URLStream
/*     */     extends ContentStreamBase
/*     */   {
/*     */     private final URL url;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public URLStream(URL url)
/*     */     {
/*  76 */       this.url = url;
/*  77 */       this.sourceInfo = "url";
/*     */     }
/*     */     
/*     */     public InputStream getStream() throws IOException
/*     */     {
/*  82 */       URLConnection conn = this.url.openConnection();
/*     */       
/*  84 */       this.contentType = conn.getContentType();
/*  85 */       this.name = this.url.toExternalForm();
/*  86 */       this.size = new Long(conn.getContentLength());
/*  87 */       return conn.getInputStream();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class FileStream
/*     */     extends ContentStreamBase
/*     */   {
/*     */     private final File file;
/*     */     
/*     */     public FileStream(File f)
/*     */     {
/*  99 */       this.file = f;
/*     */       
/* 101 */       this.contentType = null;
/* 102 */       this.name = this.file.getName();
/* 103 */       this.size = Long.valueOf(this.file.length());
/* 104 */       this.sourceInfo = this.file.toURI().toString();
/*     */     }
/*     */     
/*     */     public String getContentType()
/*     */     {
/* 109 */       if (this.contentType == null)
/*     */       {
/* 111 */         InputStream stream = null;
/*     */         try {
/* 113 */           stream = new FileInputStream(this.file);
/* 114 */           char first = (char)stream.read();
/* 115 */           String str; if (first == '<') {
/* 116 */             return "application/xml";
/*     */           }
/* 118 */           if (first == '{') {
/* 119 */             return "application/json";
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */           return this.contentType;
/*     */         }
/*     */         catch (Exception localException) {}finally
/*     */         {
/* 123 */           if (stream != null) {
/* 124 */             try { stream.close();
/*     */             }
/*     */             catch (IOException localIOException4) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public InputStream getStream() throws IOException {
/* 133 */       return new FileInputStream(this.file);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class StringStream
/*     */     extends ContentStreamBase
/*     */   {
/*     */     private final String str;
/*     */     
/*     */ 
/*     */     public StringStream(String str)
/*     */     {
/* 146 */       this(str, detect(str));
/*     */     }
/*     */     
/*     */     public StringStream(String str, String contentType) {
/* 150 */       this.str = str;
/* 151 */       this.contentType = contentType;
/* 152 */       this.name = null;
/*     */       try {
/* 154 */         this.size = new Long(str.getBytes(DEFAULT_CHARSET).length);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 157 */         throw new RuntimeException(e);
/*     */       }
/* 159 */       this.sourceInfo = "string";
/*     */     }
/*     */     
/*     */     public static String detect(String str) {
/* 163 */       String detectedContentType = null;
/* 164 */       int lim = str.length() - 1;
/* 165 */       for (int i = 0; i < lim; i++) {
/* 166 */         char ch = str.charAt(i);
/* 167 */         if (!Character.isWhitespace(ch))
/*     */         {
/*     */ 
/*     */ 
/* 171 */           if ((ch == '#') || ((ch == '/') && (
/* 172 */             (str.charAt(i + 1) == '/') || (str.charAt(i + 1) == '*'))) || (ch == '{') || (ch == '['))
/*     */           {
/*     */ 
/*     */ 
/* 176 */             detectedContentType = "application/json"; break; }
/* 177 */           if (ch != '<') break;
/* 178 */           detectedContentType = "text/xml"; break;
/*     */         }
/*     */       }
/*     */       
/* 182 */       return detectedContentType;
/*     */     }
/*     */     
/*     */     public InputStream getStream() throws IOException
/*     */     {
/* 187 */       return new ByteArrayInputStream(this.str.getBytes(DEFAULT_CHARSET));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Reader getReader()
/*     */       throws IOException
/*     */     {
/* 196 */       String charset = getCharsetFromContentType(this.contentType);
/* 197 */       return charset == null ? new StringReader(this.str) : new InputStreamReader(
/*     */       
/* 199 */         getStream(), charset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reader getReader()
/*     */     throws IOException
/*     */   {
/* 209 */     String charset = getCharsetFromContentType(getContentType());
/* 210 */     return charset == null ? new InputStreamReader(
/* 211 */       getStream(), DEFAULT_CHARSET) : new InputStreamReader(
/* 212 */       getStream(), charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 221 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/* 225 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 230 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 234 */     this.name = name;
/*     */   }
/*     */   
/*     */   public Long getSize()
/*     */   {
/* 239 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(Long size) {
/* 243 */     this.size = size;
/*     */   }
/*     */   
/*     */   public String getSourceInfo()
/*     */   {
/* 248 */     return this.sourceInfo;
/*     */   }
/*     */   
/*     */   public void setSourceInfo(String sourceInfo) {
/* 252 */     this.sourceInfo = sourceInfo;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class ByteArrayStream
/*     */     extends ContentStreamBase
/*     */   {
/*     */     private final byte[] bytes;
/*     */     
/*     */     public ByteArrayStream(byte[] bytes, String source)
/*     */     {
/* 263 */       this.bytes = bytes;
/*     */       
/* 265 */       this.contentType = null;
/* 266 */       this.name = source;
/* 267 */       this.size = new Long(bytes.length);
/* 268 */       this.sourceInfo = source;
/*     */     }
/*     */     
/*     */     public InputStream getStream()
/*     */       throws IOException
/*     */     {
/* 274 */       return new ByteArrayInputStream(this.bytes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\ContentStreamBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */