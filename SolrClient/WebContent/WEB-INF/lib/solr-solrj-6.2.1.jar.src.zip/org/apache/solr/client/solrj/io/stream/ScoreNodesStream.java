/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.client.solrj.request.QueryRequest;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScoreNodesStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected String zkHost;
/*     */   private TupleStream stream;
/*     */   private transient SolrClientCache clientCache;
/*  65 */   private Map<String, Tuple> nodes = new HashMap();
/*     */   private Iterator<Tuple> tuples;
/*     */   private String termFreq;
/*     */   
/*     */   public ScoreNodesStream(TupleStream tupleStream, String nodeFreqField) throws IOException {
/*  70 */     init(tupleStream, nodeFreqField);
/*     */   }
/*     */   
/*     */   public ScoreNodesStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  75 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  76 */     StreamExpressionNamedParameter nodeFreqParam = factory.getNamedOperand(expression, "termFreq");
/*     */     
/*  78 */     String docFreqField = "count(*)";
/*  79 */     if (nodeFreqParam != null) {
/*  80 */       docFreqField = nodeFreqParam.getParameter().toString();
/*     */     }
/*     */     
/*  83 */     if (1 != streamExpressions.size()) {
/*  84 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  87 */     this.zkHost = factory.getDefaultZkHost();
/*     */     
/*  89 */     if (null == this.zkHost) {
/*  90 */       throw new IOException("zkHost not found");
/*     */     }
/*     */     
/*  93 */     TupleStream stream = factory.constructStream((StreamExpression)streamExpressions.get(0));
/*     */     
/*  95 */     init(stream, docFreqField);
/*     */   }
/*     */   
/*     */   private void init(TupleStream tupleStream, String termFreq) throws IOException {
/*  99 */     this.stream = tupleStream;
/* 100 */     this.termFreq = termFreq;
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 105 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 110 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 113 */     expression.addParameter(new StreamExpressionNamedParameter("termFreq", this.termFreq));
/*     */     
/* 115 */     if (includeStreams)
/*     */     {
/* 117 */       if ((this.stream instanceof Expressible)) {
/* 118 */         expression.addParameter(((Expressible)this.stream).toExpression(factory));
/*     */       }
/*     */       else {
/* 121 */         throw new IOException("This ScoreNodesStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 125 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/* 128 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 134 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.stream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString());
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 145 */     this.clientCache = context.getSolrClientCache();
/* 146 */     this.stream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 150 */     List<TupleStream> l = new ArrayList();
/* 151 */     l.add(this.stream);
/* 152 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 156 */     this.stream.open();
/* 157 */     Tuple node = null;
/* 158 */     StringBuilder builder = new StringBuilder();
/* 159 */     String field = null;
/* 160 */     String collection = null;
/*     */     for (;;) {
/* 162 */       node = this.stream.read();
/* 163 */       if (node.EOF) {
/*     */         break;
/*     */       }
/*     */       
/* 167 */       if (!node.fields.containsKey("node")) {
/* 168 */         throw new IOException("node field not present in the Tuple");
/*     */       }
/*     */       
/* 171 */       String nodeId = node.getString("node");
/*     */       
/*     */ 
/* 174 */       this.nodes.put(nodeId, node);
/* 175 */       if (builder.length() > 0) {
/* 176 */         builder.append(",");
/* 177 */         field = node.getString("field");
/* 178 */         collection = node.getString("collection");
/*     */       }
/* 180 */       builder.append(nodeId);
/*     */     }
/*     */     
/* 183 */     CloudSolrClient client = this.clientCache.getCloudSolrClient(this.zkHost);
/* 184 */     ModifiableSolrParams params = new ModifiableSolrParams();
/* 185 */     params.add("qt", new String[] { "/terms" });
/* 186 */     params.add("terms", new String[] { "true" });
/* 187 */     params.add("terms.fl", new String[] { field });
/* 188 */     params.add("terms.stats", new String[] { "true" });
/* 189 */     params.add("terms.list", new String[] { builder.toString() });
/* 190 */     params.add("terms.limit", new String[] { Integer.toString(this.nodes.size()) });
/* 191 */     params.add("distrib", new String[] { "true" });
/*     */     
/* 193 */     QueryRequest request = new QueryRequest(params);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 199 */       NamedList response = client.request(request, collection);
/* 200 */       NamedList<Number> stats = (NamedList)response.get("indexstats");
/* 201 */       long numDocs = ((Number)stats.get("numDocs")).longValue();
/* 202 */       NamedList<NamedList<Number>> fields = (NamedList)response.get("terms");
/*     */       
/* 204 */       int size = fields.size();
/* 205 */       for (int i = 0; i < size; i++) {
/* 206 */         String fieldName = fields.getName(i);
/* 207 */         NamedList<Number> terms = (NamedList)fields.get(fieldName);
/* 208 */         int tsize = terms.size();
/* 209 */         for (int t = 0; t < tsize; t++) {
/* 210 */           String term = terms.getName(t);
/* 211 */           Number docFreq = (Number)terms.get(term);
/* 212 */           Tuple tuple = (Tuple)this.nodes.get(term);
/* 213 */           if (!tuple.fields.containsKey(this.termFreq)) {
/* 214 */             throw new Exception("termFreq field not present in the Tuple");
/*     */           }
/* 216 */           Number termFreqValue = (Number)tuple.get(this.termFreq);
/* 217 */           float score = termFreqValue.floatValue() * (float)(Math.log((numDocs + 1L) / (docFreq.doubleValue() + 1.0D)) + 1.0D);
/* 218 */           tuple.put("nodeScore", Float.valueOf(score));
/* 219 */           tuple.put("docFreq", docFreq);
/* 220 */           tuple.put("numDocs", Long.valueOf(numDocs));
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 224 */       throw new IOException(e);
/*     */     }
/*     */     
/* 227 */     this.tuples = this.nodes.values().iterator();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 231 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public StreamComparator getComparator() {
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException {
/* 239 */     if (this.tuples.hasNext()) {
/* 240 */       return (Tuple)this.tuples.next();
/*     */     }
/* 242 */     Map map = new HashMap();
/* 243 */     map.put("EOF", Boolean.valueOf(true));
/* 244 */     return new Tuple(map);
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 249 */     return null;
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 253 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\ScoreNodesStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */