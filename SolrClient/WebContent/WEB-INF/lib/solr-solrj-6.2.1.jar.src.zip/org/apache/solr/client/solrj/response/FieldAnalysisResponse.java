/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldAnalysisResponse
/*     */   extends AnalysisResponseBase
/*     */ {
/*  34 */   private Map<String, Analysis> analysisByFieldTypeName = new HashMap();
/*  35 */   private Map<String, Analysis> analysisByFieldName = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(NamedList<Object> response)
/*     */   {
/*  42 */     super.setResponse(response);
/*     */     
/*     */ 
/*     */ 
/*  46 */     NamedList<NamedList<NamedList<NamedList<List<NamedList<Object>>>>>> analysisNL = (NamedList)response.get("analysis");
/*     */     
/*     */ 
/*  49 */     for (Map.Entry<String, NamedList<NamedList<List<NamedList<Object>>>>> entry : (NamedList)analysisNL.get("field_types"))
/*     */     {
/*  51 */       this.analysisByFieldTypeName.put(entry.getKey(), buildAnalysis((NamedList)entry.getValue()));
/*     */     }
/*     */     
/*     */ 
/*  55 */     for (Map.Entry<String, NamedList<NamedList<List<NamedList<Object>>>>> entry : (NamedList)analysisNL.get("field_names"))
/*     */     {
/*  57 */       this.analysisByFieldName.put(entry.getKey(), buildAnalysis((NamedList)entry.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   private Analysis buildAnalysis(NamedList<NamedList<List<NamedList<Object>>>> value) {
/*  62 */     Analysis analysis = new Analysis(null);
/*     */     
/*  64 */     NamedList<List<NamedList<Object>>> queryNL = (NamedList)value.get("query");
/*  65 */     List<AnalysisResponseBase.AnalysisPhase> phases = queryNL == null ? null : buildPhases(queryNL);
/*  66 */     analysis.setQueryPhases(phases);
/*     */     
/*  68 */     NamedList<List<NamedList<Object>>> indexNL = (NamedList)value.get("index");
/*  69 */     phases = buildPhases(indexNL);
/*  70 */     analysis.setIndexPhases(phases);
/*     */     
/*  72 */     return analysis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldTypeAnalysisCount()
/*     */   {
/*  81 */     return this.analysisByFieldTypeName.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Analysis getFieldTypeAnalysis(String fieldTypeName)
/*     */   {
/*  92 */     return (Analysis)this.analysisByFieldTypeName.get(fieldTypeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterable<Map.Entry<String, Analysis>> getAllFieldTypeAnalysis()
/*     */   {
/* 101 */     return this.analysisByFieldTypeName.entrySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldNameAnalysisCount()
/*     */   {
/* 110 */     return this.analysisByFieldName.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Analysis getFieldNameAnalysis(String fieldName)
/*     */   {
/* 121 */     return (Analysis)this.analysisByFieldName.get(fieldName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterable<Map.Entry<String, Analysis>> getAllFieldNameAnalysis()
/*     */   {
/* 130 */     return this.analysisByFieldName.entrySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Analysis
/*     */   {
/*     */     private List<AnalysisResponseBase.AnalysisPhase> queryPhases;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private List<AnalysisResponseBase.AnalysisPhase> indexPhases;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getQueryPhasesCount()
/*     */     {
/* 159 */       return this.queryPhases == null ? -1 : this.queryPhases.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterable<AnalysisResponseBase.AnalysisPhase> getQueryPhases()
/*     */     {
/* 172 */       return this.queryPhases;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getIndexPhasesCount()
/*     */     {
/* 181 */       return this.indexPhases.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterable<AnalysisResponseBase.AnalysisPhase> getIndexPhases()
/*     */     {
/* 190 */       return this.indexPhases;
/*     */     }
/*     */     
/*     */     private void setQueryPhases(List<AnalysisResponseBase.AnalysisPhase> queryPhases) {
/* 194 */       this.queryPhases = queryPhases;
/*     */     }
/*     */     
/*     */     private void setIndexPhases(List<AnalysisResponseBase.AnalysisPhase> indexPhases) {
/* 198 */       this.indexPhases = indexPhases;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\FieldAnalysisResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */