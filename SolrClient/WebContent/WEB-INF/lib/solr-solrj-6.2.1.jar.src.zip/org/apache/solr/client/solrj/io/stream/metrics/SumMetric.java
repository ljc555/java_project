/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SumMetric
/*    */   extends Metric
/*    */ {
/*    */   private String columnName;
/*    */   private double doubleSum;
/*    */   private long longSum;
/*    */   
/*    */   public SumMetric(String columnName)
/*    */   {
/* 33 */     init("sum", columnName);
/*    */   }
/*    */   
/*    */   public SumMetric(StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 38 */     String functionName = expression.getFunctionName();
/* 39 */     String columnName = factory.getValueOperand(expression, 0);
/*    */     
/*    */ 
/* 42 */     if (null == columnName) {
/* 43 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expected %s(columnName)", new Object[] { expression, functionName }));
/*    */     }
/* 45 */     if (1 != expression.getParameters().size()) {
/* 46 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*    */     }
/*    */     
/* 49 */     init(functionName, columnName);
/*    */   }
/*    */   
/*    */   private void init(String functionName, String columnName) {
/* 53 */     this.columnName = columnName;
/* 54 */     setFunctionName(functionName);
/* 55 */     setIdentifier(new String[] { functionName, "(", columnName, ")" });
/*    */   }
/*    */   
/*    */   public String[] getColumns() {
/* 59 */     return new String[] { this.columnName };
/*    */   }
/*    */   
/*    */   public void update(Tuple tuple) {
/* 63 */     Object o = tuple.get(this.columnName);
/* 64 */     if ((o instanceof Double)) {
/* 65 */       Double d = (Double)o;
/* 66 */       this.doubleSum += d.doubleValue();
/*    */     } else {
/* 68 */       Long l = (Long)o;
/* 69 */       this.longSum += l.longValue();
/*    */     }
/*    */   }
/*    */   
/*    */   public Metric newInstance() {
/* 74 */     return new SumMetric(this.columnName);
/*    */   }
/*    */   
/*    */   public Number getValue() {
/* 78 */     if (this.longSum == 0L) {
/* 79 */       return Double.valueOf(this.doubleSum);
/*    */     }
/* 81 */     return Long.valueOf(this.longSum);
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory)
/*    */     throws IOException
/*    */   {
/* 87 */     return new StreamExpression(getFunctionName()).withParameter(this.columnName);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\SumMetric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */