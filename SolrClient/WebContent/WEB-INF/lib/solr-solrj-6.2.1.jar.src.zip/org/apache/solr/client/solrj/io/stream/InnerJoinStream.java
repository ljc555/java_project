/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InnerJoinStream
/*     */   extends BiJoinStream
/*     */   implements Expressible
/*     */ {
/*  36 */   private LinkedList<Tuple> joinedTuples = new LinkedList();
/*  37 */   private LinkedList<Tuple> leftTupleGroup = new LinkedList();
/*  38 */   private LinkedList<Tuple> rightTupleGroup = new LinkedList();
/*     */   
/*     */   public InnerJoinStream(TupleStream leftStream, TupleStream rightStream, StreamEqualitor eq) throws IOException {
/*  41 */     super(leftStream, rightStream, eq);
/*     */   }
/*     */   
/*     */   public InnerJoinStream(StreamExpression expression, StreamFactory factory) throws IOException {
/*  45 */     super(expression, factory);
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*  50 */     if (this.joinedTuples.size() > 0) {
/*  51 */       return (Tuple)this.joinedTuples.removeFirst();
/*     */     }
/*     */     
/*     */     for (;;)
/*     */     {
/*  56 */       if (0 == this.leftTupleGroup.size()) {
/*  57 */         Tuple firstMember = loadEqualTupleGroup(this.leftStream, this.leftTupleGroup, this.leftStreamComparator);
/*     */         
/*     */ 
/*  60 */         if (firstMember.EOF) {
/*  61 */           return firstMember;
/*     */         }
/*     */       }
/*     */       Tuple firstMember;
/*  65 */       if (0 == this.rightTupleGroup.size()) {
/*  66 */         firstMember = loadEqualTupleGroup(this.rightStream, this.rightTupleGroup, this.rightStreamComparator);
/*     */         
/*     */ 
/*  69 */         if (firstMember.EOF) {
/*  70 */           return firstMember;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  75 */       if (this.eq.test(this.leftTupleGroup.get(0), this.rightTupleGroup.get(0)))
/*     */       {
/*  77 */         for (firstMember = this.leftTupleGroup.iterator(); firstMember.hasNext();) { left = (Tuple)firstMember.next();
/*  78 */           for (Tuple right : this.rightTupleGroup) {
/*  79 */             Tuple clone = left.clone();
/*  80 */             clone.merge(right);
/*  81 */             this.joinedTuples.add(clone);
/*     */           }
/*     */         }
/*     */         
/*     */         Tuple left;
/*  86 */         this.leftTupleGroup.clear();
/*  87 */         this.rightTupleGroup.clear();
/*     */         
/*  89 */         return (Tuple)this.joinedTuples.removeFirst();
/*     */       }
/*  91 */       int c = this.iterationComparator.compare(this.leftTupleGroup.get(0), this.rightTupleGroup.get(0));
/*  92 */       if (c < 0)
/*     */       {
/*  94 */         this.leftTupleGroup.clear();
/*     */       }
/*     */       else {
/*  97 */         this.rightTupleGroup.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 106 */     return this.iterationComparator;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\InnerJoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */