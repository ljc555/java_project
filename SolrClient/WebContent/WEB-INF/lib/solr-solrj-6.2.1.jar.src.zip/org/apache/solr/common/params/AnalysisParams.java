package org.apache.solr.common.params;

public abstract interface AnalysisParams
{
  public static final String PREFIX = "analysis";
  public static final String QUERY = "analysis.query";
  public static final String SHOW_MATCH = "analysis.showmatch";
  public static final String FIELD_NAME = "analysis.fieldname";
  public static final String FIELD_TYPE = "analysis.fieldtype";
  public static final String FIELD_VALUE = "analysis.fieldvalue";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\AnalysisParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */