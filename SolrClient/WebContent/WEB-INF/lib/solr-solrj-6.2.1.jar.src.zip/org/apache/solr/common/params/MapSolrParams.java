/*    */ package org.apache.solr.common.params;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapSolrParams
/*    */   extends SolrParams
/*    */ {
/*    */   protected final Map<String, String> map;
/*    */   
/*    */   public MapSolrParams(Map<String, String> map)
/*    */   {
/* 29 */     this.map = map;
/*    */   }
/*    */   
/*    */   public String get(String name)
/*    */   {
/* 34 */     Object o = this.map.get(name);
/* 35 */     if (o == null) return null;
/* 36 */     if ((o instanceof String)) return (String)o;
/* 37 */     if ((o instanceof String[])) {
/* 38 */       String[] strings = (String[])o;
/* 39 */       if (strings.length == 0) return null;
/* 40 */       return strings[0];
/*    */     }
/* 42 */     return String.valueOf(o);
/*    */   }
/*    */   
/*    */   public String[] getParams(String name)
/*    */   {
/* 47 */     Object val = this.map.get(name);
/* 48 */     if ((val instanceof String[])) return (String[])val;
/* 49 */     return new String[] { val == null ? null : String.valueOf(val) };
/*    */   }
/*    */   
/*    */   public Iterator<String> getParameterNamesIterator()
/*    */   {
/* 54 */     return this.map.keySet().iterator();
/*    */   }
/*    */   
/* 57 */   public Map<String, String> getMap() { return this.map; }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\MapSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */