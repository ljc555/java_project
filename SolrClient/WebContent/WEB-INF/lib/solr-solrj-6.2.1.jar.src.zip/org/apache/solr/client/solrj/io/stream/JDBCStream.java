/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  70 */   private static HashSet<String> directSupportedTypes = new HashSet();
/*     */   
/*  72 */   static { directSupportedTypes.add(String.class.getName());
/*  73 */     directSupportedTypes.add(Double.class.getName());
/*  74 */     directSupportedTypes.add(Long.class.getName());
/*  75 */     directSupportedTypes.add(Boolean.class.getName());
/*     */   }
/*     */   
/*     */ 
/*     */   private String driverClassName;
/*     */   
/*     */   private String connectionUrl;
/*     */   private String sqlQuery;
/*     */   private StreamComparator definedSort;
/*     */   private Connection connection;
/*     */   private Properties connectionProperties;
/*     */   private Statement statement;
/*     */   private ResultSet resultSet;
/*     */   private ResultSetValueSelector[] valueSelectors;
/*     */   protected transient StreamContext streamContext;
/*     */   public JDBCStream(String connectionUrl, String sqlQuery, StreamComparator definedSort)
/*     */     throws IOException
/*     */   {
/*  93 */     this(connectionUrl, sqlQuery, definedSort, null, null);
/*     */   }
/*     */   
/*     */   public JDBCStream(String connectionUrl, String sqlQuery, StreamComparator definedSort, Properties connectionProperties, String driverClassName) throws IOException {
/*  97 */     init(connectionUrl, sqlQuery, definedSort, connectionProperties, driverClassName);
/*     */   }
/*     */   
/*     */   public JDBCStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/* 102 */     List<StreamExpressionNamedParameter> namedParams = factory.getNamedOperands(expression);
/* 103 */     StreamExpressionNamedParameter connectionUrlExpression = factory.getNamedOperand(expression, "connection");
/* 104 */     StreamExpressionNamedParameter sqlQueryExpression = factory.getNamedOperand(expression, "sql");
/* 105 */     StreamExpressionNamedParameter definedSortExpression = factory.getNamedOperand(expression, "sort");
/* 106 */     StreamExpressionNamedParameter driverClassNameExpression = factory.getNamedOperand(expression, "driver");
/*     */     
/*     */ 
/* 109 */     if (expression.getParameters().size() != namedParams.size()) {
/* 110 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/* 114 */     Properties connectionProperties = new Properties();
/* 115 */     for (StreamExpressionNamedParameter namedParam : namedParams) {
/* 116 */       if ((!namedParam.getName().equals("driver")) && (!namedParam.getName().equals("connection")) && (!namedParam.getName().equals("sql")) && (!namedParam.getName().equals("sort"))) {
/* 117 */         connectionProperties.put(namedParam.getName(), namedParam.getParameter().toString().trim());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 122 */     String connectionUrl = null;
/* 123 */     if ((null != connectionUrlExpression) && ((connectionUrlExpression.getParameter() instanceof StreamExpressionValue))) {
/* 124 */       connectionUrl = ((StreamExpressionValue)connectionUrlExpression.getParameter()).getValue();
/*     */     }
/* 126 */     if (null == connectionUrl) {
/* 127 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - connection not found", new Object[0]));
/*     */     }
/*     */     
/*     */ 
/* 131 */     String sqlQuery = null;
/* 132 */     if ((null != sqlQueryExpression) && ((sqlQueryExpression.getParameter() instanceof StreamExpressionValue))) {
/* 133 */       sqlQuery = ((StreamExpressionValue)sqlQueryExpression.getParameter()).getValue();
/*     */     }
/* 135 */     if (null == sqlQuery) {
/* 136 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - sql not found", new Object[0]));
/*     */     }
/*     */     
/*     */ 
/* 140 */     StreamComparator definedSort = null;
/* 141 */     if ((null != sqlQueryExpression) && ((sqlQueryExpression.getParameter() instanceof StreamExpressionValue))) {
/* 142 */       definedSort = factory.constructComparator(((StreamExpressionValue)definedSortExpression.getParameter()).getValue(), FieldComparator.class);
/*     */     }
/* 144 */     if (null == definedSort) {
/* 145 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - sort not found", new Object[0]));
/*     */     }
/*     */     
/*     */ 
/* 149 */     String driverClass = null;
/* 150 */     if ((null != driverClassNameExpression) && ((driverClassNameExpression.getParameter() instanceof StreamExpressionValue))) {
/* 151 */       driverClass = ((StreamExpressionValue)driverClassNameExpression.getParameter()).getValue();
/*     */     }
/*     */     
/*     */ 
/* 155 */     init(connectionUrl, sqlQuery, definedSort, connectionProperties, driverClass);
/*     */   }
/*     */   
/*     */   private void init(String connectionUrl, String sqlQuery, StreamComparator definedSort, Properties connectionProperties, String driverClassName) throws IOException {
/* 159 */     this.connectionUrl = connectionUrl;
/* 160 */     this.sqlQuery = sqlQuery;
/* 161 */     this.definedSort = definedSort;
/* 162 */     this.connectionProperties = connectionProperties;
/* 163 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 167 */     this.streamContext = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 177 */       if (null != this.driverClassName) {
/* 178 */         Class.forName(this.driverClassName);
/*     */       }
/*     */     } catch (ClassNotFoundException e) {
/* 181 */       throw new IOException(String.format(Locale.ROOT, "Failed to load JDBC driver for '%s'", new Object[] { this.driverClassName }), e);
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 187 */       if (null == DriverManager.getDriver(this.connectionUrl)) {
/* 188 */         throw new SQLException("DriverManager.getDriver(url) returned null");
/*     */       }
/*     */     } catch (SQLException e) {
/* 191 */       throw new IOException(String.format(Locale.ROOT, "Failed to determine JDBC driver from connection url '%s'. Usually this means the driver is not loaded - you can have JDBCStream try to load it by providing the 'driverClassName' value", new Object[] { this.connectionUrl }), e);
/*     */     }
/*     */     try
/*     */     {
/* 195 */       this.connection = DriverManager.getConnection(this.connectionUrl, this.connectionProperties);
/*     */     } catch (SQLException e) {
/* 197 */       throw new IOException(String.format(Locale.ROOT, "Failed to open JDBC connection to '%s'", new Object[] { this.connectionUrl }), e);
/*     */     }
/*     */     try
/*     */     {
/* 201 */       this.statement = this.connection.createStatement();
/*     */     } catch (SQLException e) {
/* 203 */       throw new IOException(String.format(Locale.ROOT, "Failed to create a statement from JDBC connection '%s'", new Object[] { this.connectionUrl }), e);
/*     */     }
/*     */     try
/*     */     {
/* 207 */       this.resultSet = this.statement.executeQuery(this.sqlQuery);
/*     */     } catch (SQLException e) {
/* 209 */       throw new IOException(String.format(Locale.ROOT, "Failed to execute sqlQuery '%s' against JDBC connection '%s'", new Object[] { this.sqlQuery, this.connectionUrl }), e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 214 */       this.valueSelectors = constructValueSelectors(this.resultSet.getMetaData());
/*     */     } catch (SQLException e) {
/* 216 */       throw new IOException(String.format(Locale.ROOT, "Failed to generate value selectors for sqlQuery '%s' against JDBC connection '%s'", new Object[] { this.sqlQuery, this.connectionUrl }), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private ResultSetValueSelector[] constructValueSelectors(ResultSetMetaData metadata) throws SQLException {
/* 221 */     ResultSetValueSelector[] valueSelectors = new ResultSetValueSelector[metadata.getColumnCount()];
/*     */     
/* 223 */     for (int columnIdx = 0; columnIdx < metadata.getColumnCount(); columnIdx++)
/*     */     {
/* 225 */       final int columnNumber = columnIdx + 1;
/* 226 */       final String columnName = metadata.getColumnName(columnNumber);
/* 227 */       String className = metadata.getColumnClassName(columnNumber);
/* 228 */       String typeName = metadata.getColumnTypeName(columnNumber);
/*     */       
/* 230 */       if (directSupportedTypes.contains(className)) {
/* 231 */         valueSelectors[columnIdx = new ResultSetValueSelector() {
/*     */           public Object selectValue(ResultSet resultSet) throws SQLException {
/* 233 */             Object obj = resultSet.getObject(columnNumber);
/* 234 */             if (resultSet.wasNull()) return null;
/* 235 */             return obj;
/*     */           }
/*     */           
/* 238 */           public String getColumnName() { return columnName;
/*     */           }
/*     */ 
/*     */         };
/* 242 */       } else if (Short.class.getName() == className) {
/* 243 */         valueSelectors[columnIdx = new ResultSetValueSelector() {
/*     */           public Object selectValue(ResultSet resultSet) throws SQLException {
/* 245 */             Short obj = Short.valueOf(resultSet.getShort(columnNumber));
/* 246 */             if (resultSet.wasNull()) return null;
/* 247 */             return Long.valueOf(obj.longValue());
/*     */           }
/*     */           
/* 250 */           public String getColumnName() { return columnName;
/*     */           }
/*     */ 
/*     */         };
/* 254 */       } else if (Integer.class.getName() == className) {
/* 255 */         valueSelectors[columnIdx = new ResultSetValueSelector() {
/*     */           public Object selectValue(ResultSet resultSet) throws SQLException {
/* 257 */             Integer obj = Integer.valueOf(resultSet.getInt(columnNumber));
/* 258 */             if (resultSet.wasNull()) return null;
/* 259 */             return Long.valueOf(obj.longValue());
/*     */           }
/*     */           
/* 262 */           public String getColumnName() { return columnName;
/*     */           }
/*     */ 
/*     */         };
/* 266 */       } else if (Float.class.getName() == className) {
/* 267 */         valueSelectors[columnIdx = new ResultSetValueSelector() {
/*     */           public Object selectValue(ResultSet resultSet) throws SQLException {
/* 269 */             Float obj = Float.valueOf(resultSet.getFloat(columnNumber));
/* 270 */             if (resultSet.wasNull()) return null;
/* 271 */             return Double.valueOf(obj.doubleValue());
/*     */           }
/*     */           
/* 274 */           public String getColumnName() { return columnName;
/*     */           }
/*     */ 
/*     */         };
/*     */       } else {
/* 279 */         throw new SQLException(String.format(Locale.ROOT, "Unable to determine the valueSelector for column '%s' (col #%d) of java class '%s' and type '%s'", new Object[] { columnName, Integer.valueOf(columnNumber), className, typeName }));
/*     */       }
/*     */     }
/*     */     
/* 283 */     return valueSelectors;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 291 */       if (null != this.resultSet) {
/* 292 */         this.resultSet.close();
/*     */       }
/* 294 */       if ((null != this.statement) && (!this.statement.isClosed())) {
/* 295 */         this.statement.close();
/*     */       }
/* 297 */       if ((null != this.connection) && (!this.connection.isClosed())) {
/* 298 */         this.connection.close();
/*     */       }
/*     */     } catch (SQLException e) {
/* 301 */       throw new IOException("Failed to properly close JDBCStream", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*     */     try {
/* 308 */       Map<Object, Object> fields = new HashMap();
/* 309 */       if (this.resultSet.next())
/*     */       {
/* 311 */         for (ResultSetValueSelector selector : this.valueSelectors) {
/* 312 */           fields.put(selector.getColumnName(), selector.selectValue(this.resultSet));
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 317 */         fields.put("EOF", Boolean.valueOf(true));
/*     */       }
/*     */       
/* 320 */       return new Tuple(fields);
/*     */     }
/*     */     catch (SQLException e) {
/* 323 */       throw new IOException(String.format(Locale.ROOT, "Failed to read next record with error '%s'", new Object[] { e.getMessage() }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 332 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 335 */     expression.addParameter(new StreamExpressionNamedParameter("connection", this.connectionUrl));
/*     */     
/*     */ 
/* 338 */     expression.addParameter(new StreamExpressionNamedParameter("sql", this.sqlQuery));
/*     */     
/*     */ 
/* 341 */     expression.addParameter(new StreamExpressionNamedParameter("sort", this.definedSort.toExpression(factory)));
/*     */     
/*     */ 
/* 344 */     if (null != this.driverClassName) {
/* 345 */       expression.addParameter(new StreamExpressionNamedParameter("driver", this.driverClassName));
/*     */     }
/*     */     
/*     */ 
/* 349 */     if (null != this.connectionProperties) {
/* 350 */       for (String propertyName : this.connectionProperties.stringPropertyNames()) {
/* 351 */         expression.addParameter(new StreamExpressionNamedParameter(propertyName, this.connectionProperties.getProperty(propertyName)));
/*     */       }
/*     */     }
/*     */     
/* 355 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 361 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId().toString());
/*     */     
/* 363 */     explanation.setFunctionName(factory.getFunctionName(getClass()));
/* 364 */     explanation.setImplementingClass(getClass().getName());
/* 365 */     explanation.setExpressionType("stream-source");
/*     */     
/* 367 */     StreamExpression expression = (StreamExpression)toExpression(factory);
/* 368 */     explanation.setExpression(expression.toString());
/*     */     
/* 370 */     String driverClassName = this.driverClassName;
/* 371 */     if (null == driverClassName) {
/*     */       try {
/* 373 */         driverClassName = DriverManager.getDriver(this.connectionUrl).getClass().getName();
/*     */       }
/*     */       catch (Exception e) {
/* 376 */         driverClassName = String.format(Locale.ROOT, "Failed to find driver for connectionUrl='%s'", new Object[] { this.connectionUrl });
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 381 */     StreamExplanation child = new StreamExplanation(getStreamNodeId() + "-datastore");
/* 382 */     child.setFunctionName("jdbc-source");
/* 383 */     child.setImplementingClass(driverClassName);
/* 384 */     child.setExpressionType("datastore");
/* 385 */     child.setExpression(this.sqlQuery);
/*     */     
/* 387 */     explanation.addChild(child);
/*     */     
/* 389 */     return explanation;
/*     */   }
/*     */   
/*     */   public List<TupleStream> children()
/*     */   {
/* 394 */     return new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 402 */     return this.definedSort;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\JDBCStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */