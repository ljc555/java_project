/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import org.apache.zookeeper.CreateMode;
/*     */ import org.apache.zookeeper.KeeperException;
/*     */ import org.apache.zookeeper.KeeperException.ConnectionLossException;
/*     */ import org.apache.zookeeper.KeeperException.NodeExistsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZkCmdExecutor
/*     */ {
/*  25 */   private long retryDelay = 1500L;
/*     */   
/*     */ 
/*     */ 
/*     */   private int retryCount;
/*     */   
/*     */ 
/*     */   private double timeouts;
/*     */   
/*     */ 
/*     */ 
/*     */   public ZkCmdExecutor(int timeoutms)
/*     */   {
/*  38 */     this.timeouts = (timeoutms / 1000.0D);
/*  39 */     this.retryCount = (Math.round(0.5F * ((float)Math.sqrt(8.0D * this.timeouts + 1.0D) - 1.0F)) + 1);
/*     */   }
/*     */   
/*     */   public long getRetryDelay() {
/*  43 */     return this.retryDelay;
/*     */   }
/*     */   
/*     */   public void setRetryDelay(long retryDelay) {
/*  47 */     this.retryDelay = retryDelay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T retryOperation(ZkOperation operation)
/*     */     throws KeeperException, InterruptedException
/*     */   {
/*  57 */     KeeperException exception = null;
/*  58 */     for (int i = 0; i < this.retryCount; i++) {
/*     */       try {
/*  60 */         return (T)operation.execute();
/*     */       } catch (KeeperException.ConnectionLossException e) {
/*  62 */         if (exception == null) {
/*  63 */           exception = e;
/*     */         }
/*  65 */         if (Thread.currentThread().isInterrupted()) {
/*  66 */           Thread.currentThread().interrupt();
/*  67 */           throw new InterruptedException();
/*     */         }
/*  69 */         if (i != this.retryCount - 1) {
/*  70 */           retryDelay(i);
/*     */         }
/*     */       }
/*     */     }
/*  74 */     throw exception;
/*     */   }
/*     */   
/*     */   public void ensureExists(String path, SolrZkClient zkClient) throws KeeperException, InterruptedException {
/*  78 */     ensureExists(path, null, CreateMode.PERSISTENT, zkClient);
/*     */   }
/*     */   
/*     */   public void ensureExists(String path, byte[] data, CreateMode createMode, SolrZkClient zkClient)
/*     */     throws KeeperException, InterruptedException
/*     */   {
/*  84 */     if (zkClient.exists(path, true).booleanValue()) {
/*  85 */       return;
/*     */     }
/*     */     try {
/*  88 */       zkClient.makePath(path, data, createMode, true);
/*     */     }
/*     */     catch (KeeperException.NodeExistsException localNodeExistsException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void retryDelay(int attemptCount)
/*     */     throws InterruptedException
/*     */   {
/* 102 */     Thread.sleep((attemptCount + 1) * this.retryDelay);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkCmdExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */