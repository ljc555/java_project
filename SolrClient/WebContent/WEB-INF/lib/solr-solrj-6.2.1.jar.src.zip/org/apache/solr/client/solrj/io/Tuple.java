/*     */ package org.apache.solr.client.solrj.io;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple
/*     */   implements Cloneable
/*     */ {
/*     */   public boolean EOF;
/*     */   public boolean EXCEPTION;
/*  45 */   public Map fields = new HashMap();
/*     */   
/*     */   public Tuple(Map fields) {
/*  48 */     if (fields.containsKey("EOF")) {
/*  49 */       this.EOF = true;
/*     */     }
/*     */     
/*  52 */     if (fields.containsKey("EXCEPTION")) {
/*  53 */       this.EXCEPTION = true;
/*     */     }
/*     */     
/*  56 */     this.fields.putAll(fields);
/*     */   }
/*     */   
/*     */   public Object get(Object key) {
/*  60 */     return this.fields.get(key);
/*     */   }
/*     */   
/*     */   public void put(Object key, Object value) {
/*  64 */     this.fields.put(key, value);
/*     */   }
/*     */   
/*     */   public void remove(Object key) {
/*  68 */     this.fields.remove(key);
/*     */   }
/*     */   
/*     */   public String getString(Object key) {
/*  72 */     return String.valueOf(this.fields.get(key));
/*     */   }
/*     */   
/*  75 */   public String getException() { return (String)this.fields.get("EXCEPTION"); }
/*     */   
/*     */   public Long getLong(Object key) {
/*  78 */     Object o = this.fields.get(key);
/*     */     
/*  80 */     if (o == null) {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     if ((o instanceof Long)) {
/*  85 */       return (Long)o;
/*     */     }
/*     */     
/*  88 */     return Long.valueOf(Long.parseLong(o.toString()));
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean getBool(Object key)
/*     */   {
/*  94 */     Object o = this.fields.get(key);
/*     */     
/*  96 */     if (o == null) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     if ((o instanceof Boolean)) {
/* 101 */       return (Boolean)o;
/*     */     }
/*     */     
/* 104 */     return Boolean.valueOf(Boolean.parseBoolean(o.toString()));
/*     */   }
/*     */   
/*     */   public List<Boolean> getBools(Object key)
/*     */   {
/* 109 */     return (List)this.fields.get(key);
/*     */   }
/*     */   
/*     */   public Date getDate(Object key)
/*     */   {
/* 114 */     Object o = this.fields.get(key);
/*     */     
/* 116 */     if (o == null) {
/* 117 */       return null;
/*     */     }
/*     */     
/* 120 */     if ((o instanceof Date)) {
/* 121 */       return (Date)o;
/*     */     }
/*     */     
/* 124 */     return new Date(Instant.parse(o.toString()).toEpochMilli());
/*     */   }
/*     */   
/*     */   public List<Date> getDates(Object key)
/*     */   {
/* 129 */     List<String> vals = (List)this.fields.get(key);
/* 130 */     if (vals == null) { return null;
/*     */     }
/* 132 */     List<Date> ret = new ArrayList();
/* 133 */     for (String dateStr : (List)this.fields.get(key)) {
/* 134 */       ret.add(new Date(Instant.parse(dateStr).toEpochMilli()));
/*     */     }
/* 136 */     return ret;
/*     */   }
/*     */   
/*     */   public Double getDouble(Object key) {
/* 140 */     Object o = this.fields.get(key);
/*     */     
/* 142 */     if (o == null) {
/* 143 */       return null;
/*     */     }
/*     */     
/* 146 */     if ((o instanceof Double)) {
/* 147 */       return (Double)o;
/*     */     }
/*     */     
/* 150 */     return Double.valueOf(Double.parseDouble(o.toString()));
/*     */   }
/*     */   
/*     */   public List<String> getStrings(Object key)
/*     */   {
/* 155 */     return (List)this.fields.get(key);
/*     */   }
/*     */   
/*     */   public List<Long> getLongs(Object key) {
/* 159 */     return (List)this.fields.get(key);
/*     */   }
/*     */   
/*     */   public List<Double> getDoubles(Object key) {
/* 163 */     return (List)this.fields.get(key);
/*     */   }
/*     */   
/*     */   public Map getMap() {
/* 167 */     return this.fields;
/*     */   }
/*     */   
/*     */   public List<Map> getMaps(Object key) {
/* 171 */     return (List)this.fields.get(key);
/*     */   }
/*     */   
/*     */   public void setMaps(Object key, List<Map> maps) {
/* 175 */     this.fields.put(key, maps);
/*     */   }
/*     */   
/*     */   public Map<String, Map> getMetrics() {
/* 179 */     return (Map)this.fields.get("_METRICS_");
/*     */   }
/*     */   
/*     */   public void setMetrics(Map<String, Map> metrics) {
/* 183 */     this.fields.put("_METRICS_", metrics);
/*     */   }
/*     */   
/*     */   public Tuple clone() {
/* 187 */     HashMap m = new HashMap();
/* 188 */     m.putAll(this.fields);
/* 189 */     Tuple clone = new Tuple(m);
/* 190 */     return clone;
/*     */   }
/*     */   
/*     */   public void merge(Tuple other) {
/* 194 */     this.fields.putAll(other.getMap());
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\Tuple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */