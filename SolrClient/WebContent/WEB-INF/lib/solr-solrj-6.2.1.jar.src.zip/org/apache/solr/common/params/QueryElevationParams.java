package org.apache.solr.common.params;

public abstract interface QueryElevationParams
{
  public static final String ENABLE = "enableElevation";
  public static final String EXCLUSIVE = "exclusive";
  public static final String FORCE_ELEVATION = "forceElevation";
  public static final String IDS = "elevateIds";
  public static final String EXCLUDE = "excludeIds";
  public static final String EDITORIAL_MARKER_FIELD_NAME = "editorialMarkerFieldName";
  public static final String EXCLUDE_MARKER_FIELD_NAME = "excludeMarkerFieldName";
  public static final String MARK_EXCLUDES = "markExcludes";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\QueryElevationParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */