/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.solr.common.SolrDocumentList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Group
/*    */   implements Serializable
/*    */ {
/*    */   private final String _groupValue;
/*    */   private final SolrDocumentList _result;
/*    */   
/*    */   public Group(String groupValue, SolrDocumentList result)
/*    */   {
/* 44 */     this._groupValue = groupValue;
/* 45 */     this._result = result;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getGroupValue()
/*    */   {
/* 55 */     return this._groupValue;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SolrDocumentList getResult()
/*    */   {
/* 65 */     return this._result;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */