package org.apache.solr.common.cloud;

import java.util.List;
import org.apache.zookeeper.data.ACL;

public abstract interface ZkACLProvider
{
  public abstract List<ACL> getACLsToAdd(String paramString);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkACLProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */