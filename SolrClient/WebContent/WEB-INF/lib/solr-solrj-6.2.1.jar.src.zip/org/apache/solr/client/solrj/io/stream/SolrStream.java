/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.impl.HttpSolrClient;
/*     */ import org.apache.solr.client.solrj.impl.HttpSolrClient.Builder;
/*     */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.common.params.MapSolrParams;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrStream
/*     */   extends TupleStream
/*     */ {
/*  47 */   private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private String baseUrl;
/*     */   private SolrParams params;
/*     */   private int numWorkers;
/*     */   private int workerID;
/*     */   private boolean trace;
/*     */   private Map<String, String> fieldMappings;
/*     */   private transient JSONTupleStream jsonTupleStream;
/*     */   private transient HttpSolrClient client;
/*     */   private transient SolrClientCache cache;
/*     */   private String slice;
/*  61 */   private long checkpoint = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public SolrStream(String baseUrl, Map params)
/*     */   {
/*  72 */     this.baseUrl = baseUrl;
/*  73 */     this.params = new ModifiableSolrParams(new MapSolrParams(params));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrStream(String baseUrl, SolrParams params)
/*     */   {
/*  82 */     this.baseUrl = baseUrl;
/*  83 */     this.params = params;
/*     */   }
/*     */   
/*     */   public void setFieldMappings(Map<String, String> fieldMappings) {
/*  87 */     this.fieldMappings = fieldMappings;
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/*  91 */     return new ArrayList();
/*     */   }
/*     */   
/*     */   public String getBaseUrl() {
/*  95 */     return this.baseUrl;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/*  99 */     this.numWorkers = context.numWorkers;
/* 100 */     this.workerID = context.workerID;
/* 101 */     this.cache = context.getSolrClientCache();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws IOException
/*     */   {
/* 111 */     if (this.cache == null) {
/* 112 */       this.client = new HttpSolrClient.Builder(this.baseUrl).build();
/*     */     } else {
/* 114 */       this.client = this.cache.getHttpSolrClient(this.baseUrl);
/*     */     }
/*     */     try
/*     */     {
/* 118 */       this.jsonTupleStream = JSONTupleStream.create(this.client, loadParams(this.params));
/*     */     } catch (Exception e) {
/* 120 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTrace(boolean trace)
/*     */   {
/* 129 */     this.trace = trace;
/*     */   }
/*     */   
/*     */   public void setSlice(String slice) {
/* 133 */     this.slice = slice;
/*     */   }
/*     */   
/*     */   public void setCheckpoint(long checkpoint) {
/* 137 */     this.checkpoint = checkpoint;
/*     */   }
/*     */   
/*     */   private SolrParams loadParams(SolrParams paramsIn) throws IOException {
/* 141 */     ModifiableSolrParams solrParams = new ModifiableSolrParams(paramsIn);
/* 142 */     if (this.params.get("partitionKeys") != null) {
/* 143 */       if (!this.params.get("partitionKeys").equals("none")) {
/* 144 */         String partitionFilter = getPartitionFilter();
/* 145 */         solrParams.add("fq", new String[] { partitionFilter });
/*     */       }
/*     */     }
/* 148 */     else if (this.numWorkers > 1) {
/* 149 */       throw new IOException("When numWorkers > 1 partitionKeys must be set. Set partitionKeys=none to send the entire stream to each worker.");
/*     */     }
/*     */     
/*     */ 
/* 153 */     if (this.checkpoint > 0L) {
/* 154 */       solrParams.add("fq", new String[] { "{!frange cost=100 incl=false l=" + this.checkpoint + "}_version_" });
/*     */     }
/*     */     
/* 157 */     return solrParams;
/*     */   }
/*     */   
/*     */   private String getPartitionFilter() {
/* 161 */     StringBuilder buf = new StringBuilder("{!hash workers=");
/* 162 */     buf.append(this.numWorkers);
/* 163 */     buf.append(" worker=");
/* 164 */     buf.append(this.workerID);
/* 165 */     buf.append("}");
/* 166 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 172 */     return 
/*     */     
/*     */ 
/*     */ 
/* 176 */       new StreamExplanation(getStreamNodeId().toString()).withFunctionName("non-expressible").withImplementingClass(getClass().getName()).withExpressionType("stream-source").withExpression("non-expressible");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 185 */     if (this.jsonTupleStream != null) {
/* 186 */       this.jsonTupleStream.close();
/*     */     }
/*     */     
/* 189 */     if (this.cache == null) {
/* 190 */       this.client.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Tuple read()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 200 */       Map fields = this.jsonTupleStream.next();
/*     */       
/* 202 */       if (fields == null)
/*     */       {
/* 204 */         Map m = new HashMap();
/* 205 */         m.put("EOF", Boolean.valueOf(true));
/* 206 */         return new Tuple(m);
/*     */       }
/*     */       
/* 209 */       String msg = (String)fields.get("EXCEPTION");
/* 210 */       if (msg != null) {
/* 211 */         HandledException ioException = new HandledException(msg);
/* 212 */         throw ioException;
/*     */       }
/*     */       
/* 215 */       if (this.trace) {
/* 216 */         fields.put("_CORE_", this.baseUrl);
/* 217 */         if (this.slice != null) {
/* 218 */           fields.put("_SLICE_", this.slice);
/*     */         }
/*     */       }
/*     */       
/* 222 */       if (this.fieldMappings != null) {
/* 223 */         fields = mapFields(fields, this.fieldMappings);
/*     */       }
/* 225 */       return new Tuple(fields);
/*     */     }
/*     */     catch (HandledException e) {
/* 228 */       throw new IOException("--> " + this.baseUrl + ":" + e.getMessage());
/*     */     }
/*     */     catch (Exception e) {
/* 231 */       throw new IOException("--> " + this.baseUrl + ": An exception has occurred on the server, refer to server log for details.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class HandledException extends IOException {
/*     */     public HandledException(String msg) {
/* 237 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 243 */     return null;
/*     */   }
/*     */   
/*     */   private Map mapFields(Map fields, Map<String, String> mappings)
/*     */   {
/* 248 */     Iterator<Map.Entry<String, String>> it = mappings.entrySet().iterator();
/* 249 */     while (it.hasNext()) {
/* 250 */       Map.Entry<String, String> entry = (Map.Entry)it.next();
/* 251 */       String mapFrom = (String)entry.getKey();
/* 252 */       String mapTo = (String)entry.getValue();
/* 253 */       Object o = fields.get(mapFrom);
/* 254 */       fields.remove(mapFrom);
/* 255 */       fields.put(mapTo, o);
/*     */     }
/*     */     
/* 258 */     return fields;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\SolrStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */