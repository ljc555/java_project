package org.apache.solr.common.params;

public abstract interface ShardParams
{
  public static final String SHARDS = "shards";
  public static final String SHARDS_ROWS = "shards.rows";
  public static final String SHARDS_START = "shards.start";
  public static final String IDS = "ids";
  public static final String IS_SHARD = "isShard";
  public static final String SHARD_URL = "shard.url";
  public static final String SHARDS_QT = "shards.qt";
  public static final String SHARDS_INFO = "shards.info";
  public static final String SHARDS_TOLERANT = "shards.tolerant";
  public static final String SHARDS_PURPOSE = "shards.purpose";
  public static final String _ROUTE_ = "_route_";
  public static final String DISTRIB_SINGLE_PASS = "distrib.singlePass";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\ShardParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */