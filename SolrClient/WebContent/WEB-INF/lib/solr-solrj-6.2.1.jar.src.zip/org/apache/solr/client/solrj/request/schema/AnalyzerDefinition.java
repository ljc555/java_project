/*    */ package org.apache.solr.client.solrj.request.schema;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnalyzerDefinition
/*    */ {
/*    */   private Map<String, Object> attributes;
/*    */   private List<Map<String, Object>> charFilters;
/*    */   private Map<String, Object> tokenizer;
/*    */   private List<Map<String, Object>> filters;
/*    */   
/*    */   public Map<String, Object> getAttributes()
/*    */   {
/* 32 */     return this.attributes;
/*    */   }
/*    */   
/*    */   public void setAttributes(Map<String, Object> attributes) {
/* 36 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public List<Map<String, Object>> getCharFilters() {
/* 40 */     return this.charFilters;
/*    */   }
/*    */   
/*    */   public void setCharFilters(List<Map<String, Object>> charFilters) {
/* 44 */     this.charFilters = charFilters;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getTokenizer() {
/* 48 */     return this.tokenizer;
/*    */   }
/*    */   
/*    */   public void setTokenizer(Map<String, Object> tokenizer) {
/* 52 */     this.tokenizer = tokenizer;
/*    */   }
/*    */   
/*    */   public List<Map<String, Object>> getFilters() {
/* 56 */     return this.filters;
/*    */   }
/*    */   
/*    */   public void setFilters(List<Map<String, Object>> filters) {
/* 60 */     this.filters = filters;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\schema\AnalyzerDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */