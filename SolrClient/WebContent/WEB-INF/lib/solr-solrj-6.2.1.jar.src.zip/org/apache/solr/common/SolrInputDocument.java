/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrInputDocument
/*     */   extends SolrDocumentBase<SolrInputField, SolrInputDocument>
/*     */   implements Iterable<SolrInputField>
/*     */ {
/*     */   private final Map<String, SolrInputField> _fields;
/*  38 */   private float _documentBoost = 1.0F;
/*     */   private List<SolrInputDocument> _childDocuments;
/*     */   
/*     */   public SolrInputDocument(String... fields) {
/*  42 */     this._fields = new LinkedHashMap();
/*  43 */     assert (fields.length % 2 == 0);
/*  44 */     for (int i = 0; i < fields.length; i += 2) {
/*  45 */       addField(fields[i], fields[(i + 1)]);
/*     */     }
/*     */   }
/*     */   
/*     */   public SolrInputDocument(Map<String, SolrInputField> fields) {
/*  50 */     this._fields = fields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  59 */     if (this._fields != null) {
/*  60 */       this._fields.clear();
/*     */     }
/*  62 */     this._childDocuments = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addField(String name, Object value)
/*     */   {
/*  81 */     addField(name, value, 1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getFieldValue(String name)
/*     */   {
/*  92 */     SolrInputField field = getField(name);
/*  93 */     Object o = null;
/*  94 */     if (field != null) o = field.getFirstValue();
/*  95 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Object> getFieldValues(String name)
/*     */   {
/* 106 */     SolrInputField field = getField(name);
/* 107 */     if (field != null) {
/* 108 */       return field.getValues();
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getFieldNames()
/*     */   {
/* 120 */     return this._fields.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setField(String name, Object value)
/*     */   {
/* 131 */     setField(name, value, 1.0F);
/*     */   }
/*     */   
/*     */   public void setField(String name, Object value, float boost)
/*     */   {
/* 136 */     SolrInputField field = new SolrInputField(name);
/* 137 */     this._fields.put(name, field);
/* 138 */     field.setValue(value, boost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addField(String name, Object value, float boost)
/*     */   {
/* 156 */     SolrInputField field = (SolrInputField)this._fields.get(name);
/* 157 */     if ((field == null) || (field.value == null)) {
/* 158 */       setField(name, value, boost);
/*     */     }
/*     */     else {
/* 161 */       field.addValue(value, boost);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrInputField removeField(String name)
/*     */   {
/* 173 */     return (SolrInputField)this._fields.remove(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrInputField getField(String field)
/*     */   {
/* 182 */     return (SolrInputField)this._fields.get(field);
/*     */   }
/*     */   
/*     */   public Iterator<SolrInputField> iterator()
/*     */   {
/* 187 */     return this._fields.values().iterator();
/*     */   }
/*     */   
/*     */   public float getDocumentBoost() {
/* 191 */     return this._documentBoost;
/*     */   }
/*     */   
/*     */   public void setDocumentBoost(float documentBoost) {
/* 195 */     this._documentBoost = documentBoost;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 201 */     return "SolrInputDocument(fields: " + this._fields.values() + (this._childDocuments == null ? "" : new StringBuilder().append(", children: ").append(this._childDocuments).toString()) + ")";
/*     */   }
/*     */   
/*     */ 
/*     */   public SolrInputDocument deepCopy()
/*     */   {
/* 207 */     SolrInputDocument clone = new SolrInputDocument(new String[0]);
/* 208 */     Set<Map.Entry<String, SolrInputField>> entries = this._fields.entrySet();
/* 209 */     for (Map.Entry<String, SolrInputField> fieldEntry : entries) {
/* 210 */       clone._fields.put(fieldEntry.getKey(), ((SolrInputField)fieldEntry.getValue()).deepCopy());
/*     */     }
/* 212 */     clone._documentBoost = this._documentBoost;
/*     */     
/* 214 */     if (this._childDocuments != null) {
/* 215 */       clone._childDocuments = new ArrayList(this._childDocuments.size());
/* 216 */       for (SolrInputDocument child : this._childDocuments) {
/* 217 */         clone._childDocuments.add(child.deepCopy());
/*     */       }
/*     */     }
/*     */     
/* 221 */     return clone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 230 */     return this._fields.containsKey(key);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 235 */     return this._fields.containsValue(value);
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, SolrInputField>> entrySet()
/*     */   {
/* 240 */     return this._fields.entrySet();
/*     */   }
/*     */   
/*     */   public SolrInputField get(Object key)
/*     */   {
/* 245 */     return (SolrInputField)this._fields.get(key);
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 250 */     return this._fields.isEmpty();
/*     */   }
/*     */   
/*     */   public Set<String> keySet()
/*     */   {
/* 255 */     return this._fields.keySet();
/*     */   }
/*     */   
/*     */   public SolrInputField put(String key, SolrInputField value)
/*     */   {
/* 260 */     return (SolrInputField)this._fields.put(key, value);
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends SolrInputField> t)
/*     */   {
/* 265 */     this._fields.putAll(t);
/*     */   }
/*     */   
/*     */   public SolrInputField remove(Object key)
/*     */   {
/* 270 */     return (SolrInputField)this._fields.remove(key);
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 275 */     return this._fields.size();
/*     */   }
/*     */   
/*     */   public Collection<SolrInputField> values()
/*     */   {
/* 280 */     return this._fields.values();
/*     */   }
/*     */   
/*     */   public void addChildDocument(SolrInputDocument child)
/*     */   {
/* 285 */     if (this._childDocuments == null) {
/* 286 */       this._childDocuments = new ArrayList();
/*     */     }
/* 288 */     this._childDocuments.add(child);
/*     */   }
/*     */   
/*     */   public void addChildDocuments(Collection<SolrInputDocument> children) {
/* 292 */     for (SolrInputDocument child : children) {
/* 293 */       addChildDocument(child);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<SolrInputDocument> getChildDocuments()
/*     */   {
/* 299 */     return this._childDocuments;
/*     */   }
/*     */   
/*     */   public boolean hasChildDocuments() {
/* 303 */     boolean isEmpty = (this._childDocuments == null) || (this._childDocuments.isEmpty());
/* 304 */     return !isEmpty;
/*     */   }
/*     */   
/*     */   public int getChildDocumentCount()
/*     */   {
/* 309 */     return hasChildDocuments() ? this._childDocuments.size() : 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrInputDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */