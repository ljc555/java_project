/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HashJoinStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected TupleStream hashStream;
/*     */   protected TupleStream fullStream;
/*     */   protected List<String> leftHashOn;
/*     */   protected List<String> rightHashOn;
/*     */   protected HashMap<Integer, List<Tuple>> hashedTuples;
/*  54 */   protected Tuple workingFullTuple = null;
/*  55 */   protected Integer workingFullHash = null;
/*  56 */   protected int workngHashSetIdx = 0;
/*     */   
/*     */   public HashJoinStream(TupleStream fullStream, TupleStream hashStream, List<String> hashOn) throws IOException {
/*  59 */     init(fullStream, hashStream, hashOn);
/*     */   }
/*     */   
/*     */   public HashJoinStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  64 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  65 */     StreamExpressionNamedParameter hashStreamExpression = factory.getNamedOperand(expression, "hashed");
/*  66 */     StreamExpressionNamedParameter onExpression = factory.getNamedOperand(expression, "on");
/*     */     
/*     */ 
/*  69 */     if (expression.getParameters().size() != streamExpressions.size() + 2) {
/*  70 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  73 */     if (1 != streamExpressions.size()) {
/*  74 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting two streams but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  77 */     if ((null == hashStreamExpression) || (!(hashStreamExpression.getParameter() instanceof StreamExpression))) {
/*  78 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'hashed' parameter containing the stream to hash but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  81 */     if ((null == onExpression) || (!(onExpression.getParameter() instanceof StreamExpressionValue))) {
/*  82 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'on' parameter listing fields to hash on but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  85 */     String hashOnValue = ((StreamExpressionValue)onExpression.getParameter()).getValue();
/*  86 */     String[] parts = hashOnValue.split(",");
/*  87 */     List<String> hashOn = new ArrayList(parts.length);
/*  88 */     for (String part : parts) {
/*  89 */       hashOn.add(part.trim());
/*     */     }
/*     */     
/*  92 */     init(factory.constructStream((StreamExpression)streamExpressions.get(0)), factory
/*  93 */       .constructStream((StreamExpression)hashStreamExpression.getParameter()), hashOn);
/*     */   }
/*     */   
/*     */   private void init(TupleStream fullStream, TupleStream hashStream, List<String> hashOn)
/*     */     throws IOException
/*     */   {
/*  99 */     this.fullStream = fullStream;
/* 100 */     this.hashStream = hashStream;
/* 101 */     this.hashedTuples = new HashMap();
/* 102 */     this.leftHashOn = new ArrayList();
/* 103 */     this.rightHashOn = new ArrayList();
/*     */     
/* 105 */     for (String hasher : hashOn) {
/* 106 */       String[] parts = hasher.split("=");
/* 107 */       if (1 == parts.length) {
/* 108 */         String field = parts[0].trim();
/* 109 */         this.leftHashOn.add(field);
/* 110 */         this.rightHashOn.add(field);
/*     */       }
/* 112 */       else if (2 == parts.length) {
/* 113 */         this.leftHashOn.add(parts[0].trim());
/* 114 */         this.rightHashOn.add(parts[1].trim());
/*     */       }
/*     */       else {
/* 117 */         throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - invalid 'on' parameter - expecting 1 or more instances if 'field' or 'field=hashedField' but found '%s'", new Object[] { hasher }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 124 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 129 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/* 131 */     if (includeStreams)
/*     */     {
/* 133 */       if (((this.hashStream instanceof Expressible)) && ((this.fullStream instanceof Expressible))) {
/* 134 */         expression.addParameter(((Expressible)this.fullStream).toExpression(factory));
/* 135 */         expression.addParameter(new StreamExpressionNamedParameter("hashed", ((Expressible)this.hashStream).toExpression(factory)));
/*     */       }
/*     */       else {
/* 138 */         throw new IOException("This HashJoinStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 142 */       expression.addParameter("<stream>");
/* 143 */       expression.addParameter("hashed=<stream>");
/*     */     }
/*     */     
/*     */ 
/* 147 */     StringBuilder sb = new StringBuilder();
/* 148 */     for (int idx = 0; idx < this.leftHashOn.size(); idx++) {
/* 149 */       if (sb.length() > 0) { sb.append(",");
/*     */       }
/*     */       
/* 152 */       String left = (String)this.leftHashOn.get(idx);
/* 153 */       String right = (String)this.rightHashOn.get(idx);
/*     */       
/* 155 */       if (left.equals(right)) {
/* 156 */         sb.append(left);
/*     */       }
/*     */       else {
/* 159 */         sb.append(left);
/* 160 */         sb.append("=");
/* 161 */         sb.append(right);
/*     */       }
/*     */     }
/*     */     
/* 165 */     expression.addParameter(new StreamExpressionNamedParameter("on", sb.toString()));
/* 166 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 172 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.fullStream.toExplanation(factory), this.hashStream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString());
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 184 */     this.hashStream.setStreamContext(context);
/* 185 */     this.fullStream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 189 */     List<TupleStream> l = new ArrayList();
/* 190 */     l.add(this.hashStream);
/* 191 */     l.add(this.fullStream);
/* 192 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 196 */     this.hashStream.open();
/* 197 */     this.fullStream.open();
/*     */     
/* 199 */     Tuple tuple = this.hashStream.read();
/* 200 */     while (!tuple.EOF) {
/* 201 */       Integer hash = calculateHash(tuple, this.rightHashOn);
/* 202 */       if (null != hash) {
/* 203 */         if (this.hashedTuples.containsKey(hash)) {
/* 204 */           ((List)this.hashedTuples.get(hash)).add(tuple);
/*     */         }
/*     */         else {
/* 207 */           ArrayList<Tuple> set = new ArrayList();
/* 208 */           set.add(tuple);
/* 209 */           this.hashedTuples.put(hash, set);
/*     */         }
/*     */       }
/* 212 */       tuple = this.hashStream.read();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Integer calculateHash(Tuple tuple, List<String> hashOn) {
/* 217 */     StringBuilder sb = new StringBuilder();
/* 218 */     for (String part : hashOn) {
/* 219 */       Object obj = tuple.get(part);
/* 220 */       if (null == obj) {
/* 221 */         return null;
/*     */       }
/* 223 */       sb.append(obj.toString());
/* 224 */       sb.append("::");
/*     */     }
/*     */     
/* 227 */     return Integer.valueOf(sb.toString().hashCode());
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 231 */     this.hashStream.close();
/* 232 */     this.fullStream.close();
/*     */   }
/*     */   
/*     */   public Tuple read()
/*     */     throws IOException
/*     */   {
/* 238 */     while (null == this.workingFullTuple) {
/* 239 */       Tuple fullTuple = this.fullStream.read();
/*     */       
/*     */ 
/* 242 */       if (fullTuple.EOF) {
/* 243 */         return fullTuple;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 248 */       Integer fullHash = calculateHash(fullTuple, this.leftHashOn);
/* 249 */       if ((null != fullHash) && (this.hashedTuples.containsKey(fullHash)))
/*     */       {
/*     */ 
/*     */ 
/* 253 */         this.workingFullTuple = fullTuple;
/* 254 */         this.workingFullHash = fullHash;
/* 255 */         this.workngHashSetIdx = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 260 */     List<Tuple> matches = (List)this.hashedTuples.get(this.workingFullHash);
/* 261 */     Tuple returnTuple = this.workingFullTuple.clone();
/* 262 */     returnTuple.merge((Tuple)matches.get(this.workngHashSetIdx));
/*     */     
/*     */ 
/* 265 */     this.workngHashSetIdx += 1;
/*     */     
/* 267 */     if (this.workngHashSetIdx >= matches.size())
/*     */     {
/* 269 */       this.workingFullTuple = null;
/* 270 */       this.workingFullHash = null;
/* 271 */       this.workngHashSetIdx = 0;
/*     */     }
/*     */     
/* 274 */     return returnTuple;
/*     */   }
/*     */   
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 280 */     return this.fullStream.getStreamSort();
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 284 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\HashJoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */