/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.NClob;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.RowId;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PreparedStatementImpl
/*     */   extends StatementImpl
/*     */   implements PreparedStatement
/*     */ {
/*     */   private final String sql;
/*     */   
/*     */   PreparedStatementImpl(ConnectionImpl connection, String sql)
/*     */   {
/*  44 */     super(connection);
/*  45 */     this.sql = sql;
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery() throws SQLException
/*     */   {
/*  50 */     return super.executeQuery(this.sql);
/*     */   }
/*     */   
/*     */   public int executeUpdate() throws SQLException
/*     */   {
/*  55 */     return super.executeUpdate(this.sql);
/*     */   }
/*     */   
/*     */   public boolean execute() throws SQLException
/*     */   {
/*  60 */     return super.execute(this.sql);
/*     */   }
/*     */   
/*     */   public void clearParameters()
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public ParameterMetaData getParameterMetaData() throws SQLException
/*     */   {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void addBatch() throws SQLException
/*     */   {
/*  80 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBoolean(int parameterIndex, boolean x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setByte(int parameterIndex, byte x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setShort(int parameterIndex, short x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setInt(int parameterIndex, int x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setLong(int parameterIndex, long x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setFloat(int parameterIndex, float x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setDouble(int parameterIndex, double x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setString(int parameterIndex, String x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBytes(int parameterIndex, byte[] x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setRef(int parameterIndex, Ref x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBlob(int parameterIndex, Blob x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setClob(int parameterIndex, Clob x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setArray(int parameterIndex, Array x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setURL(int parameterIndex, URL x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setRowId(int parameterIndex, RowId x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNString(int parameterIndex, String value)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNCharacterStream(int parameterIndex, Reader value, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNClob(int parameterIndex, NClob value)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setClob(int parameterIndex, Reader reader, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBlob(int parameterIndex, InputStream inputStream, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNClob(int parameterIndex, Reader reader, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setSQLXML(int parameterIndex, SQLXML xmlObject)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scaleOrLength)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, long length)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNCharacterStream(int parameterIndex, Reader value)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setClob(int parameterIndex, Reader reader)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setBlob(int parameterIndex, InputStream inputStream)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public void setNClob(int parameterIndex, Reader reader)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/* 327 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql) throws SQLException
/*     */   {
/* 332 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public boolean execute(String sql) throws SQLException
/*     */   {
/* 337 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public void addBatch(String sql) throws SQLException
/*     */   {
/* 342 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 347 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 352 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 357 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 362 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 367 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 372 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql) throws SQLException
/*     */   {
/* 377 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 382 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 387 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 392 */     throw new SQLException("Cannot be called from PreparedStatement");
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\PreparedStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */