/*    */ package org.apache.solr.client.solrj.io.stream;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PushBackStream
/*    */   extends TupleStream
/*    */   implements Expressible
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private TupleStream stream;
/*    */   private Tuple tuple;
/*    */   
/*    */   public PushBackStream(TupleStream stream)
/*    */   {
/* 44 */     this.stream = stream;
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException {
/* 48 */     if ((this.stream instanceof Expressible)) {
/* 49 */       return ((Expressible)this.stream).toExpression(factory);
/*    */     }
/*    */     
/* 52 */     throw new IOException("This PushBackStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*    */   }
/*    */   
/*    */   public Explanation toExplanation(StreamFactory factory) throws IOException {
/* 56 */     return this.stream.toExplanation(factory);
/*    */   }
/*    */   
/*    */   public void setStreamContext(StreamContext context) {
/* 60 */     this.stream.setStreamContext(context);
/*    */   }
/*    */   
/*    */   public List<TupleStream> children() {
/* 64 */     List<TupleStream> l = new ArrayList();
/* 65 */     l.add(this.stream);
/* 66 */     return l;
/*    */   }
/*    */   
/*    */   public void open() throws IOException {
/* 70 */     this.stream.open();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 74 */     this.stream.close();
/*    */   }
/*    */   
/*    */   public void pushBack(Tuple tuple) {
/* 78 */     this.tuple = tuple;
/*    */   }
/*    */   
/*    */   public Tuple read() throws IOException {
/* 82 */     if (this.tuple != null) {
/* 83 */       Tuple t = this.tuple;
/* 84 */       this.tuple = null;
/* 85 */       return t;
/*    */     }
/* 87 */     return this.stream.read();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public StreamComparator getStreamSort()
/*    */   {
/* 94 */     return this.stream.getStreamSort();
/*    */   }
/*    */   
/*    */   public int getCost()
/*    */   {
/* 99 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\PushBackStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */