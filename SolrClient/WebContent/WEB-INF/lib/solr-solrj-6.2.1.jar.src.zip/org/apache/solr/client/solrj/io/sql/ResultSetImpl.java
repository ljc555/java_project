/*      */ package org.apache.solr.client.solrj.io.sql;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import org.apache.solr.client.solrj.io.Tuple;
/*      */ import org.apache.solr.client.solrj.io.stream.PushBackStream;
/*      */ import org.apache.solr.client.solrj.io.stream.SolrStream;
/*      */ import org.apache.solr.client.solrj.io.stream.StreamContext;
/*      */ import org.apache.solr.common.util.SuppressForbidden;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ResultSetImpl
/*      */   implements ResultSet
/*      */ {
/*      */   private final StatementImpl statement;
/*      */   private final PushBackStream solrStream;
/*      */   private final ResultSetMetaData resultSetMetaData;
/*      */   private final Tuple metadataTuple;
/*      */   private final Tuple firstTuple;
/*      */   private Tuple tuple;
/*      */   private boolean done;
/*      */   private boolean closed;
/*      */   private SQLWarning currentWarning;
/*      */   private boolean wasLastValueNull;
/*      */   
/*      */   ResultSetImpl(StatementImpl statement, SolrStream solrStream)
/*      */     throws SQLException
/*      */   {
/*   62 */     this.statement = statement;
/*      */     try
/*      */     {
/*   65 */       this.solrStream = new PushBackStream(solrStream);
/*      */       
/*   67 */       StreamContext context = new StreamContext();
/*   68 */       context.setSolrClientCache(((ConnectionImpl)this.statement.getConnection()).getSolrClientCache());
/*   69 */       this.solrStream.setStreamContext(context);
/*      */       
/*   71 */       this.solrStream.open();
/*      */       
/*   73 */       this.metadataTuple = this.solrStream.read();
/*      */       
/*   75 */       Object isMetadata = this.metadataTuple.get("isMetadata");
/*   76 */       if ((isMetadata == null) || (!isMetadata.equals(Boolean.valueOf(true)))) {
/*   77 */         throw new RuntimeException("First tuple is not a metadata tuple");
/*      */       }
/*      */       
/*   80 */       this.firstTuple = this.solrStream.read();
/*   81 */       this.solrStream.pushBack(this.firstTuple);
/*      */     } catch (IOException e) {
/*   83 */       throw new SQLException(e);
/*      */     }
/*      */     
/*   86 */     this.resultSetMetaData = new ResultSetMetaDataImpl(this);
/*      */   }
/*      */   
/*      */   Tuple getMetadataTuple() {
/*   90 */     return this.metadataTuple;
/*      */   }
/*      */   
/*      */   Tuple getFirstTuple() {
/*   94 */     return this.firstTuple;
/*      */   }
/*      */   
/*      */   private void checkClosed() throws SQLException {
/*   98 */     if (isClosed()) {
/*   99 */       throw new SQLException("ResultSet is closed.");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean next() throws SQLException
/*      */   {
/*  105 */     checkClosed();
/*      */     try
/*      */     {
/*  108 */       if (this.done) {
/*  109 */         return false;
/*      */       }
/*      */       
/*  112 */       this.tuple = this.solrStream.read();
/*  113 */       if (this.tuple.EOF) {
/*  114 */         this.done = true;
/*  115 */         return false;
/*      */       }
/*  117 */       return true;
/*      */     }
/*      */     catch (IOException e) {
/*  120 */       throw new SQLException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws SQLException
/*      */   {
/*  126 */     this.done = (this.closed = 1);
/*      */     try
/*      */     {
/*  129 */       this.solrStream.close();
/*      */     } catch (IOException e) {
/*  131 */       throw new SQLException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean wasNull() throws SQLException
/*      */   {
/*  137 */     return this.wasLastValueNull;
/*      */   }
/*      */   
/*      */   public String getString(int columnIndex) throws SQLException
/*      */   {
/*  142 */     return getString(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int columnIndex) throws SQLException
/*      */   {
/*  147 */     return getBoolean(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public byte getByte(int columnIndex) throws SQLException
/*      */   {
/*  152 */     return getByte(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public short getShort(int columnIndex) throws SQLException
/*      */   {
/*  157 */     return getShort(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public int getInt(int columnIndex) throws SQLException
/*      */   {
/*  162 */     return getInt(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public long getLong(int columnIndex) throws SQLException
/*      */   {
/*  167 */     return getLong(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public float getFloat(int columnIndex) throws SQLException
/*      */   {
/*  172 */     return getFloat(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public double getDouble(int columnIndex) throws SQLException
/*      */   {
/*  177 */     return getDouble(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   @SuppressForbidden(reason="Implements deprecated method")
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException
/*      */   {
/*  183 */     return getBigDecimal(this.resultSetMetaData.getColumnLabel(columnIndex), scale);
/*      */   }
/*      */   
/*      */   public byte[] getBytes(int columnIndex) throws SQLException
/*      */   {
/*  188 */     return getBytes(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public Date getDate(int columnIndex) throws SQLException
/*      */   {
/*  193 */     return getDate(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public Time getTime(int columnIndex) throws SQLException
/*      */   {
/*  198 */     return getTime(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex) throws SQLException
/*      */   {
/*  203 */     return getTimestamp(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public InputStream getAsciiStream(int columnIndex) throws SQLException
/*      */   {
/*  208 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public InputStream getUnicodeStream(int columnIndex) throws SQLException
/*      */   {
/*  213 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public InputStream getBinaryStream(int columnIndex) throws SQLException
/*      */   {
/*  218 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public String getString(String columnLabel) throws SQLException
/*      */   {
/*  223 */     this.wasLastValueNull = false;
/*  224 */     checkClosed();
/*      */     
/*  226 */     String value = this.tuple.getString(columnLabel);
/*  227 */     if (value.equals(String.valueOf(null))) {
/*  228 */       this.wasLastValueNull = true;
/*  229 */       return null;
/*      */     }
/*  231 */     return value;
/*      */   }
/*      */   
/*      */   public boolean getBoolean(String columnLabel) throws SQLException
/*      */   {
/*  236 */     this.wasLastValueNull = false;
/*  237 */     checkClosed();
/*      */     
/*  239 */     Object value = getObject(columnLabel);
/*  240 */     if (value == null) {
/*  241 */       this.wasLastValueNull = true;
/*  242 */       return false;
/*      */     }
/*  244 */     return ((Boolean)value).booleanValue();
/*      */   }
/*      */   
/*      */   public byte getByte(String columnLabel) throws SQLException
/*      */   {
/*  249 */     this.wasLastValueNull = false;
/*  250 */     checkClosed();
/*      */     
/*  252 */     Number number = (Number)getObject(columnLabel);
/*  253 */     if (number == null) {
/*  254 */       this.wasLastValueNull = true;
/*  255 */       return 0;
/*      */     }
/*  257 */     return number.byteValue();
/*      */   }
/*      */   
/*      */   public short getShort(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  263 */     this.wasLastValueNull = false;
/*  264 */     checkClosed();
/*      */     
/*  266 */     Number number = (Number)getObject(columnLabel);
/*  267 */     if (number == null) {
/*  268 */       this.wasLastValueNull = true;
/*  269 */       return 0;
/*      */     }
/*  271 */     return number.shortValue();
/*      */   }
/*      */   
/*      */   public int getInt(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  277 */     this.wasLastValueNull = false;
/*  278 */     checkClosed();
/*      */     
/*  280 */     Number number = (Number)getObject(columnLabel);
/*  281 */     if (number == null) {
/*  282 */       this.wasLastValueNull = true;
/*  283 */       return 0;
/*      */     }
/*  285 */     return number.intValue();
/*      */   }
/*      */   
/*      */   public long getLong(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  291 */     this.wasLastValueNull = false;
/*  292 */     checkClosed();
/*      */     
/*  294 */     Number number = (Number)getObject(columnLabel);
/*  295 */     if (number == null) {
/*  296 */       this.wasLastValueNull = true;
/*  297 */       return 0L;
/*      */     }
/*  299 */     return number.longValue();
/*      */   }
/*      */   
/*      */   public float getFloat(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  305 */     this.wasLastValueNull = false;
/*  306 */     checkClosed();
/*      */     
/*  308 */     Number number = (Number)getObject(columnLabel);
/*  309 */     if (number == null) {
/*  310 */       this.wasLastValueNull = true;
/*  311 */       return 0.0F;
/*      */     }
/*  313 */     return number.floatValue();
/*      */   }
/*      */   
/*      */   public double getDouble(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  319 */     this.wasLastValueNull = false;
/*  320 */     checkClosed();
/*      */     
/*  322 */     Number number = (Number)getObject(columnLabel);
/*  323 */     if (number == null) {
/*  324 */       this.wasLastValueNull = true;
/*  325 */       return 0.0D;
/*      */     }
/*  327 */     return number.doubleValue();
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(String columnLabel, int scale)
/*      */     throws SQLException
/*      */   {
/*  333 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public byte[] getBytes(String columnLabel) throws SQLException
/*      */   {
/*  338 */     this.wasLastValueNull = false;
/*  339 */     checkClosed();
/*      */     
/*  341 */     Object value = getObject(columnLabel);
/*  342 */     if (value == null) {
/*  343 */       this.wasLastValueNull = true;
/*  344 */       return null;
/*      */     }
/*  346 */     return (byte[])value;
/*      */   }
/*      */   
/*      */   public Date getDate(String columnLabel) throws SQLException
/*      */   {
/*  351 */     this.wasLastValueNull = false;
/*  352 */     checkClosed();
/*      */     
/*  354 */     Object value = getObject(columnLabel);
/*  355 */     if (value == null) {
/*  356 */       this.wasLastValueNull = true;
/*  357 */       return null;
/*      */     }
/*  359 */     return (Date)value;
/*      */   }
/*      */   
/*      */   public Time getTime(String columnLabel) throws SQLException
/*      */   {
/*  364 */     this.wasLastValueNull = false;
/*  365 */     checkClosed();
/*      */     
/*  367 */     Object value = getObject(columnLabel);
/*  368 */     if (value == null) {
/*  369 */       this.wasLastValueNull = true;
/*  370 */       return null;
/*      */     }
/*  372 */     return (Time)value;
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(String columnLabel) throws SQLException
/*      */   {
/*  377 */     this.wasLastValueNull = false;
/*  378 */     checkClosed();
/*      */     
/*  380 */     Object value = getObject(columnLabel);
/*  381 */     if (value == null) {
/*  382 */       this.wasLastValueNull = true;
/*  383 */       return null;
/*      */     }
/*  385 */     return (Timestamp)value;
/*      */   }
/*      */   
/*      */   public InputStream getAsciiStream(String columnLabel) throws SQLException
/*      */   {
/*  390 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public InputStream getUnicodeStream(String columnLabel) throws SQLException
/*      */   {
/*  395 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public InputStream getBinaryStream(String columnLabel) throws SQLException
/*      */   {
/*  400 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException
/*      */   {
/*  405 */     if (isClosed()) {
/*  406 */       throw new SQLException("Statement is closed.");
/*      */     }
/*      */     
/*  409 */     return this.currentWarning;
/*      */   }
/*      */   
/*      */   public void clearWarnings() throws SQLException
/*      */   {
/*  414 */     if (isClosed()) {
/*  415 */       throw new SQLException("Statement is closed.");
/*      */     }
/*      */     
/*  418 */     this.currentWarning = null;
/*      */   }
/*      */   
/*      */   public String getCursorName() throws SQLException
/*      */   {
/*  423 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException
/*      */   {
/*  428 */     checkClosed();
/*      */     
/*  430 */     return this.resultSetMetaData;
/*      */   }
/*      */   
/*      */   public Object getObject(int columnIndex) throws SQLException
/*      */   {
/*  435 */     return getObject(this.resultSetMetaData.getColumnLabel(columnIndex));
/*      */   }
/*      */   
/*      */   public Object getObject(String columnLabel) throws SQLException
/*      */   {
/*  440 */     this.wasLastValueNull = false;
/*  441 */     checkClosed();
/*      */     
/*  443 */     Object value = this.tuple.get(columnLabel);
/*  444 */     if (value == null) {
/*  445 */       this.wasLastValueNull = true;
/*  446 */       return null;
/*      */     }
/*  448 */     return value;
/*      */   }
/*      */   
/*      */   public int findColumn(String columnLabel) throws SQLException
/*      */   {
/*  453 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(int columnIndex) throws SQLException
/*      */   {
/*  458 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(String columnLabel) throws SQLException
/*      */   {
/*  463 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws SQLException
/*      */   {
/*  468 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(String columnLabel) throws SQLException
/*      */   {
/*  473 */     this.wasLastValueNull = false;
/*  474 */     checkClosed();
/*      */     
/*  476 */     Object value = getObject(columnLabel);
/*  477 */     if (value == null) {
/*  478 */       this.wasLastValueNull = true;
/*  479 */       return null;
/*      */     }
/*  481 */     return (BigDecimal)value;
/*      */   }
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException
/*      */   {
/*  486 */     checkClosed();
/*      */     
/*  488 */     throw new SQLFeatureNotSupportedException();
/*      */   }
/*      */   
/*      */   public boolean isAfterLast() throws SQLException
/*      */   {
/*  493 */     checkClosed();
/*      */     
/*  495 */     throw new SQLFeatureNotSupportedException();
/*      */   }
/*      */   
/*      */   public boolean isFirst() throws SQLException
/*      */   {
/*  500 */     checkClosed();
/*      */     
/*  502 */     throw new SQLFeatureNotSupportedException();
/*      */   }
/*      */   
/*      */   public boolean isLast() throws SQLException
/*      */   {
/*  507 */     checkClosed();
/*      */     
/*  509 */     throw new SQLFeatureNotSupportedException();
/*      */   }
/*      */   
/*      */   public void beforeFirst() throws SQLException
/*      */   {
/*  514 */     checkClosed();
/*      */     
/*  516 */     throw new SQLException("beforeFirst() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public void afterLast() throws SQLException
/*      */   {
/*  521 */     checkClosed();
/*      */     
/*  523 */     throw new SQLException("afterLast() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public boolean first() throws SQLException
/*      */   {
/*  528 */     checkClosed();
/*      */     
/*  530 */     throw new SQLException("first() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public boolean last() throws SQLException
/*      */   {
/*  535 */     checkClosed();
/*      */     
/*  537 */     throw new SQLException("last() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public int getRow() throws SQLException
/*      */   {
/*  542 */     checkClosed();
/*      */     
/*  544 */     throw new SQLFeatureNotSupportedException();
/*      */   }
/*      */   
/*      */   public boolean absolute(int row) throws SQLException
/*      */   {
/*  549 */     checkClosed();
/*      */     
/*  551 */     throw new SQLException("absolute() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public boolean relative(int rows) throws SQLException
/*      */   {
/*  556 */     checkClosed();
/*      */     
/*  558 */     throw new SQLException("relative() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public boolean previous() throws SQLException
/*      */   {
/*  563 */     checkClosed();
/*      */     
/*  565 */     throw new SQLException("previous() not supported on ResultSet with type TYPE_FORWARD_ONLY");
/*      */   }
/*      */   
/*      */   public void setFetchDirection(int direction) throws SQLException
/*      */   {
/*  570 */     checkClosed();
/*      */     
/*  572 */     if (direction != 1000) {
/*  573 */       throw new SQLException("Direction must be FETCH_FORWARD since ResultSet type is TYPE_FORWARD_ONLY");
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/*  580 */     checkClosed();
/*      */     
/*  582 */     return 1000;
/*      */   }
/*      */   
/*      */   public void setFetchSize(int rows) throws SQLException
/*      */   {
/*  587 */     checkClosed();
/*      */     
/*  589 */     if (rows < 0) {
/*  590 */       throw new SQLException("Rows must be >= 0");
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchSize() throws SQLException
/*      */   {
/*  596 */     checkClosed();
/*      */     
/*  598 */     return 0;
/*      */   }
/*      */   
/*      */   public int getType() throws SQLException
/*      */   {
/*  603 */     checkClosed();
/*      */     
/*  605 */     return 1003;
/*      */   }
/*      */   
/*      */   public int getConcurrency() throws SQLException
/*      */   {
/*  610 */     checkClosed();
/*      */     
/*  612 */     return 1007;
/*      */   }
/*      */   
/*      */   public boolean rowUpdated() throws SQLException
/*      */   {
/*  617 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean rowInserted() throws SQLException
/*      */   {
/*  622 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean rowDeleted() throws SQLException
/*      */   {
/*  627 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNull(int columnIndex) throws SQLException
/*      */   {
/*  632 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBoolean(int columnIndex, boolean x) throws SQLException
/*      */   {
/*  637 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateByte(int columnIndex, byte x) throws SQLException
/*      */   {
/*  642 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateShort(int columnIndex, short x) throws SQLException
/*      */   {
/*  647 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateInt(int columnIndex, int x) throws SQLException
/*      */   {
/*  652 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateLong(int columnIndex, long x) throws SQLException
/*      */   {
/*  657 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateFloat(int columnIndex, float x) throws SQLException
/*      */   {
/*  662 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateDouble(int columnIndex, double x) throws SQLException
/*      */   {
/*  667 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException
/*      */   {
/*  672 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateString(int columnIndex, String x) throws SQLException
/*      */   {
/*  677 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBytes(int columnIndex, byte[] x) throws SQLException
/*      */   {
/*  682 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateDate(int columnIndex, Date x) throws SQLException
/*      */   {
/*  687 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateTime(int columnIndex, Time x) throws SQLException
/*      */   {
/*  692 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException
/*      */   {
/*  697 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException
/*      */   {
/*  702 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException
/*      */   {
/*  707 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException
/*      */   {
/*  712 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateObject(int columnIndex, Object x, int scaleOrLength) throws SQLException
/*      */   {
/*  717 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateObject(int columnIndex, Object x) throws SQLException
/*      */   {
/*  722 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNull(String columnLabel) throws SQLException
/*      */   {
/*  727 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBoolean(String columnLabel, boolean x) throws SQLException
/*      */   {
/*  732 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateByte(String columnLabel, byte x) throws SQLException
/*      */   {
/*  737 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateShort(String columnLabel, short x) throws SQLException
/*      */   {
/*  742 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateInt(String columnLabel, int x) throws SQLException
/*      */   {
/*  747 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateLong(String columnLabel, long x) throws SQLException
/*      */   {
/*  752 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateFloat(String columnLabel, float x) throws SQLException
/*      */   {
/*  757 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateDouble(String columnLabel, double x) throws SQLException
/*      */   {
/*  762 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBigDecimal(String columnLabel, BigDecimal x) throws SQLException
/*      */   {
/*  767 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateString(String columnLabel, String x) throws SQLException
/*      */   {
/*  772 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBytes(String columnLabel, byte[] x) throws SQLException
/*      */   {
/*  777 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateDate(String columnLabel, Date x) throws SQLException
/*      */   {
/*  782 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateTime(String columnLabel, Time x) throws SQLException
/*      */   {
/*  787 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateTimestamp(String columnLabel, Timestamp x) throws SQLException
/*      */   {
/*  792 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(String columnLabel, InputStream x, int length) throws SQLException
/*      */   {
/*  797 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(String columnLabel, InputStream x, int length) throws SQLException
/*      */   {
/*  802 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(String columnLabel, Reader reader, int length) throws SQLException
/*      */   {
/*  807 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateObject(String columnLabel, Object x, int scaleOrLength) throws SQLException
/*      */   {
/*  812 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateObject(String columnLabel, Object x) throws SQLException
/*      */   {
/*  817 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void insertRow() throws SQLException
/*      */   {
/*  822 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateRow() throws SQLException
/*      */   {
/*  827 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void deleteRow() throws SQLException
/*      */   {
/*  832 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void refreshRow() throws SQLException
/*      */   {
/*  837 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException
/*      */   {
/*  842 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void moveToInsertRow() throws SQLException
/*      */   {
/*  847 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException
/*      */   {
/*  852 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Statement getStatement() throws SQLException
/*      */   {
/*  857 */     return this.statement;
/*      */   }
/*      */   
/*      */   public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException
/*      */   {
/*  862 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Ref getRef(int columnIndex) throws SQLException
/*      */   {
/*  867 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Blob getBlob(int columnIndex) throws SQLException
/*      */   {
/*  872 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Clob getClob(int columnIndex) throws SQLException
/*      */   {
/*  877 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Array getArray(int columnIndex) throws SQLException
/*      */   {
/*  882 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Object getObject(String columnLabel, Map<String, Class<?>> map) throws SQLException
/*      */   {
/*  887 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Ref getRef(String columnLabel)
/*      */     throws SQLException
/*      */   {
/*  893 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Blob getBlob(String columnLabel) throws SQLException
/*      */   {
/*  898 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Clob getClob(String columnLabel) throws SQLException
/*      */   {
/*  903 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Array getArray(String columnLabel) throws SQLException
/*      */   {
/*  908 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Date getDate(int columnIndex, Calendar cal) throws SQLException
/*      */   {
/*  913 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Date getDate(String columnLabel, Calendar cal) throws SQLException
/*      */   {
/*  918 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Time getTime(int columnIndex, Calendar cal) throws SQLException
/*      */   {
/*  923 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Time getTime(String columnLabel, Calendar cal) throws SQLException
/*      */   {
/*  928 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException
/*      */   {
/*  933 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(String columnLabel, Calendar cal) throws SQLException
/*      */   {
/*  938 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public URL getURL(int columnIndex) throws SQLException
/*      */   {
/*  943 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public URL getURL(String columnLabel) throws SQLException
/*      */   {
/*  948 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateRef(int columnIndex, Ref x) throws SQLException
/*      */   {
/*  953 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateRef(String columnLabel, Ref x) throws SQLException
/*      */   {
/*  958 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(int columnIndex, Blob x) throws SQLException
/*      */   {
/*  963 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(String columnLabel, Blob x) throws SQLException
/*      */   {
/*  968 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(int columnIndex, Clob x) throws SQLException
/*      */   {
/*  973 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(String columnLabel, Clob x) throws SQLException
/*      */   {
/*  978 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateArray(int columnIndex, Array x) throws SQLException
/*      */   {
/*  983 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateArray(String columnLabel, Array x) throws SQLException
/*      */   {
/*  988 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public RowId getRowId(int columnIndex) throws SQLException
/*      */   {
/*  993 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public RowId getRowId(String columnLabel) throws SQLException
/*      */   {
/*  998 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateRowId(int columnIndex, RowId x) throws SQLException
/*      */   {
/* 1003 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateRowId(String columnLabel, RowId x) throws SQLException
/*      */   {
/* 1008 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public int getHoldability() throws SQLException
/*      */   {
/* 1013 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean isClosed() throws SQLException
/*      */   {
/* 1018 */     return this.closed;
/*      */   }
/*      */   
/*      */   public void updateNString(int columnIndex, String nString) throws SQLException
/*      */   {
/* 1023 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNString(String columnLabel, String nString) throws SQLException
/*      */   {
/* 1028 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(int columnIndex, NClob nClob) throws SQLException
/*      */   {
/* 1033 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(String columnLabel, NClob nClob) throws SQLException
/*      */   {
/* 1038 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public NClob getNClob(int columnIndex) throws SQLException
/*      */   {
/* 1043 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public NClob getNClob(String columnLabel) throws SQLException
/*      */   {
/* 1048 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public SQLXML getSQLXML(int columnIndex) throws SQLException
/*      */   {
/* 1053 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public SQLXML getSQLXML(String columnLabel) throws SQLException
/*      */   {
/* 1058 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException
/*      */   {
/* 1063 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException
/*      */   {
/* 1068 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public String getNString(int columnIndex) throws SQLException
/*      */   {
/* 1073 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public String getNString(String columnLabel) throws SQLException
/*      */   {
/* 1078 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Reader getNCharacterStream(int columnIndex) throws SQLException
/*      */   {
/* 1083 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public Reader getNCharacterStream(String columnLabel) throws SQLException
/*      */   {
/* 1088 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException
/*      */   {
/* 1093 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException
/*      */   {
/* 1098 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException
/*      */   {
/* 1103 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException
/*      */   {
/* 1108 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException
/*      */   {
/* 1113 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException
/*      */   {
/* 1118 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException
/*      */   {
/* 1123 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException
/*      */   {
/* 1128 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException
/*      */   {
/* 1133 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException
/*      */   {
/* 1138 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(int columnIndex, Reader reader, long length) throws SQLException
/*      */   {
/* 1143 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(String columnLabel, Reader reader, long length) throws SQLException
/*      */   {
/* 1148 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException
/*      */   {
/* 1153 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException
/*      */   {
/* 1158 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException
/*      */   {
/* 1163 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException
/*      */   {
/* 1168 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException
/*      */   {
/* 1173 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException
/*      */   {
/* 1178 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x) throws SQLException
/*      */   {
/* 1183 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException
/*      */   {
/* 1188 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException
/*      */   {
/* 1193 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException
/*      */   {
/* 1198 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException
/*      */   {
/* 1203 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException
/*      */   {
/* 1208 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(int columnIndex, Reader reader) throws SQLException
/*      */   {
/* 1213 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateClob(String columnLabel, Reader reader) throws SQLException
/*      */   {
/* 1218 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(int columnIndex, Reader reader) throws SQLException
/*      */   {
/* 1223 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void updateNClob(String columnLabel, Reader reader) throws SQLException
/*      */   {
/* 1228 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public <T> T getObject(int columnIndex, Class<T> type) throws SQLException
/*      */   {
/* 1233 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public <T> T getObject(String columnLabel, Class<T> type) throws SQLException
/*      */   {
/* 1238 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException
/*      */   {
/* 1243 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*      */   {
/* 1248 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\ResultSetImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */