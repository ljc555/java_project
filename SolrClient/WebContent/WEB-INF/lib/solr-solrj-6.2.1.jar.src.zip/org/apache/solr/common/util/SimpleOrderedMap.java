/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleOrderedMap<T>
/*    */   extends NamedList<T>
/*    */ {
/*    */   public SimpleOrderedMap() {}
/*    */   
/*    */   public SimpleOrderedMap(int sz)
/*    */   {
/* 46 */     super(sz);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Deprecated
/*    */   public SimpleOrderedMap(List<Object> nameValuePairs)
/*    */   {
/* 57 */     super(nameValuePairs);
/*    */   }
/*    */   
/*    */   public SimpleOrderedMap(Map.Entry<String, T>[] nameValuePairs) {
/* 61 */     super(nameValuePairs);
/*    */   }
/*    */   
/*    */   public SimpleOrderedMap<T> clone()
/*    */   {
/* 66 */     ArrayList<Object> newList = new ArrayList(this.nvPairs.size());
/* 67 */     newList.addAll(this.nvPairs);
/* 68 */     return new SimpleOrderedMap(newList);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\SimpleOrderedMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */