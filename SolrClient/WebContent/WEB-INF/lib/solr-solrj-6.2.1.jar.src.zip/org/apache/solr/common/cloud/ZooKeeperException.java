/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZooKeeperException
/*    */   extends SolrException
/*    */ {
/*    */   public ZooKeeperException(SolrException.ErrorCode code, String msg, Throwable th)
/*    */   {
/* 24 */     super(code, msg, th);
/*    */   }
/*    */   
/*    */   public ZooKeeperException(SolrException.ErrorCode code, String msg) {
/* 28 */     super(code, msg);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZooKeeperException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */