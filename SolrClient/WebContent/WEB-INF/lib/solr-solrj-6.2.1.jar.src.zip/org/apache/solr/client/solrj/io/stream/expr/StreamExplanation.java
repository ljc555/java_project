/*    */ package org.apache.solr.client.solrj.io.stream.expr;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamExplanation
/*    */   extends Explanation
/*    */ {
/*    */   private List<Explanation> children;
/*    */   
/*    */   public StreamExplanation(String expressionNodeId)
/*    */   {
/* 31 */     super(expressionNodeId);
/*    */   }
/*    */   
/*    */   public List<Explanation> getChildren() {
/* 35 */     return this.children;
/*    */   }
/*    */   
/* 38 */   public void setChildren(List<Explanation> children) { this.children = children; }
/*    */   
/*    */   public StreamExplanation withChildren(List<Explanation> children) {
/* 41 */     setChildren(children);
/* 42 */     return this;
/*    */   }
/*    */   
/* 45 */   public StreamExplanation withChildren(Explanation[] children) { for (Explanation child : children) {
/* 46 */       addChild(child);
/*    */     }
/* 48 */     return this;
/*    */   }
/*    */   
/* 51 */   public void addChild(Explanation child) { if (null == this.children) {
/* 52 */       this.children = new ArrayList(1);
/*    */     }
/* 54 */     this.children.add(child);
/*    */   }
/*    */   
/*    */   public Map<String, Object> toMap() {
/* 58 */     Map<String, Object> map = super.toMap();
/*    */     
/* 60 */     if ((null != this.children) && (0 != this.children.size())) {
/* 61 */       List<Map<String, Object>> childrenMaps = new ArrayList();
/* 62 */       for (Explanation child : this.children) {
/* 63 */         childrenMaps.add(child.toMap());
/*    */       }
/* 65 */       map.put("children", childrenMaps);
/*    */     }
/*    */     
/* 68 */     return map;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamExplanation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */