/*     */ package org.apache.solr.client.solrj.io.ops;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcatOperation
/*     */   implements StreamOperation
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   private UUID operationNodeId = UUID.randomUUID();
/*     */   private String[] fields;
/*     */   private String as;
/*     */   private String delim;
/*     */   
/*     */   public ConcatOperation(String[] fields, String as, String delim)
/*     */   {
/*  46 */     this.fields = fields;
/*  47 */     this.as = as;
/*  48 */     this.delim = delim;
/*     */   }
/*     */   
/*     */   public ConcatOperation(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  53 */     if (3 == expression.getParameters().size()) {
/*  54 */       StreamExpressionNamedParameter fieldsParam = factory.getNamedOperand(expression, "fields");
/*  55 */       String fieldsStr = ((StreamExpressionValue)fieldsParam.getParameter()).getValue();
/*  56 */       this.fields = fieldsStr.split(",");
/*  57 */       for (int i = 0; i < this.fields.length; i++) {
/*  58 */         this.fields[i] = this.fields[i].trim();
/*     */       }
/*     */       
/*  61 */       StreamExpressionNamedParameter asParam = factory.getNamedOperand(expression, "as");
/*  62 */       this.as = ((StreamExpressionValue)asParam.getParameter()).getValue();
/*     */       
/*  64 */       StreamExpressionNamedParameter delim = factory.getNamedOperand(expression, "delim");
/*  65 */       this.delim = ((StreamExpressionValue)delim.getParameter()).getValue();
/*     */     } else {
/*  67 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void operate(Tuple tuple)
/*     */   {
/*  73 */     StringBuilder buf = new StringBuilder();
/*  74 */     for (String field : this.fields) {
/*  75 */       if (buf.length() > 0) {
/*  76 */         buf.append(this.delim);
/*     */       }
/*  78 */       Object value = tuple.get(field);
/*  79 */       if (null == value) value = "null";
/*  80 */       buf.append(value);
/*     */     }
/*     */     
/*  83 */     tuple.put(this.as, buf.toString());
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*     */   {
/*  88 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*  90 */     StringBuilder sb = new StringBuilder();
/*  91 */     for (String field : this.fields) {
/*  92 */       if (sb.length() > 0) sb.append(",");
/*  93 */       sb.append(field);
/*     */     }
/*  95 */     expression.addParameter(new StreamExpressionNamedParameter("fields", sb.toString()));
/*  96 */     expression.addParameter(new StreamExpressionNamedParameter("delim", this.delim));
/*  97 */     expression.addParameter(new StreamExpressionNamedParameter("as", this.as));
/*  98 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/* 103 */     return 
/*     */     
/*     */ 
/*     */ 
/* 107 */       new Explanation(this.operationNodeId.toString()).withExpressionType("operation").withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\ConcatOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */