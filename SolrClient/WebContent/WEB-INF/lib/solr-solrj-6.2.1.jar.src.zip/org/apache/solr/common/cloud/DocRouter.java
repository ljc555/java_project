/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.StrUtils;
/*     */ import org.noggit.JSONWriter;
/*     */ import org.noggit.JSONWriter.Writable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DocRouter
/*     */ {
/*     */   public static final String DEFAULT_NAME = "compositeId";
/*     */   public static final DocRouter DEFAULT;
/*     */   private static final Map<String, DocRouter> routerMap;
/*     */   
/*     */   public static DocRouter getDocRouter(String routerName)
/*     */   {
/*  46 */     DocRouter router = (DocRouter)routerMap.get(routerName);
/*  47 */     if (router != null) return router;
/*  48 */     throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Unknown document router '" + routerName + "'");
/*     */   }
/*     */   
/*     */   protected String getRouteField(DocCollection coll) {
/*  52 */     if (coll == null) return null;
/*  53 */     Map m = (Map)coll.get("router");
/*  54 */     if (m == null) return null;
/*  55 */     return (String)m.get("field");
/*     */   }
/*     */   
/*     */   public static Map<String, Object> getRouterSpec(ZkNodeProps props) {
/*  59 */     Map<String, Object> map = new LinkedHashMap();
/*  60 */     for (String s : props.keySet()) {
/*  61 */       if (s.startsWith("router.")) {
/*  62 */         map.put(s.substring(7), props.get(s));
/*     */       }
/*     */     }
/*  65 */     if (map.get("name") == null) {
/*  66 */       map.put("name", "compositeId");
/*     */     }
/*  68 */     return map;
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*  42 */     DEFAULT = new CompositeIdRouter();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     routerMap = new HashMap();
/*  75 */     PlainIdRouter plain = new PlainIdRouter();
/*     */     
/*  77 */     routerMap.put(null, plain);
/*  78 */     routerMap.put("plain", plain);
/*  79 */     routerMap.put("compositeId", "compositeId".equals("compositeId") ? DEFAULT : new CompositeIdRouter());
/*  80 */     routerMap.put("implicit", new ImplicitDocRouter());
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Range
/*     */     implements JSONWriter.Writable, Comparable<Range>
/*     */   {
/*     */     public int min;
/*     */     
/*     */     public int max;
/*     */     
/*     */     public Range(int min, int max)
/*     */     {
/*  93 */       assert (min <= max);
/*  94 */       this.min = min;
/*  95 */       this.max = max;
/*     */     }
/*     */     
/*     */     public boolean includes(int hash) {
/*  99 */       return (hash >= this.min) && (hash <= this.max);
/*     */     }
/*     */     
/*     */     public boolean isSubsetOf(Range superset) {
/* 103 */       return (superset.min <= this.min) && (superset.max >= this.max);
/*     */     }
/*     */     
/*     */     public boolean overlaps(Range other) {
/* 107 */       return (includes(other.min)) || (includes(other.max)) || (isSubsetOf(other));
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 112 */       return Integer.toHexString(this.min) + '-' + Integer.toHexString(this.max);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 120 */       return (this.min >> 28) + (this.min >> 25) + (this.min >> 21) + this.min;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 125 */       if (obj.getClass() != getClass()) return false;
/* 126 */       Range other = (Range)obj;
/* 127 */       return (this.min == other.min) && (this.max == other.max);
/*     */     }
/*     */     
/*     */     public void write(JSONWriter writer)
/*     */     {
/* 132 */       writer.write(toString());
/*     */     }
/*     */     
/*     */     public int compareTo(Range that)
/*     */     {
/* 137 */       int mincomp = Integer.valueOf(this.min).compareTo(Integer.valueOf(that.min));
/* 138 */       return mincomp == 0 ? Integer.valueOf(this.max).compareTo(Integer.valueOf(that.max)) : mincomp;
/*     */     }
/*     */   }
/*     */   
/*     */   public Range fromString(String range) {
/* 143 */     int middle = range.indexOf('-');
/* 144 */     String minS = range.substring(0, middle);
/* 145 */     String maxS = range.substring(middle + 1);
/* 146 */     long min = Long.parseLong(minS, 16);
/* 147 */     long max = Long.parseLong(maxS, 16);
/* 148 */     return new Range((int)min, (int)max);
/*     */   }
/*     */   
/*     */   public Range fullRange() {
/* 152 */     return new Range(Integer.MIN_VALUE, Integer.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Range> partitionRange(int partitions, Range range)
/*     */   {
/* 159 */     int min = range.min;
/* 160 */     int max = range.max;
/*     */     
/* 162 */     assert (max >= min);
/* 163 */     if (partitions == 0) return Collections.EMPTY_LIST;
/* 164 */     long rangeSize = max - min;
/* 165 */     long rangeStep = Math.max(1L, rangeSize / partitions);
/*     */     
/* 167 */     List<Range> ranges = new ArrayList(partitions);
/*     */     
/* 169 */     long start = min;
/* 170 */     long end = start;
/*     */     
/* 172 */     while (end < max) {
/* 173 */       end = start + rangeStep;
/*     */       
/* 175 */       if (ranges.size() == partitions - 1) {
/* 176 */         end = max;
/*     */       }
/* 178 */       ranges.add(new Range((int)start, (int)end));
/* 179 */       start = end + 1L;
/*     */     }
/*     */     
/* 182 */     return ranges;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Slice> getSearchSlices(String shardKeys, SolrParams params, DocCollection collection)
/*     */   {
/* 204 */     if ((shardKeys == null) || (shardKeys.indexOf(',') < 0)) {
/* 205 */       return getSearchSlicesSingle(shardKeys, params, collection);
/*     */     }
/*     */     
/* 208 */     List<String> shardKeyList = StrUtils.splitSmart(shardKeys, ",", true);
/* 209 */     HashSet<Slice> allSlices = new HashSet();
/* 210 */     for (String shardKey : shardKeyList) {
/* 211 */       allSlices.addAll(getSearchSlicesSingle(shardKey, params, collection));
/*     */     }
/* 213 */     return allSlices;
/*     */   }
/*     */   
/*     */   public abstract Slice getTargetSlice(String paramString1, SolrInputDocument paramSolrInputDocument, String paramString2, SolrParams paramSolrParams, DocCollection paramDocCollection);
/*     */   
/*     */   public abstract Collection<Slice> getSearchSlicesSingle(String paramString, SolrParams paramSolrParams, DocCollection paramDocCollection);
/*     */   
/*     */   public abstract boolean isTargetSlice(String paramString1, SolrInputDocument paramSolrInputDocument, SolrParams paramSolrParams, String paramString2, DocCollection paramDocCollection);
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\DocRouter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */