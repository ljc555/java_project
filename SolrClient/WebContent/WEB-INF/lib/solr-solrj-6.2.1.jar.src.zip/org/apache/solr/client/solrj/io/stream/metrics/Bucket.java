/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bucket
/*    */ {
/*    */   private static final String NULL_VALUE = "NULL";
/*    */   private String bucketKey;
/*    */   
/*    */   public Bucket(String bucketKey)
/*    */   {
/* 28 */     this.bucketKey = bucketKey;
/*    */   }
/*    */   
/*    */   public Object getBucketValue(Tuple tuple)
/*    */   {
/* 33 */     Object o = tuple.get(this.bucketKey);
/* 34 */     if (o == null) {
/* 35 */       return "NULL";
/*    */     }
/* 37 */     return o;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 42 */     return this.bucketKey;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\Bucket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */