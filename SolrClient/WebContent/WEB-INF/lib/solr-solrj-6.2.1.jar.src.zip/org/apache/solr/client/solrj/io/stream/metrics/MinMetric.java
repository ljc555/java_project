/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinMetric
/*    */   extends Metric
/*    */ {
/* 29 */   private long longMin = Long.MAX_VALUE;
/* 30 */   private double doubleMin = Double.MAX_VALUE;
/*    */   private String columnName;
/*    */   
/*    */   public MinMetric(String columnName) {
/* 34 */     init("min", columnName);
/*    */   }
/*    */   
/*    */   public MinMetric(StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 39 */     String functionName = expression.getFunctionName();
/* 40 */     String columnName = factory.getValueOperand(expression, 0);
/*    */     
/*    */ 
/* 43 */     if (null == columnName) {
/* 44 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expected %s(columnName)", new Object[] { expression, functionName }));
/*    */     }
/* 46 */     if (1 != expression.getParameters().size()) {
/* 47 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*    */     }
/*    */     
/* 50 */     init(functionName, columnName);
/*    */   }
/*    */   
/*    */   private void init(String functionName, String columnName) {
/* 54 */     this.columnName = columnName;
/* 55 */     setFunctionName(functionName);
/* 56 */     setIdentifier(new String[] { functionName, "(", columnName, ")" });
/*    */   }
/*    */   
/*    */   public String[] getColumns() {
/* 60 */     return new String[] { this.columnName };
/*    */   }
/*    */   
/*    */   public Number getValue() {
/* 64 */     if (this.longMin == Long.MAX_VALUE) {
/* 65 */       return Double.valueOf(this.doubleMin);
/*    */     }
/* 67 */     return Long.valueOf(this.longMin);
/*    */   }
/*    */   
/*    */   public void update(Tuple tuple)
/*    */   {
/* 72 */     Object o = tuple.get(this.columnName);
/* 73 */     if ((o instanceof Double)) {
/* 74 */       double d = ((Double)o).doubleValue();
/* 75 */       if (d < this.doubleMin) {
/* 76 */         this.doubleMin = d;
/*    */       }
/*    */     } else {
/* 79 */       long l = ((Long)o).longValue();
/* 80 */       if (l < this.longMin) {
/* 81 */         this.longMin = l;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Metric newInstance() {
/* 87 */     return new MinMetric(this.columnName);
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*    */   {
/* 92 */     return new StreamExpression(getFunctionName()).withParameter(this.columnName);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\MinMetric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */