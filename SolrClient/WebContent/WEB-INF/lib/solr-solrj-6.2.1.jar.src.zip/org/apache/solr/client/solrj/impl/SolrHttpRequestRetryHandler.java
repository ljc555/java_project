/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.net.ConnectException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.SSLException;
/*     */ import org.apache.http.HttpRequest;
/*     */ import org.apache.http.RequestLine;
/*     */ import org.apache.http.client.HttpRequestRetryHandler;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.client.protocol.HttpClientContext;
/*     */ import org.apache.http.impl.client.RequestWrapper;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrHttpRequestRetryHandler
/*     */   implements HttpRequestRetryHandler
/*     */ {
/*     */   private static final String GET = "GET";
/*  44 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*  46 */   public static final SolrHttpRequestRetryHandler INSTANCE = new SolrHttpRequestRetryHandler();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int retryCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<Class<? extends IOException>> nonRetriableClasses;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SolrHttpRequestRetryHandler(int retryCount, Collection<Class<? extends IOException>> clazzes)
/*     */   {
/*  64 */     this.retryCount = retryCount;
/*  65 */     this.nonRetriableClasses = new HashSet();
/*  66 */     for (Class<? extends IOException> clazz : clazzes) {
/*  67 */       this.nonRetriableClasses.add(clazz);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrHttpRequestRetryHandler(int retryCount)
/*     */   {
/*  86 */     this(retryCount, Arrays.asList(new Class[] { InterruptedIOException.class, UnknownHostException.class, ConnectException.class, SSLException.class }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrHttpRequestRetryHandler()
/*     */   {
/* 101 */     this(3);
/*     */   }
/*     */   
/*     */   public boolean retryRequest(IOException exception, int executionCount, HttpContext context)
/*     */   {
/* 106 */     log.debug("Retry http request {} out of {}", Integer.valueOf(executionCount), Integer.valueOf(this.retryCount));
/* 107 */     if (executionCount > this.retryCount) {
/* 108 */       log.debug("Do not retry, over max retry count");
/* 109 */       return false;
/*     */     }
/* 111 */     if (this.nonRetriableClasses.contains(exception.getClass())) {
/* 112 */       log.debug("Do not retry, non retriable class {}", exception.getClass().getName());
/* 113 */       return false;
/*     */     }
/* 115 */     for (Class<? extends IOException> rejectException : this.nonRetriableClasses) {
/* 116 */       if (rejectException.isInstance(exception)) {
/* 117 */         log.debug("Do not retry, non retriable class {}", exception.getClass().getName());
/* 118 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 122 */     HttpClientContext clientContext = HttpClientContext.adapt(context);
/* 123 */     HttpRequest request = clientContext.getRequest();
/*     */     
/* 125 */     if (requestIsAborted(request)) {
/* 126 */       log.debug("Do not retry, request was aborted");
/* 127 */       return false;
/*     */     }
/*     */     
/* 130 */     if (handleAsIdempotent(clientContext)) {
/* 131 */       log.debug("Retry, request should be idempotent");
/* 132 */       return true;
/*     */     }
/*     */     
/* 135 */     log.debug("Do not retry, no allow rules matched");
/* 136 */     return false;
/*     */   }
/*     */   
/*     */   public int getRetryCount() {
/* 140 */     return this.retryCount;
/*     */   }
/*     */   
/*     */   protected boolean handleAsIdempotent(HttpClientContext context) {
/* 144 */     String method = context.getRequest().getRequestLine().getMethod();
/*     */     
/* 146 */     if (context.getRequest().getRequestLine().getUri().startsWith("/admin/")) {
/* 147 */       log.debug("Do not retry, this is an admin request");
/* 148 */       return false;
/*     */     }
/* 150 */     return method.equals("GET");
/*     */   }
/*     */   
/*     */   protected boolean requestIsAborted(HttpRequest request) {
/* 154 */     HttpRequest req = request;
/* 155 */     if ((request instanceof RequestWrapper)) {
/* 156 */       req = ((RequestWrapper)request).getOriginal();
/*     */     }
/* 158 */     return ((req instanceof HttpUriRequest)) && (((HttpUriRequest)req).isAborted());
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\SolrHttpRequestRetryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */