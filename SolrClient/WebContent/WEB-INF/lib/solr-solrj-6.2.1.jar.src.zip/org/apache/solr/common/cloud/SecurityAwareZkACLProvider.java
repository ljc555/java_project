/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.zookeeper.data.ACL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SecurityAwareZkACLProvider
/*    */   implements ZkACLProvider
/*    */ {
/*    */   public static final String SECURITY_ZNODE_PATH = "/security";
/*    */   private List<ACL> nonSecurityACLsToAdd;
/*    */   private List<ACL> securityACLsToAdd;
/*    */   
/*    */   public List<ACL> getACLsToAdd(String zNodePath)
/*    */   {
/* 37 */     if (isSecurityZNodePath(zNodePath)) {
/* 38 */       return getSecurityACLsToAdd();
/*    */     }
/* 40 */     return getNonSecurityACLsToAdd();
/*    */   }
/*    */   
/*    */   protected boolean isSecurityZNodePath(String zNodePath)
/*    */   {
/* 45 */     if ((zNodePath != null) && (
/* 46 */       (zNodePath.equals("/security")) || (zNodePath.startsWith("/security/")))) {
/* 47 */       return true;
/*    */     }
/* 49 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected abstract List<ACL> createNonSecurityACLsToAdd();
/*    */   
/*    */ 
/*    */ 
/*    */   protected abstract List<ACL> createSecurityACLsToAdd();
/*    */   
/*    */ 
/*    */   private List<ACL> getNonSecurityACLsToAdd()
/*    */   {
/* 63 */     if (this.nonSecurityACLsToAdd == null) {
/* 64 */       synchronized (this) {
/* 65 */         if (this.nonSecurityACLsToAdd == null) this.nonSecurityACLsToAdd = createNonSecurityACLsToAdd();
/*    */       }
/*    */     }
/* 68 */     return this.nonSecurityACLsToAdd;
/*    */   }
/*    */   
/*    */   private List<ACL> getSecurityACLsToAdd() {
/* 72 */     if (this.securityACLsToAdd == null) {
/* 73 */       synchronized (this) {
/* 74 */         if (this.securityACLsToAdd == null) this.securityACLsToAdd = createSecurityACLsToAdd();
/*    */       }
/*    */     }
/* 77 */     return this.securityACLsToAdd;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\SecurityAwareZkACLProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */