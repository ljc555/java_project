/*    */ package org.apache.solr.client.solrj.io.comp;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ComparatorOrder
/*    */ {
/* 25 */   ASCENDING,  DESCENDING;
/*    */   
/*    */   private ComparatorOrder() {}
/* 28 */   public static ComparatorOrder fromString(String order) { switch (order.toLowerCase(Locale.ROOT)) {
/*    */     case "asc": 
/* 30 */       return ASCENDING;
/*    */     case "desc": 
/* 32 */       return DESCENDING;
/*    */     }
/* 34 */     throw new IllegalArgumentException(String.format(Locale.ROOT, "Unknown order '%s'", new Object[] { order }));
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 39 */     switch (this) {
/*    */     case DESCENDING: 
/* 41 */       return "desc";
/*    */     }
/* 43 */     return "asc";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\comp\ComparatorOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */