/*     */ package org.apache.solr.client.solrj.response.schema;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.request.schema.FieldTypeDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaRepresentation
/*     */ {
/*     */   private String name;
/*     */   private float version;
/*     */   private String uniqueKey;
/*     */   private String defaultSearchField;
/*     */   private String defaultOperator;
/*     */   private Map<String, Object> similarity;
/*     */   private List<Map<String, Object>> fields;
/*     */   private List<Map<String, Object>> dynamicFields;
/*     */   private List<FieldTypeDefinition> fieldTypes;
/*     */   private List<Map<String, Object>> copyFields;
/*     */   
/*     */   public String getName()
/*     */   {
/*  48 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  52 */     this.name = name;
/*     */   }
/*     */   
/*     */   public float getVersion() {
/*  56 */     return this.version;
/*     */   }
/*     */   
/*     */   public void setVersion(float version) {
/*  60 */     this.version = version;
/*     */   }
/*     */   
/*     */   public String getUniqueKey() {
/*  64 */     return this.uniqueKey;
/*     */   }
/*     */   
/*     */   public void setUniqueKey(String uniqueKey) {
/*  68 */     this.uniqueKey = uniqueKey;
/*     */   }
/*     */   
/*     */   public String getDefaultSearchField() {
/*  72 */     return this.defaultSearchField;
/*     */   }
/*     */   
/*     */   public void setDefaultSearchField(String defaultSearchField) {
/*  76 */     this.defaultSearchField = defaultSearchField;
/*     */   }
/*     */   
/*     */   public String getDefaultOperator() {
/*  80 */     return this.defaultOperator;
/*     */   }
/*     */   
/*     */   public void setDefaultOperator(String defaultOperator) {
/*  84 */     this.defaultOperator = defaultOperator;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getSimilarity() {
/*  88 */     return this.similarity;
/*     */   }
/*     */   
/*     */   public void setSimilarity(Map<String, Object> similarity) {
/*  92 */     this.similarity = similarity;
/*     */   }
/*     */   
/*     */   public List<Map<String, Object>> getFields() {
/*  96 */     return this.fields;
/*     */   }
/*     */   
/*     */   public void setFields(List<Map<String, Object>> fields) {
/* 100 */     this.fields = fields;
/*     */   }
/*     */   
/*     */   public List<Map<String, Object>> getDynamicFields() {
/* 104 */     return this.dynamicFields;
/*     */   }
/*     */   
/*     */   public void setDynamicFields(List<Map<String, Object>> dynamicFields) {
/* 108 */     this.dynamicFields = dynamicFields;
/*     */   }
/*     */   
/*     */   public List<FieldTypeDefinition> getFieldTypes() {
/* 112 */     return this.fieldTypes;
/*     */   }
/*     */   
/*     */   public void setFieldTypes(List<FieldTypeDefinition> fieldTypes) {
/* 116 */     this.fieldTypes = fieldTypes;
/*     */   }
/*     */   
/*     */   public List<Map<String, Object>> getCopyFields() {
/* 120 */     return this.copyFields;
/*     */   }
/*     */   
/*     */   public void setCopyFields(List<Map<String, Object>> copyFields) {
/* 124 */     this.copyFields = copyFields;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\schema\SchemaRepresentation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */