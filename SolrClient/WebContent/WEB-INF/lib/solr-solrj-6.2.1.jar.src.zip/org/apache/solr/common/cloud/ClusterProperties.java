/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.util.Utils;
/*     */ import org.apache.zookeeper.CreateMode;
/*     */ import org.apache.zookeeper.KeeperException;
/*     */ import org.apache.zookeeper.KeeperException.BadVersionException;
/*     */ import org.apache.zookeeper.KeeperException.NoNodeException;
/*     */ import org.apache.zookeeper.KeeperException.NodeExistsException;
/*     */ import org.apache.zookeeper.data.Stat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterProperties
/*     */ {
/*     */   private final SolrZkClient client;
/*     */   
/*     */   public ClusterProperties(SolrZkClient client)
/*     */   {
/*  46 */     this.client = client;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T getClusterProperty(String key, T defaultValue)
/*     */     throws IOException
/*     */   {
/*  59 */     T value = getClusterProperties().get(key);
/*  60 */     if (value == null)
/*  61 */       return defaultValue;
/*  62 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getClusterProperties()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       return (Map)Utils.fromJSON(this.client.getData("/clusterprops.json", null, new Stat(), true));
/*     */     } catch (KeeperException.NoNodeException e) {
/*  74 */       return Collections.emptyMap();
/*     */     } catch (KeeperException|InterruptedException e) {
/*  76 */       throw new IOException("Error reading cluster property", SolrZkClient.checkInterrupted(e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClusterProperty(String propertyName, String propertyValue)
/*     */     throws IOException
/*     */   {
/*  90 */     if (!ZkStateReader.KNOWN_CLUSTER_PROPS.contains(propertyName)) {
/*  91 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Not a known cluster property " + propertyName);
/*     */     }
/*     */     for (;;)
/*     */     {
/*  95 */       Stat s = new Stat();
/*     */       try {
/*  97 */         if (this.client.exists("/clusterprops.json", true).booleanValue()) {
/*  98 */           Map properties = (Map)Utils.fromJSON(this.client.getData("/clusterprops.json", null, s, true));
/*  99 */           if (propertyValue == null)
/*     */           {
/* 101 */             if (properties.get(propertyName) != null) {
/* 102 */               properties.remove(propertyName);
/* 103 */               this.client.setData("/clusterprops.json", Utils.toJSON(properties), s.getVersion(), true);
/*     */             }
/*     */             
/*     */           }
/* 107 */           else if (!propertyValue.equals(properties.get(propertyName))) {
/* 108 */             properties.put(propertyName, propertyValue);
/* 109 */             this.client.setData("/clusterprops.json", Utils.toJSON(properties), s.getVersion(), true);
/*     */           }
/*     */         }
/*     */         else {
/* 113 */           Map properties = new LinkedHashMap();
/* 114 */           properties.put(propertyName, propertyValue);
/* 115 */           this.client.create("/clusterprops.json", Utils.toJSON(properties), CreateMode.PERSISTENT, true);
/*     */         }
/*     */         
/*     */       }
/*     */       catch (KeeperException.BadVersionException|KeeperException.NodeExistsException e) {}catch (InterruptedException|KeeperException e)
/*     */       {
/* 121 */         throw new IOException("Error setting cluster property", SolrZkClient.checkInterrupted(e));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ClusterProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */