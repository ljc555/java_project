/*    */ package org.apache.solr.client.solrj.io.ops;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.UUID;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DistinctOperation
/*    */   implements ReduceOperation
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 32 */   private UUID operationNodeId = UUID.randomUUID();
/*    */   private Tuple current;
/*    */   
/*    */   public DistinctOperation(StreamExpression expression, StreamFactory factory) throws IOException {
/* 36 */     init();
/*    */   }
/*    */   
/*    */   public DistinctOperation() {
/* 40 */     init();
/*    */   }
/*    */   
/*    */   private void init() {}
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*    */   {
/* 47 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/* 48 */     return expression;
/*    */   }
/*    */   
/*    */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*    */   {
/* 53 */     return 
/*    */     
/*    */ 
/*    */ 
/* 57 */       new Explanation(this.operationNodeId.toString()).withExpressionType("operation").withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*    */   }
/*    */   
/*    */ 
/*    */   public Tuple reduce()
/*    */   {
/* 63 */     Tuple toReturn = this.current;
/* 64 */     this.current = null;
/*    */     
/* 66 */     return toReturn;
/*    */   }
/*    */   
/*    */   public void operate(Tuple tuple)
/*    */   {
/* 71 */     if (null == this.current) {
/* 72 */       this.current = tuple;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\DistinctOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */