/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentAnalysisResponse
/*     */   extends AnalysisResponseBase
/*     */   implements Iterable<Map.Entry<String, DocumentAnalysis>>
/*     */ {
/*  35 */   private final Map<String, DocumentAnalysis> documentAnalysisByKey = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(NamedList<Object> response)
/*     */   {
/*  42 */     super.setResponse(response);
/*     */     
/*     */ 
/*     */ 
/*  46 */     NamedList<NamedList<NamedList<Object>>> analysis = (NamedList)response.get("analysis");
/*  47 */     for (Map.Entry<String, NamedList<NamedList<Object>>> document : analysis) {
/*  48 */       DocumentAnalysis documentAnalysis = new DocumentAnalysis((String)document.getKey(), null);
/*  49 */       for (Map.Entry<String, NamedList<Object>> fieldEntry : (NamedList)document.getValue()) {
/*  50 */         FieldAnalysis fieldAnalysis = new FieldAnalysis((String)fieldEntry.getKey(), null);
/*     */         
/*  52 */         NamedList<Object> field = (NamedList)fieldEntry.getValue();
/*     */         
/*     */ 
/*     */ 
/*  56 */         NamedList<List<NamedList<Object>>> query = (NamedList)field.get("query");
/*  57 */         if (query != null) {
/*  58 */           List<AnalysisResponseBase.AnalysisPhase> phases = buildPhases(query);
/*  59 */           fieldAnalysis.setQueryPhases(phases);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  64 */         NamedList<NamedList<List<NamedList<Object>>>> index = (NamedList)field.get("index");
/*  65 */         for (Map.Entry<String, NamedList<List<NamedList<Object>>>> valueEntry : index) {
/*  66 */           String fieldValue = (String)valueEntry.getKey();
/*  67 */           NamedList<List<NamedList<Object>>> valueNL = (NamedList)valueEntry.getValue();
/*  68 */           List<AnalysisResponseBase.AnalysisPhase> phases = buildPhases(valueNL);
/*  69 */           fieldAnalysis.setIndexPhases(fieldValue, phases);
/*     */         }
/*     */         
/*  72 */         documentAnalysis.addFieldAnalysis(fieldAnalysis);
/*     */       }
/*     */       
/*  75 */       this.documentAnalysisByKey.put(documentAnalysis.getDocumentKey(), documentAnalysis);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDocumentAnalysesCount()
/*     */   {
/*  85 */     return this.documentAnalysisByKey.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysis getDocumentAnalysis(String documentKey)
/*     */   {
/*  97 */     return (DocumentAnalysis)this.documentAnalysisByKey.get(documentKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Map.Entry<String, DocumentAnalysis>> iterator()
/*     */   {
/* 107 */     return this.documentAnalysisByKey.entrySet().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class DocumentAnalysis
/*     */     implements Iterable<Map.Entry<String, DocumentAnalysisResponse.FieldAnalysis>>
/*     */   {
/*     */     private final String documentKey;
/*     */     
/*     */ 
/* 118 */     private Map<String, DocumentAnalysisResponse.FieldAnalysis> fieldAnalysisByFieldName = new HashMap();
/*     */     
/*     */     private DocumentAnalysis(String documentKey) {
/* 121 */       this.documentKey = documentKey;
/*     */     }
/*     */     
/*     */     private void addFieldAnalysis(DocumentAnalysisResponse.FieldAnalysis fieldAnalysis) {
/* 125 */       this.fieldAnalysisByFieldName.put(fieldAnalysis.getFieldName(), fieldAnalysis);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getDocumentKey()
/*     */     {
/* 134 */       return this.documentKey;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getFieldAnalysesCount()
/*     */     {
/* 143 */       return this.fieldAnalysisByFieldName.size();
/*     */     }
/*     */     
/*     */     public DocumentAnalysisResponse.FieldAnalysis getFieldAnalysis(String fieldName) {
/* 147 */       return (DocumentAnalysisResponse.FieldAnalysis)this.fieldAnalysisByFieldName.get(fieldName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterator<Map.Entry<String, DocumentAnalysisResponse.FieldAnalysis>> iterator()
/*     */     {
/* 157 */       return this.fieldAnalysisByFieldName.entrySet().iterator();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class FieldAnalysis
/*     */   {
/*     */     private final String fieldName;
/*     */     
/*     */ 
/*     */     private List<AnalysisResponseBase.AnalysisPhase> queryPhases;
/*     */     
/* 170 */     private Map<String, List<AnalysisResponseBase.AnalysisPhase>> indexPhasesByFieldValue = new HashMap();
/*     */     
/*     */     private FieldAnalysis(String fieldName) {
/* 173 */       this.fieldName = fieldName;
/*     */     }
/*     */     
/*     */     public void setQueryPhases(List<AnalysisResponseBase.AnalysisPhase> queryPhases) {
/* 177 */       this.queryPhases = queryPhases;
/*     */     }
/*     */     
/*     */     public void setIndexPhases(String fieldValue, List<AnalysisResponseBase.AnalysisPhase> indexPhases) {
/* 181 */       this.indexPhasesByFieldValue.put(fieldValue, indexPhases);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getFieldName()
/*     */     {
/* 190 */       return this.fieldName;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getQueryPhasesCount()
/*     */     {
/* 201 */       return this.queryPhases == null ? -1 : this.queryPhases.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterable<AnalysisResponseBase.AnalysisPhase> getQueryPhases()
/*     */     {
/* 212 */       return this.queryPhases;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getValueCount()
/*     */     {
/* 221 */       return this.indexPhasesByFieldValue.entrySet().size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getIndexPhasesCount(String fieldValue)
/*     */     {
/* 232 */       return ((List)this.indexPhasesByFieldValue.get(fieldValue)).size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterable<AnalysisResponseBase.AnalysisPhase> getIndexPhases(String fieldValue)
/*     */     {
/* 243 */       return (Iterable)this.indexPhasesByFieldValue.get(fieldValue);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Iterable<Map.Entry<String, List<AnalysisResponseBase.AnalysisPhase>>> getIndexPhasesByFieldValue()
/*     */     {
/* 252 */       return this.indexPhasesByFieldValue.entrySet();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\DocumentAnalysisResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */