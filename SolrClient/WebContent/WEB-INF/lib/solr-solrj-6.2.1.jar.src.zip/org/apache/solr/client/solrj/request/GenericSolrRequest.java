/*    */ package org.apache.solr.client.solrj.request;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import org.apache.solr.client.solrj.SolrClient;
/*    */ import org.apache.solr.client.solrj.SolrRequest;
/*    */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*    */ import org.apache.solr.client.solrj.response.SimpleSolrResponse;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ import org.apache.solr.common.util.ContentStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericSolrRequest
/*    */   extends SolrRequest<SimpleSolrResponse>
/*    */ {
/*    */   public SolrParams params;
/* 30 */   public SimpleSolrResponse response = new SimpleSolrResponse();
/*    */   private Collection<ContentStream> contentStreams;
/*    */   
/*    */   public GenericSolrRequest(SolrRequest.METHOD m, String path, SolrParams params) {
/* 34 */     super(m, path);
/* 35 */     this.params = params;
/*    */   }
/*    */   
/*    */   public void setContentStreams(Collection<ContentStream> streams) {
/* 39 */     this.contentStreams = streams;
/*    */   }
/*    */   
/*    */ 
/*    */   public SolrParams getParams()
/*    */   {
/* 45 */     return this.params;
/*    */   }
/*    */   
/*    */   public Collection<ContentStream> getContentStreams() throws IOException
/*    */   {
/* 50 */     return this.contentStreams;
/*    */   }
/*    */   
/*    */   protected SimpleSolrResponse createResponse(SolrClient client)
/*    */   {
/* 55 */     return this.response;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\GenericSolrRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */