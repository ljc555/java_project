/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient.Builder;
/*     */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*  49 */   private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   private String collection;
/*     */   private String zkHost;
/*     */   private int updateBatchSize;
/*     */   private int batchNumber;
/*     */   private long totalDocsIndex;
/*     */   private PushBackStream tupleSource;
/*     */   private transient SolrClientCache cache;
/*     */   private transient CloudSolrClient cloudSolrClient;
/*  59 */   private List<SolrInputDocument> documentBatch = new ArrayList();
/*     */   private String coreName;
/*     */   
/*     */   public UpdateStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  64 */     String collectionName = factory.getValueOperand(expression, 0);
/*  65 */     verifyCollectionName(collectionName, expression);
/*     */     
/*  67 */     String zkHost = findZkHost(factory, collectionName, expression);
/*  68 */     verifyZkHost(zkHost, collectionName, expression);
/*     */     
/*  70 */     int updateBatchSize = extractBatchSize(expression, factory);
/*     */     
/*     */ 
/*  73 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  74 */     if (1 != streamExpressions.size()) {
/*  75 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*  77 */     StreamExpression sourceStreamExpression = (StreamExpression)streamExpressions.get(0);
/*     */     
/*  79 */     init(collectionName, factory.constructStream(sourceStreamExpression), zkHost, updateBatchSize);
/*     */   }
/*     */   
/*     */   public UpdateStream(String collectionName, TupleStream tupleSource, String zkHost, int updateBatchSize) throws IOException {
/*  83 */     if (updateBatchSize <= 0) {
/*  84 */       throw new IOException(String.format(Locale.ROOT, "batchSize '%d' must be greater than 0.", new Object[] { Integer.valueOf(updateBatchSize) }));
/*     */     }
/*  86 */     init(collectionName, tupleSource, zkHost, updateBatchSize);
/*     */   }
/*     */   
/*     */   private void init(String collectionName, TupleStream tupleSource, String zkHost, int updateBatchSize) {
/*  90 */     this.collection = collectionName;
/*  91 */     this.zkHost = zkHost;
/*  92 */     this.updateBatchSize = updateBatchSize;
/*  93 */     this.tupleSource = new PushBackStream(tupleSource);
/*     */   }
/*     */   
/*     */   public void open() throws IOException
/*     */   {
/*  98 */     setCloudSolrClient();
/*  99 */     this.tupleSource.open();
/*     */   }
/*     */   
/*     */   public Tuple read()
/*     */     throws IOException
/*     */   {
/* 105 */     for (int i = 0; i < this.updateBatchSize; i++) {
/* 106 */       Tuple tuple = this.tupleSource.read();
/* 107 */       if (tuple.EOF) {
/* 108 */         if (this.documentBatch.isEmpty()) {
/* 109 */           return tuple;
/*     */         }
/* 111 */         this.tupleSource.pushBack(tuple);
/* 112 */         uploadBatchToCollection(this.documentBatch);
/* 113 */         int b = this.documentBatch.size();
/* 114 */         this.documentBatch.clear();
/* 115 */         return createBatchSummaryTuple(b);
/*     */       }
/*     */       
/* 118 */       this.documentBatch.add(convertTupleToSolrDocument(tuple));
/*     */     }
/*     */     
/* 121 */     uploadBatchToCollection(this.documentBatch);
/* 122 */     int b = this.documentBatch.size();
/* 123 */     this.documentBatch.clear();
/* 124 */     return createBatchSummaryTuple(b);
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 129 */     if ((this.cache == null) && (this.cloudSolrClient != null)) {
/* 130 */       this.cloudSolrClient.close();
/*     */     }
/* 132 */     this.tupleSource.close();
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 137 */     return this.tupleSource.getStreamSort();
/*     */   }
/*     */   
/*     */   public List<TupleStream> children()
/*     */   {
/* 142 */     ArrayList<TupleStream> sourceList = new ArrayList(1);
/* 143 */     sourceList.add(this.tupleSource);
/* 144 */     return sourceList;
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 149 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException {
/* 153 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/* 154 */     expression.addParameter(this.collection);
/* 155 */     expression.addParameter(new StreamExpressionNamedParameter("zkHost", this.zkHost));
/* 156 */     expression.addParameter(new StreamExpressionNamedParameter("batchSize", Integer.toString(this.updateBatchSize)));
/*     */     
/* 158 */     if (includeStreams) {
/* 159 */       if ((this.tupleSource instanceof Expressible)) {
/* 160 */         expression.addParameter(this.tupleSource.toExpression(factory));
/*     */       } else {
/* 162 */         throw new IOException("This ParallelStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 166 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/* 169 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 178 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId() + "-datastore");
/*     */     
/* 180 */     explanation.setFunctionName(String.format(Locale.ROOT, "solr (%s)", new Object[] { this.collection }));
/* 181 */     explanation.setImplementingClass("Solr/Lucene");
/* 182 */     explanation.setExpressionType("datastore");
/* 183 */     explanation.setExpression("Update into " + this.collection);
/*     */     
/*     */ 
/* 186 */     StreamExplanation child = new StreamExplanation(getStreamNodeId().toString());
/* 187 */     child.setFunctionName(String.format(Locale.ROOT, factory.getFunctionName(getClass()), new Object[0]));
/* 188 */     child.setImplementingClass(getClass().getName());
/* 189 */     child.setExpressionType("stream-decorator");
/* 190 */     child.setExpression(toExpression(factory, false).toString());
/* 191 */     child.addChild(this.tupleSource.toExplanation(factory));
/*     */     
/* 193 */     explanation.addChild(child);
/*     */     
/* 195 */     return explanation;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context)
/*     */   {
/* 200 */     this.cache = context.getSolrClientCache();
/* 201 */     this.coreName = ((String)context.get("core"));
/* 202 */     this.tupleSource.setStreamContext(context);
/*     */   }
/*     */   
/*     */   private void verifyCollectionName(String collectionName, StreamExpression expression) throws IOException {
/* 206 */     if (null == collectionName) {
/* 207 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - collectionName expected as first operand", new Object[] { expression }));
/*     */     }
/*     */   }
/*     */   
/*     */   private String findZkHost(StreamFactory factory, String collectionName, StreamExpression expression) {
/* 212 */     StreamExpressionNamedParameter zkHostExpression = factory.getNamedOperand(expression, "zkHost");
/* 213 */     if (null == zkHostExpression) {
/* 214 */       String zkHost = factory.getCollectionZkHost(collectionName);
/* 215 */       if (zkHost == null) {
/* 216 */         return factory.getDefaultZkHost();
/*     */       }
/* 218 */       return zkHost;
/*     */     }
/* 220 */     if ((zkHostExpression.getParameter() instanceof StreamExpressionValue)) {
/* 221 */       return ((StreamExpressionValue)zkHostExpression.getParameter()).getValue();
/*     */     }
/*     */     
/* 224 */     return null;
/*     */   }
/*     */   
/*     */   private void verifyZkHost(String zkHost, String collectionName, StreamExpression expression) throws IOException {
/* 228 */     if (null == zkHost) {
/* 229 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - zkHost not found for collection '%s'", new Object[] { expression, collectionName }));
/*     */     }
/*     */   }
/*     */   
/*     */   private int extractBatchSize(StreamExpression expression, StreamFactory factory) throws IOException {
/* 234 */     StreamExpressionNamedParameter batchSizeParam = factory.getNamedOperand(expression, "batchSize");
/* 235 */     if ((null == batchSizeParam) || (null == batchSizeParam.getParameter()) || (!(batchSizeParam.getParameter() instanceof StreamExpressionValue))) {
/* 236 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a 'batchSize' parameter of type positive integer but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/* 239 */     String batchSizeStr = ((StreamExpressionValue)batchSizeParam.getParameter()).getValue();
/* 240 */     return parseBatchSize(batchSizeStr, expression);
/*     */   }
/*     */   
/*     */   private int parseBatchSize(String batchSizeStr, StreamExpression expression) throws IOException {
/*     */     try {
/* 245 */       int batchSize = Integer.parseInt(batchSizeStr);
/* 246 */       if (batchSize <= 0) {
/* 247 */         throw new IOException(String.format(Locale.ROOT, "invalid expression %s - batchSize '%d' must be greater than 0.", new Object[] { expression, Integer.valueOf(batchSize) }));
/*     */       }
/* 249 */       return batchSize;
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 252 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - batchSize '%s' is not a valid integer.", new Object[] { expression, batchSizeStr }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void setCloudSolrClient() {
/* 257 */     if (this.cache != null) {
/* 258 */       this.cloudSolrClient = this.cache.getCloudSolrClient(this.zkHost);
/*     */     }
/*     */     else
/*     */     {
/* 262 */       this.cloudSolrClient = new CloudSolrClient.Builder().withZkHost(this.zkHost).build();
/* 263 */       this.cloudSolrClient.connect();
/*     */     }
/*     */   }
/*     */   
/*     */   private SolrInputDocument convertTupleToSolrDocument(Tuple tuple) {
/* 268 */     SolrInputDocument doc = new SolrInputDocument(new String[0]);
/* 269 */     for (Object field : tuple.fields.keySet()) {
/* 270 */       if (!((String)field).equals("_version_")) {
/* 271 */         Object value = tuple.get(field);
/* 272 */         if ((value instanceof List)) {
/* 273 */           addMultivaluedField(doc, (String)field, (List)value);
/*     */         } else {
/* 275 */           doc.addField((String)field, tuple.get(field));
/*     */         }
/*     */       }
/*     */     }
/* 279 */     LOG.debug("Tuple [{}] was converted into SolrInputDocument [{}].", tuple, doc);
/*     */     
/* 281 */     return doc;
/*     */   }
/*     */   
/*     */   private void addMultivaluedField(SolrInputDocument doc, String fieldName, List<Object> values) {
/* 285 */     for (Object value : values) {
/* 286 */       doc.addField(fieldName, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void uploadBatchToCollection(List<SolrInputDocument> documentBatch) throws IOException {
/* 291 */     if (documentBatch.size() == 0) {
/* 292 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 296 */       this.cloudSolrClient.add(this.collection, documentBatch);
/*     */     } catch (SolrServerException|IOException e) {
/* 298 */       LOG.warn("Unable to add documents to collection due to unexpected error.", e);
/* 299 */       String className = e.getClass().getName();
/* 300 */       String message = e.getMessage();
/* 301 */       throw new IOException(String.format(Locale.ROOT, "Unexpected error when adding documents to collection %s- %s:%s", new Object[] { this.collection, className, message }));
/*     */     }
/*     */   }
/*     */   
/*     */   private Tuple createBatchSummaryTuple(int batchSize) {
/* 306 */     assert (batchSize > 0);
/* 307 */     Map m = new HashMap();
/* 308 */     this.totalDocsIndex += batchSize;
/* 309 */     this.batchNumber += 1;
/* 310 */     m.put("batchIndexed", Integer.valueOf(batchSize));
/* 311 */     m.put("totalIndexed", Long.valueOf(this.totalDocsIndex));
/* 312 */     m.put("batchNumber", Integer.valueOf(this.batchNumber));
/* 313 */     if (this.coreName != null) {
/* 314 */       m.put("worker", this.coreName);
/*     */     }
/* 316 */     return new Tuple(m);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\UpdateStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */