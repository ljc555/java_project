/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntersectStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PushBackStream streamA;
/*     */   private PushBackStream streamB;
/*     */   private TupleStream originalStreamB;
/*     */   private StreamEqualitor eq;
/*     */   
/*     */   public IntersectStream(TupleStream streamA, TupleStream streamB, StreamEqualitor eq)
/*     */     throws IOException
/*     */   {
/*  52 */     init(streamA, streamB, eq);
/*     */   }
/*     */   
/*     */   public IntersectStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  57 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  58 */     StreamExpressionNamedParameter onExpression = factory.getNamedOperand(expression, "on");
/*     */     
/*     */ 
/*  61 */     if (expression.getParameters().size() != streamExpressions.size() + 1) {
/*  62 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  65 */     if (2 != streamExpressions.size()) {
/*  66 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting two streams but found %d (must be TupleStream types)", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  69 */     if ((null == onExpression) || (!(onExpression.getParameter() instanceof StreamExpressionValue))) {
/*  70 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'on' parameter listing fields to merge on but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  73 */     init(factory.constructStream((StreamExpression)streamExpressions.get(0)), factory
/*  74 */       .constructStream((StreamExpression)streamExpressions.get(1)), factory
/*  75 */       .constructEqualitor(((StreamExpressionValue)onExpression.getParameter()).getValue(), FieldEqualitor.class));
/*     */   }
/*     */   
/*     */   private void init(TupleStream streamA, TupleStream streamB, StreamEqualitor eq) throws IOException
/*     */   {
/*  80 */     this.streamA = new PushBackStream(streamA);
/*  81 */     this.streamB = new PushBackStream(new UniqueStream(streamB, eq));
/*  82 */     this.originalStreamB = streamB;
/*  83 */     this.eq = eq;
/*     */     
/*     */ 
/*  86 */     if ((!eq.isDerivedFrom(streamA.getStreamSort())) || (!eq.isDerivedFrom(streamB.getStreamSort()))) {
/*  87 */       throw new IOException("Invalid IntersectStream - both substream comparators (sort) must be a superset of this stream's equalitor.");
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/*  93 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/*  98 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/* 100 */     if (includeStreams)
/*     */     {
/* 102 */       if ((this.streamA instanceof Expressible)) {
/* 103 */         expression.addParameter(this.streamA.toExpression(factory));
/*     */       }
/*     */       else {
/* 106 */         throw new IOException("This IntersectStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */       
/* 109 */       if ((this.originalStreamB instanceof Expressible)) {
/* 110 */         expression.addParameter(((Expressible)this.originalStreamB).toExpression(factory));
/*     */       }
/*     */       else {
/* 113 */         throw new IOException("This IntersectStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 117 */       expression.addParameter("<stream>");
/* 118 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 122 */     expression.addParameter(new StreamExpressionNamedParameter("on", this.eq.toExpression(factory)));
/*     */     
/* 124 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 130 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.streamA.toExplanation(factory), this.originalStreamB.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString()).withHelper(this.eq.toExplanation(factory));
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 143 */     this.streamA.setStreamContext(context);
/* 144 */     this.streamB.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 148 */     List<TupleStream> l = new ArrayList();
/* 149 */     l.add(this.streamA);
/* 150 */     l.add(this.streamB);
/* 151 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 155 */     this.streamA.open();
/* 156 */     this.streamB.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 160 */     this.streamA.close();
/* 161 */     this.streamB.close();
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*     */     for (;;) {
/* 167 */       Tuple a = this.streamA.read();
/* 168 */       Tuple b = this.streamB.read();
/*     */       
/*     */ 
/* 171 */       if (a.EOF) return a;
/* 172 */       if (b.EOF) { return b;
/*     */       }
/* 174 */       if (this.eq.test(a, b)) {
/* 175 */         this.streamB.pushBack(b);
/* 176 */         return a;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */       int aComp = this.streamA.getStreamSort().compare(a, b);
/* 187 */       if (aComp < 0) this.streamB.pushBack(b); else {
/* 188 */         this.streamA.pushBack(a);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort() {
/* 194 */     return this.streamA.getStreamSort();
/*     */   }
/*     */   
/*     */   public int getCost()
/*     */   {
/* 199 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\IntersectStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */