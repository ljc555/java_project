/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.FieldAnalysisResponse;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldAnalysisRequest
/*     */   extends SolrRequest<FieldAnalysisResponse>
/*     */ {
/*     */   private String fieldValue;
/*     */   private String query;
/*     */   private boolean showMatch;
/*     */   private List<String> fieldNames;
/*     */   private List<String> fieldTypes;
/*     */   
/*     */   public FieldAnalysisRequest()
/*     */   {
/*  50 */     super(SolrRequest.METHOD.GET, "/analysis/field");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest(String uri)
/*     */   {
/*  59 */     super(SolrRequest.METHOD.GET, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */     throws IOException
/*     */   {
/*  67 */     return null;
/*     */   }
/*     */   
/*     */   protected FieldAnalysisResponse createResponse(SolrClient client)
/*     */   {
/*  72 */     if ((this.fieldTypes == null) && (this.fieldNames == null)) {
/*  73 */       throw new IllegalStateException("At least one field type or field name need to be specified");
/*     */     }
/*  75 */     if (this.fieldValue == null) {
/*  76 */       throw new IllegalStateException("The field value must be set");
/*     */     }
/*  78 */     return new FieldAnalysisResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrParams getParams()
/*     */   {
/*  86 */     ModifiableSolrParams params = new ModifiableSolrParams();
/*  87 */     params.set("analysis.fieldvalue", new String[] { this.fieldValue });
/*  88 */     if (this.query != null) {
/*  89 */       params.add("analysis.query", new String[] { this.query });
/*  90 */       params.add("analysis.showmatch", new String[] { String.valueOf(this.showMatch) });
/*     */     }
/*  92 */     if (this.fieldNames != null) {
/*  93 */       String fieldNameValue = listToCommaDelimitedString(this.fieldNames);
/*  94 */       params.add("analysis.fieldname", new String[] { fieldNameValue });
/*     */     }
/*  96 */     if (this.fieldTypes != null) {
/*  97 */       String fieldTypeValue = listToCommaDelimitedString(this.fieldTypes);
/*  98 */       params.add("analysis.fieldtype", new String[] { fieldTypeValue });
/*     */     }
/* 100 */     return params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String listToCommaDelimitedString(List<String> list)
/*     */   {
/* 113 */     StringBuilder result = new StringBuilder();
/* 114 */     for (String str : list) {
/* 115 */       if (result.length() > 0) {
/* 116 */         result.append(",");
/*     */       }
/* 118 */       result.append(str);
/*     */     }
/* 120 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest setFieldValue(String fieldValue)
/*     */   {
/* 134 */     this.fieldValue = fieldValue;
/* 135 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldValue()
/*     */   {
/* 144 */     return this.fieldValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest setQuery(String query)
/*     */   {
/* 155 */     this.query = query;
/* 156 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQuery()
/*     */   {
/* 167 */     return this.query;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest setShowMatch(boolean showMatch)
/*     */   {
/* 179 */     this.showMatch = showMatch;
/* 180 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowMatch()
/*     */   {
/* 191 */     return this.showMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest addFieldName(String fieldName)
/*     */   {
/* 202 */     if (this.fieldNames == null) {
/* 203 */       this.fieldNames = new LinkedList();
/*     */     }
/* 205 */     this.fieldNames.add(fieldName);
/* 206 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest setFieldNames(List<String> fieldNames)
/*     */   {
/* 217 */     this.fieldNames = fieldNames;
/* 218 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getFieldNames()
/*     */   {
/* 228 */     return this.fieldNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest addFieldType(String fieldTypeName)
/*     */   {
/* 239 */     if (this.fieldTypes == null) {
/* 240 */       this.fieldTypes = new LinkedList();
/*     */     }
/* 242 */     this.fieldTypes.add(fieldTypeName);
/* 243 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldAnalysisRequest setFieldTypes(List<String> fieldTypes)
/*     */   {
/* 254 */     this.fieldTypes = fieldTypes;
/* 255 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getFieldTypes()
/*     */   {
/* 266 */     return this.fieldTypes;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\FieldAnalysisRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */