/*    */ package org.apache.solr.client.solrj.io.comp;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashKey
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Object[] parts;
/*    */   
/*    */   public HashKey(String value)
/*    */   {
/* 28 */     this.parts = value.split("::");
/*    */   }
/*    */   
/*    */   public HashKey(Object[] parts) {
/* 32 */     this.parts = parts;
/*    */   }
/*    */   
/*    */   public Object[] getParts() {
/* 36 */     return this.parts;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 40 */     int h = 0;
/* 41 */     for (Object o : this.parts) {
/* 42 */       h += o.hashCode();
/*    */     }
/*    */     
/* 45 */     return h;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 49 */     HashKey h = (HashKey)o;
/* 50 */     for (int i = 0; i < this.parts.length; i++) {
/* 51 */       if (!this.parts[i].equals(h.parts[i])) {
/* 52 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 60 */     StringBuilder buf = new StringBuilder();
/* 61 */     for (int i = 0; i < this.parts.length; i++) {
/* 62 */       if (i > 0) {
/* 63 */         buf.append("::");
/*    */       }
/* 65 */       buf.append(this.parts[i].toString());
/*    */     }
/*    */     
/* 68 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\comp\HashKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */