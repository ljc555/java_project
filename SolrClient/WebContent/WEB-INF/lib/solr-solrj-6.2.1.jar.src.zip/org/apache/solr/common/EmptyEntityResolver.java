/*    */ package org.apache.solr.common;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import javax.xml.parsers.SAXParserFactory;
/*    */ import javax.xml.stream.XMLInputFactory;
/*    */ import javax.xml.stream.XMLResolver;
/*    */ import org.apache.commons.io.input.ClosedInputStream;
/*    */ import org.xml.sax.EntityResolver;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EmptyEntityResolver
/*    */ {
/* 41 */   public static final EntityResolver SAX_INSTANCE = new EntityResolver()
/*    */   {
/*    */     public InputSource resolveEntity(String publicId, String systemId) {
/* 44 */       return new InputSource(ClosedInputStream.CLOSED_INPUT_STREAM);
/*    */     }
/*    */   };
/*    */   
/* 48 */   public static final XMLResolver STAX_INSTANCE = new XMLResolver()
/*    */   {
/*    */     public InputStream resolveEntity(String publicId, String systemId, String baseURI, String namespace) {
/* 51 */       return ClosedInputStream.CLOSED_INPUT_STREAM;
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */   private static void trySetSAXFeature(SAXParserFactory saxFactory, String feature, boolean enabled)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       saxFactory.setFeature(feature, enabled);
/*    */     }
/*    */     catch (Exception localException) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void configureSAXParserFactory(SAXParserFactory saxFactory)
/*    */   {
/* 72 */     saxFactory.setValidating(false);
/*    */     
/* 74 */     trySetSAXFeature(saxFactory, "http://javax.xml.XMLConstants/feature/secure-processing", true);
/*    */   }
/*    */   
/*    */   private static void trySetStAXProperty(XMLInputFactory inputFactory, String key, Object value) {
/*    */     try {
/* 79 */       inputFactory.setProperty(key, value);
/*    */     }
/*    */     catch (Exception localException) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void configureXMLInputFactory(XMLInputFactory inputFactory)
/*    */   {
/* 90 */     trySetStAXProperty(inputFactory, "javax.xml.stream.isValidating", Boolean.FALSE);
/*    */     
/* 92 */     trySetStAXProperty(inputFactory, "javax.xml.stream.isSupportingExternalEntities", Boolean.TRUE);
/* 93 */     inputFactory.setXMLResolver(STAX_INSTANCE);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\EmptyEntityResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */