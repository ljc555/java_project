/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pair<T1, T2>
/*    */   implements Serializable
/*    */ {
/*    */   private final T1 first;
/*    */   private final T2 second;
/*    */   
/*    */   public T1 first()
/*    */   {
/* 30 */     return (T1)this.first;
/*    */   }
/*    */   
/*    */   public T2 second() {
/* 34 */     return (T2)this.second;
/*    */   }
/*    */   
/*    */   public Pair(T1 key, T2 value) {
/* 38 */     this.first = key;
/* 39 */     this.second = value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object that)
/*    */   {
/* 44 */     return ((that instanceof Pair)) && 
/* 45 */       (Objects.equals(this.first, ((Pair)that).first)) && 
/* 46 */       (Objects.equals(this.second, ((Pair)that).second));
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 51 */     return Utils.toJSONString(Utils.makeMap(new Object[] { "first", this.first, "second", this.second }));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 56 */     return Objects.hash(new Object[] { this.first, this.second });
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */