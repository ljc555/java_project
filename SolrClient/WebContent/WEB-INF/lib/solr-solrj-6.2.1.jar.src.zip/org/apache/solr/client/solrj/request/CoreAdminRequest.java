/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.response.CoreAdminResponse;
/*     */ import org.apache.solr.client.solrj.util.SolrIdentifierValidator;
/*     */ import org.apache.solr.common.cloud.Replica.State;
/*     */ import org.apache.solr.common.params.CoreAdminParams.CoreAdminAction;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoreAdminRequest
/*     */   extends SolrRequest<CoreAdminResponse>
/*     */ {
/*  44 */   protected String core = null;
/*  45 */   protected String other = null;
/*  46 */   protected boolean isIndexInfoNeeded = true;
/*  47 */   protected CoreAdminParams.CoreAdminAction action = null;
/*     */   
/*     */   public static class Create
/*     */     extends CoreAdminRequest
/*     */   {
/*     */     protected String instanceDir;
/*  53 */     protected String configName = null;
/*  54 */     protected String schemaName = null;
/*  55 */     protected String dataDir = null;
/*  56 */     protected String ulogDir = null;
/*  57 */     protected String configSet = null;
/*     */     protected String collection;
/*     */     private Integer numShards;
/*     */     private String shardId;
/*     */     private String roles;
/*     */     private String coreNodeName;
/*     */     private Boolean loadOnStartup;
/*     */     private Boolean isTransient;
/*     */     private String collectionConfigName;
/*     */     
/*     */     public Create() {
/*  68 */       this.action = CoreAdminParams.CoreAdminAction.CREATE;
/*     */     }
/*     */     
/*  71 */     public void setInstanceDir(String instanceDir) { this.instanceDir = instanceDir; }
/*  72 */     public void setSchemaName(String schema) { this.schemaName = schema; }
/*  73 */     public void setConfigName(String config) { this.configName = config; }
/*  74 */     public void setDataDir(String dataDir) { this.dataDir = dataDir; }
/*  75 */     public void setUlogDir(String ulogDir) { this.ulogDir = ulogDir; }
/*     */     
/*  77 */     public void setConfigSet(String configSet) { this.configSet = configSet; }
/*     */     
/*  79 */     public void setCollection(String collection) { this.collection = collection; }
/*  80 */     public void setNumShards(int numShards) { this.numShards = Integer.valueOf(numShards); }
/*  81 */     public void setShardId(String shardId) { this.shardId = shardId; }
/*  82 */     public void setRoles(String roles) { this.roles = roles; }
/*  83 */     public void setCoreNodeName(String coreNodeName) { this.coreNodeName = coreNodeName; }
/*  84 */     public void setIsTransient(Boolean isTransient) { this.isTransient = isTransient; }
/*  85 */     public void setIsLoadOnStartup(Boolean loadOnStartup) { this.loadOnStartup = loadOnStartup; }
/*  86 */     public void setCollectionConfigName(String name) { this.collectionConfigName = name; }
/*     */     
/*  88 */     public String getInstanceDir() { return this.instanceDir; }
/*  89 */     public String getSchemaName() { return this.schemaName; }
/*  90 */     public String getConfigName() { return this.configName; }
/*  91 */     public String getDataDir() { return this.dataDir; }
/*  92 */     public String getUlogDir() { return this.ulogDir; }
/*     */     
/*  94 */     public String getConfigSet() { return this.configSet; }
/*     */     
/*  96 */     public String getCollection() { return this.collection; }
/*  97 */     public String getShardId() { return this.shardId; }
/*  98 */     public String getRoles() { return this.roles; }
/*  99 */     public String getCoreNodeName() { return this.coreNodeName; }
/* 100 */     public Boolean getIsLoadOnStartup() { return this.loadOnStartup; }
/* 101 */     public Boolean getIsTransient() { return this.isTransient; }
/* 102 */     public String getCollectionConfigName() { return this.collectionConfigName; }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setCoreName(String coreName)
/*     */     {
/* 113 */       this.core = SolrIdentifierValidator.validateCoreName(coreName);
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 118 */       if (this.action == null) {
/* 119 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 121 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 122 */       params.set("action", new String[] { this.action.toString() });
/* 123 */       if (this.action.equals(CoreAdminParams.CoreAdminAction.CREATE)) {
/* 124 */         params.set("name", new String[] { this.core });
/*     */       } else {
/* 126 */         params.set("core", new String[] { this.core });
/*     */       }
/* 128 */       params.set("instanceDir", new String[] { this.instanceDir });
/* 129 */       if (this.configName != null) {
/* 130 */         params.set("config", new String[] { this.configName });
/*     */       }
/* 132 */       if (this.schemaName != null) {
/* 133 */         params.set("schema", new String[] { this.schemaName });
/*     */       }
/* 135 */       if (this.dataDir != null) {
/* 136 */         params.set("dataDir", new String[] { this.dataDir });
/*     */       }
/* 138 */       if (this.ulogDir != null) {
/* 139 */         params.set("ulogDir", new String[] { this.ulogDir });
/*     */       }
/* 141 */       if (this.configSet != null) {
/* 142 */         params.set("configSet", new String[] { this.configSet });
/*     */       }
/* 144 */       if (this.collection != null) {
/* 145 */         params.set("collection", new String[] { this.collection });
/*     */       }
/* 147 */       if (this.numShards != null) {
/* 148 */         params.set("numShards", this.numShards.intValue());
/*     */       }
/* 150 */       if (this.shardId != null) {
/* 151 */         params.set("shard", new String[] { this.shardId });
/*     */       }
/* 153 */       if (this.roles != null) {
/* 154 */         params.set("roles", new String[] { this.roles });
/*     */       }
/* 156 */       if (this.coreNodeName != null) {
/* 157 */         params.set("coreNodeName", new String[] { this.coreNodeName });
/*     */       }
/*     */       
/* 160 */       if (this.isTransient != null) {
/* 161 */         params.set("transient", this.isTransient.booleanValue());
/*     */       }
/*     */       
/* 164 */       if (this.loadOnStartup != null) {
/* 165 */         params.set("loadOnStartup", this.loadOnStartup.booleanValue());
/*     */       }
/*     */       
/* 168 */       if (this.collectionConfigName != null) {
/* 169 */         params.set("collection.configName", new String[] { this.collectionConfigName });
/*     */       }
/*     */       
/* 172 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WaitForState extends CoreAdminRequest
/*     */   {
/*     */     protected String nodeName;
/*     */     protected String coreNodeName;
/*     */     protected Replica.State state;
/*     */     protected Boolean checkLive;
/*     */     protected Boolean onlyIfLeader;
/*     */     protected Boolean onlyIfLeaderActive;
/*     */     
/*     */     public WaitForState() {
/* 186 */       this.action = CoreAdminParams.CoreAdminAction.PREPRECOVERY;
/*     */     }
/*     */     
/*     */     public void setNodeName(String nodeName) {
/* 190 */       this.nodeName = nodeName;
/*     */     }
/*     */     
/*     */     public String getNodeName() {
/* 194 */       return this.nodeName;
/*     */     }
/*     */     
/*     */     public String getCoreNodeName() {
/* 198 */       return this.coreNodeName;
/*     */     }
/*     */     
/*     */     public void setCoreNodeName(String coreNodeName) {
/* 202 */       this.coreNodeName = coreNodeName;
/*     */     }
/*     */     
/*     */     public Replica.State getState() {
/* 206 */       return this.state;
/*     */     }
/*     */     
/*     */     public void setState(Replica.State state) {
/* 210 */       this.state = state;
/*     */     }
/*     */     
/*     */     public Boolean getCheckLive() {
/* 214 */       return this.checkLive;
/*     */     }
/*     */     
/*     */     public void setCheckLive(Boolean checkLive) {
/* 218 */       this.checkLive = checkLive;
/*     */     }
/*     */     
/*     */     public boolean isOnlyIfLeader() {
/* 222 */       return this.onlyIfLeader.booleanValue();
/*     */     }
/*     */     
/*     */     public void setOnlyIfLeader(boolean onlyIfLeader) {
/* 226 */       this.onlyIfLeader = Boolean.valueOf(onlyIfLeader);
/*     */     }
/*     */     
/*     */     public void setOnlyIfLeaderActive(boolean onlyIfLeaderActive) {
/* 230 */       this.onlyIfLeaderActive = Boolean.valueOf(onlyIfLeaderActive);
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 235 */       if (this.action == null) {
/* 236 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 238 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 239 */       params.set("action", new String[] { this.action.toString() });
/*     */       
/* 241 */       params.set("core", new String[] { this.core });
/*     */       
/* 243 */       if (this.nodeName != null) {
/* 244 */         params.set("nodeName", new String[] { this.nodeName });
/*     */       }
/*     */       
/* 247 */       if (this.coreNodeName != null) {
/* 248 */         params.set("coreNodeName", new String[] { this.coreNodeName });
/*     */       }
/*     */       
/* 251 */       if (this.state != null) {
/* 252 */         params.set("state", new String[] { this.state.toString() });
/*     */       }
/*     */       
/* 255 */       if (this.checkLive != null) {
/* 256 */         params.set("checkLive", this.checkLive.booleanValue());
/*     */       }
/*     */       
/* 259 */       if (this.onlyIfLeader != null) {
/* 260 */         params.set("onlyIfLeader", this.onlyIfLeader.booleanValue());
/*     */       }
/*     */       
/* 263 */       if (this.onlyIfLeaderActive != null) {
/* 264 */         params.set("onlyIfLeaderActive", this.onlyIfLeaderActive.booleanValue());
/*     */       }
/*     */       
/* 267 */       return params;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 271 */       if (this.action != null) {
/* 272 */         return "WaitForState: " + getParams();
/*     */       }
/* 274 */       return super.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RequestRecovery extends CoreAdminRequest
/*     */   {
/*     */     public RequestRecovery()
/*     */     {
/* 282 */       this.action = CoreAdminParams.CoreAdminAction.REQUESTRECOVERY;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 287 */       if (this.action == null) {
/* 288 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 290 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 291 */       params.set("action", new String[] { this.action.toString() });
/*     */       
/* 293 */       params.set("core", new String[] { this.core });
/*     */       
/* 295 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RequestSyncShard extends CoreAdminRequest {
/*     */     private String shard;
/*     */     private String collection;
/*     */     
/*     */     public RequestSyncShard() {
/* 304 */       this.action = CoreAdminParams.CoreAdminAction.REQUESTSYNCSHARD;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 309 */       if (this.action == null) {
/* 310 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 312 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 313 */       params.set("action", new String[] { this.action.toString() });
/* 314 */       params.set("shard", new String[] { this.shard });
/* 315 */       params.set("collection", new String[] { this.collection });
/* 316 */       params.set("core", new String[] { this.core });
/* 317 */       return params;
/*     */     }
/*     */     
/*     */     public String getShard() {
/* 321 */       return this.shard;
/*     */     }
/*     */     
/*     */     public void setShard(String shard) {
/* 325 */       this.shard = shard;
/*     */     }
/*     */     
/*     */     public String getCollection() {
/* 329 */       return this.collection;
/*     */     }
/*     */     
/*     */     public void setCollection(String collection) {
/* 333 */       this.collection = collection;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class OverrideLastPublished extends CoreAdminRequest {
/*     */     protected String state;
/*     */     
/*     */     public OverrideLastPublished() {
/* 341 */       this.action = CoreAdminParams.CoreAdminAction.FORCEPREPAREFORLEADERSHIP;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 346 */       if (this.action == null) {
/* 347 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 349 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 350 */       params.set("action", new String[] { this.action.toString() });
/* 351 */       params.set("core", new String[] { this.core });
/* 352 */       params.set("state", new String[] { this.state });
/* 353 */       return params;
/*     */     }
/*     */     
/*     */     public String getState() {
/* 357 */       return this.state;
/*     */     }
/*     */     
/*     */     public void setState(String state) {
/* 361 */       this.state = state;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MergeIndexes extends CoreAdminRequest {
/*     */     protected List<String> indexDirs;
/*     */     protected List<String> srcCores;
/*     */     
/*     */     public MergeIndexes() {
/* 370 */       this.action = CoreAdminParams.CoreAdminAction.MERGEINDEXES;
/*     */     }
/*     */     
/*     */     public void setIndexDirs(List<String> indexDirs) {
/* 374 */       this.indexDirs = indexDirs;
/*     */     }
/*     */     
/*     */     public List<String> getIndexDirs() {
/* 378 */       return this.indexDirs;
/*     */     }
/*     */     
/*     */     public List<String> getSrcCores() {
/* 382 */       return this.srcCores;
/*     */     }
/*     */     
/*     */     public void setSrcCores(List<String> srcCores) {
/* 386 */       this.srcCores = srcCores;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 391 */       if (this.action == null) {
/* 392 */         throw new RuntimeException("no action specified!");
/*     */       }
/* 394 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 395 */       params.set("action", new String[] { this.action.toString() });
/* 396 */       params.set("core", new String[] { this.core });
/* 397 */       if (this.indexDirs != null) {
/* 398 */         for (String indexDir : this.indexDirs) {
/* 399 */           params.add("indexDir", new String[] { indexDir });
/*     */         }
/*     */       }
/* 402 */       if (this.srcCores != null) {
/* 403 */         for (String srcCore : this.srcCores) {
/* 404 */           params.add("srcCore", new String[] { srcCore });
/*     */         }
/*     */       }
/* 407 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Unload extends CoreAdminRequest {
/*     */     protected boolean deleteIndex;
/*     */     protected boolean deleteDataDir;
/*     */     protected boolean deleteInstanceDir;
/*     */     
/*     */     public Unload(boolean deleteIndex) {
/* 417 */       this.action = CoreAdminParams.CoreAdminAction.UNLOAD;
/* 418 */       this.deleteIndex = deleteIndex;
/*     */     }
/*     */     
/*     */     public boolean isDeleteIndex() {
/* 422 */       return this.deleteIndex;
/*     */     }
/*     */     
/*     */     public void setDeleteIndex(boolean deleteIndex) {
/* 426 */       this.deleteIndex = deleteIndex;
/*     */     }
/*     */     
/*     */     public void setDeleteDataDir(boolean deleteDataDir) {
/* 430 */       this.deleteDataDir = deleteDataDir;
/*     */     }
/*     */     
/*     */     public void setDeleteInstanceDir(boolean deleteInstanceDir) {
/* 434 */       this.deleteInstanceDir = deleteInstanceDir;
/*     */     }
/*     */     
/*     */     public boolean isDeleteDataDir() {
/* 438 */       return this.deleteDataDir;
/*     */     }
/*     */     
/*     */     public boolean isDeleteInstanceDir() {
/* 442 */       return this.deleteInstanceDir;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 447 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/* 448 */       params.set("deleteIndex", this.deleteIndex);
/* 449 */       params.set("deleteDataDir", this.deleteDataDir);
/* 450 */       params.set("deleteInstanceDir", this.deleteInstanceDir);
/* 451 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CreateSnapshot extends CoreAdminRequest
/*     */   {
/*     */     private String commitName;
/*     */     
/*     */     public CreateSnapshot(String commitName)
/*     */     {
/* 461 */       this.action = CoreAdminParams.CoreAdminAction.CREATESNAPSHOT;
/* 462 */       if (commitName == null) {
/* 463 */         throw new NullPointerException("Please specify non null value for commitName parameter.");
/*     */       }
/* 465 */       this.commitName = commitName;
/*     */     }
/*     */     
/*     */     public String getCommitName() {
/* 469 */       return this.commitName;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 474 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 475 */       params.set("commitName", new String[] { this.commitName });
/* 476 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DeleteSnapshot extends CoreAdminRequest
/*     */   {
/*     */     private String commitName;
/*     */     
/*     */     public DeleteSnapshot(String commitName) {
/* 485 */       this.action = CoreAdminParams.CoreAdminAction.DELETESNAPSHOT;
/*     */       
/* 487 */       if (commitName == null) {
/* 488 */         throw new NullPointerException("Please specify non null value for commitName parameter.");
/*     */       }
/* 490 */       this.commitName = commitName;
/*     */     }
/*     */     
/*     */     public String getCommitName() {
/* 494 */       return this.commitName;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 499 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 500 */       params.set("commitName", new String[] { this.commitName });
/* 501 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ListSnapshots extends CoreAdminRequest
/*     */   {
/*     */     public ListSnapshots() {
/* 508 */       this.action = CoreAdminParams.CoreAdminAction.LISTSNAPSHOTS;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public CoreAdminRequest()
/*     */   {
/* 515 */     super(SolrRequest.METHOD.GET, "/admin/cores");
/*     */   }
/*     */   
/*     */   public CoreAdminRequest(String path)
/*     */   {
/* 520 */     super(SolrRequest.METHOD.GET, path);
/*     */   }
/*     */   
/*     */   public void setCoreName(String coreName)
/*     */   {
/* 525 */     this.core = coreName;
/*     */   }
/*     */   
/*     */   public final void setOtherCoreName(String otherCoreName)
/*     */   {
/* 530 */     this.other = otherCoreName;
/*     */   }
/*     */   
/*     */   public final void setIndexInfoNeeded(boolean isIndexInfoNeeded) {
/* 534 */     this.isIndexInfoNeeded = isIndexInfoNeeded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAction(CoreAdminParams.CoreAdminAction action)
/*     */   {
/* 543 */     this.action = action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrParams getParams()
/*     */   {
/* 553 */     if (this.action == null) {
/* 554 */       throw new RuntimeException("no action specified!");
/*     */     }
/* 556 */     ModifiableSolrParams params = new ModifiableSolrParams();
/* 557 */     params.set("action", new String[] { this.action.toString() });
/* 558 */     params.set("core", new String[] { this.core });
/* 559 */     params.set("indexInfo", new String[] { this.isIndexInfoNeeded ? "true" : "false" });
/* 560 */     if (this.other != null) {
/* 561 */       params.set("other", new String[] { this.other });
/*     */     }
/* 563 */     return params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */     throws IOException
/*     */   {
/* 572 */     return null;
/*     */   }
/*     */   
/*     */   protected CoreAdminResponse createResponse(SolrClient client)
/*     */   {
/* 577 */     return new CoreAdminResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CoreAdminResponse reloadCore(String name, SolrClient client)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 586 */     CoreAdminRequest req = new CoreAdminRequest();
/* 587 */     req.setCoreName(name);
/* 588 */     req.setAction(CoreAdminParams.CoreAdminAction.RELOAD);
/* 589 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse unloadCore(String name, SolrClient client) throws SolrServerException, IOException
/*     */   {
/* 594 */     return unloadCore(name, false, client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse unloadCore(String name, boolean deleteIndex, SolrClient client) throws SolrServerException, IOException {
/* 598 */     return unloadCore(name, deleteIndex, false, client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse unloadCore(String name, boolean deleteIndex, boolean deleteInstanceDir, SolrClient client) throws SolrServerException, IOException {
/* 602 */     Unload req = new Unload(deleteIndex);
/* 603 */     req.setCoreName(name);
/* 604 */     req.setDeleteInstanceDir(deleteInstanceDir);
/* 605 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CoreAdminResponse renameCore(String coreName, String newName, SolrClient client)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 615 */     CoreAdminRequest req = new CoreAdminRequest();
/* 616 */     req.setCoreName(coreName);
/* 617 */     req.setOtherCoreName(SolrIdentifierValidator.validateCoreName(newName));
/* 618 */     req.setAction(CoreAdminParams.CoreAdminAction.RENAME);
/* 619 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse getStatus(String name, SolrClient client) throws SolrServerException, IOException
/*     */   {
/* 624 */     CoreAdminRequest req = new CoreAdminRequest();
/* 625 */     req.setCoreName(name);
/* 626 */     req.setAction(CoreAdminParams.CoreAdminAction.STATUS);
/* 627 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse createCore(String name, String instanceDir, SolrClient client) throws SolrServerException, IOException
/*     */   {
/* 632 */     return createCore(name, instanceDir, client, null, null);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse createCore(String name, String instanceDir, SolrClient client, String configFile, String schemaFile) throws SolrServerException, IOException {
/* 636 */     return createCore(name, instanceDir, client, configFile, schemaFile, null, null);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse createCore(String name, String instanceDir, SolrClient client, String configFile, String schemaFile, String dataDir, String tlogDir) throws SolrServerException, IOException
/*     */   {
/* 641 */     Create req = new Create();
/* 642 */     req.setCoreName(name);
/* 643 */     req.setInstanceDir(instanceDir);
/* 644 */     if (dataDir != null) {
/* 645 */       req.setDataDir(dataDir);
/*     */     }
/* 647 */     if (tlogDir != null) {
/* 648 */       req.setUlogDir(tlogDir);
/*     */     }
/* 650 */     if (configFile != null) {
/* 651 */       req.setConfigName(configFile);
/*     */     }
/* 653 */     if (schemaFile != null) {
/* 654 */       req.setSchemaName(schemaFile);
/*     */     }
/* 656 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */   
/*     */   public static CoreAdminResponse mergeIndexes(String name, String[] indexDirs, String[] srcCores, SolrClient client)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 662 */     MergeIndexes req = new MergeIndexes();
/* 663 */     req.setCoreName(name);
/* 664 */     req.setIndexDirs(Arrays.asList(indexDirs));
/* 665 */     req.setSrcCores(Arrays.asList(srcCores));
/* 666 */     return (CoreAdminResponse)req.process(client);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\CoreAdminRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */