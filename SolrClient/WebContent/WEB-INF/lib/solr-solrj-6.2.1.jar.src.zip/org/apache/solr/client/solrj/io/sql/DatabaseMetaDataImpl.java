/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.RowIdLifetime;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrQuery;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.impl.HttpSolrClient.Builder;
/*     */ import org.apache.solr.client.solrj.response.QueryResponse;
/*     */ import org.apache.solr.common.cloud.ClusterState;
/*     */ import org.apache.solr.common.cloud.ZkStateReader;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SimpleOrderedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DatabaseMetaDataImpl
/*     */   implements DatabaseMetaData
/*     */ {
/*     */   private final ConnectionImpl connection;
/*     */   private final Statement connectionStatement;
/*     */   
/*     */   public DatabaseMetaDataImpl(ConnectionImpl connection, Statement connectionStatement)
/*     */   {
/*  41 */     this.connection = connection;
/*  42 */     this.connectionStatement = connectionStatement;
/*     */   }
/*     */   
/*     */ 
/*     */   private int getVersionPart(String version, int part)
/*     */   {
/*  48 */     if (version != null) {
/*     */       try {
/*  50 */         String[] versionParts = version.split("\\.", 3);
/*  51 */         return Integer.parseInt(versionParts[part]);
/*     */       } catch (Throwable e) {
/*  53 */         return 0;
/*     */       }
/*     */     }
/*  56 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean allProceduresAreCallable()
/*     */     throws SQLException
/*     */   {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public boolean allTablesAreSelectable() throws SQLException
/*     */   {
/*  67 */     return false;
/*     */   }
/*     */   
/*     */   public String getURL() throws SQLException
/*     */   {
/*  72 */     return this.connection.getUrl();
/*     */   }
/*     */   
/*     */   public String getUserName() throws SQLException
/*     */   {
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() throws SQLException
/*     */   {
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nullsAreSortedHigh() throws SQLException
/*     */   {
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nullsAreSortedLow() throws SQLException
/*     */   {
/*  92 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nullsAreSortedAtStart() throws SQLException
/*     */   {
/*  97 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nullsAreSortedAtEnd() throws SQLException
/*     */   {
/* 102 */     return false;
/*     */   }
/*     */   
/*     */   public String getDatabaseProductName() throws SQLException
/*     */   {
/* 107 */     return "Apache Solr";
/*     */   }
/*     */   
/*     */   public String getDatabaseProductVersion()
/*     */     throws SQLException
/*     */   {
/* 113 */     SolrQuery sysQuery = new SolrQuery();
/* 114 */     sysQuery.setRequestHandler("/admin/info/system");
/*     */     
/* 116 */     CloudSolrClient cloudSolrClient = this.connection.getClient();
/* 117 */     Set<String> liveNodes = cloudSolrClient.getZkStateReader().getClusterState().getLiveNodes();
/* 118 */     SolrClient solrClient = null;
/* 119 */     Iterator localIterator = liveNodes.iterator(); if (localIterator.hasNext()) { String node = (String)localIterator.next();
/*     */       try {
/* 121 */         String nodeURL = cloudSolrClient.getZkStateReader().getBaseUrlForNodeName(node);
/* 122 */         solrClient = new HttpSolrClient.Builder(nodeURL).build();
/*     */         
/* 124 */         rsp = solrClient.query(sysQuery);
/* 125 */         return String.valueOf(((SimpleOrderedMap)rsp.getResponse().get("lucene")).get("solr-spec-version"));
/*     */       } catch (SolrServerException|IOException ignore) { QueryResponse rsp;
/* 127 */         return "";
/*     */       } finally {
/* 129 */         if (solrClient != null) {
/*     */           try {
/* 131 */             solrClient.close();
/*     */           }
/*     */           catch (IOException localIOException2) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 140 */     return "";
/*     */   }
/*     */   
/*     */   public int getDatabaseMajorVersion() throws SQLException
/*     */   {
/* 145 */     return getVersionPart(getDatabaseProductVersion(), 0);
/*     */   }
/*     */   
/*     */   public int getDatabaseMinorVersion() throws SQLException
/*     */   {
/* 150 */     return getVersionPart(getDatabaseProductVersion(), 1);
/*     */   }
/*     */   
/*     */   public String getDriverName() throws SQLException
/*     */   {
/* 155 */     return getClass().getPackage().getSpecificationTitle();
/*     */   }
/*     */   
/*     */   public String getDriverVersion() throws SQLException
/*     */   {
/* 160 */     return getClass().getPackage().getSpecificationVersion();
/*     */   }
/*     */   
/*     */   public int getDriverMajorVersion()
/*     */   {
/*     */     try {
/* 166 */       return getVersionPart(getDriverVersion(), 0);
/*     */     } catch (SQLException e) {}
/* 168 */     return 0;
/*     */   }
/*     */   
/*     */   public int getDriverMinorVersion()
/*     */   {
/*     */     try
/*     */     {
/* 175 */       return getVersionPart(getDriverVersion(), 1);
/*     */     } catch (SQLException e) {}
/* 177 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean usesLocalFiles()
/*     */     throws SQLException
/*     */   {
/* 183 */     return false;
/*     */   }
/*     */   
/*     */   public boolean usesLocalFilePerTable() throws SQLException
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMixedCaseIdentifiers() throws SQLException
/*     */   {
/* 193 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesUpperCaseIdentifiers() throws SQLException
/*     */   {
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesLowerCaseIdentifiers() throws SQLException
/*     */   {
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesMixedCaseIdentifiers() throws SQLException
/*     */   {
/* 208 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException
/*     */   {
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLException
/*     */   {
/* 218 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLException
/*     */   {
/* 223 */     return false;
/*     */   }
/*     */   
/*     */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLException
/*     */   {
/* 228 */     return false;
/*     */   }
/*     */   
/*     */   public String getIdentifierQuoteString() throws SQLException
/*     */   {
/* 233 */     return null;
/*     */   }
/*     */   
/*     */   public String getSQLKeywords() throws SQLException
/*     */   {
/* 238 */     return null;
/*     */   }
/*     */   
/*     */   public String getNumericFunctions() throws SQLException
/*     */   {
/* 243 */     return null;
/*     */   }
/*     */   
/*     */   public String getStringFunctions() throws SQLException
/*     */   {
/* 248 */     return null;
/*     */   }
/*     */   
/*     */   public String getSystemFunctions() throws SQLException
/*     */   {
/* 253 */     return null;
/*     */   }
/*     */   
/*     */   public String getTimeDateFunctions() throws SQLException
/*     */   {
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   public String getSearchStringEscape() throws SQLException
/*     */   {
/* 263 */     return null;
/*     */   }
/*     */   
/*     */   public String getExtraNameCharacters() throws SQLException
/*     */   {
/* 268 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsAlterTableWithAddColumn() throws SQLException
/*     */   {
/* 273 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsAlterTableWithDropColumn() throws SQLException
/*     */   {
/* 278 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsColumnAliasing() throws SQLException
/*     */   {
/* 283 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nullPlusNonNullIsNull() throws SQLException
/*     */   {
/* 288 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsConvert() throws SQLException
/*     */   {
/* 293 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsConvert(int fromType, int toType) throws SQLException
/*     */   {
/* 298 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsTableCorrelationNames() throws SQLException
/*     */   {
/* 303 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsDifferentTableCorrelationNames() throws SQLException
/*     */   {
/* 308 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsExpressionsInOrderBy() throws SQLException
/*     */   {
/* 313 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOrderByUnrelated() throws SQLException
/*     */   {
/* 318 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsGroupBy() throws SQLException
/*     */   {
/* 323 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsGroupByUnrelated() throws SQLException
/*     */   {
/* 328 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsGroupByBeyondSelect() throws SQLException
/*     */   {
/* 333 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsLikeEscapeClause() throws SQLException
/*     */   {
/* 338 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMultipleResultSets() throws SQLException
/*     */   {
/* 343 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMultipleTransactions() throws SQLException
/*     */   {
/* 348 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsNonNullableColumns() throws SQLException
/*     */   {
/* 353 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMinimumSQLGrammar() throws SQLException
/*     */   {
/* 358 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCoreSQLGrammar() throws SQLException
/*     */   {
/* 363 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsExtendedSQLGrammar() throws SQLException
/*     */   {
/* 368 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsANSI92EntryLevelSQL() throws SQLException
/*     */   {
/* 373 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsANSI92IntermediateSQL() throws SQLException
/*     */   {
/* 378 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsANSI92FullSQL() throws SQLException
/*     */   {
/* 383 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsIntegrityEnhancementFacility() throws SQLException
/*     */   {
/* 388 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOuterJoins() throws SQLException
/*     */   {
/* 393 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsFullOuterJoins() throws SQLException
/*     */   {
/* 398 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsLimitedOuterJoins() throws SQLException
/*     */   {
/* 403 */     return false;
/*     */   }
/*     */   
/*     */   public String getSchemaTerm() throws SQLException
/*     */   {
/* 408 */     return null;
/*     */   }
/*     */   
/*     */   public String getProcedureTerm() throws SQLException
/*     */   {
/* 413 */     return null;
/*     */   }
/*     */   
/*     */   public String getCatalogTerm() throws SQLException
/*     */   {
/* 418 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCatalogAtStart() throws SQLException
/*     */   {
/* 423 */     return false;
/*     */   }
/*     */   
/*     */   public String getCatalogSeparator() throws SQLException
/*     */   {
/* 428 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsSchemasInDataManipulation() throws SQLException
/*     */   {
/* 433 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSchemasInProcedureCalls() throws SQLException
/*     */   {
/* 438 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSchemasInTableDefinitions() throws SQLException
/*     */   {
/* 443 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSchemasInIndexDefinitions() throws SQLException
/*     */   {
/* 448 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException
/*     */   {
/* 453 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCatalogsInDataManipulation() throws SQLException
/*     */   {
/* 458 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCatalogsInProcedureCalls() throws SQLException
/*     */   {
/* 463 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCatalogsInTableDefinitions() throws SQLException
/*     */   {
/* 468 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCatalogsInIndexDefinitions() throws SQLException
/*     */   {
/* 473 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException
/*     */   {
/* 478 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsPositionedDelete() throws SQLException
/*     */   {
/* 483 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsPositionedUpdate() throws SQLException
/*     */   {
/* 488 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSelectForUpdate() throws SQLException
/*     */   {
/* 493 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsStoredProcedures() throws SQLException
/*     */   {
/* 498 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSubqueriesInComparisons() throws SQLException
/*     */   {
/* 503 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSubqueriesInExists() throws SQLException
/*     */   {
/* 508 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSubqueriesInIns() throws SQLException
/*     */   {
/* 513 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsSubqueriesInQuantifieds() throws SQLException
/*     */   {
/* 518 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCorrelatedSubqueries() throws SQLException
/*     */   {
/* 523 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsUnion() throws SQLException
/*     */   {
/* 528 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsUnionAll() throws SQLException
/*     */   {
/* 533 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOpenCursorsAcrossCommit() throws SQLException
/*     */   {
/* 538 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOpenCursorsAcrossRollback() throws SQLException
/*     */   {
/* 543 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOpenStatementsAcrossCommit() throws SQLException
/*     */   {
/* 548 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsOpenStatementsAcrossRollback() throws SQLException
/*     */   {
/* 553 */     return false;
/*     */   }
/*     */   
/*     */   public int getMaxBinaryLiteralLength() throws SQLException
/*     */   {
/* 558 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxCharLiteralLength() throws SQLException
/*     */   {
/* 563 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnNameLength() throws SQLException
/*     */   {
/* 568 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnsInGroupBy() throws SQLException
/*     */   {
/* 573 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnsInIndex() throws SQLException
/*     */   {
/* 578 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnsInOrderBy() throws SQLException
/*     */   {
/* 583 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnsInSelect() throws SQLException
/*     */   {
/* 588 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxColumnsInTable() throws SQLException
/*     */   {
/* 593 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxConnections() throws SQLException
/*     */   {
/* 598 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxCursorNameLength() throws SQLException
/*     */   {
/* 603 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxIndexLength() throws SQLException
/*     */   {
/* 608 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxSchemaNameLength() throws SQLException
/*     */   {
/* 613 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxProcedureNameLength() throws SQLException
/*     */   {
/* 618 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxCatalogNameLength() throws SQLException
/*     */   {
/* 623 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxRowSize() throws SQLException
/*     */   {
/* 628 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLException
/*     */   {
/* 633 */     return false;
/*     */   }
/*     */   
/*     */   public int getMaxStatementLength() throws SQLException
/*     */   {
/* 638 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxStatements() throws SQLException
/*     */   {
/* 643 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxTableNameLength() throws SQLException
/*     */   {
/* 648 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxTablesInSelect() throws SQLException
/*     */   {
/* 653 */     return 0;
/*     */   }
/*     */   
/*     */   public int getMaxUserNameLength() throws SQLException
/*     */   {
/* 658 */     return 0;
/*     */   }
/*     */   
/*     */   public int getDefaultTransactionIsolation() throws SQLException
/*     */   {
/* 663 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean supportsTransactions() throws SQLException
/*     */   {
/* 668 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsTransactionIsolationLevel(int level) throws SQLException
/*     */   {
/* 673 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException
/*     */   {
/* 678 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsDataManipulationTransactionsOnly() throws SQLException
/*     */   {
/* 683 */     return false;
/*     */   }
/*     */   
/*     */   public boolean dataDefinitionCausesTransactionCommit() throws SQLException
/*     */   {
/* 688 */     return false;
/*     */   }
/*     */   
/*     */   public boolean dataDefinitionIgnoredInTransactions() throws SQLException
/*     */   {
/* 693 */     return false;
/*     */   }
/*     */   
/*     */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException
/*     */   {
/* 698 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException
/*     */   {
/* 703 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) throws SQLException
/*     */   {
/* 708 */     return this.connectionStatement.executeQuery("select TABLE_CAT, TABLE_SCHEM, TABLE_NAME, TABLE_TYPE, REMARKS from _TABLES_");
/*     */   }
/*     */   
/*     */   public ResultSet getSchemas() throws SQLException
/*     */   {
/* 713 */     return this.connectionStatement.executeQuery("select TABLE_SCHEM, TABLE_CATALOG from _SCHEMAS_");
/*     */   }
/*     */   
/*     */   public ResultSet getCatalogs() throws SQLException
/*     */   {
/* 718 */     return this.connectionStatement.executeQuery("select TABLE_CAT from _CATALOGS_");
/*     */   }
/*     */   
/*     */   public ResultSet getTableTypes() throws SQLException
/*     */   {
/* 723 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException
/*     */   {
/* 728 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException
/*     */   {
/* 733 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException
/*     */   {
/* 738 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLException
/*     */   {
/* 743 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLException
/*     */   {
/* 748 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getPrimaryKeys(String catalog, String schema, String table) throws SQLException
/*     */   {
/* 753 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getImportedKeys(String catalog, String schema, String table) throws SQLException
/*     */   {
/* 758 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getExportedKeys(String catalog, String schema, String table) throws SQLException
/*     */   {
/* 763 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getCrossReference(String parentCatalog, String parentSchema, String parentTable, String foreignCatalog, String foreignSchema, String foreignTable) throws SQLException
/*     */   {
/* 768 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getTypeInfo() throws SQLException
/*     */   {
/* 773 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate) throws SQLException
/*     */   {
/* 778 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsResultSetType(int type) throws SQLException
/*     */   {
/* 783 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsResultSetConcurrency(int type, int concurrency) throws SQLException
/*     */   {
/* 788 */     return false;
/*     */   }
/*     */   
/*     */   public boolean ownUpdatesAreVisible(int type) throws SQLException
/*     */   {
/* 793 */     return false;
/*     */   }
/*     */   
/*     */   public boolean ownDeletesAreVisible(int type) throws SQLException
/*     */   {
/* 798 */     return false;
/*     */   }
/*     */   
/*     */   public boolean ownInsertsAreVisible(int type) throws SQLException
/*     */   {
/* 803 */     return false;
/*     */   }
/*     */   
/*     */   public boolean othersUpdatesAreVisible(int type) throws SQLException
/*     */   {
/* 808 */     return false;
/*     */   }
/*     */   
/*     */   public boolean othersDeletesAreVisible(int type) throws SQLException
/*     */   {
/* 813 */     return false;
/*     */   }
/*     */   
/*     */   public boolean othersInsertsAreVisible(int type) throws SQLException
/*     */   {
/* 818 */     return false;
/*     */   }
/*     */   
/*     */   public boolean updatesAreDetected(int type) throws SQLException
/*     */   {
/* 823 */     return false;
/*     */   }
/*     */   
/*     */   public boolean deletesAreDetected(int type) throws SQLException
/*     */   {
/* 828 */     return false;
/*     */   }
/*     */   
/*     */   public boolean insertsAreDetected(int type) throws SQLException
/*     */   {
/* 833 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsBatchUpdates() throws SQLException
/*     */   {
/* 838 */     return false;
/*     */   }
/*     */   
/*     */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException
/*     */   {
/* 843 */     return null;
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException
/*     */   {
/* 848 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean supportsSavepoints() throws SQLException
/*     */   {
/* 853 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsNamedParameters() throws SQLException
/*     */   {
/* 858 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsMultipleOpenResults() throws SQLException
/*     */   {
/* 863 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsGetGeneratedKeys() throws SQLException
/*     */   {
/* 868 */     return false;
/*     */   }
/*     */   
/*     */   public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException
/*     */   {
/* 873 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException
/*     */   {
/* 878 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException
/*     */   {
/* 883 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsResultSetHoldability(int holdability) throws SQLException
/*     */   {
/* 888 */     return false;
/*     */   }
/*     */   
/*     */   public int getResultSetHoldability() throws SQLException
/*     */   {
/* 893 */     return 0;
/*     */   }
/*     */   
/*     */   public int getJDBCMajorVersion() throws SQLException
/*     */   {
/* 898 */     return 4;
/*     */   }
/*     */   
/*     */   public int getJDBCMinorVersion() throws SQLException
/*     */   {
/* 903 */     return 0;
/*     */   }
/*     */   
/*     */   public int getSQLStateType() throws SQLException
/*     */   {
/* 908 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean locatorsUpdateCopy() throws SQLException
/*     */   {
/* 913 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsStatementPooling() throws SQLException
/*     */   {
/* 918 */     return false;
/*     */   }
/*     */   
/*     */   public RowIdLifetime getRowIdLifetime() throws SQLException
/*     */   {
/* 923 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException
/*     */   {
/* 928 */     return null;
/*     */   }
/*     */   
/*     */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException
/*     */   {
/* 933 */     return false;
/*     */   }
/*     */   
/*     */   public boolean autoCommitFailureClosesAllResultSets() throws SQLException
/*     */   {
/* 938 */     return false;
/*     */   }
/*     */   
/*     */   public ResultSet getClientInfoProperties() throws SQLException
/*     */   {
/* 943 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException
/*     */   {
/* 948 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException
/*     */   {
/* 953 */     return null;
/*     */   }
/*     */   
/*     */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException
/*     */   {
/* 958 */     return null;
/*     */   }
/*     */   
/*     */   public boolean generatedKeyAlwaysReturned() throws SQLException
/*     */   {
/* 963 */     return false;
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException
/*     */   {
/* 968 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*     */   {
/* 973 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\DatabaseMetaDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */