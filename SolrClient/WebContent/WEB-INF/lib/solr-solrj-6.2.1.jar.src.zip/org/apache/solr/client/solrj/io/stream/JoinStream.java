/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JoinStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private List<PushBackStream> streams;
/*     */   protected StreamEqualitor eq;
/*     */   
/*     */   public JoinStream(StreamEqualitor eq, TupleStream first, TupleStream second, TupleStream... others)
/*     */   {
/*  46 */     this.streams = new ArrayList();
/*     */     
/*  48 */     this.eq = eq;
/*     */     
/*  50 */     this.streams.add(new PushBackStream(first));
/*  51 */     this.streams.add(new PushBackStream(second));
/*     */     
/*  53 */     for (TupleStream other : others) {
/*  54 */       this.streams.add(new PushBackStream(other));
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void validateTupleOrder() throws IOException;
/*     */   
/*     */   public JoinStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  62 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*     */     
/*  64 */     StreamExpressionNamedParameter onExpression = factory.getNamedOperand(expression, "on");
/*     */     
/*     */ 
/*  67 */     if (expression.getParameters().size() != streamExpressions.size() + 1) {
/*  68 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  71 */     if (streamExpressions.size() < 2) {
/*  72 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting at least two streams but found %d (must be PushBackStream types)", new Object[] { expression, 
/*     */       
/*  74 */         Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  77 */     this.streams = new ArrayList();
/*  78 */     for (StreamExpression streamExpression : streamExpressions) {
/*  79 */       this.streams.add(new PushBackStream(factory.constructStream(streamExpression)));
/*     */     }
/*     */     
/*  82 */     if ((null == onExpression) || (!(onExpression.getParameter() instanceof StreamExpressionValue))) {
/*  83 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'on' parameter listing fields to join on but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  88 */     this.eq = factory.constructEqualitor(((StreamExpressionValue)onExpression.getParameter()).getValue(), FieldEqualitor.class);
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/*  94 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/*  99 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 102 */     for (PushBackStream stream : this.streams) {
/* 103 */       if (includeStreams) {
/* 104 */         expression.addParameter(stream.toExpression(factory));
/*     */       }
/*     */       else {
/* 107 */         expression.addParameter("<stream>");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 112 */     if ((this.eq instanceof Expressible)) {
/* 113 */       expression.addParameter(new StreamExpressionNamedParameter("on", this.eq.toExpression(factory)));
/*     */     } else {
/* 115 */       throw new IOException("This JoinStream contains a non-expressible equalitor - it cannot be converted to an expression");
/*     */     }
/*     */     
/*     */ 
/* 119 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 125 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId().toString());
/* 126 */     explanation.setFunctionName(factory.getFunctionName(getClass()));
/* 127 */     explanation.setImplementingClass(getClass().getName());
/* 128 */     explanation.setExpressionType("stream-decorator");
/* 129 */     explanation.setExpression(toExpression(factory, false).toString());
/* 130 */     explanation.addHelper(this.eq.toExplanation(factory));
/*     */     
/* 132 */     for (TupleStream stream : this.streams) {
/* 133 */       explanation.addChild(stream.toExplanation(factory));
/*     */     }
/*     */     
/* 136 */     return explanation;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 140 */     for (PushBackStream stream : this.streams) {
/* 141 */       stream.setStreamContext(context);
/*     */     }
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 146 */     for (PushBackStream stream : this.streams) {
/* 147 */       stream.open();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 152 */     for (PushBackStream stream : this.streams) {
/* 153 */       stream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 158 */     List<TupleStream> list = new ArrayList();
/* 159 */     for (TupleStream stream : this.streams) {
/* 160 */       list.add(stream);
/*     */     }
/* 162 */     return list;
/*     */   }
/*     */   
/*     */   public PushBackStream getStream(int idx) {
/* 166 */     if (this.streams.size() > idx) {
/* 167 */       return (PushBackStream)this.streams.get(idx);
/*     */     }
/*     */     
/* 170 */     throw new IllegalArgumentException(String.format(Locale.ROOT, "Stream idx=%d doesn't exist. Number of streams is %d", new Object[] { Integer.valueOf(idx), 
/* 171 */       Integer.valueOf(this.streams.size()) }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isValidTupleOrder()
/*     */   {
/* 178 */     for (TupleStream stream : this.streams) {
/* 179 */       if (!this.eq.isDerivedFrom(stream.getStreamSort())) {
/* 180 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 184 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Tuple loadEqualTupleGroup(PushBackStream stream, LinkedList<Tuple> group, StreamComparator groupComparator)
/*     */     throws IOException
/*     */   {
/* 199 */     Tuple firstMember = stream.read();
/*     */     
/* 201 */     if (!firstMember.EOF)
/*     */     {
/* 203 */       group.add(firstMember);
/*     */       for (;;)
/*     */       {
/* 206 */         Tuple nMember = stream.read();
/* 207 */         if ((!nMember.EOF) && (0 == groupComparator.compare(firstMember, nMember)))
/*     */         {
/* 209 */           group.add(nMember);
/*     */         } else {
/* 211 */           stream.pushBack(nMember);
/* 212 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 217 */     return firstMember;
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 221 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\JoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */