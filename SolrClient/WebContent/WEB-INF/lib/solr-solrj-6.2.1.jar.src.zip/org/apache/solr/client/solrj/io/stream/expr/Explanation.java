/*     */ package org.apache.solr.client.solrj.io.stream.expr;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Explanation
/*     */ {
/*     */   private String expressionNodeId;
/*     */   private String expressionType;
/*     */   private String functionName;
/*     */   private String implementingClass;
/*     */   private String expression;
/*     */   private String note;
/*     */   private List<Explanation> helpers;
/*     */   
/*     */   public Explanation(String expressionNodeId)
/*     */   {
/*  39 */     this.expressionNodeId = expressionNodeId;
/*     */   }
/*     */   
/*     */   public String getExpressionNodeId() {
/*  43 */     return this.expressionNodeId;
/*     */   }
/*     */   
/*     */   public String getExpressionType() {
/*  47 */     return this.expressionType;
/*     */   }
/*     */   
/*  50 */   public void setExpressionType(String expressionType) { this.expressionType = expressionType; }
/*     */   
/*     */   public Explanation withExpressionType(String expressionType) {
/*  53 */     setExpressionType(expressionType);
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public String getFunctionName() {
/*  58 */     return this.functionName;
/*     */   }
/*     */   
/*  61 */   public void setFunctionName(String functionName) { this.functionName = functionName; }
/*     */   
/*     */   public Explanation withFunctionName(String functionName) {
/*  64 */     setFunctionName(functionName);
/*  65 */     return this;
/*     */   }
/*     */   
/*     */   public String getImplementingClass() {
/*  69 */     return this.implementingClass;
/*     */   }
/*     */   
/*  72 */   public void setImplementingClass(String implementingClass) { this.implementingClass = implementingClass; }
/*     */   
/*     */   public Explanation withImplementingClass(String implementingClass) {
/*  75 */     setImplementingClass(implementingClass);
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public String getExpression() {
/*  80 */     return this.expression;
/*     */   }
/*     */   
/*  83 */   public void setExpression(String expression) { this.expression = expression; }
/*     */   
/*     */   public Explanation withExpression(String expression) {
/*  86 */     setExpression(expression);
/*  87 */     return this;
/*     */   }
/*     */   
/*     */   public String getNote() {
/*  91 */     return this.note;
/*     */   }
/*     */   
/*  94 */   public void setNote(String note) { this.note = note; }
/*     */   
/*     */   public Explanation withNote(String note) {
/*  97 */     setNote(note);
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public List<Explanation> getHelpers() {
/* 102 */     return this.helpers;
/*     */   }
/*     */   
/* 105 */   public void setHelpers(List<Explanation> helpers) { this.helpers = helpers; }
/*     */   
/*     */   public Explanation withHelpers(List<Explanation> helpers) {
/* 108 */     setHelpers(helpers);
/* 109 */     return this;
/*     */   }
/*     */   
/* 112 */   public Explanation withHelpers(Explanation[] helpers) { for (Explanation helper : helpers) {
/* 113 */       addHelper(helper);
/*     */     }
/* 115 */     return this;
/*     */   }
/*     */   
/* 118 */   public Explanation withHelper(Explanation helper) { addHelper(helper);
/* 119 */     return this;
/*     */   }
/*     */   
/* 122 */   public void addHelper(Explanation helper) { if (null == this.helpers) {
/* 123 */       this.helpers = new ArrayList(1);
/*     */     }
/* 125 */     this.helpers.add(helper);
/*     */   }
/*     */   
/*     */   public Map<String, Object> toMap() {
/* 129 */     Map<String, Object> map = new HashMap();
/* 130 */     if (null != this.expressionNodeId) map.put("expressionNodeId", this.expressionNodeId);
/* 131 */     if (null != this.expressionType) map.put("expressionType", this.expressionType);
/* 132 */     if (null != this.functionName) map.put("functionName", this.functionName);
/* 133 */     if (null != this.implementingClass) map.put("implementingClass", this.implementingClass);
/* 134 */     if (null != this.expression) map.put("expression", this.expression);
/* 135 */     if (null != this.note) { map.put("note", this.note);
/*     */     }
/* 137 */     if ((null != this.helpers) && (0 != this.helpers.size())) {
/* 138 */       List<Map<String, Object>> helperMaps = new ArrayList();
/* 139 */       for (Explanation helper : this.helpers) {
/* 140 */         helperMaps.add(helper.toMap());
/*     */       }
/* 142 */       map.put("helpers", helperMaps);
/*     */     }
/*     */     
/* 145 */     return map;
/*     */   }
/*     */   
/*     */   public static abstract interface ExpressionType
/*     */   {
/*     */     public static final String GRAPH_SOURCE = "graph-source";
/*     */     public static final String MACHINE_LEARNING_MODEL = "ml-model";
/*     */     public static final String STREAM_SOURCE = "stream-source";
/*     */     public static final String STREAM_DECORATOR = "stream-decorator";
/*     */     public static final String DATASTORE = "datastore";
/*     */     public static final String METRIC = "metric";
/*     */     public static final String OPERATION = "operation";
/*     */     public static final String EQUALITOR = "equalitor";
/*     */     public static final String SORTER = "sorter";
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\Explanation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */