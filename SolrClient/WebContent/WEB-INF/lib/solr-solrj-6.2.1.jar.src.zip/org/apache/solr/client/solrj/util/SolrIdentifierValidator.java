/*    */ package org.apache.solr.client.solrj.util;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrIdentifierValidator
/*    */ {
/* 31 */   static final Pattern identifierPattern = Pattern.compile("^(?!\\-)[\\._A-Za-z0-9\\-]+$");
/*    */   
/*    */   public static enum IdentifierType {
/* 34 */     SHARD,  COLLECTION,  CORE,  ALIAS;
/*    */     
/*    */     private IdentifierType() {} }
/*    */   
/* 38 */   public static String validateName(IdentifierType type, String name) { if (!validateIdentifier(name))
/* 39 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, getIdentifierMessage(type, name));
/* 40 */     return name;
/*    */   }
/*    */   
/*    */   public static String validateShardName(String shardName) {
/* 44 */     return validateName(IdentifierType.SHARD, shardName);
/*    */   }
/*    */   
/*    */   public static String validateCollectionName(String collectionName) {
/* 48 */     return validateName(IdentifierType.COLLECTION, collectionName);
/*    */   }
/*    */   
/*    */   public static String validateAliasName(String alias) {
/* 52 */     return validateName(IdentifierType.ALIAS, alias);
/*    */   }
/*    */   
/*    */   public static String validateCoreName(String coreName) {
/* 56 */     return validateName(IdentifierType.CORE, coreName);
/*    */   }
/*    */   
/*    */   private static boolean validateIdentifier(String identifier) {
/* 60 */     if ((identifier == null) || (!identifierPattern.matcher(identifier).matches())) {
/* 61 */       return false;
/*    */     }
/* 63 */     return true;
/*    */   }
/*    */   
/*    */   public static String getIdentifierMessage(IdentifierType identifierType, String name) {
/* 67 */     String typeStr = identifierType.toString().toLowerCase(Locale.ROOT);
/* 68 */     return "Invalid " + typeStr + ": [" + name + "]. " + typeStr + " names must consist entirely of periods, underscores, hyphens, and alphanumerics as well not start with a hyphen";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\util\SolrIdentifierValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */