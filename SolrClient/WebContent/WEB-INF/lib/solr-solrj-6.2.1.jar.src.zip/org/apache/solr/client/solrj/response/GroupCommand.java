/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupCommand
/*     */   implements Serializable
/*     */ {
/*     */   private final String _name;
/*  47 */   private final List<Group> _values = new ArrayList();
/*     */   
/*     */ 
/*     */   private final int _matches;
/*     */   
/*     */ 
/*     */   private final Integer _ngroups;
/*     */   
/*     */ 
/*     */   public GroupCommand(String name, int matches)
/*     */   {
/*  58 */     this._name = name;
/*  59 */     this._matches = matches;
/*  60 */     this._ngroups = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupCommand(String name, int matches, int nGroups)
/*     */   {
/*  71 */     this._name = name;
/*  72 */     this._matches = matches;
/*  73 */     this._ngroups = Integer.valueOf(nGroups);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  82 */     return this._name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Group group)
/*     */   {
/*  91 */     this._values.add(group);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Group> getValues()
/*     */   {
/* 101 */     return this._values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMatches()
/*     */   {
/* 110 */     return this._matches;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getNGroups()
/*     */   {
/* 121 */     return this._ngroups;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\GroupCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */