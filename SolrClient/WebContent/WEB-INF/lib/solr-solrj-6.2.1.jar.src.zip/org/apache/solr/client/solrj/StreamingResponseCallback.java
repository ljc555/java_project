package org.apache.solr.client.solrj;

import org.apache.solr.common.SolrDocument;

public abstract class StreamingResponseCallback
{
  public abstract void streamSolrDocument(SolrDocument paramSolrDocument);
  
  public abstract void streamDocListInfo(long paramLong1, long paramLong2, Float paramFloat);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\StreamingResponseCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */