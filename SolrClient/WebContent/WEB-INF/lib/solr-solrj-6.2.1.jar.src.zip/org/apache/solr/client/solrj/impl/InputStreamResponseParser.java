/*    */ package org.apache.solr.client.solrj.impl;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.apache.solr.client.solrj.ResponseParser;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputStreamResponseParser
/*    */   extends ResponseParser
/*    */ {
/*    */   private final String writerType;
/*    */   
/*    */   public InputStreamResponseParser(String writerType)
/*    */   {
/* 33 */     this.writerType = writerType;
/*    */   }
/*    */   
/*    */   public String getWriterType()
/*    */   {
/* 38 */     return this.writerType;
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(Reader reader)
/*    */   {
/* 43 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(InputStream body, String encoding)
/*    */   {
/* 48 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\InputStreamResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */