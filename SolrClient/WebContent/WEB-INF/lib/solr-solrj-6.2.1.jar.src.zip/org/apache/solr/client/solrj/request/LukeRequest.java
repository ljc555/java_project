/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.LukeResponse;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LukeRequest
/*     */   extends SolrRequest<LukeResponse>
/*     */ {
/*     */   private List<String> fields;
/*  39 */   private int numTerms = -1;
/*  40 */   private boolean showSchema = false;
/*     */   
/*     */   public LukeRequest()
/*     */   {
/*  44 */     super(SolrRequest.METHOD.GET, "/admin/luke");
/*     */   }
/*     */   
/*     */   public LukeRequest(String path)
/*     */   {
/*  49 */     super(SolrRequest.METHOD.GET, path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addField(String f)
/*     */   {
/*  57 */     if (this.fields == null) {
/*  58 */       this.fields = new ArrayList();
/*     */     }
/*  60 */     this.fields.add(f);
/*     */   }
/*     */   
/*     */   public void setFields(List<String> f)
/*     */   {
/*  65 */     this.fields = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isShowSchema()
/*     */   {
/*  72 */     return this.showSchema;
/*     */   }
/*     */   
/*     */   public void setShowSchema(boolean showSchema) {
/*  76 */     this.showSchema = showSchema;
/*     */   }
/*     */   
/*     */   public int getNumTerms() {
/*  80 */     return this.numTerms;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNumTerms(int count)
/*     */   {
/*  87 */     this.numTerms = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */   {
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   protected LukeResponse createResponse(SolrClient client)
/*     */   {
/* 100 */     return new LukeResponse();
/*     */   }
/*     */   
/*     */   public SolrParams getParams()
/*     */   {
/* 105 */     ModifiableSolrParams params = new ModifiableSolrParams();
/* 106 */     if ((this.fields != null) && (this.fields.size() > 0)) {
/* 107 */       params.add("fl", (String[])this.fields.toArray(new String[this.fields.size()]));
/*     */     }
/* 109 */     if (this.numTerms >= 0) {
/* 110 */       params.add("numTerms", new String[] { this.numTerms + "" });
/*     */     }
/* 112 */     if (this.showSchema) {
/* 113 */       params.add("show", new String[] { "schema" });
/*     */     }
/* 115 */     return params;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\LukeRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */