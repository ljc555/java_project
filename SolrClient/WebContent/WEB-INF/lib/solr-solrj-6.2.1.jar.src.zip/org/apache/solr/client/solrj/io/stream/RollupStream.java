/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.HashKey;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.MultipleFieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.client.solrj.io.stream.metrics.Bucket;
/*     */ import org.apache.solr.client.solrj.io.stream.metrics.Metric;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RollupStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PushBackStream tupleStream;
/*     */   private Bucket[] buckets;
/*     */   private Metric[] metrics;
/*  51 */   private HashKey currentKey = new HashKey("-");
/*     */   private Metric[] currentMetrics;
/*  53 */   private boolean finished = false;
/*     */   
/*     */ 
/*     */   public RollupStream(TupleStream tupleStream, Bucket[] buckets, Metric[] metrics)
/*     */   {
/*  58 */     init(tupleStream, buckets, metrics);
/*     */   }
/*     */   
/*     */   public RollupStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  63 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  64 */     List<StreamExpression> metricExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, Metric.class });
/*  65 */     StreamExpressionNamedParameter overExpression = factory.getNamedOperand(expression, "over");
/*     */     
/*     */ 
/*  68 */     if (expression.getParameters().size() != streamExpressions.size() + metricExpressions.size() + 1) {
/*  69 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  72 */     if (1 != streamExpressions.size()) {
/*  73 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*  75 */     if (0 == metricExpressions.size()) {
/*  76 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting at least 1 metric but found %d", new Object[] { expression, Integer.valueOf(metricExpressions.size()) }));
/*     */     }
/*  78 */     if ((null == overExpression) || (!(overExpression.getParameter() instanceof StreamExpressionValue))) {
/*  79 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'over' parameter listing fields to rollup by but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/*  83 */     Metric[] metrics = new Metric[metricExpressions.size()];
/*  84 */     for (int idx = 0; idx < metricExpressions.size(); idx++) {
/*  85 */       metrics[idx] = factory.constructMetric((StreamExpression)metricExpressions.get(idx));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  91 */     StreamEqualitor streamEqualitor = factory.constructEqualitor(((StreamExpressionValue)overExpression.getParameter()).getValue(), FieldEqualitor.class);
/*  92 */     List<FieldEqualitor> flattenedEqualitors = flattenEqualitor(streamEqualitor);
/*  93 */     Bucket[] buckets = new Bucket[flattenedEqualitors.size()];
/*  94 */     for (int idx = 0; idx < flattenedEqualitors.size(); idx++) {
/*  95 */       buckets[idx] = new Bucket(((FieldEqualitor)flattenedEqualitors.get(idx)).getLeftFieldName());
/*     */     }
/*     */     
/*     */ 
/*  99 */     init(factory.constructStream((StreamExpression)streamExpressions.get(0)), buckets, metrics);
/*     */   }
/*     */   
/*     */   private List<FieldEqualitor> flattenEqualitor(StreamEqualitor equalitor) {
/* 103 */     List<FieldEqualitor> flattenedList = new ArrayList();
/*     */     
/* 105 */     if ((equalitor instanceof FieldEqualitor)) {
/* 106 */       flattenedList.add((FieldEqualitor)equalitor);
/*     */     }
/* 108 */     else if ((equalitor instanceof MultipleFieldEqualitor)) {
/* 109 */       MultipleFieldEqualitor mEqualitor = (MultipleFieldEqualitor)equalitor;
/* 110 */       for (StreamEqualitor subEqualitor : mEqualitor.getEqs()) {
/* 111 */         flattenedList.addAll(flattenEqualitor(subEqualitor));
/*     */       }
/*     */     }
/*     */     
/* 115 */     return flattenedList;
/*     */   }
/*     */   
/*     */   private void init(TupleStream tupleStream, Bucket[] buckets, Metric[] metrics) {
/* 119 */     this.tupleStream = new PushBackStream(tupleStream);
/* 120 */     this.buckets = buckets;
/* 121 */     this.metrics = metrics;
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 126 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 131 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 134 */     if (includeStreams) {
/* 135 */       expression.addParameter(this.tupleStream.toExpression(factory));
/*     */     }
/*     */     else {
/* 138 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 142 */     StringBuilder overBuilder = new StringBuilder();
/* 143 */     for (Bucket bucket : this.buckets) {
/* 144 */       if (overBuilder.length() > 0) overBuilder.append(",");
/* 145 */       overBuilder.append(bucket.toString());
/*     */     }
/* 147 */     expression.addParameter(new StreamExpressionNamedParameter("over", overBuilder.toString()));
/*     */     
/*     */ 
/* 150 */     for (Metric metric : this.metrics) {
/* 151 */       expression.addParameter(metric.toExpression(factory));
/*     */     }
/*     */     
/* 154 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 167 */     Explanation explanation = new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.tupleStream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString());
/*     */     
/* 169 */     for (Metric metric : this.metrics) {
/* 170 */       explanation.withHelper(metric.toExplanation(factory));
/*     */     }
/*     */     
/* 173 */     return explanation;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 177 */     this.tupleStream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 181 */     List<TupleStream> l = new ArrayList();
/* 182 */     l.add(this.tupleStream);
/* 183 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 187 */     this.tupleStream.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 191 */     this.tupleStream.close();
/* 192 */     this.currentMetrics = null;
/* 193 */     this.currentKey = new HashKey("-");
/* 194 */     this.finished = false;
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*     */     for (;;) {
/* 200 */       Tuple tuple = this.tupleStream.read();
/* 201 */       Metric localMetric1; Metric metric; if (tuple.EOF) {
/* 202 */         if (!this.finished)
/*     */         {
/* 204 */           if (this.currentMetrics == null) {
/* 205 */             return tuple;
/*     */           }
/*     */           
/* 208 */           Map<String, Object> map = new HashMap();
/* 209 */           Metric[] arrayOfMetric1 = this.currentMetrics;int i = arrayOfMetric1.length; for (localMetric1 = 0; localMetric1 < i; localMetric1++) { metric = arrayOfMetric1[localMetric1];
/* 210 */             map.put(metric.getIdentifier(), metric.getValue());
/*     */           }
/*     */           
/* 213 */           for (int i = 0; i < this.buckets.length; i++) {
/* 214 */             map.put(this.buckets[i].toString(), this.currentKey.getParts()[i]);
/*     */           }
/* 216 */           Tuple t = new Tuple(map);
/* 217 */           this.tupleStream.pushBack(tuple);
/* 218 */           this.finished = true;
/* 219 */           return t;
/*     */         }
/* 221 */         return tuple;
/*     */       }
/*     */       
/*     */ 
/* 225 */       Object[] bucketValues = new Object[this.buckets.length];
/* 226 */       for (int i = 0; i < this.buckets.length; i++) {
/* 227 */         bucketValues[i] = this.buckets[i].getBucketValue(tuple);
/*     */       }
/*     */       
/* 230 */       HashKey hashKey = new HashKey(bucketValues);
/*     */       Metric bucketMetric;
/* 232 */       if (hashKey.equals(this.currentKey)) {
/* 233 */         Metric[] arrayOfMetric2 = this.currentMetrics;localMetric1 = arrayOfMetric2.length; for (metric = 0; metric < localMetric1; metric++) { bucketMetric = arrayOfMetric2[metric];
/* 234 */           bucketMetric.update(tuple);
/*     */         }
/*     */       } else {
/* 237 */         Tuple t = null;
/* 238 */         if (this.currentMetrics != null) {
/* 239 */           Object map = new HashMap();
/* 240 */           metric = this.currentMetrics;bucketMetric = metric.length; for (Metric localMetric2 = 0; localMetric2 < bucketMetric; localMetric2++) { Metric metric = metric[localMetric2];
/* 241 */             ((Map)map).put(metric.getIdentifier(), metric.getValue());
/*     */           }
/*     */           
/* 244 */           for (int i = 0; i < this.buckets.length; i++) {
/* 245 */             ((Map)map).put(this.buckets[i].toString(), this.currentKey.getParts()[i]);
/*     */           }
/* 247 */           t = new Tuple((Map)map);
/*     */         }
/*     */         
/* 250 */         this.currentMetrics = new Metric[this.metrics.length];
/* 251 */         this.currentKey = hashKey;
/* 252 */         for (int i = 0; i < this.metrics.length; i++) {
/* 253 */           Metric bucketMetric = this.metrics[i].newInstance();
/* 254 */           bucketMetric.update(tuple);
/* 255 */           this.currentMetrics[i] = bucketMetric;
/*     */         }
/*     */         
/* 258 */         if (t != null) {
/* 259 */           return t;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 266 */     return 0;
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 271 */     return this.tupleStream.getStreamSort();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\RollupStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */