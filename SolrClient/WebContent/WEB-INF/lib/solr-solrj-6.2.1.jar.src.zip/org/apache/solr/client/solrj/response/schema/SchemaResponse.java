/*     */ package org.apache.solr.client.solrj.response.schema;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.request.schema.AnalyzerDefinition;
/*     */ import org.apache.solr.client.solrj.request.schema.FieldTypeDefinition;
/*     */ import org.apache.solr.client.solrj.response.SolrResponseBase;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaResponse
/*     */   extends SolrResponseBase
/*     */ {
/*     */   private SchemaRepresentation schemaRepresentation;
/*     */   
/*     */   private static <T> Map<String, T> extractAttributeMap(NamedList<T> namedList)
/*     */   {
/*  39 */     if (namedList == null) return null;
/*  40 */     LinkedHashMap<String, T> result = new LinkedHashMap();
/*  41 */     for (int i = 0; i < namedList.size(); i++) {
/*  42 */       T val = namedList.getVal(i);
/*  43 */       String name = namedList.getName(i);
/*  44 */       if ((!(val instanceof NamedList)) && (!(val instanceof List))) {
/*  45 */         result.put(name, val);
/*     */       }
/*     */     }
/*     */     
/*  49 */     return result;
/*     */   }
/*     */   
/*     */   private static AnalyzerDefinition createAnalyzerDefinition(NamedList<Object> analyzerNamedList)
/*     */   {
/*  54 */     AnalyzerDefinition analyzerDefinition = new AnalyzerDefinition();
/*  55 */     Map<String, Object> analyzerAttributes = extractAttributeMap(analyzerNamedList);
/*  56 */     analyzerDefinition.setAttributes(analyzerAttributes);
/*  57 */     List<NamedList<Object>> charFiltersList = (List)analyzerNamedList.get("charFilters");
/*  58 */     Map<String, Object> charFilterAttributes; if (charFiltersList != null) {
/*  59 */       List<Map<String, Object>> charFiltersAttributesList = new LinkedList();
/*  60 */       for (NamedList<Object> charFilterNamedList : charFiltersList) {
/*  61 */         charFilterAttributes = extractAttributeMap(charFilterNamedList);
/*  62 */         charFiltersAttributesList.add(charFilterAttributes);
/*     */       }
/*  64 */       analyzerDefinition.setCharFilters(charFiltersAttributesList);
/*     */     }
/*  66 */     NamedList<Object> tokenizerNamedList = (NamedList)analyzerNamedList.get("tokenizer");
/*  67 */     if (tokenizerNamedList != null) {
/*  68 */       Object tokenizerAttributes = extractAttributeMap(tokenizerNamedList);
/*  69 */       analyzerDefinition.setTokenizer((Map)tokenizerAttributes);
/*     */     }
/*  71 */     Object filtersList = (List)analyzerNamedList.get("filters");
/*  72 */     List<Map<String, Object>> filtersAttributesList = new LinkedList();
/*  73 */     if (filtersList != null) {
/*  74 */       for (NamedList<Object> filterNamedList : (List)filtersList) {
/*  75 */         Map<String, Object> filterAttributes = extractAttributeMap(filterNamedList);
/*  76 */         filtersAttributesList.add(filterAttributes);
/*     */       }
/*  78 */       analyzerDefinition.setFilters(filtersAttributesList);
/*     */     }
/*     */     
/*  81 */     return analyzerDefinition;
/*     */   }
/*     */   
/*     */   private static FieldTypeDefinition createFieldTypeDefinition(NamedList<Object> fieldTypeNamedList)
/*     */   {
/*  86 */     FieldTypeDefinition fieldTypeDefinition = new FieldTypeDefinition();
/*  87 */     fillFieldTypeDefinition(fieldTypeDefinition, fieldTypeNamedList);
/*  88 */     return fieldTypeDefinition;
/*     */   }
/*     */   
/*     */   private static FieldTypeRepresentation createFieldTypeRepresentation(NamedList<Object> fieldTypeNamedList)
/*     */   {
/*  93 */     FieldTypeRepresentation fieldTypeRepresentation = new FieldTypeRepresentation();
/*  94 */     fillFieldTypeDefinition(fieldTypeRepresentation, fieldTypeNamedList);
/*  95 */     List<String> fields = (List)fieldTypeNamedList.get("fields");
/*  96 */     if (fields != null) fieldTypeRepresentation.setFields(fields);
/*  97 */     List<String> dynamicFields = (List)fieldTypeNamedList.get("dynamicFields");
/*  98 */     if (dynamicFields != null) fieldTypeRepresentation.setDynamicFields(dynamicFields);
/*  99 */     return fieldTypeRepresentation;
/*     */   }
/*     */   
/*     */   private static void fillFieldTypeDefinition(FieldTypeDefinition fieldTypeDefinition, NamedList<Object> fieldTypeNamedList)
/*     */   {
/* 104 */     Map<String, Object> fieldTypeAttributes = extractAttributeMap(fieldTypeNamedList);
/* 105 */     fieldTypeDefinition.setAttributes(fieldTypeAttributes);
/* 106 */     NamedList<Object> analyzerNamedList = (NamedList)fieldTypeNamedList.get("analyzer");
/* 107 */     if (analyzerNamedList != null) {
/* 108 */       AnalyzerDefinition analyzerDefinition = createAnalyzerDefinition(analyzerNamedList);
/* 109 */       fieldTypeDefinition.setAnalyzer(analyzerDefinition);
/*     */     }
/* 111 */     NamedList<Object> indexAnalyzerNamedList = (NamedList)fieldTypeNamedList.get("indexAnalyzer");
/* 112 */     if (indexAnalyzerNamedList != null)
/*     */     {
/* 114 */       AnalyzerDefinition indexAnalyzerDefinition = createAnalyzerDefinition(indexAnalyzerNamedList);
/* 115 */       fieldTypeDefinition.setIndexAnalyzer(indexAnalyzerDefinition);
/*     */     }
/* 117 */     NamedList<Object> queryAnalyzerNamedList = (NamedList)fieldTypeNamedList.get("queryAnalyzer");
/* 118 */     if (queryAnalyzerNamedList != null) {
/* 119 */       AnalyzerDefinition queryAnalyzerDefinition = createAnalyzerDefinition(queryAnalyzerNamedList);
/* 120 */       fieldTypeDefinition.setQueryAnalyzer(queryAnalyzerDefinition);
/*     */     }
/* 122 */     NamedList<Object> multiTermAnalyzerNamedList = (NamedList)fieldTypeNamedList.get("multiTermAnalyzer");
/* 123 */     if (multiTermAnalyzerNamedList != null)
/*     */     {
/* 125 */       AnalyzerDefinition multiTermAnalyzerDefinition = createAnalyzerDefinition(multiTermAnalyzerNamedList);
/* 126 */       fieldTypeDefinition.setMultiTermAnalyzer(multiTermAnalyzerDefinition);
/*     */     }
/* 128 */     NamedList<Object> similarityNamedList = (NamedList)fieldTypeNamedList.get("similarity");
/* 129 */     if (similarityNamedList != null) {
/* 130 */       Map<String, Object> similarityAttributes = extractAttributeMap(similarityNamedList);
/* 131 */       fieldTypeDefinition.setSimilarity(similarityAttributes);
/*     */     }
/*     */   }
/*     */   
/*     */   private static SchemaRepresentation createSchemaConfiguration(Map schemaObj) {
/* 136 */     SchemaRepresentation schemaRepresentation = new SchemaRepresentation();
/* 137 */     schemaRepresentation.setName(getSchemaName(schemaObj));
/* 138 */     schemaRepresentation.setVersion(getSchemaVersion(schemaObj).floatValue());
/* 139 */     schemaRepresentation.setUniqueKey(getSchemaUniqueKey(schemaObj));
/* 140 */     schemaRepresentation.setDefaultSearchField(getDefaultSearchField(schemaObj));
/* 141 */     schemaRepresentation.setDefaultOperator(getDefaultOperator(schemaObj));
/* 142 */     schemaRepresentation.setSimilarity(getSimilarity(schemaObj));
/* 143 */     schemaRepresentation.setFields(getFields(schemaObj));
/* 144 */     schemaRepresentation.setDynamicFields(getDynamicFields(schemaObj));
/* 145 */     schemaRepresentation.setFieldTypes(getFieldTypeDefinitions(schemaObj));
/* 146 */     schemaRepresentation.setCopyFields(getCopyFields(schemaObj));
/* 147 */     return schemaRepresentation;
/*     */   }
/*     */   
/*     */   private static String getSchemaName(Map schemaNamedList) {
/* 151 */     return (String)schemaNamedList.get("name");
/*     */   }
/*     */   
/*     */   private static Float getSchemaVersion(Map schemaNamedList) {
/* 155 */     return (Float)schemaNamedList.get("version");
/*     */   }
/*     */   
/*     */   private static String getSchemaUniqueKey(Map schemaNamedList) {
/* 159 */     return (String)schemaNamedList.get("uniqueKey");
/*     */   }
/*     */   
/*     */   private static String getDefaultSearchField(Map schemaNamedList) {
/* 163 */     return (String)schemaNamedList.get("defaultSearchField");
/*     */   }
/*     */   
/*     */   private static Map<String, Object> getSimilarity(Map schemaNamedList) {
/* 167 */     NamedList<Object> similarityNamedList = (NamedList)schemaNamedList.get("similarity");
/* 168 */     Map<String, Object> similarity = null;
/* 169 */     if (similarityNamedList != null) similarity = extractAttributeMap(similarityNamedList);
/* 170 */     return similarity;
/*     */   }
/*     */   
/*     */   private static String getDefaultOperator(Map schemaNamedList)
/*     */   {
/* 175 */     String defaultOperator = null;
/* 176 */     NamedList<Object> solrQueryParserProperties = (NamedList)schemaNamedList.get("solrQueryParser");
/* 177 */     if (solrQueryParserProperties != null) defaultOperator = (String)solrQueryParserProperties.get("defaultOperator");
/* 178 */     return defaultOperator;
/*     */   }
/*     */   
/*     */   private static List<Map<String, Object>> getFields(Map schemaNamedList)
/*     */   {
/* 183 */     List<Map<String, Object>> fieldsAttributes = new LinkedList();
/* 184 */     List<NamedList<Object>> fieldsResponse = (List)schemaNamedList.get("fields");
/* 185 */     for (NamedList<Object> fieldNamedList : fieldsResponse) {
/* 186 */       Map<String, Object> fieldAttributes = new LinkedHashMap();
/* 187 */       fieldAttributes.putAll(extractAttributeMap(fieldNamedList));
/* 188 */       fieldsAttributes.add(fieldAttributes);
/*     */     }
/*     */     
/* 191 */     return fieldsAttributes;
/*     */   }
/*     */   
/*     */   private static List<Map<String, Object>> getDynamicFields(Map schemaNamedList)
/*     */   {
/* 196 */     List<Map<String, Object>> dynamicFieldsAttributes = new LinkedList();
/* 197 */     List<NamedList<Object>> dynamicFieldsResponse = (List)schemaNamedList.get("dynamicFields");
/* 198 */     for (NamedList<Object> fieldNamedList : dynamicFieldsResponse) {
/* 199 */       Map<String, Object> dynamicFieldAttributes = new LinkedHashMap();
/* 200 */       dynamicFieldAttributes.putAll(extractAttributeMap(fieldNamedList));
/* 201 */       dynamicFieldsAttributes.add(dynamicFieldAttributes);
/*     */     }
/*     */     
/* 204 */     return dynamicFieldsAttributes;
/*     */   }
/*     */   
/*     */   private static List<Map<String, Object>> getCopyFields(Map schemaNamedList)
/*     */   {
/* 209 */     List<Map<String, Object>> copyFieldsAttributes = new LinkedList();
/* 210 */     List<NamedList<Object>> copyFieldsResponse = (List)schemaNamedList.get("copyFields");
/* 211 */     for (NamedList<Object> copyFieldNamedList : copyFieldsResponse) {
/* 212 */       Map<String, Object> copyFieldAttributes = new LinkedHashMap();
/* 213 */       copyFieldAttributes.putAll(extractAttributeMap(copyFieldNamedList));
/* 214 */       copyFieldsAttributes.add(copyFieldAttributes);
/*     */     }
/*     */     
/* 217 */     return copyFieldsAttributes;
/*     */   }
/*     */   
/*     */   private static List<FieldTypeDefinition> getFieldTypeDefinitions(Map schemaNamedList)
/*     */   {
/* 222 */     List<FieldTypeDefinition> fieldTypeDefinitions = new LinkedList();
/* 223 */     List<NamedList<Object>> fieldsResponse = (List)schemaNamedList.get("fieldTypes");
/* 224 */     for (NamedList<Object> fieldNamedList : fieldsResponse) {
/* 225 */       FieldTypeDefinition fieldTypeDefinition = createFieldTypeDefinition(fieldNamedList);
/* 226 */       fieldTypeDefinitions.add(fieldTypeDefinition);
/*     */     }
/*     */     
/* 229 */     return fieldTypeDefinitions;
/*     */   }
/*     */   
/*     */   private static List<FieldTypeRepresentation> getFieldTypeRepresentations(Map schemaNamedList)
/*     */   {
/* 234 */     List<FieldTypeRepresentation> fieldTypeRepresentations = new LinkedList();
/* 235 */     List<NamedList<Object>> fieldsResponse = (List)schemaNamedList.get("fieldTypes");
/* 236 */     for (NamedList<Object> fieldNamedList : fieldsResponse) {
/* 237 */       FieldTypeRepresentation fieldTypeRepresentation = createFieldTypeRepresentation(fieldNamedList);
/* 238 */       fieldTypeRepresentations.add(fieldTypeRepresentation);
/*     */     }
/*     */     
/* 241 */     return fieldTypeRepresentations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(NamedList<Object> response)
/*     */   {
/* 250 */     super.setResponse(response);
/*     */     
/* 252 */     Map schemaObj = (Map)response.get("schema");
/* 253 */     this.schemaRepresentation = createSchemaConfiguration(schemaObj);
/*     */   }
/*     */   
/*     */   public SchemaRepresentation getSchemaRepresentation() {
/* 257 */     return this.schemaRepresentation;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class SchemaNameResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     private String schemaName;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 269 */       super.setResponse(response);
/*     */       
/* 271 */       this.schemaName = SchemaResponse.getSchemaName(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public String getSchemaName() {
/* 275 */       return this.schemaName;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class SchemaVersionResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     private float schemaVersion;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 289 */       super.setResponse(response);
/*     */       
/* 291 */       this.schemaVersion = SchemaResponse.getSchemaVersion(response.asShallowMap()).floatValue();
/*     */     }
/*     */     
/*     */     public float getSchemaVersion() {
/* 295 */       return this.schemaVersion;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FieldResponse extends SolrResponseBase
/*     */   {
/* 301 */     Map<String, Object> field = new LinkedHashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 309 */       super.setResponse(response);
/*     */       
/* 311 */       NamedList<Object> fieldResponse = (NamedList)response.get("field");
/* 312 */       this.field.putAll(SchemaResponse.extractAttributeMap(fieldResponse));
/*     */     }
/*     */     
/*     */     public Map<String, Object> getField() {
/* 316 */       return this.field;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class FieldsResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     List<Map<String, Object>> fields;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 330 */       super.setResponse(response);
/*     */       
/* 332 */       this.fields = SchemaResponse.getFields(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public List<Map<String, Object>> getFields() {
/* 336 */       return this.fields;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DynamicFieldResponse extends SolrResponseBase {
/* 341 */     Map<String, Object> dynamicField = new LinkedHashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 349 */       super.setResponse(response);
/*     */       
/* 351 */       NamedList<Object> dynamicFieldResponse = (NamedList)response.get("dynamicField");
/* 352 */       this.dynamicField.putAll(SchemaResponse.extractAttributeMap(dynamicFieldResponse));
/*     */     }
/*     */     
/*     */     public Map<String, Object> getDynamicField() {
/* 356 */       return this.dynamicField;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class DynamicFieldsResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     List<Map<String, Object>> dynamicFields;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 370 */       super.setResponse(response);
/*     */       
/* 372 */       this.dynamicFields = SchemaResponse.getDynamicFields(response.asMap(3));
/*     */     }
/*     */     
/*     */     public List<Map<String, Object>> getDynamicFields() {
/* 376 */       return this.dynamicFields;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class UniqueKeyResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     private String uniqueKey;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 389 */       super.setResponse(response);
/*     */       
/* 391 */       this.uniqueKey = SchemaResponse.getSchemaUniqueKey(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public String getUniqueKey() {
/* 395 */       return this.uniqueKey;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class GlobalSimilarityResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     Map<String, Object> similarity;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 408 */       super.setResponse(response);
/*     */       
/* 410 */       this.similarity = SchemaResponse.getSimilarity(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public Map<String, Object> getSimilarity() {
/* 414 */       return this.similarity;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class DefaultQueryOperatorResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     private String defaultOperator;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 428 */       super.setResponse(response);
/*     */       
/* 430 */       this.defaultOperator = ((String)response.get("defaultOperator"));
/*     */     }
/*     */     
/*     */     public String getDefaultOperator() {
/* 434 */       return this.defaultOperator;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class CopyFieldsResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     List<Map<String, Object>> copyFields;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 447 */       super.setResponse(response);
/*     */       
/* 449 */       this.copyFields = SchemaResponse.getCopyFields(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public List<Map<String, Object>> getCopyFields() {
/* 453 */       return this.copyFields;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class FieldTypeResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     private FieldTypeRepresentation fieldType;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 466 */       super.setResponse(response);
/*     */       
/* 468 */       NamedList<Object> fieldTypeNamedList = (NamedList)response.get("fieldType");
/* 469 */       this.fieldType = SchemaResponse.createFieldTypeRepresentation(fieldTypeNamedList);
/*     */     }
/*     */     
/*     */     public FieldTypeRepresentation getFieldType() {
/* 473 */       return this.fieldType;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class FieldTypesResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     List<FieldTypeRepresentation> fieldTypes;
/*     */     
/*     */ 
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 487 */       super.setResponse(response);
/*     */       
/* 489 */       this.fieldTypes = SchemaResponse.getFieldTypeRepresentations(response.asShallowMap());
/*     */     }
/*     */     
/*     */     public List<FieldTypeRepresentation> getFieldTypes() {
/* 493 */       return this.fieldTypes;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class UpdateResponse
/*     */     extends SolrResponseBase
/*     */   {
/*     */     public void setResponse(NamedList<Object> response)
/*     */     {
/* 504 */       super.setResponse(response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\schema\SchemaResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */