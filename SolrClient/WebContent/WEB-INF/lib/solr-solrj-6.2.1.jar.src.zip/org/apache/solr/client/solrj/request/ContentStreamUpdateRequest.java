/*    */ package org.apache.solr.client.solrj.request;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*    */ import org.apache.solr.common.util.ContentStream;
/*    */ import org.apache.solr.common.util.ContentStreamBase;
/*    */ import org.apache.solr.common.util.ContentStreamBase.FileStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentStreamUpdateRequest
/*    */   extends AbstractUpdateRequest
/*    */ {
/*    */   List<ContentStream> contentStreams;
/*    */   
/*    */   public ContentStreamUpdateRequest(String url)
/*    */   {
/* 45 */     super(SolrRequest.METHOD.POST, url);
/* 46 */     this.contentStreams = new ArrayList();
/*    */   }
/*    */   
/*    */   public Collection<ContentStream> getContentStreams() throws IOException
/*    */   {
/* 51 */     return this.contentStreams;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addFile(File file, String contentType)
/*    */     throws IOException
/*    */   {
/* 63 */     ContentStreamBase cs = new ContentStreamBase.FileStream(file);
/* 64 */     cs.setContentType(contentType);
/* 65 */     addContentStream(cs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addContentStream(ContentStream contentStream)
/*    */   {
/* 73 */     this.contentStreams.add(contentStream);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\ContentStreamUpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */