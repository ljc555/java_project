/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodHandles.Lookup;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RetryUtil
/*    */ {
/* 31 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void retryOnThrowable(Class clazz, long timeoutms, long intervalms, RetryCmd cmd)
/*    */     throws Throwable
/*    */   {
/* 42 */     retryOnThrowable(Collections.singleton(clazz), timeoutms, intervalms, cmd);
/*    */   }
/*    */   
/*    */   public static void retryOnThrowable(Set<Class> classes, long timeoutms, long intervalms, RetryCmd cmd) throws Throwable {
/* 46 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutms, TimeUnit.MILLISECONDS);
/*    */     try
/*    */     {
/* 49 */       cmd.execute();
/*    */     } catch (Throwable t) {
/* 51 */       while ((isInstanceOf(classes, t)) && (System.nanoTime() < timeout)) {
/* 52 */         log.info("Retry due to Throwable, " + t.getClass().getName() + " " + t.getMessage());
/* 53 */         Thread.sleep(intervalms);
/*    */       }
/*    */       
/* 56 */       throw t;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static boolean isInstanceOf(Set<Class> classes, Throwable t)
/*    */   {
/* 64 */     for (Class c : classes) {
/* 65 */       if (c.isInstance(t)) {
/* 66 */         return true;
/*    */       }
/*    */     }
/* 69 */     return false;
/*    */   }
/*    */   
/*    */   public static void retryOnBoolean(long timeoutms, long intervalms, BooleanRetryCmd cmd) {
/* 73 */     long timeout = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeoutms, TimeUnit.MILLISECONDS);
/*    */     boolean resp;
/* 75 */     do { resp = cmd.execute();
/* 76 */     } while ((!resp) && (System.nanoTime() < timeout));
/*    */     
/* 78 */     if (System.nanoTime() >= timeout) {
/* 79 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Timed out while retrying operation");
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface BooleanRetryCmd
/*    */   {
/*    */     public abstract boolean execute();
/*    */   }
/*    */   
/*    */   public static abstract interface RetryCmd
/*    */   {
/*    */     public abstract void execute()
/*    */       throws Throwable;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\RetryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */