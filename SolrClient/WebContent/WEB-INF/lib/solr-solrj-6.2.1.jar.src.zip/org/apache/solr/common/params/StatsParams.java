package org.apache.solr.common.params;

public abstract interface StatsParams
{
  public static final String STATS = "stats";
  public static final String STATS_FIELD = "stats.field";
  public static final String STATS_FACET = "stats.facet";
  public static final String STATS_CALC_DISTINCT = "stats.calcdistinct";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\StatsParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */