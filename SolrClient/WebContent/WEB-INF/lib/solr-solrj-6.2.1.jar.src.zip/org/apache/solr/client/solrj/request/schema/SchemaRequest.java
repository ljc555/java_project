/*     */ package org.apache.solr.client.solrj.request.schema;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.CopyFieldsResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.DefaultQueryOperatorResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.DynamicFieldResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.DynamicFieldsResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.FieldResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.FieldTypeResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.FieldTypesResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.FieldsResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.GlobalSimilarityResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.SchemaNameResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.SchemaVersionResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.UniqueKeyResponse;
/*     */ import org.apache.solr.client.solrj.response.schema.SchemaResponse.UpdateResponse;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ import org.apache.solr.common.util.ContentStreamBase.StringStream;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.noggit.CharArr;
/*     */ import org.noggit.JSONWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaRequest
/*     */   extends AbstractSchemaRequest<SchemaResponse>
/*     */ {
/*     */   public SchemaRequest()
/*     */   {
/*  61 */     this(null);
/*     */   }
/*     */   
/*     */   public SchemaRequest(SolrParams q) {
/*  65 */     super(SolrRequest.METHOD.GET, "/schema", q);
/*     */   }
/*     */   
/*     */   private static NamedList<Object> createAddFieldTypeNamedList(FieldTypeDefinition fieldTypeDefinition) {
/*  69 */     NamedList<Object> addFieldTypeNamedList = new NamedList();
/*  70 */     addFieldTypeNamedList.addAll(fieldTypeDefinition.getAttributes());
/*  71 */     AnalyzerDefinition analyzerDefinition = fieldTypeDefinition.getAnalyzer();
/*  72 */     if (analyzerDefinition != null) {
/*  73 */       NamedList<Object> analyzerNamedList = createAnalyzerNamedList(analyzerDefinition);
/*  74 */       addFieldTypeNamedList.add("analyzer", analyzerNamedList);
/*     */     }
/*  76 */     AnalyzerDefinition indexAnalyzerDefinition = fieldTypeDefinition.getIndexAnalyzer();
/*  77 */     if (indexAnalyzerDefinition != null) {
/*  78 */       NamedList<Object> indexAnalyzerNamedList = createAnalyzerNamedList(indexAnalyzerDefinition);
/*  79 */       addFieldTypeNamedList.add("indexAnalyzer", indexAnalyzerNamedList);
/*     */     }
/*  81 */     AnalyzerDefinition queryAnalyzerDefinition = fieldTypeDefinition.getQueryAnalyzer();
/*  82 */     if (queryAnalyzerDefinition != null) {
/*  83 */       NamedList<Object> queryAnalyzerNamedList = createAnalyzerNamedList(queryAnalyzerDefinition);
/*  84 */       addFieldTypeNamedList.add("queryAnalyzer", queryAnalyzerNamedList);
/*     */     }
/*  86 */     AnalyzerDefinition multiTermAnalyzerDefinition = fieldTypeDefinition.getMultiTermAnalyzer();
/*  87 */     if (multiTermAnalyzerDefinition != null) {
/*  88 */       NamedList<Object> multiTermAnalyzerNamedList = createAnalyzerNamedList(multiTermAnalyzerDefinition);
/*  89 */       addFieldTypeNamedList.add("multiTermAnalyzer", multiTermAnalyzerNamedList);
/*     */     }
/*  91 */     Map<String, Object> similarityAttributes = fieldTypeDefinition.getSimilarity();
/*  92 */     if ((similarityAttributes != null) && (!similarityAttributes.isEmpty())) {
/*  93 */       addFieldTypeNamedList.add("similarity", new NamedList(similarityAttributes));
/*     */     }
/*     */     
/*  96 */     return addFieldTypeNamedList;
/*     */   }
/*     */   
/*     */   private static NamedList<Object> createAnalyzerNamedList(AnalyzerDefinition analyzerDefinition) {
/* 100 */     NamedList<Object> analyzerNamedList = new NamedList();
/* 101 */     Map<String, Object> analyzerAttributes = analyzerDefinition.getAttributes();
/* 102 */     if (analyzerAttributes != null)
/* 103 */       analyzerNamedList.addAll(analyzerAttributes);
/* 104 */     List<Map<String, Object>> charFiltersAttributes = analyzerDefinition.getCharFilters();
/* 105 */     if (charFiltersAttributes != null) {
/* 106 */       List<NamedList<Object>> charFiltersList = new LinkedList();
/* 107 */       for (Map<String, Object> charFilterAttributes : charFiltersAttributes)
/* 108 */         charFiltersList.add(new NamedList(charFilterAttributes));
/* 109 */       analyzerNamedList.add("charFilters", charFiltersList);
/*     */     }
/* 111 */     Map<String, Object> tokenizerAttributes = analyzerDefinition.getTokenizer();
/* 112 */     if (tokenizerAttributes != null) {
/* 113 */       analyzerNamedList.add("tokenizer", new NamedList(tokenizerAttributes));
/*     */     }
/* 115 */     Object filtersAttributes = analyzerDefinition.getFilters();
/* 116 */     if (filtersAttributes != null) {
/* 117 */       List<NamedList<Object>> filtersList = new LinkedList();
/* 118 */       for (Map<String, Object> filterAttributes : (List)filtersAttributes)
/* 119 */         filtersList.add(new NamedList(filterAttributes));
/* 120 */       analyzerNamedList.add("filters", filtersList);
/*     */     }
/* 122 */     return analyzerNamedList;
/*     */   }
/*     */   
/*     */   private static NamedList<Object> createAddFieldNamedList(Map<String, Object> fieldAttributes) {
/* 126 */     NamedList<Object> addFieldProps = new NamedList();
/* 127 */     if (fieldAttributes != null) addFieldProps.addAll(fieldAttributes);
/* 128 */     return addFieldProps;
/*     */   }
/*     */   
/*     */   protected SchemaResponse createResponse(SolrClient client)
/*     */   {
/* 133 */     return new SchemaResponse();
/*     */   }
/*     */   
/*     */   public static class SchemaName
/*     */     extends AbstractSchemaRequest<SchemaResponse.SchemaNameResponse>
/*     */   {
/*     */     public SchemaName()
/*     */     {
/* 141 */       this(null);
/*     */     }
/*     */     
/*     */     public SchemaName(SolrParams q) {
/* 145 */       super("/schema/name", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.SchemaNameResponse createResponse(SolrClient client)
/*     */     {
/* 150 */       return new SchemaResponse.SchemaNameResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class SchemaVersion
/*     */     extends AbstractSchemaRequest<SchemaResponse.SchemaVersionResponse>
/*     */   {
/*     */     public SchemaVersion()
/*     */     {
/* 160 */       this(null);
/*     */     }
/*     */     
/*     */     public SchemaVersion(SolrParams q) {
/* 164 */       super("/schema/version", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.SchemaVersionResponse createResponse(SolrClient client)
/*     */     {
/* 169 */       return new SchemaResponse.SchemaVersionResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Fields
/*     */     extends AbstractSchemaRequest<SchemaResponse.FieldsResponse>
/*     */   {
/*     */     public Fields()
/*     */     {
/* 178 */       this(null);
/*     */     }
/*     */     
/*     */     public Fields(SolrParams q) {
/* 182 */       super("/schema/fields", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.FieldsResponse createResponse(SolrClient client)
/*     */     {
/* 187 */       return new SchemaResponse.FieldsResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Field
/*     */     extends AbstractSchemaRequest<SchemaResponse.FieldResponse>
/*     */   {
/*     */     public Field(String fieldName)
/*     */     {
/* 202 */       this(fieldName, null);
/*     */     }
/*     */     
/*     */     public Field(String fieldName, SolrParams q) {
/* 206 */       super("/schema/fields/" + fieldName, q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.FieldResponse createResponse(SolrClient client)
/*     */     {
/* 211 */       return new SchemaResponse.FieldResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class DynamicFields
/*     */     extends AbstractSchemaRequest<SchemaResponse.DynamicFieldsResponse>
/*     */   {
/*     */     public DynamicFields()
/*     */     {
/* 221 */       this(null);
/*     */     }
/*     */     
/*     */     public DynamicFields(SolrParams q) {
/* 225 */       super("/schema/dynamicfields", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.DynamicFieldsResponse createResponse(SolrClient client)
/*     */     {
/* 230 */       return new SchemaResponse.DynamicFieldsResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DynamicField
/*     */     extends AbstractSchemaRequest<SchemaResponse.DynamicFieldResponse>
/*     */   {
/*     */     public DynamicField(String dynamicFieldName)
/*     */     {
/* 245 */       this(dynamicFieldName, null);
/*     */     }
/*     */     
/*     */     public DynamicField(String dynamicFieldName, SolrParams q) {
/* 249 */       super("/schema/dynamicfields/" + dynamicFieldName);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.DynamicFieldResponse createResponse(SolrClient client)
/*     */     {
/* 254 */       return new SchemaResponse.DynamicFieldResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class FieldTypes
/*     */     extends AbstractSchemaRequest<SchemaResponse.FieldTypesResponse>
/*     */   {
/*     */     public FieldTypes()
/*     */     {
/* 264 */       this(null);
/*     */     }
/*     */     
/*     */     public FieldTypes(SolrParams q) {
/* 268 */       super("/schema/fieldtypes");
/*     */     }
/*     */     
/*     */     protected SchemaResponse.FieldTypesResponse createResponse(SolrClient client)
/*     */     {
/* 273 */       return new SchemaResponse.FieldTypesResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class FieldType
/*     */     extends AbstractSchemaRequest<SchemaResponse.FieldTypeResponse>
/*     */   {
/*     */     public FieldType(String fieldTypeName)
/*     */     {
/* 288 */       this(fieldTypeName, null);
/*     */     }
/*     */     
/*     */     public FieldType(String fieldTypeName, SolrParams q) {
/* 292 */       super("/schema/fieldtypes/" + fieldTypeName, q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.FieldTypeResponse createResponse(SolrClient client)
/*     */     {
/* 297 */       return new SchemaResponse.FieldTypeResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class CopyFields
/*     */     extends AbstractSchemaRequest<SchemaResponse.CopyFieldsResponse>
/*     */   {
/*     */     public CopyFields()
/*     */     {
/* 307 */       this(null);
/*     */     }
/*     */     
/*     */     public CopyFields(SolrParams q) {
/* 311 */       super("/schema/copyfields", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.CopyFieldsResponse createResponse(SolrClient client)
/*     */     {
/* 316 */       return new SchemaResponse.CopyFieldsResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class UniqueKey
/*     */     extends AbstractSchemaRequest<SchemaResponse.UniqueKeyResponse>
/*     */   {
/*     */     public UniqueKey()
/*     */     {
/* 326 */       this(null);
/*     */     }
/*     */     
/*     */     public UniqueKey(SolrParams q) {
/* 330 */       super("/schema/uniquekey", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.UniqueKeyResponse createResponse(SolrClient client)
/*     */     {
/* 335 */       return new SchemaResponse.UniqueKeyResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GlobalSimilarity
/*     */     extends AbstractSchemaRequest<SchemaResponse.GlobalSimilarityResponse>
/*     */   {
/*     */     public GlobalSimilarity()
/*     */     {
/* 344 */       this(null);
/*     */     }
/*     */     
/*     */     public GlobalSimilarity(SolrParams q) {
/* 348 */       super("/schema/similarity", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.GlobalSimilarityResponse createResponse(SolrClient client)
/*     */     {
/* 353 */       return new SchemaResponse.GlobalSimilarityResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DefaultQueryOperator
/*     */     extends AbstractSchemaRequest<SchemaResponse.DefaultQueryOperatorResponse>
/*     */   {
/*     */     public DefaultQueryOperator()
/*     */     {
/* 362 */       this(null);
/*     */     }
/*     */     
/*     */     public DefaultQueryOperator(SolrParams q) {
/* 366 */       super("/schema/solrqueryparser/defaultoperator", q);
/*     */     }
/*     */     
/*     */     protected SchemaResponse.DefaultQueryOperatorResponse createResponse(SolrClient client)
/*     */     {
/* 371 */       return new SchemaResponse.DefaultQueryOperatorResponse();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AddField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public AddField(Map<String, Object> fieldAttributes)
/*     */     {
/* 391 */       this(fieldAttributes, null);
/*     */     }
/*     */     
/*     */     public AddField(Map<String, Object> fieldAttributes, SolrParams q) {
/* 395 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(Map<String, Object> fieldAttributes) {
/* 399 */       NamedList<Object> addFieldParameters = SchemaRequest.createAddFieldNamedList(fieldAttributes);
/* 400 */       NamedList<Object> requestParameters = new NamedList();
/* 401 */       requestParameters.add("add-field", addFieldParameters);
/* 402 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ReplaceField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public ReplaceField(Map<String, Object> fieldAttributes)
/*     */     {
/* 420 */       this(fieldAttributes, null);
/*     */     }
/*     */     
/*     */     public ReplaceField(Map<String, Object> fieldAttributes, SolrParams q) {
/* 424 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(Map<String, Object> fieldAttributes) {
/* 428 */       NamedList<Object> replaceFieldParameters = SchemaRequest.createAddFieldNamedList(fieldAttributes);
/* 429 */       NamedList<Object> requestParameters = new NamedList();
/* 430 */       requestParameters.add("replace-field", replaceFieldParameters);
/* 431 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DeleteField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public DeleteField(String fieldName)
/*     */     {
/* 448 */       this(fieldName, null);
/*     */     }
/*     */     
/*     */     public DeleteField(String fieldName, SolrParams q) {
/* 452 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(String fieldName) {
/* 456 */       NamedList<Object> deleteFieldParameters = new NamedList();
/* 457 */       deleteFieldParameters.add("name", fieldName);
/* 458 */       NamedList<Object> requestParameters = new NamedList();
/* 459 */       requestParameters.add("delete-field", deleteFieldParameters);
/* 460 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AddDynamicField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public AddDynamicField(Map<String, Object> fieldAttributes)
/*     */     {
/* 477 */       this(fieldAttributes, null);
/*     */     }
/*     */     
/*     */     public AddDynamicField(Map<String, Object> fieldAttributes, SolrParams q) {
/* 481 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(Map<String, Object> fieldAttributes) {
/* 485 */       NamedList<Object> addDynamicFieldParameters = SchemaRequest.createAddFieldNamedList(fieldAttributes);
/* 486 */       NamedList<Object> requestParameters = new NamedList();
/* 487 */       requestParameters.add("add-dynamic-field", addDynamicFieldParameters);
/* 488 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ReplaceDynamicField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public ReplaceDynamicField(Map<String, Object> dynamicFieldAttributes)
/*     */     {
/* 508 */       this(dynamicFieldAttributes, null);
/*     */     }
/*     */     
/*     */     public ReplaceDynamicField(Map<String, Object> dynamicFieldAttributes, SolrParams q) {
/* 512 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(Map<String, Object> dynamicFieldAttributes)
/*     */     {
/* 517 */       NamedList<Object> replaceDynamicFieldParameters = SchemaRequest.createAddFieldNamedList(dynamicFieldAttributes);
/* 518 */       NamedList<Object> requestParameters = new NamedList();
/* 519 */       requestParameters.add("replace-dynamic-field", replaceDynamicFieldParameters);
/* 520 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DeleteDynamicField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public DeleteDynamicField(String dynamicFieldName)
/*     */     {
/* 536 */       this(dynamicFieldName, null);
/*     */     }
/*     */     
/*     */     public DeleteDynamicField(String fieldName, SolrParams q) {
/* 540 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(String fieldName) {
/* 544 */       NamedList<Object> deleteDynamicFieldParameters = new NamedList();
/* 545 */       deleteDynamicFieldParameters.add("name", fieldName);
/* 546 */       NamedList<Object> requestParameters = new NamedList();
/* 547 */       requestParameters.add("delete-dynamic-field", deleteDynamicFieldParameters);
/* 548 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AddFieldType
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public AddFieldType(FieldTypeDefinition fieldTypeDefinition)
/*     */     {
/* 563 */       this(fieldTypeDefinition, null);
/*     */     }
/*     */     
/*     */     public AddFieldType(FieldTypeDefinition fieldTypeDefinition, SolrParams q) {
/* 567 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(FieldTypeDefinition fieldTypeDefinition) {
/* 571 */       NamedList<Object> addFieldTypeParameters = SchemaRequest.createAddFieldTypeNamedList(fieldTypeDefinition);
/* 572 */       NamedList<Object> requestParameters = new NamedList();
/* 573 */       requestParameters.add("add-field-type", addFieldTypeParameters);
/* 574 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ReplaceFieldType
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public ReplaceFieldType(FieldTypeDefinition fieldTypeDefinition)
/*     */     {
/* 592 */       this(fieldTypeDefinition, null);
/*     */     }
/*     */     
/*     */     public ReplaceFieldType(FieldTypeDefinition fieldTypeDefinition, SolrParams q) {
/* 596 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(FieldTypeDefinition fieldTypeDefinition) {
/* 600 */       NamedList<Object> replaceFieldTypeParameters = SchemaRequest.createAddFieldTypeNamedList(fieldTypeDefinition);
/* 601 */       NamedList<Object> requestParameters = new NamedList();
/* 602 */       requestParameters.add("replace-field-type", replaceFieldTypeParameters);
/* 603 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DeleteFieldType
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public DeleteFieldType(String fieldTypeName)
/*     */     {
/* 620 */       this(fieldTypeName, null);
/*     */     }
/*     */     
/*     */     public DeleteFieldType(String fieldTypeName, SolrParams q) {
/* 624 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(String fieldTypeName) {
/* 628 */       NamedList<Object> deleteFieldTypeParameters = new NamedList();
/* 629 */       deleteFieldTypeParameters.add("name", fieldTypeName);
/* 630 */       NamedList<Object> requestParameters = new NamedList();
/* 631 */       requestParameters.add("delete-field-type", deleteFieldTypeParameters);
/* 632 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AddCopyField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public AddCopyField(String source, List<String> dest)
/*     */     {
/* 648 */       this(source, dest, (SolrParams)null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AddCopyField(String source, List<String> dest, Integer maxChars)
/*     */     {
/* 661 */       this(source, dest, maxChars, null);
/*     */     }
/*     */     
/*     */     public AddCopyField(String source, List<String> dest, SolrParams q) {
/* 665 */       super(q);
/*     */     }
/*     */     
/*     */     public AddCopyField(String source, List<String> dest, Integer maxChars, SolrParams q) {
/* 669 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(String source, List<String> dest, Integer maxchars) {
/* 673 */       NamedList<Object> addCopyFieldParameters = new NamedList();
/* 674 */       addCopyFieldParameters.add("source", source);
/* 675 */       addCopyFieldParameters.add("dest", dest);
/* 676 */       if (maxchars != null) {
/* 677 */         addCopyFieldParameters.add("maxChars", maxchars);
/*     */       }
/* 679 */       NamedList<Object> requestParameters = new NamedList();
/* 680 */       requestParameters.add("add-copy-field", addCopyFieldParameters);
/* 681 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DeleteCopyField
/*     */     extends SchemaRequest.SingleUpdate
/*     */   {
/*     */     public DeleteCopyField(String source, List<String> dest)
/*     */     {
/* 698 */       this(source, dest, null);
/*     */     }
/*     */     
/*     */     public DeleteCopyField(String source, List<String> dest, SolrParams q) {
/* 702 */       super(q);
/*     */     }
/*     */     
/*     */     private static NamedList<Object> createRequestParameters(String source, List<String> dest) {
/* 706 */       NamedList<Object> addCopyFieldParameters = new NamedList();
/* 707 */       addCopyFieldParameters.add("source", source);
/* 708 */       addCopyFieldParameters.add("dest", dest);
/* 709 */       NamedList<Object> requestParameters = new NamedList();
/* 710 */       requestParameters.add("delete-copy-field", addCopyFieldParameters);
/* 711 */       return requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class Update extends AbstractSchemaRequest<SchemaResponse.UpdateResponse>
/*     */   {
/*     */     public Update() {
/* 718 */       this(null);
/*     */     }
/*     */     
/*     */     public Update(SolrParams q) {
/* 722 */       super("/schema", q);
/*     */     }
/*     */     
/*     */     protected abstract NamedList<Object> getRequestParameters();
/*     */     
/*     */     public Collection<ContentStream> getContentStreams() throws IOException
/*     */     {
/* 729 */       CharArr json = new CharArr();
/* 730 */       new SchemaRequest.SchemaRequestJSONWriter(json).write(getRequestParameters());
/* 731 */       return Collections.singletonList(new ContentStreamBase.StringStream(json.toString()));
/*     */     }
/*     */     
/*     */     protected SchemaResponse.UpdateResponse createResponse(SolrClient client)
/*     */     {
/* 736 */       return new SchemaResponse.UpdateResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract class SingleUpdate extends SchemaRequest.Update {
/*     */     private final NamedList<Object> requestParameters;
/*     */     
/*     */     public SingleUpdate(NamedList<Object> requestParameters) {
/* 744 */       this(requestParameters, null);
/*     */     }
/*     */     
/*     */     public SingleUpdate(NamedList<Object> requestParameters, SolrParams q) {
/* 748 */       super();
/* 749 */       this.requestParameters = requestParameters;
/*     */     }
/*     */     
/*     */     protected NamedList<Object> getRequestParameters()
/*     */     {
/* 754 */       return this.requestParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class MultiUpdate
/*     */     extends SchemaRequest.Update
/*     */   {
/* 764 */     private List<SchemaRequest.Update> updateSchemaRequests = new LinkedList();
/*     */     
/*     */     public MultiUpdate(List<SchemaRequest.Update> updateSchemaRequests) {
/* 767 */       this(updateSchemaRequests, null);
/*     */     }
/*     */     
/*     */     public MultiUpdate(List<SchemaRequest.Update> updateSchemaRequests, SolrParams q) {
/* 771 */       super();
/* 772 */       if (updateSchemaRequests == null) {
/* 773 */         throw new IllegalArgumentException("updateSchemaRequests must be non-null");
/*     */       }
/* 775 */       for (SchemaRequest.Update updateSchemaRequest : updateSchemaRequests) {
/* 776 */         if (updateSchemaRequest == null) {
/* 777 */           throw new IllegalArgumentException("updateSchemaRequests elements must be non-null");
/*     */         }
/* 779 */         this.updateSchemaRequests.add(updateSchemaRequest);
/*     */       }
/*     */     }
/*     */     
/*     */     protected NamedList<Object> getRequestParameters()
/*     */     {
/* 785 */       NamedList<Object> multipleRequestsParameters = new NamedList();
/* 786 */       for (SchemaRequest.Update updateSchemaRequest : this.updateSchemaRequests) {
/* 787 */         multipleRequestsParameters.addAll(updateSchemaRequest.getRequestParameters());
/*     */       }
/* 789 */       return multipleRequestsParameters;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SchemaRequestJSONWriter
/*     */     extends JSONWriter
/*     */   {
/*     */     public SchemaRequestJSONWriter(CharArr out, int indentSize)
/*     */     {
/* 808 */       super(indentSize);
/*     */     }
/*     */     
/*     */     public SchemaRequestJSONWriter(CharArr out) {
/* 812 */       super();
/*     */     }
/*     */     
/*     */     public void write(Object o) {
/* 816 */       if ((o instanceof NamedList))
/* 817 */         write((NamedList)o); else {
/* 818 */         super.write(o);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void write(NamedList<?> val)
/*     */     {
/* 826 */       startObject();
/* 827 */       int sz = val.size();
/* 828 */       boolean first = true;
/* 829 */       Iterator i$ = val.iterator();
/*     */       
/* 831 */       while (i$.hasNext()) {
/* 832 */         Map.Entry<String, ?> entry = (Map.Entry)i$.next();
/* 833 */         if (first) {
/* 834 */           first = false;
/*     */         } else {
/* 836 */           writeValueSeparator();
/*     */         }
/*     */         
/* 839 */         if (sz > 1) {
/* 840 */           indent();
/*     */         }
/*     */         
/* 843 */         writeString((CharSequence)entry.getKey());
/* 844 */         writeNameSeparator();
/* 845 */         write(entry.getValue());
/*     */       }
/*     */       
/* 848 */       endObject();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\schema\SchemaRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */