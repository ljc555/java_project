/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.ResponseParser;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DelegationTokenResponse
/*     */   extends SolrResponseBase
/*     */ {
/*     */   public static class Get
/*     */     extends DelegationTokenResponse
/*     */   {
/*     */     public String getDelegationToken()
/*     */     {
/*     */       try
/*     */       {
/*  43 */         Map map = (Map)getResponse().get("Token");
/*  44 */         if (map != null) {
/*  45 */           return (String)map.get("urlString");
/*     */         }
/*     */       } catch (ClassCastException e) {
/*  48 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*     */       }
/*     */       
/*  51 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Renew extends DelegationTokenResponse {
/*     */     public Long getExpirationTime() {
/*     */       try {
/*  58 */         return (Long)getResponse().get("long");
/*     */       } catch (ClassCastException e) {
/*  60 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Cancel
/*     */     extends DelegationTokenResponse
/*     */   {}
/*     */   
/*     */   public static class JsonMapResponseParser
/*     */     extends ResponseParser
/*     */   {
/*     */     public String getWriterType()
/*     */     {
/*  75 */       return "json";
/*     */     }
/*     */     
/*     */     public NamedList<Object> processResponse(InputStream body, String encoding)
/*     */     {
/*  80 */       ObjectMapper mapper = new ObjectMapper();
/*  81 */       Map map = null;
/*     */       try {
/*  83 */         map = (Map)mapper.readValue(body, Map.class);
/*     */       } catch (IOException e) {
/*  85 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*     */       }
/*     */       
/*  88 */       NamedList<Object> list = new NamedList();
/*  89 */       list.addAll(map);
/*  90 */       return list;
/*     */     }
/*     */     
/*     */     public NamedList<Object> processResponse(Reader reader)
/*     */     {
/*  95 */       throw new RuntimeException("Cannot handle character stream");
/*     */     }
/*     */     
/*     */     public String getContentType()
/*     */     {
/* 100 */       return "application/json";
/*     */     }
/*     */     
/*     */     public String getVersion()
/*     */     {
/* 105 */       return "1";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\DelegationTokenResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */