/*    */ package org.apache.solr.common.luke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FieldFlag
/*    */ {
/* 23 */   INDEXED('I', "Indexed"), 
/* 24 */   TOKENIZED('T', "Tokenized"), 
/* 25 */   STORED('S', "Stored"), 
/* 26 */   DOC_VALUES('D', "DocValues"), 
/* 27 */   MULTI_VALUED('M', "Multivalued"), 
/* 28 */   TERM_VECTOR_STORED('V', "TermVector Stored"), 
/* 29 */   TERM_VECTOR_OFFSET('o', "Store Offset With TermVector"), 
/* 30 */   TERM_VECTOR_POSITION('p', "Store Position With TermVector"), 
/* 31 */   TERM_VECTOR_PAYLOADS('y', "Store Payloads With TermVector"), 
/* 32 */   OMIT_NORMS('O', "Omit Norms"), 
/* 33 */   OMIT_TF('F', "Omit Term Frequencies & Positions"), 
/* 34 */   OMIT_POSITIONS('P', "Omit Positions"), 
/* 35 */   STORE_OFFSETS_WITH_POSITIONS('H', "Store Offsets with Positions"), 
/* 36 */   LAZY('L', "Lazy"), 
/* 37 */   BINARY('B', "Binary"), 
/* 38 */   SORT_MISSING_FIRST('f', "Sort Missing First"), 
/* 39 */   SORT_MISSING_LAST('l', "Sort Missing Last");
/*    */   
/*    */   private final char abbreviation;
/*    */   private final String display;
/*    */   
/*    */   private FieldFlag(char abbreviation, String display) {
/* 45 */     this.abbreviation = abbreviation;
/* 46 */     this.display = display;
/* 47 */     this.display.intern();
/*    */   }
/*    */   
/*    */   public static FieldFlag getFlag(char abbrev) {
/* 51 */     FieldFlag result = null;
/* 52 */     FieldFlag[] vals = values();
/* 53 */     for (int i = 0; i < vals.length; i++) {
/* 54 */       if (vals[i].getAbbreviation() == abbrev) {
/* 55 */         result = vals[i];
/* 56 */         break;
/*    */       }
/*    */     }
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   public char getAbbreviation() {
/* 63 */     return this.abbreviation;
/*    */   }
/*    */   
/*    */   public String getDisplay() {
/* 67 */     return this.display;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\luke\FieldFlag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */