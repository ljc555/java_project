/*    */ package org.apache.solr.client.solrj.io.stream;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamContext
/*    */   implements Serializable
/*    */ {
/* 36 */   private Map entries = new HashMap();
/*    */   public int workerID;
/*    */   public int numWorkers;
/*    */   private SolrClientCache clientCache;
/*    */   private StreamFactory streamFactory;
/*    */   
/*    */   public Object get(Object key) {
/* 43 */     return this.entries.get(key);
/*    */   }
/*    */   
/*    */   public void put(Object key, Object value) {
/* 47 */     this.entries.put(key, value);
/*    */   }
/*    */   
/*    */   public Map getEntries() {
/* 51 */     return this.entries;
/*    */   }
/*    */   
/*    */   public void setSolrClientCache(SolrClientCache clientCache) {
/* 55 */     this.clientCache = clientCache;
/*    */   }
/*    */   
/*    */   public SolrClientCache getSolrClientCache() {
/* 59 */     return this.clientCache;
/*    */   }
/*    */   
/*    */   public void setStreamFactory(StreamFactory streamFactory) {
/* 63 */     this.streamFactory = streamFactory;
/*    */   }
/*    */   
/*    */   public StreamFactory getStreamFactory() {
/* 67 */     return this.streamFactory;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\StreamContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */