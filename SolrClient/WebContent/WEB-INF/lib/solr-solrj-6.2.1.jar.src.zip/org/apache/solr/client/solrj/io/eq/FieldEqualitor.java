/*     */ package org.apache.solr.client.solrj.io.eq;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.MultipleFieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldEqualitor
/*     */   implements StreamEqualitor
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   private UUID equalitorNodeId = UUID.randomUUID();
/*     */   private String leftFieldName;
/*     */   private String rightFieldName;
/*     */   
/*     */   public FieldEqualitor(String fieldName)
/*     */   {
/*  44 */     init(fieldName, fieldName);
/*     */   }
/*     */   
/*  47 */   public FieldEqualitor(String leftFieldName, String rightFieldName) { init(leftFieldName, rightFieldName); }
/*     */   
/*     */   private void init(String leftFieldName, String rightFieldName)
/*     */   {
/*  51 */     this.leftFieldName = leftFieldName;
/*  52 */     this.rightFieldName = rightFieldName;
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) {
/*  56 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  58 */     sb.append(this.leftFieldName);
/*     */     
/*  60 */     if (!this.leftFieldName.equals(this.rightFieldName)) {
/*  61 */       sb.append("=");
/*  62 */       sb.append(this.rightFieldName);
/*     */     }
/*     */     
/*  65 */     return new StreamExpressionValue(sb.toString());
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/*  70 */     return 
/*     */     
/*     */ 
/*  73 */       new Explanation(this.equalitorNodeId.toString()).withExpressionType("equalitor").withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*     */   }
/*     */   
/*     */   public boolean test(Tuple leftTuple, Tuple rightTuple)
/*     */   {
/*  78 */     Comparable leftComp = (Comparable)leftTuple.get(this.leftFieldName);
/*  79 */     Comparable rightComp = (Comparable)rightTuple.get(this.rightFieldName);
/*     */     
/*  81 */     if (leftComp == rightComp) return true;
/*  82 */     if ((null == leftComp) || (null == rightComp)) { return false;
/*     */     }
/*  84 */     return 0 == leftComp.compareTo(rightComp);
/*     */   }
/*     */   
/*     */   public String getLeftFieldName() {
/*  88 */     return this.leftFieldName;
/*     */   }
/*     */   
/*     */   public String getRightFieldName() {
/*  92 */     return this.rightFieldName;
/*     */   }
/*     */   
/*     */   public boolean isDerivedFrom(StreamEqualitor base)
/*     */   {
/*  97 */     if (null == base) return false;
/*  98 */     if ((base instanceof FieldEqualitor)) {
/*  99 */       FieldEqualitor baseEq = (FieldEqualitor)base;
/* 100 */       return (this.leftFieldName.equals(baseEq.leftFieldName)) && (this.rightFieldName.equals(baseEq.rightFieldName));
/*     */     }
/* 102 */     if ((base instanceof MultipleFieldEqualitor))
/*     */     {
/* 104 */       MultipleFieldEqualitor baseEqs = (MultipleFieldEqualitor)base;
/* 105 */       if (baseEqs.getEqs().length > 0) {
/* 106 */         return isDerivedFrom(baseEqs.getEqs()[0]);
/*     */       }
/*     */     }
/*     */     
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDerivedFrom(StreamComparator base)
/*     */   {
/* 115 */     if (null == base) return false;
/* 116 */     if ((base instanceof FieldComparator)) {
/* 117 */       FieldComparator baseComp = (FieldComparator)base;
/* 118 */       return (this.leftFieldName.equals(baseComp.getLeftFieldName())) || (this.rightFieldName.equals(baseComp.getRightFieldName()));
/*     */     }
/* 120 */     if ((base instanceof MultipleFieldComparator))
/*     */     {
/* 122 */       MultipleFieldComparator baseComps = (MultipleFieldComparator)base;
/* 123 */       if (baseComps.getComps().length > 0) {
/* 124 */         return isDerivedFrom(baseComps.getComps()[0]);
/*     */       }
/*     */     }
/*     */     
/* 128 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\eq\FieldEqualitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */