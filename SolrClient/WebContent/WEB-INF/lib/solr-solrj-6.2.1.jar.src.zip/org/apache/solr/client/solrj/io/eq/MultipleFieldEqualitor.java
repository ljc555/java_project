/*     */ package org.apache.solr.client.solrj.io.eq;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.MultipleFieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleFieldEqualitor
/*     */   implements StreamEqualitor
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   private UUID equalitorNodeId = UUID.randomUUID();
/*     */   private StreamEqualitor[] eqs;
/*     */   
/*     */   public MultipleFieldEqualitor(StreamEqualitor... eqs)
/*     */   {
/*  45 */     this.eqs = eqs;
/*     */   }
/*     */   
/*     */   public StreamEqualitor[] getEqs() {
/*  49 */     return this.eqs;
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*     */   {
/*  54 */     StringBuilder sb = new StringBuilder();
/*  55 */     for (Equalitor<Tuple> eq : this.eqs) {
/*  56 */       if ((eq instanceof Expressible)) {
/*  57 */         if (sb.length() > 0) sb.append(",");
/*  58 */         sb.append(((Expressible)eq).toExpression(factory));
/*     */       }
/*     */       else {
/*  61 */         throw new IOException("This MultiEqualitor contains a non-expressible equalitor - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     
/*  65 */     return new StreamExpressionValue(sb.toString());
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/*  70 */     return 
/*     */     
/*     */ 
/*  73 */       new Explanation(this.equalitorNodeId.toString()).withExpressionType("equalitor").withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*     */   }
/*     */   
/*     */   public boolean isDerivedFrom(StreamEqualitor base)
/*     */   {
/*  78 */     if (null == base) return false;
/*  79 */     if ((base instanceof MultipleFieldEqualitor)) {
/*  80 */       MultipleFieldEqualitor baseEq = (MultipleFieldEqualitor)base;
/*     */       
/*  82 */       if (baseEq.eqs.length >= this.eqs.length) {
/*  83 */         for (int idx = 0; idx < this.eqs.length; idx++) {
/*  84 */           if (!this.eqs[idx].isDerivedFrom(baseEq.eqs[idx])) {
/*  85 */             return false;
/*     */           }
/*     */         }
/*  88 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  92 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDerivedFrom(StreamComparator base)
/*     */   {
/*  97 */     if (null == base) return false;
/*  98 */     if ((base instanceof StreamComparator)) {
/*  99 */       MultipleFieldComparator baseComps = (MultipleFieldComparator)base;
/*     */       
/* 101 */       if (baseComps.getComps().length >= this.eqs.length) {
/* 102 */         for (int idx = 0; idx < this.eqs.length; idx++) {
/* 103 */           if (!this.eqs[idx].isDerivedFrom(baseComps.getComps()[idx])) {
/* 104 */             return false;
/*     */           }
/*     */         }
/* 107 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 111 */     return false;
/*     */   }
/*     */   
/*     */   public boolean test(Tuple t1, Tuple t2)
/*     */   {
/* 116 */     for (Equalitor<Tuple> eq : this.eqs) {
/* 117 */       if (!eq.test(t1, t2)) {
/* 118 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 122 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\eq\MultipleFieldEqualitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */