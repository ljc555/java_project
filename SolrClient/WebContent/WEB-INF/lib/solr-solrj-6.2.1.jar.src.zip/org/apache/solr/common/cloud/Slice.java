/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.noggit.JSONUtil;
/*     */ import org.noggit.JSONWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Slice
/*     */   extends ZkNodeProps
/*     */   implements Iterable<Replica>
/*     */ {
/*     */   public static final String REPLICAS = "replicas";
/*     */   public static final String RANGE = "range";
/*     */   public static final String LEADER = "leader";
/*     */   public static final String PARENT = "parent";
/*     */   private final String name;
/*     */   private final DocRouter.Range range;
/*     */   private final Integer replicationFactor;
/*     */   private final Map<String, Replica> replicas;
/*     */   private final Replica leader;
/*     */   private final State state;
/*     */   private final String parent;
/*     */   private final Map<String, RoutingRule> routingRules;
/*     */   
/*     */   public static Map<String, Slice> loadAllFromMap(Map<String, Object> genericSlices)
/*     */   {
/*  37 */     if (genericSlices == null) return Collections.emptyMap();
/*  38 */     Map<String, Slice> result = new LinkedHashMap(genericSlices.size());
/*  39 */     for (Map.Entry<String, Object> entry : genericSlices.entrySet()) {
/*  40 */       String name = (String)entry.getKey();
/*  41 */       Object val = entry.getValue();
/*  42 */       if ((val instanceof Slice)) {
/*  43 */         result.put(name, (Slice)val);
/*  44 */       } else if ((val instanceof Map)) {
/*  45 */         result.put(name, new Slice(name, null, (Map)val));
/*     */       }
/*     */     }
/*  48 */     return result;
/*     */   }
/*     */   
/*     */   public Iterator<Replica> iterator()
/*     */   {
/*  53 */     return this.replicas.values().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static enum State
/*     */   {
/*  60 */     ACTIVE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     INACTIVE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */     CONSTRUCTION, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     RECOVERY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     RECOVERY_FAILED;
/*     */     
/*     */     private State() {}
/*     */     
/*  97 */     public String toString() { return super.toString().toLowerCase(Locale.ROOT); }
/*     */     
/*     */ 
/*     */     public static State getState(String stateStr)
/*     */     {
/* 102 */       return valueOf(stateStr.toUpperCase(Locale.ROOT));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Slice(String name, Map<String, Replica> replicas, Map<String, Object> props)
/*     */   {
/* 126 */     super(props == null ? new LinkedHashMap(2) : new LinkedHashMap(props));
/* 127 */     this.name = name;
/*     */     
/* 129 */     Object rangeObj = this.propMap.get("range");
/* 130 */     if (this.propMap.get("state") != null) {
/* 131 */       this.state = State.getState((String)this.propMap.get("state"));
/*     */     } else {
/* 133 */       this.state = State.ACTIVE;
/* 134 */       this.propMap.put("state", this.state.toString());
/*     */     }
/* 136 */     DocRouter.Range tmpRange = null;
/* 137 */     if ((rangeObj instanceof DocRouter.Range)) {
/* 138 */       tmpRange = (DocRouter.Range)rangeObj;
/* 139 */     } else if (rangeObj != null)
/*     */     {
/* 141 */       tmpRange = DocRouter.DEFAULT.fromString(rangeObj.toString());
/*     */     }
/* 143 */     this.range = tmpRange;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */     if ((this.propMap.containsKey("parent")) && (this.propMap.get("parent") != null)) {
/* 152 */       this.parent = ((String)this.propMap.get("parent"));
/*     */     } else {
/* 154 */       this.parent = null;
/*     */     }
/* 156 */     this.replicationFactor = null;
/*     */     
/*     */ 
/* 159 */     this.replicas = (replicas != null ? replicas : makeReplicas((Map)this.propMap.get("replicas")));
/* 160 */     this.propMap.put("replicas", this.replicas);
/*     */     
/* 162 */     Map<String, Object> rules = (Map)this.propMap.get("routingRules");
/* 163 */     if (rules != null) {
/* 164 */       this.routingRules = new HashMap();
/* 165 */       for (Map.Entry<String, Object> entry : rules.entrySet()) {
/* 166 */         Object o = entry.getValue();
/* 167 */         if ((o instanceof Map)) {
/* 168 */           Map map = (Map)o;
/* 169 */           RoutingRule rule = new RoutingRule((String)entry.getKey(), map);
/* 170 */           this.routingRules.put(entry.getKey(), rule);
/*     */         } else {
/* 172 */           this.routingRules.put(entry.getKey(), (RoutingRule)o);
/*     */         }
/*     */       }
/*     */     } else {
/* 176 */       this.routingRules = null;
/*     */     }
/*     */     
/* 179 */     this.leader = findLeader();
/*     */   }
/*     */   
/*     */   private Map<String, Replica> makeReplicas(Map<String, Object> genericReplicas)
/*     */   {
/* 184 */     if (genericReplicas == null) return new HashMap(1);
/* 185 */     Map<String, Replica> result = new LinkedHashMap(genericReplicas.size());
/* 186 */     for (Map.Entry<String, Object> entry : genericReplicas.entrySet()) {
/* 187 */       String name = (String)entry.getKey();
/* 188 */       Object val = entry.getValue();
/*     */       Replica r;
/* 190 */       Replica r; if ((val instanceof Replica)) {
/* 191 */         r = (Replica)val;
/*     */       } else {
/* 193 */         r = new Replica(name, (Map)val);
/*     */       }
/* 195 */       result.put(name, r);
/*     */     }
/* 197 */     return result;
/*     */   }
/*     */   
/*     */   private Replica findLeader() {
/* 201 */     for (Replica replica : this.replicas.values()) {
/* 202 */       if (replica.getStr("leader") != null) return replica;
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 211 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<Replica> getReplicas()
/*     */   {
/* 218 */     return this.replicas.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Replica> getReplicasMap()
/*     */   {
/* 225 */     return this.replicas;
/*     */   }
/*     */   
/*     */   public Map<String, Replica> getReplicasCopy() {
/* 229 */     return new LinkedHashMap(this.replicas);
/*     */   }
/*     */   
/*     */   public Replica getLeader() {
/* 233 */     return this.leader;
/*     */   }
/*     */   
/*     */   public Replica getReplica(String replicaName) {
/* 237 */     return (Replica)this.replicas.get(replicaName);
/*     */   }
/*     */   
/*     */   public DocRouter.Range getRange() {
/* 241 */     return this.range;
/*     */   }
/*     */   
/*     */   public State getState() {
/* 245 */     return this.state;
/*     */   }
/*     */   
/*     */   public String getParent() {
/* 249 */     return this.parent;
/*     */   }
/*     */   
/*     */   public Map<String, RoutingRule> getRoutingRules() {
/* 253 */     return this.routingRules;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 258 */     return this.name + ':' + JSONUtil.toJSON(this.propMap);
/*     */   }
/*     */   
/*     */   public void write(JSONWriter jsonWriter)
/*     */   {
/* 263 */     jsonWriter.write(this.propMap);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\Slice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */