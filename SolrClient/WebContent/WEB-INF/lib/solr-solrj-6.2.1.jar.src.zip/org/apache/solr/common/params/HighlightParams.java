package org.apache.solr.common.params;

public abstract interface HighlightParams
{
  public static final String HIGHLIGHT = "hl";
  public static final String Q = "hl.q";
  public static final String QPARSER = "hl.qparser";
  public static final String FIELDS = "hl.fl";
  public static final String SNIPPETS = "hl.snippets";
  public static final String FRAGSIZE = "hl.fragsize";
  public static final String INCREMENT = "hl.increment";
  public static final String MAX_CHARS = "hl.maxAnalyzedChars";
  public static final String FORMATTER = "hl.formatter";
  public static final String ENCODER = "hl.encoder";
  public static final String FRAGMENTER = "hl.fragmenter";
  public static final String PRESERVE_MULTI = "hl.preserveMulti";
  public static final String FRAG_LIST_BUILDER = "hl.fragListBuilder";
  public static final String FRAGMENTS_BUILDER = "hl.fragmentsBuilder";
  public static final String BOUNDARY_SCANNER = "hl.boundaryScanner";
  public static final String BS_MAX_SCAN = "hl.bs.maxScan";
  public static final String BS_CHARS = "hl.bs.chars";
  public static final String BS_TYPE = "hl.bs.type";
  public static final String BS_LANGUAGE = "hl.bs.language";
  public static final String BS_COUNTRY = "hl.bs.country";
  public static final String BS_VARIANT = "hl.bs.variant";
  public static final String FIELD_MATCH = "hl.requireFieldMatch";
  public static final String DEFAULT_SUMMARY = "hl.defaultSummary";
  public static final String ALTERNATE_FIELD = "hl.alternateField";
  public static final String ALTERNATE_FIELD_LENGTH = "hl.maxAlternateFieldLength";
  public static final String HIGHLIGHT_ALTERNATE = "hl.highlightAlternate";
  public static final String MAX_MULTIVALUED_TO_EXAMINE = "hl.maxMultiValuedToExamine";
  public static final String MAX_MULTIVALUED_TO_MATCH = "hl.maxMultiValuedToMatch";
  public static final String USE_PHRASE_HIGHLIGHTER = "hl.usePhraseHighlighter";
  public static final String HIGHLIGHT_MULTI_TERM = "hl.highlightMultiTerm";
  public static final String PAYLOADS = "hl.payloads";
  public static final String MERGE_CONTIGUOUS_FRAGMENTS = "hl.mergeContiguous";
  public static final String USE_FVH = "hl.useFastVectorHighlighter";
  public static final String TAG_PRE = "hl.tag.pre";
  public static final String TAG_POST = "hl.tag.post";
  public static final String TAG_ELLIPSIS = "hl.tag.ellipsis";
  public static final String PHRASE_LIMIT = "hl.phraseLimit";
  public static final String MULTI_VALUED_SEPARATOR = "hl.multiValuedSeparatorChar";
  public static final String SIMPLE = "simple";
  public static final String SIMPLE_PRE = "hl.simple.pre";
  public static final String SIMPLE_POST = "hl.simple.post";
  public static final String REGEX = "regex";
  public static final String SLOP = "hl.regex.slop";
  public static final String PATTERN = "hl.regex.pattern";
  public static final String MAX_RE_CHARS = "hl.regex.maxAnalyzedChars";
  public static final String SCORE = "score";
  public static final String SCORE_K1 = "hl.score.k1";
  public static final String SCORE_B = "hl.score.b";
  public static final String SCORE_PIVOT = "hl.score.pivot";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\HighlightParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */