package org.apache.solr.client.solrj.io.stream;

import java.sql.ResultSet;
import java.sql.SQLException;

abstract interface ResultSetValueSelector
{
  public abstract String getColumnName();
  
  public abstract Object selectValue(ResultSet paramResultSet)
    throws SQLException;
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\ResultSetValueSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */