/*    */ package org.apache.solr.client.solrj.io.graph;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.metrics.Metric;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Node
/*    */ {
/*    */   private String id;
/*    */   private List<Metric> metrics;
/*    */   private Set<String> ancestors;
/*    */   
/*    */   public Node(String id, boolean track)
/*    */   {
/* 31 */     this.id = id;
/* 32 */     if (track) {
/* 33 */       this.ancestors = new HashSet();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setMetrics(List<Metric> metrics) {
/* 38 */     this.metrics = metrics;
/*    */   }
/*    */   
/*    */   public void add(String ancestor, Tuple tuple) {
/* 42 */     if (this.ancestors != null) {
/* 43 */       this.ancestors.add(ancestor);
/*    */     }
/*    */     
/* 46 */     if (this.metrics != null) {
/* 47 */       for (Metric metric : this.metrics) {
/* 48 */         metric.update(tuple);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Tuple toTuple(String collection, String field, int level, Traversal traversal) {
/* 54 */     Map map = new HashMap();
/*    */     
/* 56 */     map.put("node", this.id);
/* 57 */     map.put("collection", collection);
/* 58 */     map.put("field", field);
/* 59 */     map.put("level", Integer.valueOf(level));
/*    */     
/* 61 */     boolean prependCollection = traversal.isMultiCollection();
/* 62 */     List<String> cols = traversal.getCollections();
/*    */     List<String> l;
/* 64 */     if (this.ancestors != null) {
/* 65 */       l = new ArrayList();
/* 66 */       for (String ancestor : this.ancestors) {
/* 67 */         String[] ancestorParts = ancestor.split("\\^");
/*    */         
/* 69 */         if (prependCollection)
/*    */         {
/* 71 */           int colIndex = Integer.parseInt(ancestorParts[0]);
/* 72 */           l.add((String)cols.get(colIndex) + "/" + ancestorParts[1]);
/*    */         }
/*    */         else {
/* 75 */           l.add(ancestorParts[1]);
/*    */         }
/*    */       }
/*    */       
/* 79 */       map.put("ancestors", l);
/*    */     }
/*    */     
/* 82 */     if (this.metrics != null) {
/* 83 */       for (Metric metric : this.metrics) {
/* 84 */         map.put(metric.getIdentifier(), metric.getValue());
/*    */       }
/*    */     }
/*    */     
/* 88 */     return new Tuple(map);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\graph\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */