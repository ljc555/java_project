/*    */ package org.apache.solr.client.solrj.io.stream;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodHandles.Lookup;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionStream
/*    */   extends TupleStream
/*    */ {
/*    */   private TupleStream stream;
/*    */   private Exception openException;
/* 39 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*    */   
/*    */   public ExceptionStream(TupleStream stream) {
/* 42 */     this.stream = stream;
/*    */   }
/*    */   
/*    */   public List<TupleStream> children() {
/* 46 */     return null;
/*    */   }
/*    */   
/*    */   public void open() {
/*    */     try {
/* 51 */       this.stream.open();
/*    */     } catch (Exception e) {
/* 53 */       this.openException = e;
/*    */     }
/*    */   }
/*    */   
/*    */   public Tuple read() {
/* 58 */     if (this.openException != null)
/*    */     {
/* 60 */       Map fields = new HashMap();
/* 61 */       fields.put("EXCEPTION", this.openException.getMessage());
/* 62 */       fields.put("EOF", Boolean.valueOf(true));
/* 63 */       SolrException.log(log, this.openException);
/* 64 */       return new Tuple(fields);
/*    */     }
/*    */     try
/*    */     {
/* 68 */       return this.stream.read();
/*    */     } catch (Exception e) {
/* 70 */       Map fields = new HashMap();
/* 71 */       fields.put("EXCEPTION", e.getMessage());
/* 72 */       fields.put("EOF", Boolean.valueOf(true));
/* 73 */       SolrException.log(log, e);
/* 74 */       return new Tuple(fields);
/*    */     }
/*    */   }
/*    */   
/*    */   public Explanation toExplanation(StreamFactory factory)
/*    */     throws IOException
/*    */   {
/* 81 */     return 
/*    */     
/*    */ 
/*    */ 
/* 85 */       new StreamExplanation(getStreamNodeId().toString()).withFunctionName("non-expressible").withImplementingClass(getClass().getName()).withExpressionType("stream-source").withExpression("non-expressible");
/*    */   }
/*    */   
/*    */   public StreamComparator getStreamSort() {
/* 89 */     return this.stream.getStreamSort();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 93 */     this.stream.close();
/*    */   }
/*    */   
/*    */   public void setStreamContext(StreamContext context) {
/* 97 */     this.stream.setStreamContext(context);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\ExceptionStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */