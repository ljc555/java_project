/*    */ package org.apache.solr.client.solrj.beans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindingException
/*    */   extends RuntimeException
/*    */ {
/*    */   public BindingException(String message)
/*    */   {
/* 22 */     super(message);
/*    */   }
/*    */   
/*    */   public BindingException(String message, Throwable cause) {
/* 26 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\beans\BindingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */