/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.util.Utils;
/*     */ import org.noggit.JSONUtil;
/*     */ import org.noggit.JSONWriter;
/*     */ import org.noggit.JSONWriter.Writable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZkNodeProps
/*     */   implements JSONWriter.Writable
/*     */ {
/*     */   protected final Map<String, Object> propMap;
/*     */   
/*     */   public ZkNodeProps(Map<String, Object> propMap)
/*     */   {
/*  39 */     this.propMap = propMap;
/*     */   }
/*     */   
/*     */ 
/*     */   public ZkNodeProps plus(String key, Object val)
/*     */   {
/*  45 */     return plus(Collections.singletonMap(key, val));
/*     */   }
/*     */   
/*     */   public ZkNodeProps plus(Map<String, Object> newVals) {
/*  49 */     LinkedHashMap<String, Object> copy = new LinkedHashMap(this.propMap);
/*  50 */     if ((newVals == null) || (newVals.isEmpty())) return new ZkNodeProps(copy);
/*  51 */     copy.putAll(newVals);
/*  52 */     return new ZkNodeProps(copy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZkNodeProps(String... keyVals)
/*     */   {
/*  61 */     this(Utils.makeMap((Object[])keyVals));
/*     */   }
/*     */   
/*     */   public static ZkNodeProps fromKeyVals(Object... keyVals) {
/*  65 */     return new ZkNodeProps(Utils.makeMap(keyVals));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> keySet()
/*     */   {
/*  73 */     return this.propMap.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getProperties()
/*     */   {
/*  80 */     return this.propMap;
/*     */   }
/*     */   
/*     */   public Map<String, Object> shallowCopy()
/*     */   {
/*  85 */     return new LinkedHashMap(this.propMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ZkNodeProps load(byte[] bytes)
/*     */   {
/*  92 */     Map<String, Object> props = (Map)Utils.fromJSON(bytes);
/*  93 */     return new ZkNodeProps(props);
/*     */   }
/*     */   
/*     */   public void write(JSONWriter jsonWriter)
/*     */   {
/*  98 */     jsonWriter.write(this.propMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStr(String key)
/*     */   {
/* 105 */     Object o = this.propMap.get(key);
/* 106 */     return o == null ? null : o.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer getInt(String key, Integer def)
/*     */   {
/* 113 */     Object o = this.propMap.get(key);
/* 114 */     return o == null ? def : Integer.valueOf(o.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStr(String key, String def)
/*     */   {
/* 121 */     Object o = this.propMap.get(key);
/* 122 */     return o == null ? def : o.toString();
/*     */   }
/*     */   
/*     */   public Object get(String key) {
/* 126 */     return this.propMap.get(key);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 131 */     return JSONUtil.toJSON(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(String key)
/*     */   {
/* 146 */     return this.propMap.containsKey(key);
/*     */   }
/*     */   
/*     */   public boolean getBool(String key, boolean b) {
/* 150 */     Object o = this.propMap.get(key);
/* 151 */     if (o == null) return b;
/* 152 */     return Boolean.parseBoolean(o.toString());
/*     */   }
/*     */   
/*     */   public boolean equals(Object that)
/*     */   {
/* 157 */     return ((that instanceof ZkNodeProps)) && (((ZkNodeProps)that).propMap.equals(this.propMap));
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkNodeProps.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */