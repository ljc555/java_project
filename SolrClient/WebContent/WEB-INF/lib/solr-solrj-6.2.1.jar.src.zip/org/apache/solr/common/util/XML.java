/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XML
/*     */ {
/*  34 */   private static final String[] chardata_escapes = { "#0;", "#1;", "#2;", "#3;", "#4;", "#5;", "#6;", "#7;", "#8;", null, null, "#11;", "#12;", null, "#14;", "#15;", "#16;", "#17;", "#18;", "#19;", "#20;", "#21;", "#22;", "#23;", "#24;", "#25;", "#26;", "#27;", "#28;", "#29;", "#30;", "#31;", null, null, null, null, null, null, "&amp;", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "&lt;", null, "&gt;" };
/*     */   
/*     */ 
/*  37 */   private static final String[] attribute_escapes = { "#0;", "#1;", "#2;", "#3;", "#4;", "#5;", "#6;", "#7;", "#8;", null, null, "#11;", "#12;", null, "#14;", "#15;", "#16;", "#17;", "#18;", "#19;", "#20;", "#21;", "#22;", "#23;", "#24;", "#25;", "#26;", "#27;", "#28;", "#29;", "#30;", "#31;", null, null, "&quot;", null, null, null, "&amp;", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "&lt;" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeCharData(String str, Writer out)
/*     */     throws IOException
/*     */   {
/*  76 */     escape(str, out, chardata_escapes);
/*     */   }
/*     */   
/*     */   public static void escapeAttributeValue(String str, Writer out) throws IOException {
/*  80 */     escape(str, out, attribute_escapes);
/*     */   }
/*     */   
/*     */   public static void escapeAttributeValue(char[] chars, int start, int length, Writer out) throws IOException {
/*  84 */     escape(chars, start, length, out, attribute_escapes);
/*     */   }
/*     */   
/*     */   public static final void writeXML(Writer out, String tag, String val) throws IOException
/*     */   {
/*  89 */     out.write(60);
/*  90 */     out.write(tag);
/*  91 */     if (val == null) {
/*  92 */       out.write(47);
/*  93 */       out.write(62);
/*     */     } else {
/*  95 */       out.write(62);
/*  96 */       escapeCharData(val, out);
/*  97 */       out.write(60);
/*  98 */       out.write(47);
/*  99 */       out.write(tag);
/* 100 */       out.write(62);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final void writeUnescapedXML(Writer out, String tag, String val, Object... attrs) throws IOException
/*     */   {
/* 106 */     out.write(60);
/* 107 */     out.write(tag);
/* 108 */     for (int i = 0; i < attrs.length; i++) {
/* 109 */       out.write(32);
/* 110 */       out.write(attrs[(i++)].toString());
/* 111 */       out.write(61);
/* 112 */       out.write(34);
/* 113 */       out.write(attrs[i].toString());
/* 114 */       out.write(34);
/*     */     }
/* 116 */     if (val == null) {
/* 117 */       out.write(47);
/* 118 */       out.write(62);
/*     */     } else {
/* 120 */       out.write(62);
/* 121 */       out.write(val);
/* 122 */       out.write(60);
/* 123 */       out.write(47);
/* 124 */       out.write(tag);
/* 125 */       out.write(62);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final void writeXML(Writer out, String tag, String val, Object... attrs) throws IOException
/*     */   {
/* 131 */     out.write(60);
/* 132 */     out.write(tag);
/* 133 */     for (int i = 0; i < attrs.length; i++) {
/* 134 */       out.write(32);
/* 135 */       out.write(attrs[(i++)].toString());
/* 136 */       out.write(61);
/* 137 */       out.write(34);
/* 138 */       escapeAttributeValue(attrs[i].toString(), out);
/* 139 */       out.write(34);
/*     */     }
/* 141 */     if (val == null) {
/* 142 */       out.write(47);
/* 143 */       out.write(62);
/*     */     } else {
/* 145 */       out.write(62);
/* 146 */       escapeCharData(val, out);
/* 147 */       out.write(60);
/* 148 */       out.write(47);
/* 149 */       out.write(tag);
/* 150 */       out.write(62);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void writeXML(Writer out, String tag, String val, Map<String, String> attrs) throws IOException
/*     */   {
/* 156 */     out.write(60);
/* 157 */     out.write(tag);
/* 158 */     for (Map.Entry<String, String> entry : attrs.entrySet()) {
/* 159 */       out.write(32);
/* 160 */       out.write((String)entry.getKey());
/* 161 */       out.write(61);
/* 162 */       out.write(34);
/* 163 */       escapeAttributeValue((String)entry.getValue(), out);
/* 164 */       out.write(34);
/*     */     }
/* 166 */     if (val == null) {
/* 167 */       out.write(47);
/* 168 */       out.write(62);
/*     */     } else {
/* 170 */       out.write(62);
/* 171 */       escapeCharData(val, out);
/* 172 */       out.write(60);
/* 173 */       out.write(47);
/* 174 */       out.write(tag);
/* 175 */       out.write(62);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void escape(char[] chars, int offset, int length, Writer out, String[] escapes) throws IOException {
/* 180 */     for (int i = offset; i < length; i++) {
/* 181 */       char ch = chars[i];
/* 182 */       if (ch < escapes.length) {
/* 183 */         String replacement = escapes[ch];
/* 184 */         if (replacement != null) {
/* 185 */           out.write(replacement);
/* 186 */           continue;
/*     */         }
/*     */       }
/* 189 */       out.write(ch);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void escape(String str, Writer out, String[] escapes) throws IOException {
/* 194 */     for (int i = 0; i < str.length(); i++) {
/* 195 */       char ch = str.charAt(i);
/* 196 */       if (ch < escapes.length) {
/* 197 */         String replacement = escapes[ch];
/* 198 */         if (replacement != null) {
/* 199 */           out.write(replacement);
/* 200 */           continue;
/*     */         }
/*     */       }
/* 203 */       out.write(ch);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\XML.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */