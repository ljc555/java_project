/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import org.apache.solr.client.solrj.SolrResponse;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSolrResponse
/*    */   extends SolrResponse
/*    */ {
/*    */   public long elapsedTime;
/*    */   public NamedList<Object> nl;
/*    */   
/*    */   public long getElapsedTime()
/*    */   {
/* 30 */     return this.elapsedTime;
/*    */   }
/*    */   
/*    */   public NamedList<Object> getResponse()
/*    */   {
/* 35 */     return this.nl;
/*    */   }
/*    */   
/*    */   public void setResponse(NamedList<Object> rsp)
/*    */   {
/* 40 */     this.nl = rsp;
/*    */   }
/*    */   
/*    */   public void setElapsedTime(long elapsedTime)
/*    */   {
/* 45 */     this.elapsedTime = elapsedTime;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\SimpleSolrResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */