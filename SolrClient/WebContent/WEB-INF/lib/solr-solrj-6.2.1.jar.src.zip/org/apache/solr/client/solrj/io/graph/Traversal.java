/*    */ package org.apache.solr.client.solrj.io.graph;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Traversal
/*    */ {
/* 25 */   private List<Map<String, Node>> graph = new ArrayList();
/* 26 */   private List<String> fields = new ArrayList();
/* 27 */   private List<String> collections = new ArrayList();
/* 28 */   private Set<Scatter> scatter = new HashSet();
/* 29 */   private Set<String> collectionSet = new HashSet();
/*    */   private boolean trackTraversal;
/*    */   private int depth;
/*    */   
/*    */   public void addLevel(Map<String, Node> level, String collection, String field) {
/* 34 */     this.graph.add(level);
/* 35 */     this.collections.add(collection);
/* 36 */     this.collectionSet.add(collection);
/* 37 */     this.fields.add(field);
/* 38 */     this.depth += 1;
/*    */   }
/*    */   
/*    */   public int getDepth() {
/* 42 */     return this.depth;
/*    */   }
/*    */   
/*    */   public boolean getTrackTraversal() {
/* 46 */     return this.trackTraversal;
/*    */   }
/*    */   
/*    */   public boolean visited(String nodeId, String ancestorId, Tuple tuple) {
/* 50 */     for (Map<String, Node> level : this.graph) {
/* 51 */       Node node = (Node)level.get(nodeId);
/* 52 */       if (node != null) {
/* 53 */         node.add(this.depth + "^" + ancestorId, tuple);
/* 54 */         return true;
/*    */       }
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isMultiCollection() {
/* 61 */     return this.collectionSet.size() > 1;
/*    */   }
/*    */   
/*    */   public List<Map<String, Node>> getGraph() {
/* 65 */     return this.graph;
/*    */   }
/*    */   
/*    */   public void setScatter(Set<Scatter> scatter) {
/* 69 */     this.scatter = scatter;
/*    */   }
/*    */   
/*    */   public Set<Scatter> getScatter() {
/* 73 */     return this.scatter;
/*    */   }
/*    */   
/*    */   public void setTrackTraversal(boolean trackTraversal) {
/* 77 */     this.trackTraversal = trackTraversal;
/*    */   }
/*    */   
/*    */   public List<String> getCollections() {
/* 81 */     return this.collections;
/*    */   }
/*    */   
/*    */   public List<String> getFields() {
/* 85 */     return this.fields;
/*    */   }
/*    */   
/*    */   public static enum Scatter {
/* 89 */     BRANCHES, 
/* 90 */     LEAVES;
/*    */     
/*    */     private Scatter() {} }
/*    */   
/* 94 */   public Iterator<Tuple> iterator() { return new TraversalIterator(this, this.scatter); }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\graph\Traversal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */