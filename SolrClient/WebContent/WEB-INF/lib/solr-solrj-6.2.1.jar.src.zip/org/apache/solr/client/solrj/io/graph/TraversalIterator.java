/*     */ package org.apache.solr.client.solrj.io.graph;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TraversalIterator
/*     */   implements Iterator
/*     */ {
/*     */   private List<Map<String, Node>> graph;
/*     */   private List<String> collections;
/*     */   private List<String> fields;
/*     */   private Iterator<Iterator<Node>> graphIterator;
/*     */   private Iterator<Node> levelIterator;
/*     */   private Iterator<String> fieldIterator;
/*     */   private Iterator<String> collectionIterator;
/*     */   private Iterator<Integer> levelNumIterator;
/*     */   private String outField;
/*     */   private String outCollection;
/*     */   private int outLevel;
/*     */   private Traversal traversal;
/*     */   
/*     */   public TraversalIterator(Traversal traversal, Set<Traversal.Scatter> scatter)
/*     */   {
/*  47 */     this.traversal = traversal;
/*  48 */     this.graph = traversal.getGraph();
/*  49 */     this.collections = traversal.getCollections();
/*  50 */     this.fields = traversal.getFields();
/*     */     
/*  52 */     List<String> outCollections = new ArrayList();
/*  53 */     List<String> outFields = new ArrayList();
/*  54 */     List<Integer> levelNums = new ArrayList();
/*  55 */     List<Iterator<Node>> levelIterators = new ArrayList();
/*     */     
/*  57 */     if ((scatter.contains(Traversal.Scatter.BRANCHES)) && 
/*  58 */       (this.graph.size() > 1)) {
/*  59 */       for (int i = 0; i < this.graph.size() - 1; i++) {
/*  60 */         Map<String, Node> graphLevel = (Map)this.graph.get(i);
/*  61 */         String collection = (String)this.collections.get(i);
/*  62 */         String field = (String)this.fields.get(i);
/*  63 */         outCollections.add(collection);
/*  64 */         outFields.add(field);
/*  65 */         levelNums.add(Integer.valueOf(i));
/*  66 */         levelIterators.add(graphLevel.values().iterator());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  71 */     if (scatter.contains(Traversal.Scatter.LEAVES)) {
/*  72 */       int leavesLevel = this.graph.size() > 1 ? this.graph.size() - 1 : 0;
/*  73 */       Map<String, Node> graphLevel = (Map)this.graph.get(leavesLevel);
/*  74 */       String collection = (String)this.collections.get(leavesLevel);
/*  75 */       String field = (String)this.fields.get(leavesLevel);
/*  76 */       levelNums.add(Integer.valueOf(leavesLevel));
/*  77 */       outCollections.add(collection);
/*  78 */       outFields.add(field);
/*  79 */       levelIterators.add(graphLevel.values().iterator());
/*     */     }
/*     */     
/*  82 */     this.graphIterator = levelIterators.iterator();
/*  83 */     this.levelIterator = ((Iterator)this.graphIterator.next());
/*     */     
/*  85 */     this.fieldIterator = outFields.iterator();
/*  86 */     this.collectionIterator = outCollections.iterator();
/*  87 */     this.levelNumIterator = levelNums.iterator();
/*     */     
/*  89 */     this.outField = ((String)this.fieldIterator.next());
/*  90 */     this.outCollection = ((String)this.collectionIterator.next());
/*  91 */     this.outLevel = ((Integer)this.levelNumIterator.next()).intValue();
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */   {
/*  96 */     if (this.levelIterator.hasNext()) {
/*  97 */       return true;
/*     */     }
/*  99 */     if (this.graphIterator.hasNext()) {
/* 100 */       this.levelIterator = ((Iterator)this.graphIterator.next());
/* 101 */       this.outField = ((String)this.fieldIterator.next());
/* 102 */       this.outCollection = ((String)this.collectionIterator.next());
/* 103 */       this.outLevel = ((Integer)this.levelNumIterator.next()).intValue();
/* 104 */       return hasNext();
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Tuple next()
/*     */   {
/* 113 */     if (hasNext()) {
/* 114 */       Node node = (Node)this.levelIterator.next();
/* 115 */       return node.toTuple(this.outCollection, this.outField, this.outLevel, this.traversal);
/*     */     }
/* 117 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\graph\TraversalIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */