package org.apache.solr.common.cloud;

import java.util.Set;

public abstract interface CollectionStatePredicate
{
  public abstract boolean matches(Set<String> paramSet, DocCollection paramDocCollection);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\CollectionStatePredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */