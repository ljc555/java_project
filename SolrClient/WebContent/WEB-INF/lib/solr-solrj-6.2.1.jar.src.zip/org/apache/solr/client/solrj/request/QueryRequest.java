/*    */ package org.apache.solr.client.solrj.request;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.apache.solr.client.solrj.SolrClient;
/*    */ import org.apache.solr.client.solrj.SolrRequest;
/*    */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*    */ import org.apache.solr.client.solrj.response.QueryResponse;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ import org.apache.solr.common.util.ContentStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryRequest
/*    */   extends SolrRequest<QueryResponse>
/*    */ {
/*    */   private SolrParams query;
/*    */   
/*    */   public QueryRequest()
/*    */   {
/* 39 */     super(SolrRequest.METHOD.GET, null);
/*    */   }
/*    */   
/*    */   public QueryRequest(SolrParams q)
/*    */   {
/* 44 */     super(SolrRequest.METHOD.GET, null);
/* 45 */     this.query = q;
/*    */   }
/*    */   
/*    */   public QueryRequest(SolrParams q, SolrRequest.METHOD method)
/*    */   {
/* 50 */     super(method, null);
/* 51 */     this.query = q;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getPath()
/*    */   {
/* 59 */     String qt = this.query == null ? null : this.query.get("qt");
/* 60 */     if (qt == null) {
/* 61 */       qt = super.getPath();
/*    */     }
/* 63 */     if ((qt != null) && (qt.startsWith("/"))) {
/* 64 */       return qt;
/*    */     }
/* 66 */     return "/select";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Collection<ContentStream> getContentStreams()
/*    */   {
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   protected QueryResponse createResponse(SolrClient client)
/*    */   {
/* 79 */     return new QueryResponse(client);
/*    */   }
/*    */   
/*    */   public SolrParams getParams()
/*    */   {
/* 84 */     return this.query;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\QueryRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */