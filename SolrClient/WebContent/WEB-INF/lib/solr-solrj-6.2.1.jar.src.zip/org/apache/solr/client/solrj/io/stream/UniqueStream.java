/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.ops.DistinctOperation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UniqueStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private TupleStream originalStream;
/*     */   private StreamEqualitor originalEqualitor;
/*     */   private ReducerStream reducerStream;
/*     */   
/*     */   public UniqueStream(TupleStream stream, StreamEqualitor eq)
/*     */     throws IOException
/*     */   {
/*  55 */     init(stream, eq);
/*     */   }
/*     */   
/*     */   public UniqueStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  60 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  61 */     StreamExpressionNamedParameter overExpression = factory.getNamedOperand(expression, "over");
/*     */     
/*     */ 
/*  64 */     if (expression.getParameters().size() != streamExpressions.size() + 1) {
/*  65 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  68 */     if (1 != streamExpressions.size()) {
/*  69 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  72 */     if ((null == overExpression) || (!(overExpression.getParameter() instanceof StreamExpressionValue))) {
/*  73 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'over' parameter listing fields to unique over but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  76 */     init(factory.constructStream((StreamExpression)streamExpressions.get(0)), factory.constructEqualitor(((StreamExpressionValue)overExpression.getParameter()).getValue(), FieldEqualitor.class));
/*     */   }
/*     */   
/*     */   private void init(TupleStream stream, StreamEqualitor eq) throws IOException {
/*  80 */     this.originalStream = stream;
/*  81 */     this.originalEqualitor = eq;
/*     */     
/*  83 */     this.reducerStream = new ReducerStream(stream, eq, new DistinctOperation());
/*     */     
/*  85 */     if (!eq.isDerivedFrom(stream.getStreamSort())) {
/*  86 */       throw new IOException("Invalid UniqueStream - substream comparator (sort) must be a superset of this stream's equalitor.");
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/*  92 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/*  97 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*  99 */     if (includeStreams)
/*     */     {
/* 101 */       if ((this.originalStream instanceof Expressible)) {
/* 102 */         expression.addParameter(((Expressible)this.originalStream).toExpression(factory));
/*     */       }
/*     */       else {
/* 105 */         throw new IOException("This UniqueStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 109 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 113 */     if ((this.originalEqualitor instanceof Expressible)) {
/* 114 */       expression.addParameter(new StreamExpressionNamedParameter("over", this.originalEqualitor.toExpression(factory)));
/*     */     }
/*     */     else {
/* 117 */       throw new IOException("This UniqueStream contains a non-expressible equalitor - it cannot be converted to an expression");
/*     */     }
/*     */     
/* 120 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 126 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.originalStream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString()).withHelper(this.originalEqualitor.toExplanation(factory));
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 139 */     this.originalStream.setStreamContext(context);
/* 140 */     this.reducerStream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 144 */     List<TupleStream> l = new ArrayList();
/* 145 */     l.add(this.originalStream);
/* 146 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 150 */     this.reducerStream.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 155 */     this.reducerStream.close();
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/* 160 */     return this.reducerStream.read();
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 165 */     return this.reducerStream.getStreamSort();
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 169 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\UniqueStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */