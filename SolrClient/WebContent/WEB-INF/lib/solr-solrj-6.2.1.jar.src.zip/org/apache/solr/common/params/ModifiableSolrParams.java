/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifiableSolrParams
/*     */   extends SolrParams
/*     */ {
/*     */   private Map<String, String[]> vals;
/*     */   
/*     */   public ModifiableSolrParams()
/*     */   {
/*  39 */     this.vals = new LinkedHashMap();
/*     */   }
/*     */   
/*     */ 
/*     */   public ModifiableSolrParams(Map<String, String[]> v)
/*     */   {
/*  45 */     this.vals = v;
/*     */   }
/*     */   
/*     */ 
/*     */   public ModifiableSolrParams(SolrParams params)
/*     */   {
/*  51 */     this.vals = new LinkedHashMap();
/*  52 */     if (params != null) {
/*  53 */       add(params);
/*     */     }
/*     */   }
/*     */   
/*     */   public int size() {
/*  58 */     return this.vals == null ? 0 : this.vals.size();
/*     */   }
/*     */   
/*     */   public Map<String, String[]> getMap() {
/*  62 */     return this.vals;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModifiableSolrParams set(String name, String... val)
/*     */   {
/*  73 */     if ((val == null) || ((val.length == 1) && (val[0] == null))) {
/*  74 */       this.vals.remove(name);
/*     */     } else {
/*  76 */       this.vals.put(name, val);
/*     */     }
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public ModifiableSolrParams set(String name, int val) {
/*  82 */     set(name, new String[] { String.valueOf(val) });
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public ModifiableSolrParams set(String name, boolean val) {
/*  87 */     set(name, new String[] { String.valueOf(val) });
/*  88 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModifiableSolrParams add(String name, String... val)
/*     */   {
/* 100 */     String[] old = (String[])this.vals.put(name, val);
/* 101 */     if (old != null) {
/* 102 */       if ((val == null) || (val.length < 1)) {
/* 103 */         String[] both = new String[old.length + 1];
/* 104 */         System.arraycopy(old, 0, both, 0, old.length);
/* 105 */         both[old.length] = null;
/* 106 */         this.vals.put(name, both);
/*     */       }
/*     */       else {
/* 109 */         String[] both = new String[old.length + val.length];
/* 110 */         System.arraycopy(old, 0, both, 0, old.length);
/* 111 */         System.arraycopy(val, 0, both, old.length, val.length);
/* 112 */         this.vals.put(name, both);
/*     */       }
/*     */     }
/* 115 */     return this;
/*     */   }
/*     */   
/*     */   public void add(SolrParams params)
/*     */   {
/* 120 */     Iterator<String> names = params.getParameterNamesIterator();
/* 121 */     while (names.hasNext()) {
/* 122 */       String name = (String)names.next();
/* 123 */       set(name, params.getParams(name));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] remove(String name)
/*     */   {
/* 132 */     return (String[])this.vals.remove(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/* 138 */     this.vals.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean remove(String name, String value)
/*     */   {
/* 147 */     String[] tmp = (String[])this.vals.get(name);
/* 148 */     if (tmp == null) return false;
/* 149 */     for (int i = 0; i < tmp.length; i++) {
/* 150 */       if (tmp[i].equals(value)) {
/* 151 */         String[] tmp2 = new String[tmp.length - 1];
/* 152 */         if (tmp2.length == 0) {
/* 153 */           tmp2 = null;
/* 154 */           remove(name);
/*     */         } else {
/* 156 */           System.arraycopy(tmp, 0, tmp2, 0, i);
/* 157 */           System.arraycopy(tmp, i + 1, tmp2, i, tmp.length - i - 1);
/* 158 */           set(name, tmp2);
/*     */         }
/* 160 */         return true;
/*     */       }
/*     */     }
/* 163 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String param)
/*     */   {
/* 171 */     String[] v = (String[])this.vals.get(param);
/* 172 */     if ((v != null) && (v.length > 0)) {
/* 173 */       return v[0];
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */   
/*     */   public Iterator<String> getParameterNamesIterator()
/*     */   {
/* 180 */     return this.vals.keySet().iterator();
/*     */   }
/*     */   
/*     */   public Set<String> getParameterNames() {
/* 184 */     return this.vals.keySet();
/*     */   }
/*     */   
/*     */   public String[] getParams(String param)
/*     */   {
/* 189 */     return (String[])this.vals.get(param);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\ModifiableSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */