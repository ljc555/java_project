/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RequestStatusState
/*    */ {
/* 29 */   COMPLETED("completed"), 
/*    */   
/*    */ 
/* 32 */   FAILED("failed"), 
/*    */   
/*    */ 
/* 35 */   RUNNING("running"), 
/*    */   
/*    */ 
/* 38 */   SUBMITTED("submitted"), 
/*    */   
/*    */ 
/* 41 */   NOT_FOUND("notfound");
/*    */   
/*    */   private final String key;
/*    */   
/*    */   private RequestStatusState(String key) {
/* 46 */     this.key = key;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getKey()
/*    */   {
/* 54 */     return this.key;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static RequestStatusState fromKey(String key)
/*    */   {
/*    */     try
/*    */     {
/* 63 */       return valueOf(key.toUpperCase(Locale.ENGLISH));
/*    */     } catch (IllegalArgumentException e) {
/* 65 */       if (key.equalsIgnoreCase(NOT_FOUND.getKey())) {
/* 66 */         return NOT_FOUND;
/*    */       }
/* 68 */       throw e;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\RequestStatusState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */