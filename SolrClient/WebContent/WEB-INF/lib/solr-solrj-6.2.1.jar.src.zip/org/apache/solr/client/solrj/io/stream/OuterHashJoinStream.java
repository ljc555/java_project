/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OuterHashJoinStream
/*     */   extends HashJoinStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public OuterHashJoinStream(TupleStream fullStream, TupleStream hashStream, List<String> hashOn)
/*     */     throws IOException
/*     */   {
/*  45 */     super(fullStream, hashStream, hashOn);
/*     */   }
/*     */   
/*     */   public OuterHashJoinStream(StreamExpression expression, StreamFactory factory) throws IOException {
/*  49 */     super(expression, factory);
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/*  55 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/*  58 */     if (((this.hashStream instanceof Expressible)) && ((this.fullStream instanceof Expressible))) {
/*  59 */       expression.addParameter(((Expressible)this.fullStream).toExpression(factory));
/*  60 */       expression.addParameter(new StreamExpressionNamedParameter("hashed", ((Expressible)this.hashStream).toExpression(factory)));
/*     */     }
/*     */     else {
/*  63 */       throw new IOException("This OuterHashJoinStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */     }
/*     */     
/*     */ 
/*  67 */     StringBuilder sb = new StringBuilder();
/*  68 */     for (int idx = 0; idx < this.leftHashOn.size(); idx++) {
/*  69 */       if (sb.length() > 0) { sb.append(",");
/*     */       }
/*     */       
/*  72 */       String left = (String)this.leftHashOn.get(idx);
/*  73 */       String right = (String)this.rightHashOn.get(idx);
/*     */       
/*  75 */       if (left.equals(right)) {
/*  76 */         sb.append(left);
/*     */       }
/*     */       else {
/*  79 */         sb.append(left);
/*  80 */         sb.append("=");
/*  81 */         sb.append(right);
/*     */       }
/*     */     }
/*  84 */     expression.addParameter(new StreamExpressionNamedParameter("on", sb.toString()));
/*     */     
/*  86 */     return expression;
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*  91 */     if (null == this.workingFullTuple) {
/*  92 */       Tuple fullTuple = this.fullStream.read();
/*     */       
/*     */ 
/*  95 */       if (fullTuple.EOF) {
/*  96 */         return fullTuple;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 102 */       Integer fullHash = calculateHash(fullTuple, this.leftHashOn);
/* 103 */       if ((null == fullHash) || (!this.hashedTuples.containsKey(fullHash))) {
/* 104 */         return fullTuple.clone();
/*     */       }
/*     */       
/* 107 */       this.workingFullTuple = fullTuple;
/* 108 */       this.workingFullHash = fullHash;
/* 109 */       this.workngHashSetIdx = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 114 */     List<Tuple> matches = (List)this.hashedTuples.get(this.workingFullHash);
/* 115 */     Tuple returnTuple = this.workingFullTuple.clone();
/* 116 */     returnTuple.merge((Tuple)matches.get(this.workngHashSetIdx));
/*     */     
/*     */ 
/* 119 */     this.workngHashSetIdx += 1;
/*     */     
/* 121 */     if (this.workngHashSetIdx >= matches.size())
/*     */     {
/* 123 */       this.workingFullTuple = null;
/* 124 */       this.workingFullHash = null;
/* 125 */       this.workngHashSetIdx = 0;
/*     */     }
/*     */     
/* 128 */     return returnTuple;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\OuterHashJoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */