/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.MultipleFieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.MultipleFieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BiJoinStream
/*     */   extends JoinStream
/*     */   implements Expressible
/*     */ {
/*     */   protected PushBackStream leftStream;
/*     */   protected PushBackStream rightStream;
/*     */   protected StreamComparator iterationComparator;
/*     */   protected StreamComparator leftStreamComparator;
/*     */   protected StreamComparator rightStreamComparator;
/*     */   
/*     */   public BiJoinStream(TupleStream leftStream, TupleStream rightStream, StreamEqualitor eq)
/*     */     throws IOException
/*     */   {
/*  46 */     super(eq, leftStream, rightStream, new TupleStream[0]);
/*  47 */     init();
/*     */   }
/*     */   
/*     */   public BiJoinStream(StreamExpression expression, StreamFactory factory) throws IOException {
/*  51 */     super(expression, factory);
/*  52 */     init();
/*     */   }
/*     */   
/*     */   private void init()
/*     */     throws IOException
/*     */   {
/*  58 */     validateTupleOrder();
/*     */     
/*  60 */     this.leftStream = getStream(0);
/*  61 */     this.rightStream = getStream(1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  66 */     this.iterationComparator = createIterationComparator(this.eq, this.leftStream.getStreamSort());
/*  67 */     this.leftStreamComparator = createSideComparator(this.eq, this.leftStream.getStreamSort());
/*  68 */     this.rightStreamComparator = createSideComparator(this.eq, this.rightStream.getStreamSort());
/*     */   }
/*     */   
/*     */   protected void validateTupleOrder() throws IOException {
/*  72 */     if (!isValidTupleOrder()) {
/*  73 */       throw new IOException("Invalid JoinStream - all incoming stream comparators (sort) must be a superset of this stream's equalitor.");
/*     */     }
/*     */   }
/*     */   
/*     */   private StreamComparator createIterationComparator(StreamEqualitor eq, StreamComparator comp) throws IOException
/*     */   {
/*  79 */     if (((eq instanceof MultipleFieldEqualitor)) && ((comp instanceof MultipleFieldComparator)))
/*     */     {
/*  81 */       StreamComparator[] compoundComps = new StreamComparator[((MultipleFieldEqualitor)eq).getEqs().length];
/*  82 */       for (int idx = 0; idx < compoundComps.length; idx++) {
/*  83 */         StreamEqualitor sourceEqualitor = ((MultipleFieldEqualitor)eq).getEqs()[idx];
/*  84 */         StreamComparator sourceComparator = ((MultipleFieldComparator)comp).getComps()[idx];
/*     */         
/*  86 */         if (((sourceEqualitor instanceof FieldEqualitor)) && ((sourceComparator instanceof FieldComparator))) {
/*  87 */           FieldEqualitor fieldEqualitor = (FieldEqualitor)sourceEqualitor;
/*  88 */           FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/*  89 */           compoundComps[idx] = new FieldComparator(fieldEqualitor.getLeftFieldName(), fieldEqualitor
/*  90 */             .getRightFieldName(), fieldComparator.getOrder());
/*     */         } else {
/*  92 */           throw new IOException("Failed to create an iteration comparator");
/*     */         }
/*     */       }
/*  95 */       return new MultipleFieldComparator(compoundComps); }
/*  96 */     if ((comp instanceof MultipleFieldComparator)) {
/*  97 */       StreamEqualitor sourceEqualitor = eq;
/*  98 */       StreamComparator sourceComparator = ((MultipleFieldComparator)comp).getComps()[0];
/*     */       
/* 100 */       if (((sourceEqualitor instanceof FieldEqualitor)) && ((sourceComparator instanceof FieldComparator))) {
/* 101 */         FieldEqualitor fieldEqualitor = (FieldEqualitor)sourceEqualitor;
/* 102 */         FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/* 103 */         return new FieldComparator(fieldEqualitor.getLeftFieldName(), fieldEqualitor.getRightFieldName(), fieldComparator
/* 104 */           .getOrder());
/*     */       }
/* 106 */       throw new IOException("Failed to create an iteration comparator");
/*     */     }
/*     */     
/* 109 */     StreamEqualitor sourceEqualitor = eq;
/* 110 */     StreamComparator sourceComparator = comp;
/*     */     
/* 112 */     if (((sourceEqualitor instanceof FieldEqualitor)) && ((sourceComparator instanceof FieldComparator))) {
/* 113 */       FieldEqualitor fieldEqualitor = (FieldEqualitor)sourceEqualitor;
/* 114 */       FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/* 115 */       return new FieldComparator(fieldEqualitor.getLeftFieldName(), fieldEqualitor.getRightFieldName(), fieldComparator
/* 116 */         .getOrder());
/*     */     }
/* 118 */     throw new IOException("Failed to create an iteration comparator");
/*     */   }
/*     */   
/*     */   private StreamComparator createSideComparator(StreamEqualitor eq, StreamComparator comp)
/*     */     throws IOException
/*     */   {
/* 124 */     if (((eq instanceof MultipleFieldEqualitor)) && ((comp instanceof MultipleFieldComparator)))
/*     */     {
/* 126 */       StreamComparator[] compoundComps = new StreamComparator[((MultipleFieldEqualitor)eq).getEqs().length];
/* 127 */       for (int idx = 0; idx < compoundComps.length; idx++) {
/* 128 */         StreamComparator sourceComparator = ((MultipleFieldComparator)comp).getComps()[idx];
/*     */         
/* 130 */         if ((sourceComparator instanceof FieldComparator)) {
/* 131 */           FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/* 132 */           compoundComps[idx] = new FieldComparator(fieldComparator.getLeftFieldName(), fieldComparator
/* 133 */             .getRightFieldName(), fieldComparator.getOrder());
/*     */         } else {
/* 135 */           throw new IOException("Failed to create an side comparator");
/*     */         }
/*     */       }
/* 138 */       return new MultipleFieldComparator(compoundComps); }
/* 139 */     if ((comp instanceof MultipleFieldComparator)) {
/* 140 */       StreamComparator sourceComparator = ((MultipleFieldComparator)comp).getComps()[0];
/*     */       
/* 142 */       if ((sourceComparator instanceof FieldComparator)) {
/* 143 */         FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/* 144 */         return new FieldComparator(fieldComparator.getLeftFieldName(), fieldComparator.getRightFieldName(), fieldComparator
/* 145 */           .getOrder());
/*     */       }
/* 147 */       throw new IOException("Failed to create an side comparator");
/*     */     }
/*     */     
/* 150 */     StreamComparator sourceComparator = comp;
/*     */     
/* 152 */     if ((sourceComparator instanceof FieldComparator)) {
/* 153 */       FieldComparator fieldComparator = (FieldComparator)sourceComparator;
/* 154 */       return new FieldComparator(fieldComparator.getLeftFieldName(), fieldComparator.getRightFieldName(), fieldComparator
/* 155 */         .getOrder());
/*     */     }
/* 157 */     throw new IOException("Failed to create an side comparator");
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\BiJoinStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */