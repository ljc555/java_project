/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.DocumentAnalysisResponse;
/*     */ import org.apache.solr.client.solrj.util.ClientUtils;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentAnalysisRequest
/*     */   extends SolrRequest<DocumentAnalysisResponse>
/*     */ {
/*  42 */   private List<SolrInputDocument> documents = new ArrayList();
/*     */   private String query;
/*  44 */   private boolean showMatch = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest()
/*     */   {
/*  50 */     super(SolrRequest.METHOD.POST, "/analysis/document");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest(String uri)
/*     */   {
/*  59 */     super(SolrRequest.METHOD.POST, uri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */     throws IOException
/*     */   {
/*  67 */     return ClientUtils.toContentStreams(getXML(), "application/xml; charset=UTF-8");
/*     */   }
/*     */   
/*     */   protected DocumentAnalysisResponse createResponse(SolrClient client)
/*     */   {
/*  72 */     return new DocumentAnalysisResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModifiableSolrParams getParams()
/*     */   {
/*  80 */     ModifiableSolrParams params = new ModifiableSolrParams();
/*  81 */     if (this.query != null) {
/*  82 */       params.add("analysis.query", new String[] { this.query });
/*  83 */       params.add("analysis.showmatch", new String[] { String.valueOf(this.showMatch) });
/*     */     }
/*  85 */     return params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getXML()
/*     */     throws IOException
/*     */   {
/*  98 */     StringWriter writer = new StringWriter();
/*  99 */     writer.write("<docs>");
/* 100 */     for (SolrInputDocument document : this.documents) {
/* 101 */       ClientUtils.writeXML(document, writer);
/*     */     }
/* 103 */     writer.write("</docs>");
/* 104 */     writer.flush();
/*     */     
/* 106 */     String xml = writer.toString();
/* 107 */     return xml.length() > 0 ? xml : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest addDocument(SolrInputDocument doc)
/*     */   {
/* 121 */     this.documents.add(doc);
/* 122 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest addDocuments(Collection<SolrInputDocument> docs)
/*     */   {
/* 135 */     this.documents.addAll(docs);
/* 136 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest setQuery(String query)
/*     */   {
/* 147 */     this.query = query;
/* 148 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentAnalysisRequest setShowMatch(boolean showMatch)
/*     */   {
/* 160 */     this.showMatch = showMatch;
/* 161 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<SolrInputDocument> getDocuments()
/*     */   {
/* 172 */     return this.documents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQuery()
/*     */   {
/* 184 */     return this.query;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowMatch()
/*     */   {
/* 195 */     return this.showMatch;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\DocumentAnalysisRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */