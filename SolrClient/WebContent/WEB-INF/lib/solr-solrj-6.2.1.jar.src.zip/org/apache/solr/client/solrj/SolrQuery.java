/*      */ package org.apache.solr.client.solrj;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.time.Instant;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.solr.common.params.ModifiableSolrParams;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SolrQuery
/*      */   extends ModifiableSolrParams
/*      */ {
/*      */   public static final String DOCID = "_docid_";
/*      */   private List<SortClause> sortClauses;
/*      */   public SolrQuery() {}
/*      */   
/*      */   public static enum ORDER
/*      */   {
/*   45 */     desc,  asc;
/*      */     private ORDER() {}
/*   47 */     public ORDER reverse() { return this == asc ? desc : asc; }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery(String q)
/*      */   {
/*   63 */     this();
/*   64 */     set("q", new String[] { q });
/*      */   }
/*      */   
/*      */   public SolrQuery(String k, String v, String... params) {
/*   68 */     assert (params.length % 2 == 0);
/*   69 */     set(k, new String[] { v });
/*   70 */     for (int i = 0; i < params.length; i += 2) {
/*   71 */       set(params[i], new String[] { params[(i + 1)] });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setTerms(boolean b)
/*      */   {
/*   81 */     if (b) {
/*   82 */       set("terms", true);
/*      */     } else {
/*   84 */       remove("terms");
/*   85 */       remove("terms.fl");
/*   86 */       remove("terms.lower");
/*   87 */       remove("terms.upper");
/*   88 */       remove("terms.upper.incl");
/*   89 */       remove("terms.lower.incl");
/*   90 */       remove("terms.limit");
/*   91 */       remove("terms.prefix");
/*   92 */       remove("terms.mincount");
/*   93 */       remove("terms.maxcount");
/*   94 */       remove("terms.raw");
/*   95 */       remove("terms.sort");
/*   96 */       remove("terms.regex");
/*   97 */       remove("terms.regex.flag");
/*      */     }
/*   99 */     return this;
/*      */   }
/*      */   
/*      */   public boolean getTerms() {
/*  103 */     return getBool("terms", false);
/*      */   }
/*      */   
/*      */   public SolrQuery addTermsField(String field) {
/*  107 */     add("terms.fl", new String[] { field });
/*  108 */     return this;
/*      */   }
/*      */   
/*      */   public String[] getTermsFields() {
/*  112 */     return getParams("terms.fl");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsLower(String lower) {
/*  116 */     set("terms.lower", new String[] { lower });
/*  117 */     return this;
/*      */   }
/*      */   
/*      */   public String getTermsLower() {
/*  121 */     return get("terms.lower", "");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsUpper(String upper) {
/*  125 */     set("terms.upper", new String[] { upper });
/*  126 */     return this;
/*      */   }
/*      */   
/*      */   public String getTermsUpper() {
/*  130 */     return get("terms.upper", "");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsUpperInclusive(boolean b) {
/*  134 */     set("terms.upper.incl", b);
/*  135 */     return this;
/*      */   }
/*      */   
/*      */   public boolean getTermsUpperInclusive() {
/*  139 */     return getBool("terms.upper.incl", false);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsLowerInclusive(boolean b) {
/*  143 */     set("terms.lower.incl", b);
/*  144 */     return this;
/*      */   }
/*      */   
/*      */   public boolean getTermsLowerInclusive() {
/*  148 */     return getBool("terms.lower.incl", true);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsLimit(int limit) {
/*  152 */     set("terms.limit", limit);
/*  153 */     return this;
/*      */   }
/*      */   
/*      */   public int getTermsLimit() {
/*  157 */     return getInt("terms.limit", 10);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsMinCount(int cnt) {
/*  161 */     set("terms.mincount", cnt);
/*  162 */     return this;
/*      */   }
/*      */   
/*      */   public int getTermsMinCount() {
/*  166 */     return getInt("terms.mincount", 1);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsMaxCount(int cnt) {
/*  170 */     set("terms.maxcount", cnt);
/*  171 */     return this;
/*      */   }
/*      */   
/*      */   public int getTermsMaxCount() {
/*  175 */     return getInt("terms.maxcount", -1);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsPrefix(String prefix) {
/*  179 */     set("terms.prefix", new String[] { prefix });
/*  180 */     return this;
/*      */   }
/*      */   
/*      */   public String getTermsPrefix() {
/*  184 */     return get("terms.prefix", "");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsRaw(boolean b) {
/*  188 */     set("terms.raw", b);
/*  189 */     return this;
/*      */   }
/*      */   
/*      */   public boolean getTermsRaw() {
/*  193 */     return getBool("terms.raw", false);
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsSortString(String type) {
/*  197 */     set("terms.sort", new String[] { type });
/*  198 */     return this;
/*      */   }
/*      */   
/*      */   public String getTermsSortString() {
/*  202 */     return get("terms.sort", "count");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsRegex(String regex) {
/*  206 */     set("terms.regex", new String[] { regex });
/*  207 */     return this;
/*      */   }
/*      */   
/*      */   public String getTermsRegex() {
/*  211 */     return get("terms.regex");
/*      */   }
/*      */   
/*      */   public SolrQuery setTermsRegexFlag(String flag) {
/*  215 */     add("terms.regex.flag", new String[] { flag });
/*  216 */     return this;
/*      */   }
/*      */   
/*      */   public String[] getTermsRegexFlags() {
/*  220 */     return getParams("terms.regex.flag");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addFacetField(String... fields)
/*      */   {
/*  229 */     add("facet.field", fields);
/*  230 */     set("facet", true);
/*  231 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addFacetPivotField(String... fields)
/*      */   {
/*  242 */     add("facet.pivot", fields);
/*  243 */     set("facet", true);
/*  244 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addNumericRangeFacet(String field, Number start, Number end, Number gap)
/*      */   {
/*  257 */     add("facet.range", new String[] { field });
/*  258 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.start" }), new String[] { start.toString() });
/*  259 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.end" }), new String[] { end.toString() });
/*  260 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.gap" }), new String[] { gap.toString() });
/*  261 */     set("facet", true);
/*  262 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addDateRangeFacet(String field, Date start, Date end, String gap)
/*      */   {
/*  275 */     add("facet.range", new String[] { field });
/*  276 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.start" }), new String[] { start.toInstant().toString() });
/*  277 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.end" }), new String[] { end.toInstant().toString() });
/*  278 */     add(String.format(Locale.ROOT, "f.%s.%s", new Object[] { field, "facet.range.gap" }), new String[] { gap });
/*  279 */     set("facet", true);
/*  280 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addIntervalFacets(String field, String[] intervals)
/*      */   {
/*  299 */     if (intervals == null) {
/*  300 */       throw new IllegalArgumentException("Can't add null intervals");
/*      */     }
/*  302 */     if (field == null) {
/*  303 */       throw new IllegalArgumentException("Field can't be null");
/*      */     }
/*  305 */     set("facet", true);
/*  306 */     add("facet.interval", new String[] { field });
/*  307 */     for (String interval : intervals) {
/*  308 */       add(String.format(Locale.ROOT, "f.%s.facet.interval.set", new Object[] { field }), new String[] { interval });
/*      */     }
/*  310 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] removeIntervalFacets(String field)
/*      */   {
/*  320 */     while (remove("facet.interval", field)) {}
/*  321 */     return remove(String.format(Locale.ROOT, "f.%s.facet.interval.set", new Object[] { field }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getFacetFields()
/*      */   {
/*  329 */     return getParams("facet.field");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeFacetField(String name)
/*      */   {
/*  340 */     boolean b = remove("facet.field", name);
/*  341 */     if ((get("facet.field") == null) && (get("facet.query") == null)) {
/*  342 */       setFacet(false);
/*      */     }
/*  344 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setFacet(boolean b)
/*      */   {
/*  353 */     if (b) {
/*  354 */       set("facet", true);
/*      */     } else {
/*  356 */       remove("facet");
/*  357 */       remove("facet.mincount");
/*  358 */       remove("facet.field");
/*  359 */       remove("facet.limit");
/*  360 */       remove("facet.missing");
/*  361 */       remove("facet.offset");
/*  362 */       remove("facet.prefix");
/*  363 */       remove("facet.query");
/*  364 */       remove("facet.sort");
/*  365 */       remove("facet.zeros");
/*  366 */       remove("facet.prefix");
/*  367 */       remove("facet.interval");
/*      */     }
/*  369 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery setFacetPrefix(String prefix)
/*      */   {
/*  374 */     set("facet.prefix", new String[] { prefix });
/*  375 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery setFacetPrefix(String field, String prefix)
/*      */   {
/*  380 */     set("f." + field + "." + "facet.prefix", new String[] { prefix });
/*  381 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addFacetQuery(String f)
/*      */   {
/*  389 */     add("facet.query", new String[] { f });
/*  390 */     set("facet", true);
/*  391 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getFacetQuery()
/*      */   {
/*  399 */     return getParams("facet.query");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeFacetQuery(String q)
/*      */   {
/*  408 */     boolean b = remove("facet.query", q);
/*  409 */     if ((get("facet.field") == null) && (get("facet.query") == null)) {
/*  410 */       setFacet(false);
/*      */     }
/*  412 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setFacetLimit(int lim)
/*      */   {
/*  420 */     set("facet.limit", lim);
/*  421 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFacetLimit()
/*      */   {
/*  429 */     return getInt("facet.limit", 25);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setFacetMinCount(int cnt)
/*      */   {
/*  437 */     set("facet.mincount", cnt);
/*  438 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFacetMinCount()
/*      */   {
/*  446 */     return getInt("facet.mincount", 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setFacetMissing(Boolean v)
/*      */   {
/*  456 */     set("facet.missing", v.booleanValue());
/*  457 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFacetSortString()
/*      */   {
/*  465 */     return get("facet.sort", "count");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setFacetSort(String sort)
/*      */   {
/*  475 */     set("facet.sort", new String[] { sort });
/*  476 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addHighlightField(String f)
/*      */   {
/*  484 */     add("hl.fl", new String[] { f });
/*  485 */     set("hl", true);
/*  486 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeHighlightField(String f)
/*      */   {
/*  495 */     boolean b = remove("hl.fl", f);
/*  496 */     if (get("hl.fl") == null) {
/*  497 */       setHighlight(false);
/*      */     }
/*  499 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getHighlightFields()
/*      */   {
/*  507 */     return getParams("hl.fl");
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlightSnippets(int num) {
/*  511 */     set("hl.snippets", num);
/*  512 */     return this;
/*      */   }
/*      */   
/*      */   public int getHighlightSnippets() {
/*  516 */     return getInt("hl.snippets", 1);
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlightFragsize(int num) {
/*  520 */     set("hl.fragsize", num);
/*  521 */     return this;
/*      */   }
/*      */   
/*      */   public int getHighlightFragsize() {
/*  525 */     return getInt("hl.fragsize", 100);
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlightRequireFieldMatch(boolean flag) {
/*  529 */     set("hl.requireFieldMatch", flag);
/*  530 */     return this;
/*      */   }
/*      */   
/*      */   public boolean getHighlightRequireFieldMatch() {
/*  534 */     return getBool("hl.requireFieldMatch", false);
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlightSimplePre(String f) {
/*  538 */     set("hl.simple.pre", new String[] { f });
/*  539 */     return this;
/*      */   }
/*      */   
/*      */   public String getHighlightSimplePre() {
/*  543 */     return get("hl.simple.pre", "");
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlightSimplePost(String f) {
/*  547 */     set("hl.simple.post", new String[] { f });
/*  548 */     return this;
/*      */   }
/*      */   
/*      */   public String getHighlightSimplePost() {
/*  552 */     return get("hl.simple.post", "");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSortField()
/*      */   {
/*  565 */     return get("sort");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery clearSorts()
/*      */   {
/*  575 */     this.sortClauses = null;
/*  576 */     serializeSorts();
/*  577 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setSorts(List<SortClause> value)
/*      */   {
/*  587 */     this.sortClauses = new ArrayList(value);
/*  588 */     serializeSorts();
/*  589 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<SortClause> getSorts()
/*      */   {
/*  599 */     if (this.sortClauses == null) return Collections.emptyList();
/*  600 */     return Collections.unmodifiableList(this.sortClauses);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setSort(String field, ORDER order)
/*      */   {
/*  610 */     return setSort(new SortClause(field, order));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setSort(SortClause sortClause)
/*      */   {
/*  620 */     clearSorts();
/*  621 */     return addSort(sortClause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addSort(String field, ORDER order)
/*      */   {
/*  631 */     return addSort(new SortClause(field, order));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addSort(SortClause sortClause)
/*      */   {
/*  641 */     if (this.sortClauses == null) this.sortClauses = new ArrayList();
/*  642 */     this.sortClauses.add(sortClause);
/*  643 */     serializeSorts();
/*  644 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addOrUpdateSort(String field, ORDER order)
/*      */   {
/*  657 */     return addOrUpdateSort(new SortClause(field, order));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery addOrUpdateSort(SortClause sortClause)
/*      */   {
/*  670 */     if (this.sortClauses != null) {
/*  671 */       for (int index = 0; index < this.sortClauses.size(); index++) {
/*  672 */         SortClause existing = (SortClause)this.sortClauses.get(index);
/*  673 */         if (existing.getItem().equals(sortClause.getItem())) {
/*  674 */           this.sortClauses.set(index, sortClause);
/*  675 */           serializeSorts();
/*  676 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*  680 */     return addSort(sortClause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery removeSort(SortClause sortClause)
/*      */   {
/*  690 */     return removeSort(sortClause.getItem());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery removeSort(String itemName)
/*      */   {
/*  700 */     if (this.sortClauses != null) {
/*  701 */       for (SortClause existing : this.sortClauses) {
/*  702 */         if (existing.getItem().equals(itemName)) {
/*  703 */           this.sortClauses.remove(existing);
/*  704 */           if (this.sortClauses.isEmpty()) this.sortClauses = null;
/*  705 */           serializeSorts();
/*  706 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  710 */     return this;
/*      */   }
/*      */   
/*      */   private void serializeSorts() {
/*  714 */     if ((this.sortClauses == null) || (this.sortClauses.isEmpty())) {
/*  715 */       remove("sort");
/*      */     } else {
/*  717 */       StringBuilder sb = new StringBuilder();
/*  718 */       for (SortClause sortClause : this.sortClauses) {
/*  719 */         if (sb.length() > 0) sb.append(",");
/*  720 */         sb.append(sortClause.getItem());
/*  721 */         sb.append(" ");
/*  722 */         sb.append(sortClause.getOrder());
/*      */       }
/*  724 */       set("sort", new String[] { sb.toString() });
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGetFieldStatistics(boolean v)
/*      */   {
/*  730 */     set("stats", v);
/*      */   }
/*      */   
/*      */   public void setGetFieldStatistics(String field)
/*      */   {
/*  735 */     set("stats", true);
/*  736 */     add("stats.field", new String[] { field });
/*      */   }
/*      */   
/*      */ 
/*      */   public void addGetFieldStatistics(String... field)
/*      */   {
/*  742 */     set("stats", true);
/*  743 */     add("stats.field", field);
/*      */   }
/*      */   
/*      */   public void addStatsFieldFacets(String field, String... facets)
/*      */   {
/*  748 */     if (field == null) {
/*  749 */       add("stats.facet", facets);
/*      */     }
/*      */     else {
/*  752 */       for (String f : facets) {
/*  753 */         add("f." + field + "." + "stats.facet", new String[] { f });
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void addStatsFieldCalcDistinct(String field, boolean calcDistinct) {
/*  759 */     if (field == null) {
/*  760 */       add("stats.calcdistinct", new String[] { Boolean.toString(calcDistinct) });
/*      */     } else {
/*  762 */       add("f." + field + "." + "stats.calcdistinct", new String[] { Boolean.toString(calcDistinct) });
/*      */     }
/*      */   }
/*      */   
/*      */   public SolrQuery setFilterQueries(String... fq) {
/*  767 */     set("fq", fq);
/*  768 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery addFilterQuery(String... fq) {
/*  772 */     add("fq", fq);
/*  773 */     return this;
/*      */   }
/*      */   
/*      */   public boolean removeFilterQuery(String fq) {
/*  777 */     return remove("fq", fq);
/*      */   }
/*      */   
/*      */   public String[] getFilterQueries() {
/*  781 */     return getParams("fq");
/*      */   }
/*      */   
/*      */   public boolean getHighlight() {
/*  785 */     return getBool("hl", false);
/*      */   }
/*      */   
/*      */   public SolrQuery setHighlight(boolean b) {
/*  789 */     if (b) {
/*  790 */       set("hl", true);
/*      */     } else {
/*  792 */       remove("hl");
/*  793 */       remove("hl.requireFieldMatch");
/*  794 */       remove("hl.fl");
/*  795 */       remove("hl.formatter");
/*  796 */       remove("hl.fragsize");
/*  797 */       remove("hl.simple.post");
/*  798 */       remove("hl.simple.pre");
/*  799 */       remove("hl.snippets");
/*      */     }
/*  801 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery setFields(String... fields) {
/*  805 */     if ((fields == null) || (fields.length == 0)) {
/*  806 */       remove("fl");
/*  807 */       return this;
/*      */     }
/*  809 */     StringBuilder sb = new StringBuilder();
/*  810 */     sb.append(fields[0]);
/*  811 */     for (int i = 1; i < fields.length; i++) {
/*  812 */       sb.append(',');
/*  813 */       sb.append(fields[i]);
/*      */     }
/*  815 */     set("fl", new String[] { sb.toString() });
/*  816 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery addField(String field) {
/*  820 */     return addValueToParam("fl", field);
/*      */   }
/*      */   
/*      */   public String getFields() {
/*  824 */     String fields = get("fl");
/*  825 */     if ((fields != null) && (fields.equals("score"))) {
/*  826 */       fields = "*, score";
/*      */     }
/*  828 */     return fields;
/*      */   }
/*      */   
/*  831 */   private static Pattern scorePattern = Pattern.compile("(^|[, ])score");
/*      */   
/*      */   public SolrQuery setIncludeScore(boolean includeScore) {
/*  834 */     String fields = get("fl", "*");
/*  835 */     if (includeScore) {
/*  836 */       if (!scorePattern.matcher(fields).find()) {
/*  837 */         set("fl", new String[] { fields + ",score" });
/*      */       }
/*      */     } else {
/*  840 */       set("fl", new String[] { scorePattern.matcher(fields).replaceAll("") });
/*      */     }
/*  842 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery setQuery(String query) {
/*  846 */     set("q", new String[] { query });
/*  847 */     return this;
/*      */   }
/*      */   
/*      */   public String getQuery() {
/*  851 */     return get("q");
/*      */   }
/*      */   
/*      */   public SolrQuery setRows(Integer rows) {
/*  855 */     if (rows == null) {
/*  856 */       remove("rows");
/*      */     }
/*      */     else {
/*  859 */       set("rows", rows.intValue());
/*      */     }
/*  861 */     return this;
/*      */   }
/*      */   
/*      */   public Integer getRows()
/*      */   {
/*  866 */     return getInt("rows");
/*      */   }
/*      */   
/*      */   public SolrQuery setShowDebugInfo(boolean showDebugInfo) {
/*  870 */     set("debugQuery", new String[] { String.valueOf(showDebugInfo) });
/*  871 */     return this;
/*      */   }
/*      */   
/*      */   public void setDistrib(boolean val) {
/*  875 */     set("distrib", new String[] { String.valueOf(val) });
/*      */   }
/*      */   
/*      */   public SolrQuery setStart(Integer start)
/*      */   {
/*  880 */     if (start == null) {
/*  881 */       remove("start");
/*      */     }
/*      */     else {
/*  884 */       set("start", start.intValue());
/*      */     }
/*  886 */     return this;
/*      */   }
/*      */   
/*      */   public Integer getStart()
/*      */   {
/*  891 */     return getInt("start");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setRequestHandler(String qt)
/*      */   {
/*  904 */     set("qt", new String[] { qt });
/*  905 */     return this;
/*      */   }
/*      */   
/*      */   public String getRequestHandler() {
/*  909 */     return get("qt");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setParam(String name, String... values)
/*      */   {
/*  917 */     set(name, values);
/*  918 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setParam(String name, boolean value)
/*      */   {
/*  926 */     set(name, value);
/*  927 */     return this;
/*      */   }
/*      */   
/*      */   public SolrQuery getCopy()
/*      */   {
/*  932 */     SolrQuery q = new SolrQuery();
/*  933 */     for (String name : getParameterNames()) {
/*  934 */       q.setParam(name, getParams(name));
/*      */     }
/*  936 */     return q;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrQuery setTimeAllowed(Integer milliseconds)
/*      */   {
/*  949 */     if (milliseconds == null) {
/*  950 */       remove("timeAllowed");
/*      */     } else {
/*  952 */       set("timeAllowed", milliseconds.intValue());
/*      */     }
/*  954 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Integer getTimeAllowed()
/*      */   {
/*  961 */     return getInt("timeAllowed");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String toSortString(String field, ORDER order)
/*      */   {
/*  969 */     return field.trim() + ' ' + String.valueOf(order).trim();
/*      */   }
/*      */   
/*      */   private String join(String a, String b, String sep) {
/*  973 */     StringBuilder sb = new StringBuilder();
/*  974 */     if ((a != null) && (a.length() > 0)) {
/*  975 */       sb.append(a);
/*  976 */       sb.append(sep);
/*      */     }
/*  978 */     if ((b != null) && (b.length() > 0)) {
/*  979 */       sb.append(b);
/*      */     }
/*  981 */     return sb.toString().trim();
/*      */   }
/*      */   
/*      */   private SolrQuery addValueToParam(String name, String value) {
/*  985 */     String tmp = get(name);
/*  986 */     tmp = join(tmp, value, ",");
/*  987 */     set(name, new String[] { tmp });
/*  988 */     return this;
/*      */   }
/*      */   
/*      */   private String join(String[] vals, String sep, String removeVal) {
/*  992 */     StringBuilder sb = new StringBuilder();
/*  993 */     for (int i = 0; i < vals.length; i++) {
/*  994 */       if (!vals[i].equals(removeVal)) {
/*  995 */         if (sb.length() > 0) {
/*  996 */           sb.append(sep);
/*      */         }
/*  998 */         sb.append(vals[i]);
/*      */       }
/*      */     }
/* 1001 */     return sb.toString().trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class SortClause
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final String item;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final SolrQuery.ORDER order;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public SortClause(String item, SolrQuery.ORDER order)
/*      */     {
/* 1032 */       this.item = item;
/* 1033 */       this.order = order;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public SortClause(String item, String order)
/*      */     {
/* 1042 */       this(item, SolrQuery.ORDER.valueOf(order));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static SortClause create(String item, SolrQuery.ORDER order)
/*      */     {
/* 1050 */       return new SortClause(item, order);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static SortClause create(String item, String order)
/*      */     {
/* 1059 */       return new SortClause(item, SolrQuery.ORDER.valueOf(order));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static SortClause asc(String item)
/*      */     {
/* 1067 */       return new SortClause(item, SolrQuery.ORDER.asc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static SortClause desc(String item)
/*      */     {
/* 1075 */       return new SortClause(item, SolrQuery.ORDER.desc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getItem()
/*      */     {
/* 1083 */       return this.item;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public SolrQuery.ORDER getOrder()
/*      */     {
/* 1091 */       return this.order;
/*      */     }
/*      */     
/*      */     public boolean equals(Object other) {
/* 1095 */       if (this == other) return true;
/* 1096 */       if (!(other instanceof SortClause)) return false;
/* 1097 */       SortClause that = (SortClause)other;
/* 1098 */       return (getItem().equals(that.getItem())) && (getOrder().equals(that.getOrder()));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 1102 */       return getItem().hashCode();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1113 */       return "[" + getClass().getSimpleName() + ": item=" + getItem() + "; order=" + getOrder() + "]";
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\SolrQuery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */