/*    */ package org.apache.solr.common.params;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppendedSolrParams
/*    */   extends DefaultSolrParams
/*    */ {
/*    */   public static AppendedSolrParams wrapAppended(SolrParams params, SolrParams extra)
/*    */   {
/* 27 */     return new AppendedSolrParams(params, extra);
/*    */   }
/*    */   
/*    */   private AppendedSolrParams(SolrParams main, SolrParams extra) {
/* 31 */     super(main, extra);
/*    */   }
/*    */   
/*    */   public String[] getParams(String param)
/*    */   {
/* 36 */     String[] main = this.params.getParams(param);
/* 37 */     String[] extra = this.defaults.getParams(param);
/* 38 */     if ((null == extra) || (0 == extra.length)) {
/* 39 */       return main;
/*    */     }
/* 41 */     if ((null == main) || (0 == main.length)) {
/* 42 */       return extra;
/*    */     }
/* 44 */     String[] result = new String[main.length + extra.length];
/* 45 */     System.arraycopy(main, 0, result, 0, main.length);
/* 46 */     System.arraycopy(extra, 0, result, main.length, extra.length);
/* 47 */     return result;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return "{main(" + this.params + "),extra(" + this.defaults + ")}";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\AppendedSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */