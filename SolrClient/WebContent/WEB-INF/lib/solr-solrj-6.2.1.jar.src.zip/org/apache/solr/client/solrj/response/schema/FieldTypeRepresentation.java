/*    */ package org.apache.solr.client.solrj.response.schema;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.solr.client.solrj.request.schema.FieldTypeDefinition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldTypeRepresentation
/*    */   extends FieldTypeDefinition
/*    */ {
/*    */   private List<String> fields;
/*    */   private List<String> dynamicFields;
/*    */   
/*    */   public List<String> getFields()
/*    */   {
/* 32 */     return this.fields;
/*    */   }
/*    */   
/*    */   public void setFields(List<String> fields) {
/* 36 */     this.fields = fields;
/*    */   }
/*    */   
/*    */   public List<String> getDynamicFields() {
/* 40 */     return this.dynamicFields;
/*    */   }
/*    */   
/*    */   public void setDynamicFields(List<String> dynamicFields) {
/* 44 */     this.dynamicFields = dynamicFields;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\schema\FieldTypeRepresentation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */