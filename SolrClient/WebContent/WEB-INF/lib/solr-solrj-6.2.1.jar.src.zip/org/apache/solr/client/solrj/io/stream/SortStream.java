/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private TupleStream stream;
/*     */   private StreamComparator comparator;
/*     */   private Worker worker;
/*     */   
/*     */   public SortStream(TupleStream stream, StreamComparator comp)
/*     */     throws IOException
/*     */   {
/*  51 */     init(stream, comp);
/*     */   }
/*     */   
/*     */   public SortStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  56 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  57 */     StreamExpressionNamedParameter byExpression = factory.getNamedOperand(expression, "by");
/*     */     
/*     */ 
/*  60 */     if (expression.getParameters().size() != streamExpressions.size() + 1) {
/*  61 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  64 */     if (1 != streamExpressions.size()) {
/*  65 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  68 */     if ((null == byExpression) || (!(byExpression.getParameter() instanceof StreamExpressionValue))) {
/*  69 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'by' parameter listing fields to sort over but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  72 */     init(factory
/*  73 */       .constructStream((StreamExpression)streamExpressions.get(0)), factory
/*  74 */       .constructComparator(((StreamExpressionValue)byExpression.getParameter()).getValue(), FieldComparator.class));
/*     */   }
/*     */   
/*     */   private void init(TupleStream stream, StreamComparator comp) throws IOException
/*     */   {
/*  79 */     this.stream = stream;
/*  80 */     this.comparator = comp;
/*     */     
/*     */ 
/*  83 */     this.worker = new Worker()
/*     */     {
/*  85 */       private LinkedList<Tuple> tuples = new LinkedList();
/*     */       private Tuple eofTuple;
/*     */       
/*     */       public void readStream(TupleStream stream) throws IOException {
/*  89 */         Tuple tuple = stream.read();
/*  90 */         while (!tuple.EOF) {
/*  91 */           this.tuples.add(tuple);
/*  92 */           tuple = stream.read();
/*     */         }
/*  94 */         this.eofTuple = tuple;
/*     */       }
/*     */       
/*     */       public void sort() {
/*  98 */         this.tuples.sort(SortStream.this.comparator);
/*     */       }
/*     */       
/*     */       public Tuple read() {
/* 102 */         if (this.tuples.isEmpty()) {
/* 103 */           return this.eofTuple;
/*     */         }
/* 105 */         return (Tuple)this.tuples.removeFirst();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 113 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 118 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/* 120 */     if (includeStreams)
/*     */     {
/* 122 */       if ((this.stream instanceof Expressible)) {
/* 123 */         expression.addParameter(((Expressible)this.stream).toExpression(factory));
/*     */       }
/*     */       else {
/* 126 */         throw new IOException("This SortStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 130 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 134 */     if ((this.comparator instanceof Expressible)) {
/* 135 */       expression.addParameter(new StreamExpressionNamedParameter("by", this.comparator.toExpression(factory)));
/*     */     }
/*     */     else {
/* 138 */       throw new IOException("This SortStream contains a non-expressible equalitor - it cannot be converted to an expression");
/*     */     }
/*     */     
/* 141 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 147 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.stream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString()).withHelper(this.comparator.toExplanation(factory));
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 159 */     this.stream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 163 */     List<TupleStream> l = new ArrayList();
/* 164 */     l.add(this.stream);
/* 165 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 169 */     this.stream.open();
/*     */     
/* 171 */     this.worker.readStream(this.stream);
/* 172 */     this.worker.sort();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 176 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/* 181 */     return this.worker.read();
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 186 */     return this.comparator;
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 190 */     return 0;
/*     */   }
/*     */   
/*     */   private static abstract interface Worker
/*     */   {
/*     */     public abstract void readStream(TupleStream paramTupleStream)
/*     */       throws IOException;
/*     */     
/*     */     public abstract void sort();
/*     */     
/*     */     public abstract Tuple read();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\SortStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */