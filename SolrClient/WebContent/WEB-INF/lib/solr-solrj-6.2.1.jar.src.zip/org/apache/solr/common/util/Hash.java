/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hash
/*     */ {
/*     */   public static int lookup3(int[] k, int offset, int length, int initval)
/*     */   {
/*     */     int c;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int b;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */     int a = b = c = -559038737 + (length << 2) + initval;
/*     */     
/*  62 */     int i = offset;
/*  63 */     while (length > 3)
/*     */     {
/*  65 */       a += k[i];
/*  66 */       b += k[(i + 1)];
/*  67 */       c += k[(i + 2)];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */       a -= c;a ^= (c << 4 | c >>> -4);c += b;
/*  74 */       b -= a;b ^= (a << 6 | a >>> -6);a += c;
/*  75 */       c -= b;c ^= (b << 8 | b >>> -8);b += a;
/*  76 */       a -= c;a ^= (c << 16 | c >>> -16);c += b;
/*  77 */       b -= a;b ^= (a << 19 | a >>> -19);a += c;
/*  78 */       c -= b;c ^= (b << 4 | b >>> -4);b += a;
/*     */       
/*     */ 
/*  81 */       length -= 3;
/*  82 */       i += 3;
/*     */     }
/*     */     
/*  85 */     switch (length) {
/*  86 */     case 3:  c += k[(i + 2)];
/*  87 */     case 2:  b += k[(i + 1)];
/*  88 */     case 1:  a += k[(i + 0)];
/*     */       
/*     */ 
/*  91 */       c ^= b;c -= (b << 14 | b >>> -14);
/*  92 */       a ^= c;a -= (c << 11 | c >>> -11);
/*  93 */       b ^= a;b -= (a << 25 | a >>> -25);
/*  94 */       c ^= b;c -= (b << 16 | b >>> -16);
/*  95 */       a ^= c;a -= (c << 4 | c >>> -4);
/*  96 */       b ^= a;b -= (a << 14 | a >>> -14);
/*  97 */       c ^= b;c -= (b << 24 | b >>> -24);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 102 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int lookup3ycs(int[] k, int offset, int length, int initval)
/*     */   {
/* 114 */     return lookup3(k, offset, length, initval - (length << 2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int lookup3ycs(CharSequence s, int start, int end, int initval)
/*     */   {
/*     */     int c;
/*     */     
/*     */ 
/*     */     int b;
/*     */     
/*     */ 
/* 128 */     int a = b = c = -559038737 + initval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     int i = start;
/* 134 */     boolean mixed = true;
/*     */     
/* 136 */     while (i < end) {
/* 137 */       mixed = false;
/*     */       
/* 139 */       char ch = s.charAt(i++);
/* 140 */       a += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 141 */       if (i >= end) break;
/* 142 */       ch = s.charAt(i++);
/* 143 */       b += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 144 */       if (i >= end) break;
/* 145 */       ch = s.charAt(i++);
/* 146 */       c += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 147 */       if (i >= end) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 153 */       a -= c;a ^= (c << 4 | c >>> -4);c += b;
/* 154 */       b -= a;b ^= (a << 6 | a >>> -6);a += c;
/* 155 */       c -= b;c ^= (b << 8 | b >>> -8);b += a;
/* 156 */       a -= c;a ^= (c << 16 | c >>> -16);c += b;
/* 157 */       b -= a;b ^= (a << 19 | a >>> -19);a += c;
/* 158 */       c -= b;c ^= (b << 4 | b >>> -4);b += a;
/*     */       
/* 160 */       mixed = true;
/*     */     }
/*     */     
/*     */ 
/* 164 */     if (!mixed)
/*     */     {
/* 166 */       c ^= b;c -= (b << 14 | b >>> -14);
/* 167 */       a ^= c;a -= (c << 11 | c >>> -11);
/* 168 */       b ^= a;b -= (a << 25 | a >>> -25);
/* 169 */       c ^= b;c -= (b << 16 | b >>> -16);
/* 170 */       a ^= c;a -= (c << 4 | c >>> -4);
/* 171 */       b ^= a;b -= (a << 14 | a >>> -14);
/* 172 */       c ^= b;c -= (b << 24 | b >>> -24);
/*     */     }
/*     */     
/* 175 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static long lookup3ycs64(CharSequence s, int start, int end, long initval)
/*     */   {
/*     */     int c;
/*     */     
/*     */ 
/*     */     int b;
/*     */     
/* 187 */     int a = b = c = -559038737 + (int)initval;
/* 188 */     c += (int)(initval >>> 32);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 193 */     int i = start;
/* 194 */     boolean mixed = true;
/*     */     
/* 196 */     while (i < end) {
/* 197 */       mixed = false;
/*     */       
/* 199 */       char ch = s.charAt(i++);
/* 200 */       a += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 201 */       if (i >= end) break;
/* 202 */       ch = s.charAt(i++);
/* 203 */       b += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 204 */       if (i >= end) break;
/* 205 */       ch = s.charAt(i++);
/* 206 */       c += ((Character.isHighSurrogate(ch)) && (i < end) ? Character.toCodePoint(ch, s.charAt(i++)) : ch);
/* 207 */       if (i >= end) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 213 */       a -= c;a ^= (c << 4 | c >>> -4);c += b;
/* 214 */       b -= a;b ^= (a << 6 | a >>> -6);a += c;
/* 215 */       c -= b;c ^= (b << 8 | b >>> -8);b += a;
/* 216 */       a -= c;a ^= (c << 16 | c >>> -16);c += b;
/* 217 */       b -= a;b ^= (a << 19 | a >>> -19);a += c;
/* 218 */       c -= b;c ^= (b << 4 | b >>> -4);b += a;
/*     */       
/* 220 */       mixed = true;
/*     */     }
/*     */     
/*     */ 
/* 224 */     if (!mixed)
/*     */     {
/* 226 */       c ^= b;c -= (b << 14 | b >>> -14);
/* 227 */       a ^= c;a -= (c << 11 | c >>> -11);
/* 228 */       b ^= a;b -= (a << 25 | a >>> -25);
/* 229 */       c ^= b;c -= (b << 16 | b >>> -16);
/* 230 */       a ^= c;a -= (c << 4 | c >>> -4);
/* 231 */       b ^= a;b -= (a << 14 | a >>> -14);
/* 232 */       c ^= b;c -= (b << 24 | b >>> -24);
/*     */     }
/*     */     
/* 235 */     return c + (b << 32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int murmurhash3_x86_32(byte[] data, int offset, int len, int seed)
/*     */   {
/* 244 */     int c1 = -862048943;
/* 245 */     int c2 = 461845907;
/*     */     
/* 247 */     int h1 = seed;
/* 248 */     int roundedEnd = offset + (len & 0xFFFFFFFC);
/*     */     
/* 250 */     for (int i = offset; i < roundedEnd; i += 4)
/*     */     {
/* 252 */       int k1 = data[i] & 0xFF | (data[(i + 1)] & 0xFF) << 8 | (data[(i + 2)] & 0xFF) << 16 | data[(i + 3)] << 24;
/* 253 */       k1 *= -862048943;
/* 254 */       k1 = k1 << 15 | k1 >>> 17;
/* 255 */       k1 *= 461845907;
/*     */       
/* 257 */       h1 ^= k1;
/* 258 */       h1 = h1 << 13 | h1 >>> 19;
/* 259 */       h1 = h1 * 5 + -430675100;
/*     */     }
/*     */     
/*     */ 
/* 263 */     int k1 = 0;
/*     */     
/* 265 */     switch (len & 0x3) {
/*     */     case 3: 
/* 267 */       k1 = (data[(roundedEnd + 2)] & 0xFF) << 16;
/*     */     
/*     */     case 2: 
/* 270 */       k1 |= (data[(roundedEnd + 1)] & 0xFF) << 8;
/*     */     
/*     */     case 1: 
/* 273 */       k1 |= data[roundedEnd] & 0xFF;
/* 274 */       k1 *= -862048943;
/* 275 */       k1 = k1 << 15 | k1 >>> 17;
/* 276 */       k1 *= 461845907;
/* 277 */       h1 ^= k1;
/*     */     }
/*     */     
/*     */     
/* 281 */     h1 ^= len;
/*     */     
/*     */ 
/* 284 */     h1 ^= h1 >>> 16;
/* 285 */     h1 *= -2048144789;
/* 286 */     h1 ^= h1 >>> 13;
/* 287 */     h1 *= -1028477387;
/* 288 */     h1 ^= h1 >>> 16;
/*     */     
/* 290 */     return h1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int murmurhash3_x86_32(CharSequence data, int offset, int len, int seed)
/*     */   {
/* 301 */     int c1 = -862048943;
/* 302 */     int c2 = 461845907;
/*     */     
/* 304 */     int h1 = seed;
/*     */     
/* 306 */     int pos = offset;
/* 307 */     int end = offset + len;
/* 308 */     int k1 = 0;
/* 309 */     int k2 = 0;
/* 310 */     int shift = 0;
/* 311 */     int bits = 0;
/* 312 */     int nBytes = 0;
/*     */     
/*     */ 
/* 315 */     while (pos < end) {
/* 316 */       int code = data.charAt(pos++);
/* 317 */       if (code < 128) {
/* 318 */         k2 = code;
/* 319 */         bits = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 345 */       else if (code < 2048) {
/* 346 */         k2 = 0xC0 | code >> 6 | (0x80 | code & 0x3F) << 8;
/*     */         
/* 348 */         bits = 16;
/*     */       }
/* 350 */       else if ((code < 55296) || (code > 57343) || (pos >= end))
/*     */       {
/* 352 */         k2 = 0xE0 | code >> 12 | (0x80 | code >> 6 & 0x3F) << 8 | (0x80 | code & 0x3F) << 16;
/*     */         
/*     */ 
/* 355 */         bits = 24;
/*     */       }
/*     */       else
/*     */       {
/* 359 */         int utf32 = data.charAt(pos++);
/* 360 */         utf32 = (code - 55232 << 10) + (utf32 & 0x3FF);
/* 361 */         k2 = 0xFF & (0xF0 | utf32 >> 18) | (0x80 | utf32 >> 12 & 0x3F) << 8 | (0x80 | utf32 >> 6 & 0x3F) << 16 | (0x80 | utf32 & 0x3F) << 24;
/*     */         
/*     */ 
/*     */ 
/* 365 */         bits = 32;
/*     */       }
/*     */       
/*     */ 
/* 369 */       k1 |= k2 << shift;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 374 */       shift += bits;
/* 375 */       if (shift >= 32)
/*     */       {
/*     */ 
/* 378 */         k1 *= -862048943;
/* 379 */         k1 = k1 << 15 | k1 >>> 17;
/* 380 */         k1 *= 461845907;
/*     */         
/* 382 */         h1 ^= k1;
/* 383 */         h1 = h1 << 13 | h1 >>> 19;
/* 384 */         h1 = h1 * 5 + -430675100;
/*     */         
/* 386 */         shift -= 32;
/*     */         
/* 388 */         if (shift != 0) {
/* 389 */           k1 = k2 >>> bits - shift;
/*     */         } else {
/* 391 */           k1 = 0;
/*     */         }
/* 393 */         nBytes += 4;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 399 */     if (shift > 0) {
/* 400 */       nBytes += (shift >> 3);
/* 401 */       k1 *= -862048943;
/* 402 */       k1 = k1 << 15 | k1 >>> 17;
/* 403 */       k1 *= 461845907;
/* 404 */       h1 ^= k1;
/*     */     }
/*     */     
/*     */ 
/* 408 */     h1 ^= nBytes;
/*     */     
/*     */ 
/* 411 */     h1 ^= h1 >>> 16;
/* 412 */     h1 *= -2048144789;
/* 413 */     h1 ^= h1 >>> 13;
/* 414 */     h1 *= -1028477387;
/* 415 */     h1 ^= h1 >>> 16;
/*     */     
/* 417 */     return h1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int fmix32(int h)
/*     */   {
/* 428 */     h ^= h >>> 16;
/* 429 */     h *= -2048144789;
/* 430 */     h ^= h >>> 13;
/* 431 */     h *= -1028477387;
/* 432 */     h ^= h >>> 16;
/* 433 */     return h;
/*     */   }
/*     */   
/*     */   public static final long fmix64(long k) {
/* 437 */     k ^= k >>> 33;
/* 438 */     k *= -49064778989728563L;
/* 439 */     k ^= k >>> 33;
/* 440 */     k *= -4265267296055464877L;
/* 441 */     k ^= k >>> 33;
/* 442 */     return k;
/*     */   }
/*     */   
/*     */   public static final long getLongLittleEndian(byte[] buf, int offset)
/*     */   {
/* 447 */     return buf[(offset + 7)] << 56 | (buf[(offset + 6)] & 0xFF) << 48 | (buf[(offset + 5)] & 0xFF) << 40 | (buf[(offset + 4)] & 0xFF) << 32 | (buf[(offset + 3)] & 0xFF) << 24 | (buf[(offset + 2)] & 0xFF) << 16 | (buf[(offset + 1)] & 0xFF) << 8 | buf[offset] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void murmurhash3_x64_128(byte[] key, int offset, int len, int seed, LongPair out)
/*     */   {
/* 462 */     long h1 = seed & 0xFFFFFFFF;
/* 463 */     long h2 = seed & 0xFFFFFFFF;
/*     */     
/* 465 */     long c1 = -8663945395140668459L;
/* 466 */     long c2 = 5545529020109919103L;
/*     */     
/* 468 */     int roundedEnd = offset + (len & 0xFFFFFFF0);
/* 469 */     for (int i = offset; i < roundedEnd; i += 16) {
/* 470 */       long k1 = getLongLittleEndian(key, i);
/* 471 */       long k2 = getLongLittleEndian(key, i + 8);
/* 472 */       k1 *= -8663945395140668459L;k1 = Long.rotateLeft(k1, 31);k1 *= 5545529020109919103L;h1 ^= k1;
/* 473 */       h1 = Long.rotateLeft(h1, 27);h1 += h2;h1 = h1 * 5L + 1390208809L;
/* 474 */       k2 *= 5545529020109919103L;k2 = Long.rotateLeft(k2, 33);k2 *= -8663945395140668459L;h2 ^= k2;
/* 475 */       h2 = Long.rotateLeft(h2, 31);h2 += h1;h2 = h2 * 5L + 944331445L;
/*     */     }
/*     */     
/* 478 */     long k1 = 0L;
/* 479 */     long k2 = 0L;
/*     */     
/* 481 */     switch (len & 0xF) {
/* 482 */     case 15:  k2 = (key[(roundedEnd + 14)] & 0xFF) << 48;
/* 483 */     case 14:  k2 |= (key[(roundedEnd + 13)] & 0xFF) << 40;
/* 484 */     case 13:  k2 |= (key[(roundedEnd + 12)] & 0xFF) << 32;
/* 485 */     case 12:  k2 |= (key[(roundedEnd + 11)] & 0xFF) << 24;
/* 486 */     case 11:  k2 |= (key[(roundedEnd + 10)] & 0xFF) << 16;
/* 487 */     case 10:  k2 |= (key[(roundedEnd + 9)] & 0xFF) << 8;
/* 488 */     case 9:  k2 |= key[(roundedEnd + 8)] & 0xFF;
/* 489 */       k2 *= 5545529020109919103L;k2 = Long.rotateLeft(k2, 33);k2 *= -8663945395140668459L;h2 ^= k2;
/* 490 */     case 8:  k1 = key[(roundedEnd + 7)] << 56;
/* 491 */     case 7:  k1 |= (key[(roundedEnd + 6)] & 0xFF) << 48;
/* 492 */     case 6:  k1 |= (key[(roundedEnd + 5)] & 0xFF) << 40;
/* 493 */     case 5:  k1 |= (key[(roundedEnd + 4)] & 0xFF) << 32;
/* 494 */     case 4:  k1 |= (key[(roundedEnd + 3)] & 0xFF) << 24;
/* 495 */     case 3:  k1 |= (key[(roundedEnd + 2)] & 0xFF) << 16;
/* 496 */     case 2:  k1 |= (key[(roundedEnd + 1)] & 0xFF) << 8;
/* 497 */     case 1:  k1 |= key[roundedEnd] & 0xFF;
/* 498 */       k1 *= -8663945395140668459L;k1 = Long.rotateLeft(k1, 31);k1 *= 5545529020109919103L;h1 ^= k1;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 504 */     h1 ^= len;h2 ^= len;
/*     */     
/* 506 */     h1 += h2;
/* 507 */     h2 += h1;
/*     */     
/* 509 */     h1 = fmix64(h1);
/* 510 */     h2 = fmix64(h2);
/*     */     
/* 512 */     h1 += h2;
/* 513 */     h2 += h1;
/*     */     
/* 515 */     out.val1 = h1;
/* 516 */     out.val2 = h2;
/*     */   }
/*     */   
/*     */   public static final class LongPair
/*     */   {
/*     */     public long val1;
/*     */     public long val2;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\Hash.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */