package org.apache.solr.client.solrj.impl;

interface package-info {}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */