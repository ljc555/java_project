package org.apache.solr.common.cloud;

public abstract interface BeforeReconnect
{
  public abstract void command();
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\BeforeReconnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */