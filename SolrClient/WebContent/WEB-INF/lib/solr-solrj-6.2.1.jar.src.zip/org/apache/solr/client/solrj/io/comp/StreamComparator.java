package org.apache.solr.client.solrj.io.comp;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;
import org.apache.solr.client.solrj.io.Tuple;
import org.apache.solr.client.solrj.io.stream.expr.Expressible;

public abstract interface StreamComparator
  extends Comparator<Tuple>, Expressible, Serializable
{
  public abstract boolean isDerivedFrom(StreamComparator paramStreamComparator);
  
  public abstract StreamComparator copyAliased(Map<String, String> paramMap);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\comp\StreamComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */