/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TermsResponse
/*    */ {
/* 29 */   private Map<String, List<Term>> termMap = new HashMap();
/*    */   
/*    */   public TermsResponse(NamedList<NamedList<Number>> termsInfo) {
/* 32 */     for (int i = 0; i < termsInfo.size(); i++) {
/* 33 */       String fieldName = termsInfo.getName(i);
/* 34 */       List<Term> itemList = new ArrayList();
/* 35 */       NamedList<Number> items = (NamedList)termsInfo.getVal(i);
/*    */       
/* 37 */       for (int j = 0; j < items.size(); j++) {
/* 38 */         Term t = new Term(items.getName(j), ((Number)items.getVal(j)).longValue());
/* 39 */         itemList.add(t);
/*    */       }
/*    */       
/* 42 */       this.termMap.put(fieldName, itemList);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<Term> getTerms(String field)
/*    */   {
/* 52 */     return (List)this.termMap.get(field);
/*    */   }
/*    */   
/*    */   public Map<String, List<Term>> getTermMap() {
/* 56 */     return this.termMap;
/*    */   }
/*    */   
/*    */   public static class Term {
/*    */     private String term;
/*    */     private long frequency;
/*    */     
/*    */     public Term(String term, long frequency) {
/* 64 */       this.term = term;
/* 65 */       this.frequency = frequency;
/*    */     }
/*    */     
/*    */     public String getTerm() {
/* 69 */       return this.term;
/*    */     }
/*    */     
/*    */     public void setTerm(String term) {
/* 73 */       this.term = term;
/*    */     }
/*    */     
/*    */     public long getFrequency() {
/* 77 */       return this.frequency;
/*    */     }
/*    */     
/*    */     public void setFrequency(long frequency) {
/* 81 */       this.frequency = frequency;
/*    */     }
/*    */     
/*    */     public void addFrequency(long frequency) {
/* 85 */       this.frequency += frequency;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\TermsResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */