/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodHandles.Lookup;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IOUtils
/*    */ {
/* 26 */   private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*    */   
/*    */   public static void closeQuietly(Closeable closeable) {
/*    */     try {
/* 30 */       if (closeable != null) {
/* 31 */         closeable.close();
/*    */       }
/*    */     } catch (Exception e) {
/* 34 */       LOG.error("Error while closing", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\IOUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */