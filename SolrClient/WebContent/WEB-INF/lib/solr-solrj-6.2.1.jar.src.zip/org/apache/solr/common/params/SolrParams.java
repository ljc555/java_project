/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SimpleOrderedMap;
/*     */ import org.apache.solr.common.util.StrUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SolrParams
/*     */   implements Serializable
/*     */ {
/*     */   public abstract String get(String paramString);
/*     */   
/*     */   public abstract String[] getParams(String paramString);
/*     */   
/*     */   public abstract Iterator<String> getParameterNamesIterator();
/*     */   
/*     */   public String get(String param, String def)
/*     */   {
/*  55 */     String val = get(param);
/*  56 */     return val == null ? def : val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequiredSolrParams required()
/*     */   {
/*  63 */     return new RequiredSolrParams(this);
/*     */   }
/*     */   
/*     */   protected String fpname(String field, String param) {
/*  67 */     return "f." + field + '.' + param;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFieldParam(String field, String param)
/*     */   {
/*  74 */     String val = get(fpname(field, param));
/*  75 */     return val != null ? val : get(param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFieldParam(String field, String param, String def)
/*     */   {
/*  82 */     String val = get(fpname(field, param));
/*  83 */     return val != null ? val : get(param, def);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getFieldParams(String field, String param)
/*     */   {
/*  90 */     String[] val = getParams(fpname(field, param));
/*  91 */     return val != null ? val : getParams(param);
/*     */   }
/*     */   
/*     */   public Boolean getBool(String param)
/*     */   {
/*  96 */     String val = get(param);
/*  97 */     return val == null ? null : Boolean.valueOf(StrUtils.parseBool(val));
/*     */   }
/*     */   
/*     */   public boolean getBool(String param, boolean def)
/*     */   {
/* 102 */     String val = get(param);
/* 103 */     return val == null ? def : StrUtils.parseBool(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean getFieldBool(String field, String param)
/*     */   {
/* 109 */     String val = getFieldParam(field, param);
/* 110 */     return val == null ? null : Boolean.valueOf(StrUtils.parseBool(val));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getFieldBool(String field, String param, boolean def)
/*     */   {
/* 116 */     String val = getFieldParam(field, param);
/* 117 */     return val == null ? def : StrUtils.parseBool(val);
/*     */   }
/*     */   
/*     */   public Integer getInt(String param)
/*     */   {
/* 122 */     String val = get(param);
/*     */     try {
/* 124 */       return val == null ? null : Integer.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 127 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Long getLong(String param, Long def)
/*     */   {
/* 133 */     String val = get(param);
/*     */     try {
/* 135 */       return Long.valueOf(val == null ? def.longValue() : Long.parseLong(val));
/*     */     }
/*     */     catch (Exception ex) {
/* 138 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getInt(String param, int def)
/*     */   {
/* 144 */     String val = get(param);
/*     */     try {
/* 146 */       return val == null ? def : Integer.parseInt(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 149 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Long getLong(String param)
/*     */   {
/* 155 */     String val = get(param);
/*     */     try {
/* 157 */       return val == null ? null : Long.valueOf(val);
/*     */     } catch (Exception ex) {
/* 159 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getLong(String param, long def)
/*     */   {
/* 165 */     String val = get(param);
/*     */     try {
/* 167 */       return val == null ? def : Long.parseLong(val);
/*     */     } catch (Exception ex) {
/* 169 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getFieldInt(String field, String param)
/*     */   {
/* 179 */     String val = getFieldParam(field, param);
/*     */     try {
/* 181 */       return val == null ? null : Integer.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 184 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getFieldInt(String field, String param, int def)
/*     */   {
/* 191 */     String val = getFieldParam(field, param);
/*     */     try {
/* 193 */       return val == null ? def : Integer.parseInt(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 196 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Float getFloat(String param)
/*     */   {
/* 203 */     String val = get(param);
/*     */     try {
/* 205 */       return val == null ? null : Float.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 208 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getFloat(String param, float def)
/*     */   {
/* 214 */     String val = get(param);
/*     */     try {
/* 216 */       return val == null ? def : Float.parseFloat(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 219 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Double getDouble(String param)
/*     */   {
/* 225 */     String val = get(param);
/*     */     try {
/* 227 */       return val == null ? null : Double.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 230 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public double getDouble(String param, double def)
/*     */   {
/* 236 */     String val = get(param);
/*     */     try {
/* 238 */       return val == null ? def : Double.parseDouble(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 241 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Float getFieldFloat(String field, String param)
/*     */   {
/* 248 */     String val = getFieldParam(field, param);
/*     */     try {
/* 250 */       return val == null ? null : Float.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 253 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public float getFieldFloat(String field, String param, float def)
/*     */   {
/* 260 */     String val = getFieldParam(field, param);
/*     */     try {
/* 262 */       return val == null ? def : Float.parseFloat(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 265 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Double getFieldDouble(String field, String param)
/*     */   {
/* 271 */     String val = getFieldParam(field, param);
/*     */     try {
/* 273 */       return val == null ? null : Double.valueOf(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 276 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public double getFieldDouble(String field, String param, double def)
/*     */   {
/* 283 */     String val = getFieldParam(field, param);
/*     */     try {
/* 285 */       return val == null ? def : Double.parseDouble(val);
/*     */     }
/*     */     catch (Exception ex) {
/* 288 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public static SolrParams wrapDefaults(SolrParams params, SolrParams defaults) {
/* 293 */     if (params == null)
/* 294 */       return defaults;
/* 295 */     if (defaults == null)
/* 296 */       return params;
/* 297 */     return new DefaultSolrParams(params, defaults);
/*     */   }
/*     */   
/*     */   public static SolrParams wrapAppended(SolrParams params, SolrParams defaults) {
/* 301 */     if (params == null)
/* 302 */       return defaults;
/* 303 */     if (defaults == null)
/* 304 */       return params;
/* 305 */     return AppendedSolrParams.wrapAppended(params, defaults);
/*     */   }
/*     */   
/*     */   public static Map<String, String> toMap(NamedList params)
/*     */   {
/* 310 */     HashMap<String, String> map = new HashMap();
/* 311 */     for (int i = 0; i < params.size(); i++) {
/* 312 */       map.put(params.getName(i), params.getVal(i).toString());
/*     */     }
/* 314 */     return map;
/*     */   }
/*     */   
/*     */   public static Map<String, String[]> toMultiMap(NamedList params)
/*     */   {
/* 319 */     HashMap<String, String[]> map = new HashMap();
/* 320 */     for (int i = 0; i < params.size(); i++) {
/* 321 */       String name = params.getName(i);
/* 322 */       Object val = params.getVal(i);
/* 323 */       if ((val instanceof String[])) {
/* 324 */         MultiMapSolrParams.addParam(name, (String[])val, map);
/* 325 */       } else if ((val instanceof List)) {
/* 326 */         List l = (List)val;
/* 327 */         String[] s = new String[l.size()];
/* 328 */         for (int j = 0; j < l.size(); j++) {
/* 329 */           s[j] = (l.get(j) == null ? null : String.valueOf(l.get(j)));
/*     */         }
/* 331 */         MultiMapSolrParams.addParam(name, s, map);
/*     */       } else {
/* 333 */         MultiMapSolrParams.addParam(name, val.toString(), map);
/*     */       }
/*     */     }
/* 336 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */   public static SolrParams toSolrParams(NamedList params)
/*     */   {
/* 342 */     return new MultiMapSolrParams(toMultiMap(params));
/*     */   }
/*     */   
/*     */   public SolrParams toFilteredSolrParams(List<String> names)
/*     */   {
/* 347 */     NamedList<String> nl = new NamedList();
/* 348 */     for (Iterator<String> it = getParameterNamesIterator(); it.hasNext();) {
/* 349 */       String name = (String)it.next();
/* 350 */       if (names.contains(name)) {
/* 351 */         String[] values = getParams(name);
/* 352 */         for (String value : values) {
/* 353 */           nl.add(name, value);
/*     */         }
/*     */       }
/*     */     }
/* 357 */     return toSolrParams(nl);
/*     */   }
/*     */   
/*     */   public NamedList<Object> toNamedList()
/*     */   {
/* 362 */     SimpleOrderedMap<Object> result = new SimpleOrderedMap();
/*     */     
/* 364 */     for (Iterator<String> it = getParameterNamesIterator(); it.hasNext();) {
/* 365 */       String name = (String)it.next();
/* 366 */       String[] values = getParams(name);
/* 367 */       if (values.length == 1) {
/* 368 */         result.add(name, values[0]);
/*     */       }
/*     */       else {
/* 371 */         result.add(name, values);
/*     */       }
/*     */     }
/* 374 */     return result;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getAll(Map<String, Object> sink, Collection<String> params) {
/* 378 */     if (sink == null) sink = new LinkedHashMap();
/* 379 */     for (String param : params) {
/* 380 */       String[] v = getParams(param);
/* 381 */       if ((v != null) && (v.length > 0)) {
/* 382 */         if (v.length == 1) {
/* 383 */           sink.put(param, v[0]);
/*     */         } else {
/* 385 */           sink.put(param, v);
/*     */         }
/*     */       }
/*     */     }
/* 389 */     return sink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getAll(Map<String, Object> sink, String... params)
/*     */   {
/* 397 */     return getAll(sink, params == null ? Collections.emptyList() : Arrays.asList(params));
/*     */   }
/*     */   
/*     */   public String toQueryString()
/*     */   {
/*     */     try {
/* 403 */       String charset = StandardCharsets.UTF_8.name();
/* 404 */       StringBuilder sb = new StringBuilder(128);
/* 405 */       boolean first = true;
/* 406 */       for (Iterator<String> it = getParameterNamesIterator(); it.hasNext();) {
/* 407 */         String name = (String)it.next();String nameEnc = URLEncoder.encode(name, charset);
/* 408 */         for (String val : getParams(name)) {
/* 409 */           sb.append(first ? '?' : '&').append(nameEnc).append('=').append(URLEncoder.encode(val, charset));
/* 410 */           first = false;
/*     */         }
/*     */       }
/* 413 */       return sb.toString();
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 416 */       throw new AssertionError(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 430 */     StringBuilder sb = new StringBuilder(128);
/*     */     try {
/* 432 */       boolean first = true;
/* 433 */       for (Iterator<String> it = getParameterNamesIterator(); it.hasNext();) {
/* 434 */         String name = (String)it.next();
/* 435 */         for (String val : getParams(name)) {
/* 436 */           if (!first) sb.append('&');
/* 437 */           first = false;
/* 438 */           StrUtils.partialURLEncodeVal(sb, name);
/* 439 */           sb.append('=');
/* 440 */           StrUtils.partialURLEncodeVal(sb, val);
/*     */         }
/*     */       }
/* 443 */       return sb.toString();
/*     */     }
/*     */     catch (IOException e) {
/* 446 */       throw new AssertionError(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\SolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */