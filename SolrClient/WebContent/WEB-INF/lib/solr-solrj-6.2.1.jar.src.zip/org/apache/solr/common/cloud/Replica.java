/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.noggit.JSONUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Replica
/*     */   extends ZkNodeProps
/*     */ {
/*     */   private final String name;
/*     */   private final String nodeName;
/*     */   private final State state;
/*     */   
/*     */   public static enum State
/*     */   {
/*  47 */     ACTIVE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */     DOWN, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */     RECOVERING, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     RECOVERY_FAILED;
/*     */     
/*     */     private State() {}
/*     */     
/*  78 */     public String toString() { return super.toString().toLowerCase(Locale.ROOT); }
/*     */     
/*     */ 
/*     */     public static State getState(String stateStr)
/*     */     {
/*  83 */       return stateStr == null ? null : valueOf(stateStr.toUpperCase(Locale.ROOT));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Replica(String name, Map<String, Object> propMap)
/*     */   {
/*  92 */     super(propMap);
/*  93 */     this.name = name;
/*  94 */     this.nodeName = ((String)propMap.get("node_name"));
/*  95 */     if (propMap.get("state") != null) {
/*  96 */       this.state = State.getState((String)propMap.get("state"));
/*     */     } else {
/*  98 */       this.state = State.ACTIVE;
/*  99 */       propMap.put("state", this.state.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 105 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getCoreUrl() {
/* 109 */     return ZkCoreNodeProps.getCoreUrl(getStr("base_url"), getStr("core"));
/*     */   }
/*     */   
/*     */   public String getCoreName() {
/* 113 */     return getStr("core");
/*     */   }
/*     */   
/*     */   public String getNodeName()
/*     */   {
/* 118 */     return this.nodeName;
/*     */   }
/*     */   
/*     */   public State getState()
/*     */   {
/* 123 */     return this.state;
/*     */   }
/*     */   
/*     */   public boolean isActive(Set<String> liveNodes) {
/* 127 */     return (liveNodes.contains(this.nodeName)) && (this.state == State.ACTIVE);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 132 */     return this.name + ':' + JSONUtil.toJSON(this.propMap, -1);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\Replica.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */