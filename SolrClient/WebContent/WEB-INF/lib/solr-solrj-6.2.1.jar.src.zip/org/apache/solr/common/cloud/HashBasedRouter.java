/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.SolrInputDocument;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ import org.apache.solr.common.util.Hash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HashBasedRouter
/*    */   extends DocRouter
/*    */ {
/*    */   public Slice getTargetSlice(String id, SolrInputDocument sdoc, String route, SolrParams params, DocCollection collection)
/*    */   {
/*    */     int hash;
/*    */     int hash;
/* 32 */     if (route != null) {
/* 33 */       hash = sliceHash(route, sdoc, params, collection);
/*    */     } else {
/* 35 */       if (id == null) id = getId(sdoc, params);
/* 36 */       hash = sliceHash(id, sdoc, params, collection);
/*    */     }
/* 38 */     return hashToSlice(hash, collection);
/*    */   }
/*    */   
/*    */   public boolean isTargetSlice(String id, SolrInputDocument sdoc, SolrParams params, String shardId, DocCollection collection)
/*    */   {
/* 43 */     if (id == null) id = getId(sdoc, params);
/* 44 */     int hash = sliceHash(id, sdoc, params, collection);
/* 45 */     DocRouter.Range range = collection.getSlice(shardId).getRange();
/* 46 */     return (range != null) && (range.includes(hash));
/*    */   }
/*    */   
/*    */   public int sliceHash(String id, SolrInputDocument sdoc, SolrParams params, DocCollection collection) {
/* 50 */     return Hash.murmurhash3_x86_32(id, 0, id.length(), 0);
/*    */   }
/*    */   
/*    */   protected String getId(SolrInputDocument sdoc, SolrParams params) {
/* 54 */     Object idObj = sdoc.getFieldValue("id");
/* 55 */     String id = idObj != null ? idObj.toString() : "null";
/* 56 */     return id;
/*    */   }
/*    */   
/*    */   protected Slice hashToSlice(int hash, DocCollection collection) { Slice slice;
/* 60 */     for (Iterator localIterator = collection.getActiveSlices().iterator(); localIterator.hasNext(); 
/*    */         
/* 62 */         return slice)
/*    */     {
/* 60 */       slice = (Slice)localIterator.next();
/* 61 */       DocRouter.Range range = slice.getRange();
/* 62 */       if ((range == null) || (!range.includes(hash))) {}
/*    */     }
/* 64 */     throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "No active slice servicing hash code " + Integer.toHexString(hash) + " in " + collection);
/*    */   }
/*    */   
/*    */ 
/*    */   public Collection<Slice> getSearchSlicesSingle(String shardKey, SolrParams params, DocCollection collection)
/*    */   {
/* 70 */     if (shardKey == null)
/*    */     {
/*    */ 
/* 73 */       return collection.getActiveSlices();
/*    */     }
/*    */     
/*    */ 
/* 77 */     Slice slice = getTargetSlice(shardKey, null, null, params, collection);
/* 78 */     return slice == null ? Collections.emptyList() : Collections.singletonList(slice);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\HashBasedRouter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */