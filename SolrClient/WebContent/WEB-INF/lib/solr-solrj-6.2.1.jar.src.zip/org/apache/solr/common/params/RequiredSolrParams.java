/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequiredSolrParams
/*     */   extends SolrParams
/*     */ {
/*     */   protected final SolrParams params;
/*     */   
/*     */   public RequiredSolrParams(SolrParams params)
/*     */   {
/*  40 */     this.params = params;
/*     */   }
/*     */   
/*     */ 
/*     */   public String get(String param)
/*     */   {
/*  46 */     String val = this.params.get(param);
/*  47 */     if (val == null) {
/*  48 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Missing required parameter: " + param);
/*     */     }
/*  50 */     return val;
/*     */   }
/*     */   
/*     */   public String getFieldParam(String field, String param)
/*     */   {
/*  55 */     String fpname = fpname(field, param);
/*  56 */     String val = this.params.get(fpname);
/*  57 */     if (null == val)
/*     */     {
/*  59 */       val = this.params.get(param);
/*  60 */       if (null == val) {
/*  61 */         throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Missing required parameter: " + fpname + " (or default: " + param + ")");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  66 */     return val;
/*     */   }
/*     */   
/*     */   public String[] getFieldParams(String field, String param)
/*     */   {
/*  71 */     String fpname = fpname(field, param);
/*  72 */     String[] val = this.params.getParams(fpname);
/*  73 */     if (null == val)
/*     */     {
/*  75 */       val = this.params.getParams(param);
/*  76 */       if (null == val) {
/*  77 */         throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Missing required parameter: " + fpname + " (or default: " + param + ")");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  82 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getParams(String param)
/*     */   {
/*  88 */     String[] vals = this.params.getParams(param);
/*  89 */     if ((vals == null) || (vals.length == 0)) {
/*  90 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Missing required parameter: " + param);
/*     */     }
/*  92 */     return vals;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator<String> getParameterNamesIterator()
/*     */   {
/*  98 */     return this.params.getParameterNamesIterator();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 103 */     return "{required(" + this.params + ")}";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String param, String def)
/*     */   {
/* 113 */     return this.params.get(param, def);
/*     */   }
/*     */   
/*     */   public int getInt(String param, int def)
/*     */   {
/* 118 */     return this.params.getInt(param, def);
/*     */   }
/*     */   
/*     */   public float getFloat(String param, float def)
/*     */   {
/* 123 */     return this.params.getFloat(param, def);
/*     */   }
/*     */   
/*     */   public boolean getBool(String param, boolean def)
/*     */   {
/* 128 */     return this.params.getBool(param, def);
/*     */   }
/*     */   
/*     */   public int getFieldInt(String field, String param, int def)
/*     */   {
/* 133 */     return this.params.getFieldInt(field, param, def);
/*     */   }
/*     */   
/*     */   public boolean getFieldBool(String field, String param, boolean def)
/*     */   {
/* 138 */     return this.params.getFieldBool(field, param, def);
/*     */   }
/*     */   
/*     */   public float getFieldFloat(String field, String param, float def)
/*     */   {
/* 143 */     return this.params.getFieldFloat(field, param, def);
/*     */   }
/*     */   
/*     */   public String getFieldParam(String field, String param, String def)
/*     */   {
/* 148 */     return this.params.getFieldParam(field, param, def);
/*     */   }
/*     */   
/*     */   public void check(String... params) {
/* 152 */     for (String param : params) get(param);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\RequiredSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */