/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.UUID;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Metric
/*    */   implements Expressible
/*    */ {
/* 30 */   private UUID metricNodeId = UUID.randomUUID();
/*    */   private String functionName;
/*    */   private String identifier;
/*    */   
/*    */   public String getFunctionName() {
/* 35 */     return this.functionName;
/*    */   }
/*    */   
/*    */   public void setFunctionName(String functionName) {
/* 39 */     this.functionName = functionName;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 43 */     return this.identifier;
/*    */   }
/*    */   
/* 46 */   public void setIdentifier(String identifier) { this.identifier = identifier; }
/*    */   
/*    */   public void setIdentifier(String... identifierParts) {
/* 49 */     StringBuilder sb = new StringBuilder();
/* 50 */     for (String part : identifierParts) {
/* 51 */       sb.append(part);
/*    */     }
/* 53 */     this.identifier = sb.toString();
/*    */   }
/*    */   
/*    */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*    */   {
/* 58 */     return 
/*    */     
/*    */ 
/*    */ 
/* 62 */       new Explanation(getMetricNodeId().toString()).withFunctionName(this.functionName).withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString()).withExpressionType("metric");
/*    */   }
/*    */   
/*    */   public UUID getMetricNodeId() {
/* 66 */     return this.metricNodeId;
/*    */   }
/*    */   
/*    */   public abstract Number getValue();
/*    */   
/*    */   public abstract void update(Tuple paramTuple);
/*    */   
/*    */   public abstract Metric newInstance();
/*    */   
/*    */   public abstract String[] getColumns();
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\Metric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */