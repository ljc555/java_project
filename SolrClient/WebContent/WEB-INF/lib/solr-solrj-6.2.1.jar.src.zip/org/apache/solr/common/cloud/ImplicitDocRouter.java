/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.SolrInputDocument;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitDocRouter
/*    */   extends DocRouter
/*    */ {
/*    */   public static final String NAME = "implicit";
/*    */   
/*    */   public Slice getTargetSlice(String id, SolrInputDocument sdoc, String route, SolrParams params, DocCollection collection)
/*    */   {
/* 36 */     String shard = null;
/*    */     
/* 38 */     if (route != null) {
/* 39 */       shard = route;
/* 40 */     } else if (sdoc != null) {
/* 41 */       String f = getRouteField(collection);
/* 42 */       if (f != null) {
/* 43 */         Object o = sdoc.getFieldValue(f);
/* 44 */         if (o != null) shard = o.toString(); else
/* 45 */           throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "No value for field " + f + " in " + sdoc);
/*    */       }
/* 47 */       if (shard == null) {
/* 48 */         Object o = sdoc.getFieldValue("_route_");
/* 49 */         if (o != null) {
/* 50 */           shard = o.toString();
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 55 */     if (shard == null) {
/* 56 */       shard = params.get("_route_");
/*    */     }
/*    */     
/* 59 */     if (shard != null)
/*    */     {
/* 61 */       Slice slice = collection.getSlice(shard);
/* 62 */       if (slice == null) {
/* 63 */         throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "No shard called =" + shard + " in " + collection);
/*    */       }
/* 65 */       return slice;
/*    */     }
/*    */     
/* 68 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isTargetSlice(String id, SolrInputDocument sdoc, SolrParams params, String shardId, DocCollection collection)
/*    */   {
/* 75 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public Collection<Slice> getSearchSlicesSingle(String shardKey, SolrParams params, DocCollection collection)
/*    */   {
/* 81 */     if (shardKey == null) {
/* 82 */       return collection.getActiveSlices();
/*    */     }
/*    */     
/*    */ 
/* 86 */     Slice slice = collection.getSlice(shardKey);
/* 87 */     if (slice == null) {
/* 88 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "implicit router can't find shard " + shardKey + " in collection " + collection.getName());
/*    */     }
/*    */     
/* 91 */     return Collections.singleton(slice);
/*    */   }
/*    */   
/*    */   public List<DocRouter.Range> partitionRange(int partitions, DocRouter.Range range)
/*    */   {
/* 96 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ImplicitDocRouter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */