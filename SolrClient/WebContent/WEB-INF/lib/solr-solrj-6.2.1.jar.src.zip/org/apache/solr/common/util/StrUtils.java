/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrUtils
/*     */ {
/*  33 */   public static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> splitSmart(String s, char separator)
/*     */   {
/*  42 */     ArrayList<String> lst = new ArrayList(4);
/*  43 */     int pos = 0;int start = 0;int end = s.length();
/*  44 */     char inString = '\000';
/*  45 */     char ch = '\000';
/*  46 */     while (pos < end) {
/*  47 */       char prevChar = ch;
/*  48 */       ch = s.charAt(pos++);
/*  49 */       if (ch == '\\') {
/*  50 */         pos++;
/*  51 */       } else if ((inString != 0) && (ch == inString)) {
/*  52 */         inString = '\000';
/*  53 */       } else if ((ch == '\'') || (ch == '"'))
/*     */       {
/*     */ 
/*     */ 
/*  57 */         if (!Character.isLetterOrDigit(prevChar)) {
/*  58 */           inString = ch;
/*     */         }
/*  60 */       } else if ((ch == separator) && (inString == 0)) {
/*  61 */         lst.add(s.substring(start, pos - 1));
/*  62 */         start = pos;
/*     */       }
/*     */     }
/*  65 */     if (start < end) {
/*  66 */       lst.add(s.substring(start, end));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */     return lst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> splitSmart(String s, String separator, boolean decode)
/*     */   {
/*  89 */     ArrayList<String> lst = new ArrayList(2);
/*  90 */     StringBuilder sb = new StringBuilder();
/*  91 */     int pos = 0;int end = s.length();
/*  92 */     while (pos < end) {
/*  93 */       if (s.startsWith(separator, pos)) {
/*  94 */         if (sb.length() > 0) {
/*  95 */           lst.add(sb.toString());
/*  96 */           sb = new StringBuilder();
/*     */         }
/*  98 */         pos += separator.length();
/*     */       }
/*     */       else
/*     */       {
/* 102 */         char ch = s.charAt(pos++);
/* 103 */         if (ch == '\\') {
/* 104 */           if (!decode) sb.append(ch);
/* 105 */           if (pos >= end) break;
/* 106 */           ch = s.charAt(pos++);
/* 107 */           if (decode) {
/* 108 */             switch (ch) {
/* 109 */             case 'n':  ch = '\n'; break;
/* 110 */             case 't':  ch = '\t'; break;
/* 111 */             case 'r':  ch = '\r'; break;
/* 112 */             case 'b':  ch = '\b'; break;
/* 113 */             case 'f':  ch = '\f';
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 118 */         sb.append(ch);
/*     */       }
/*     */     }
/* 121 */     if (sb.length() > 0) {
/* 122 */       lst.add(sb.toString());
/*     */     }
/*     */     
/* 125 */     return lst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> splitFileNames(String fileNames)
/*     */   {
/* 136 */     if (fileNames == null) {
/* 137 */       return Collections.emptyList();
/*     */     }
/* 139 */     List<String> result = new ArrayList();
/* 140 */     for (String file : fileNames.split("(?<!\\\\),")) {
/* 141 */       result.add(file.replaceAll("\\\\(?=,)", ""));
/*     */     }
/*     */     
/* 144 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String join(Collection<?> items, char separator)
/*     */   {
/* 152 */     if (items == null) return "";
/* 153 */     StringBuilder sb = new StringBuilder(items.size() << 3);
/* 154 */     boolean first = true;
/* 155 */     for (Object o : items) {
/* 156 */       String item = String.valueOf(o);
/* 157 */       if (first) {
/* 158 */         first = false;
/*     */       } else {
/* 160 */         sb.append(separator);
/*     */       }
/* 162 */       appendEscapedTextToBuilder(sb, item, separator);
/*     */     }
/* 164 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<String> splitWS(String s, boolean decode)
/*     */   {
/* 170 */     ArrayList<String> lst = new ArrayList(2);
/* 171 */     StringBuilder sb = new StringBuilder();
/* 172 */     int pos = 0;int end = s.length();
/* 173 */     while (pos < end) {
/* 174 */       char ch = s.charAt(pos++);
/* 175 */       if (Character.isWhitespace(ch)) {
/* 176 */         if (sb.length() > 0) {
/* 177 */           lst.add(sb.toString());
/* 178 */           sb = new StringBuilder();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 183 */         if (ch == '\\') {
/* 184 */           if (!decode) sb.append(ch);
/* 185 */           if (pos >= end) break;
/* 186 */           ch = s.charAt(pos++);
/* 187 */           if (decode) {
/* 188 */             switch (ch) {
/* 189 */             case 'n':  ch = '\n'; break;
/* 190 */             case 't':  ch = '\t'; break;
/* 191 */             case 'r':  ch = '\r'; break;
/* 192 */             case 'b':  ch = '\b'; break;
/* 193 */             case 'f':  ch = '\f';
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 198 */         sb.append(ch);
/*     */       }
/*     */     }
/* 201 */     if (sb.length() > 0) {
/* 202 */       lst.add(sb.toString());
/*     */     }
/*     */     
/* 205 */     return lst;
/*     */   }
/*     */   
/*     */   public static List<String> toLower(List<String> strings) {
/* 209 */     ArrayList<String> ret = new ArrayList(strings.size());
/* 210 */     for (String str : strings) {
/* 211 */       ret.add(str.toLowerCase(Locale.ROOT));
/*     */     }
/* 213 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean parseBoolean(String s)
/*     */   {
/* 222 */     char ch = s.length() > 0 ? s.charAt(0) : '\000';
/* 223 */     return (ch == '1') || (ch == 't') || (ch == 'T');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean parseBool(String s)
/*     */   {
/* 230 */     if (s != null) {
/* 231 */       if ((s.startsWith("true")) || (s.startsWith("on")) || (s.startsWith("yes"))) {
/* 232 */         return true;
/*     */       }
/* 234 */       if ((s.startsWith("false")) || (s.startsWith("off")) || (s.equals("no"))) {
/* 235 */         return false;
/*     */       }
/*     */     }
/* 238 */     throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "invalid boolean value: " + s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean parseBool(String s, boolean def)
/*     */   {
/* 246 */     if (s != null) {
/* 247 */       if ((s.startsWith("true")) || (s.startsWith("on")) || (s.startsWith("yes"))) {
/* 248 */         return true;
/*     */       }
/* 250 */       if ((s.startsWith("false")) || (s.startsWith("off")) || (s.equals("no"))) {
/* 251 */         return false;
/*     */       }
/*     */     }
/* 254 */     return def;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void partialURLEncodeVal(Appendable dest, String val)
/*     */     throws IOException
/*     */   {
/* 265 */     for (int i = 0; i < val.length(); i++) {
/* 266 */       char ch = val.charAt(i);
/* 267 */       if (ch < ' ') {
/* 268 */         dest.append('%');
/* 269 */         if (ch < '\020') dest.append('0');
/* 270 */         dest.append(Integer.toHexString(ch));
/*     */       } else {
/* 272 */         switch (ch) {
/* 273 */         case ' ':  dest.append('+'); break;
/* 274 */         case '&':  dest.append("%26"); break;
/* 275 */         case '%':  dest.append("%25"); break;
/* 276 */         case '=':  dest.append("%3D"); break;
/* 277 */         case '+':  dest.append("%2B"); break;
/* 278 */         default:  dest.append(ch);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String escapeTextWithSeparator(String item, char separator)
/*     */   {
/* 289 */     StringBuilder sb = new StringBuilder(item.length() * 2);
/* 290 */     appendEscapedTextToBuilder(sb, item, separator);
/* 291 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void appendEscapedTextToBuilder(StringBuilder out, String item, char separator)
/*     */   {
/* 301 */     for (int i = 0; i < item.length(); i++) {
/* 302 */       char ch = item.charAt(i);
/* 303 */       if ((ch == '\\') || (ch == separator)) {
/* 304 */         out.append('\\');
/*     */       }
/* 306 */       out.append(ch);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static String formatString(String pattern, Object... args)
/*     */   {
/* 313 */     return new MessageFormat(pattern, Locale.ROOT).format(args);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\StrUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */