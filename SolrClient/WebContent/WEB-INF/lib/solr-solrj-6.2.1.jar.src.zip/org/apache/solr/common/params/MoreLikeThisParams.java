/*    */ package org.apache.solr.common.params;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface MoreLikeThisParams
/*    */ {
/*    */   public static final String MLT = "mlt";
/*    */   public static final String PREFIX = "mlt.";
/*    */   public static final String SIMILARITY_FIELDS = "mlt.fl";
/*    */   public static final String MIN_TERM_FREQ = "mlt.mintf";
/*    */   public static final String MAX_DOC_FREQ = "mlt.maxdf";
/*    */   public static final String MIN_DOC_FREQ = "mlt.mindf";
/*    */   public static final String MIN_WORD_LEN = "mlt.minwl";
/*    */   public static final String MAX_WORD_LEN = "mlt.maxwl";
/*    */   public static final String MAX_QUERY_TERMS = "mlt.maxqt";
/*    */   public static final String MAX_NUM_TOKENS_PARSED = "mlt.maxntp";
/*    */   public static final String BOOST = "mlt.boost";
/*    */   public static final String QF = "mlt.qf";
/*    */   public static final String DOC_COUNT = "mlt.count";
/*    */   public static final String MATCH_INCLUDE = "mlt.match.include";
/*    */   public static final String MATCH_OFFSET = "mlt.match.offset";
/*    */   public static final String INTERESTING_TERMS = "mlt.interestingTerms";
/*    */   
/*    */   public static enum TermStyle
/*    */   {
/* 55 */     NONE, 
/* 56 */     LIST, 
/* 57 */     DETAILS;
/*    */     
/*    */     private TermStyle() {}
/*    */     
/* 61 */     public static TermStyle get(String p) { if (p != null) {
/* 62 */         p = p.toUpperCase(Locale.ROOT);
/* 63 */         if (p.equals("DETAILS")) {
/* 64 */           return DETAILS;
/*    */         }
/* 66 */         if (p.equals("LIST")) {
/* 67 */           return LIST;
/*    */         }
/*    */       }
/* 70 */       return NONE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\MoreLikeThisParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */