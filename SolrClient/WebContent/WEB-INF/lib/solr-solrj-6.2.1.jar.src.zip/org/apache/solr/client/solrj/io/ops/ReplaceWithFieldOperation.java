/*     */ package org.apache.solr.client.solrj.io.ops;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplaceWithFieldOperation
/*     */   implements StreamOperation
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   private UUID operationNodeId = UUID.randomUUID();
/*     */   private boolean wasBuiltWithFieldName;
/*     */   private String originalFieldName;
/*     */   private Object originalValue;
/*     */   private String replacementFieldName;
/*     */   
/*     */   public ReplaceWithFieldOperation(String forField, StreamExpression expression, StreamFactory factory)
/*     */     throws IOException
/*     */   {
/*  48 */     if (2 == expression.getParameters().size()) {
/*  49 */       this.wasBuiltWithFieldName = false;
/*     */       
/*  51 */       this.originalFieldName = forField;
/*  52 */       this.originalValue = factory.constructPrimitiveObject(factory.getValueOperand(expression, 0));
/*     */ 
/*     */     }
/*  55 */     else if (3 == expression.getParameters().size()) {
/*  56 */       this.wasBuiltWithFieldName = true;
/*     */       
/*  58 */       this.originalFieldName = factory.getValueOperand(expression, 0);
/*  59 */       this.originalValue = factory.constructPrimitiveObject(factory.getValueOperand(expression, 1));
/*     */     }
/*     */     else {
/*  62 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  65 */     StreamExpressionNamedParameter replacementParameter = factory.getNamedOperand(expression, "withField");
/*  66 */     if (null == replacementParameter) {
/*  67 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a parameter named 'withField' but didn't find one.", new Object[] { expression }));
/*     */     }
/*  69 */     if (!(replacementParameter.getParameter() instanceof StreamExpressionValue)) {
/*  70 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting parameter named 'withField' to be a field name.", new Object[] { expression }));
/*     */     }
/*     */     
/*  73 */     this.replacementFieldName = ((StreamExpressionValue)replacementParameter.getParameter()).getValue();
/*     */   }
/*     */   
/*     */   public void operate(Tuple tuple)
/*     */   {
/*  78 */     if (matchesOriginal(tuple)) {
/*  79 */       replace(tuple);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean matchesOriginal(Tuple tuple) {
/*  84 */     Object value = tuple.get(this.originalFieldName);
/*     */     
/*  86 */     if (null == value) {
/*  87 */       return null == this.originalValue;
/*     */     }
/*  89 */     if (null != this.originalValue) {
/*  90 */       return this.originalValue.equals(value);
/*     */     }
/*     */     
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   private void replace(Tuple tuple) {
/*  97 */     tuple.put(this.originalFieldName, tuple.get(this.replacementFieldName));
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 103 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/* 105 */     if (this.wasBuiltWithFieldName) {
/* 106 */       expression.addParameter(this.originalFieldName);
/*     */     }
/*     */     
/* 109 */     expression.addParameter(null == this.originalValue ? "null" : this.originalValue.toString());
/* 110 */     expression.addParameter(new StreamExpressionNamedParameter("withField", this.replacementFieldName));
/*     */     
/* 112 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/* 117 */     return 
/*     */     
/*     */ 
/*     */ 
/* 121 */       new Explanation(this.operationNodeId.toString()).withExpressionType("operation").withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\ReplaceWithFieldOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */