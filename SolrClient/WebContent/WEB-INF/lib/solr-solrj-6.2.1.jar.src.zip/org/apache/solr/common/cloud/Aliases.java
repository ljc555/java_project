/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Aliases
/*    */ {
/*    */   private Map<String, Map<String, String>> aliasMap;
/*    */   
/*    */   public Aliases(Map<String, Map<String, String>> aliasMap)
/*    */   {
/* 28 */     this.aliasMap = aliasMap;
/*    */   }
/*    */   
/*    */   public Aliases() {
/* 32 */     this.aliasMap = new HashMap();
/*    */   }
/*    */   
/*    */   public Map<String, String> getCollectionAliasMap() {
/* 36 */     Map<String, String> cam = (Map)this.aliasMap.get("collection");
/* 37 */     if (cam == null) return null;
/* 38 */     return Collections.unmodifiableMap(cam);
/*    */   }
/*    */   
/*    */   public Map<String, Map<String, String>> getAliasMap() {
/* 42 */     return Collections.unmodifiableMap(this.aliasMap);
/*    */   }
/*    */   
/*    */   public int collectionAliasSize() {
/* 46 */     Map<String, String> cam = (Map)this.aliasMap.get("collection");
/* 47 */     if (cam == null) return 0;
/* 48 */     return cam.size();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 53 */     return "Aliases [aliasMap=" + this.aliasMap + "]";
/*    */   }
/*    */   
/*    */   public String getCollectionAlias(String collectionName) {
/* 57 */     Map<String, String> cam = (Map)this.aliasMap.get("collection");
/* 58 */     if (cam == null) return null;
/* 59 */     return (String)cam.get(collectionName);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\Aliases.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */