/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZkCoreNodeProps
/*    */ {
/*    */   private ZkNodeProps nodeProps;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ZkCoreNodeProps(ZkNodeProps nodeProps)
/*    */   {
/* 23 */     this.nodeProps = nodeProps;
/*    */   }
/*    */   
/*    */   public String getCoreUrl() {
/* 27 */     return getCoreUrl(this.nodeProps.getStr("base_url"), this.nodeProps.getStr("core"));
/*    */   }
/*    */   
/*    */   public String getNodeName() {
/* 31 */     return this.nodeProps.getStr("node_name");
/*    */   }
/*    */   
/*    */   public String getState() {
/* 35 */     return this.nodeProps.getStr("state");
/*    */   }
/*    */   
/*    */   public String getBaseUrl() {
/* 39 */     return this.nodeProps.getStr("base_url");
/*    */   }
/*    */   
/*    */   public String getCoreName() {
/* 43 */     return this.nodeProps.getStr("core");
/*    */   }
/*    */   
/*    */   public static String getCoreUrl(ZkNodeProps nodeProps) {
/* 47 */     return getCoreUrl(nodeProps.getStr("base_url"), nodeProps.getStr("core"));
/*    */   }
/*    */   
/*    */   public static String getCoreUrl(String baseUrl, String coreName) {
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     sb.append(baseUrl);
/* 53 */     if (!baseUrl.endsWith("/")) sb.append("/");
/* 54 */     sb.append(coreName);
/* 55 */     if (!sb.substring(sb.length() - 1).equals("/")) sb.append("/");
/* 56 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 61 */     return this.nodeProps.toString();
/*    */   }
/*    */   
/*    */   public ZkNodeProps getNodeProps() {
/* 65 */     return this.nodeProps;
/*    */   }
/*    */   
/*    */   public boolean isLeader() {
/* 69 */     return this.nodeProps.containsKey("leader");
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkCoreNodeProps.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */