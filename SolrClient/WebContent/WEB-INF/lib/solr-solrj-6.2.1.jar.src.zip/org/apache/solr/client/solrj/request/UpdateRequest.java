/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.impl.LBHttpSolrClient.Req;
/*     */ import org.apache.solr.client.solrj.response.UpdateResponse;
/*     */ import org.apache.solr.client.solrj.util.ClientUtils;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.cloud.DocCollection;
/*     */ import org.apache.solr.common.cloud.DocRouter;
/*     */ import org.apache.solr.common.cloud.Slice;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ import org.apache.solr.common.util.XML;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateRequest
/*     */   extends AbstractUpdateRequest
/*     */ {
/*     */   public static final String REPFACT = "rf";
/*     */   public static final String MIN_REPFACT = "min_rf";
/*     */   public static final String VER = "ver";
/*     */   public static final String ROUTE = "_route_";
/*     */   public static final String OVERWRITE = "ow";
/*     */   public static final String COMMIT_WITHIN = "cw";
/*  60 */   private Map<SolrInputDocument, Map<String, Object>> documents = null;
/*  61 */   private Iterator<SolrInputDocument> docIterator = null;
/*  62 */   private Map<String, Map<String, Object>> deleteById = null;
/*  63 */   private List<String> deleteQuery = null;
/*     */   
/*  65 */   private boolean isLastDocInBatch = false;
/*     */   
/*     */   public UpdateRequest() {
/*  68 */     super(SolrRequest.METHOD.POST, "/update");
/*     */   }
/*     */   
/*     */   public UpdateRequest(String url) {
/*  72 */     super(SolrRequest.METHOD.POST, url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  82 */     if (this.documents != null) {
/*  83 */       this.documents.clear();
/*     */     }
/*  85 */     if (this.deleteById != null) {
/*  86 */       this.deleteById.clear();
/*     */     }
/*  88 */     if (this.deleteQuery != null) {
/*  89 */       this.deleteQuery.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest add(SolrInputDocument doc)
/*     */   {
/* 102 */     Objects.requireNonNull(doc, "Cannot add a null SolrInputDocument");
/* 103 */     if (this.documents == null) {
/* 104 */       this.documents = new LinkedHashMap();
/*     */     }
/* 106 */     this.documents.put(doc, null);
/* 107 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateRequest add(String... fields) {
/* 111 */     return add(new SolrInputDocument(fields));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest add(SolrInputDocument doc, Boolean overwrite)
/*     */   {
/* 121 */     return add(doc, null, overwrite);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest add(SolrInputDocument doc, Integer commitWithin)
/*     */   {
/* 131 */     return add(doc, commitWithin, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest add(SolrInputDocument doc, Integer commitWithin, Boolean overwrite)
/*     */   {
/* 142 */     Objects.requireNonNull(doc, "Cannot add a null SolrInputDocument");
/* 143 */     if (this.documents == null) {
/* 144 */       this.documents = new LinkedHashMap();
/*     */     }
/* 146 */     Map<String, Object> params = new HashMap(2);
/* 147 */     if (commitWithin != null) params.put("cw", commitWithin);
/* 148 */     if (overwrite != null) { params.put("ow", overwrite);
/*     */     }
/* 150 */     this.documents.put(doc, params);
/*     */     
/* 152 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest add(Collection<SolrInputDocument> docs)
/*     */   {
/* 161 */     if (this.documents == null) {
/* 162 */       this.documents = new LinkedHashMap();
/*     */     }
/* 164 */     for (SolrInputDocument doc : docs) {
/* 165 */       Objects.requireNonNull(doc, "Cannot add a null SolrInputDocument");
/* 166 */       this.documents.put(doc, null);
/*     */     }
/* 168 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteById(String id) {
/* 172 */     if (this.deleteById == null) {
/* 173 */       this.deleteById = new LinkedHashMap();
/*     */     }
/* 175 */     this.deleteById.put(id, null);
/* 176 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteById(String id, String route) {
/* 180 */     return deleteById(id, route, null);
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteById(String id, String route, Long version) {
/* 184 */     if (this.deleteById == null) {
/* 185 */       this.deleteById = new LinkedHashMap();
/*     */     }
/* 187 */     Map<String, Object> params = (route == null) && (version == null) ? null : new HashMap(1);
/* 188 */     if (version != null)
/* 189 */       params.put("ver", version);
/* 190 */     if (route != null)
/* 191 */       params.put("_route_", route);
/* 192 */     this.deleteById.put(id, params);
/* 193 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteById(List<String> ids)
/*     */   {
/* 198 */     if (this.deleteById == null) {
/* 199 */       this.deleteById = new LinkedHashMap();
/*     */     }
/*     */     
/* 202 */     for (String id : ids) {
/* 203 */       this.deleteById.put(id, null);
/*     */     }
/*     */     
/* 206 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteById(String id, Long version) {
/* 210 */     return deleteById(id, null, version);
/*     */   }
/*     */   
/*     */   public UpdateRequest deleteByQuery(String q) {
/* 214 */     if (this.deleteQuery == null) {
/* 215 */       this.deleteQuery = new ArrayList();
/*     */     }
/* 217 */     this.deleteQuery.add(q);
/* 218 */     return this;
/*     */   }
/*     */   
/*     */   public UpdateResponse commit(SolrClient client, String collection) throws IOException, SolrServerException {
/* 222 */     if (this.params == null)
/* 223 */       this.params = new ModifiableSolrParams();
/* 224 */     this.params.set("commit", new String[] { "true" });
/* 225 */     return (UpdateResponse)process(client, collection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, LBHttpSolrClient.Req> getRoutes(DocRouter router, DocCollection col, Map<String, List<String>> urlMap, ModifiableSolrParams params, String idField)
/*     */   {
/* 240 */     if (((this.documents == null) || (this.documents.size() == 0)) && ((this.deleteById == null) || 
/* 241 */       (this.deleteById.size() == 0))) {
/* 242 */       return null;
/*     */     }
/*     */     
/* 245 */     Map<String, LBHttpSolrClient.Req> routes = new HashMap();
/* 246 */     if (this.documents != null) {
/* 247 */       Set<Map.Entry<SolrInputDocument, Map<String, Object>>> entries = this.documents.entrySet();
/* 248 */       for (Map.Entry<SolrInputDocument, Map<String, Object>> entry : entries) {
/* 249 */         SolrInputDocument doc = (SolrInputDocument)entry.getKey();
/* 250 */         Object id = doc.getFieldValue(idField);
/* 251 */         if (id == null) {
/* 252 */           return null;
/*     */         }
/* 254 */         Slice slice = router.getTargetSlice(id
/* 255 */           .toString(), doc, null, null, col);
/* 256 */         if (slice == null) {
/* 257 */           return null;
/*     */         }
/* 259 */         List<String> urls = (List)urlMap.get(slice.getName());
/* 260 */         if (urls == null) {
/* 261 */           return null;
/*     */         }
/* 263 */         String leaderUrl = (String)urls.get(0);
/*     */         
/* 265 */         LBHttpSolrClient.Req request = (LBHttpSolrClient.Req)routes.get(leaderUrl);
/* 266 */         if (request == null) {
/* 267 */           UpdateRequest updateRequest = new UpdateRequest();
/* 268 */           updateRequest.setMethod(getMethod());
/* 269 */           updateRequest.setCommitWithin(getCommitWithin());
/* 270 */           updateRequest.setParams(params);
/* 271 */           updateRequest.setPath(getPath());
/* 272 */           updateRequest.setBasicAuthCredentials(getBasicAuthUser(), getBasicAuthPassword());
/* 273 */           request = new LBHttpSolrClient.Req(updateRequest, urls);
/* 274 */           routes.put(leaderUrl, request);
/*     */         }
/* 276 */         UpdateRequest urequest = (UpdateRequest)request.getRequest();
/* 277 */         Map<String, Object> value = (Map)entry.getValue();
/* 278 */         Boolean ow = null;
/* 279 */         if (value != null) {
/* 280 */           ow = (Boolean)value.get("ow");
/*     */         }
/* 282 */         if (ow != null) {
/* 283 */           urequest.add(doc, ow);
/*     */         } else {
/* 285 */           urequest.add(doc);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 292 */     if (this.deleteById != null)
/*     */     {
/*     */ 
/* 295 */       Iterator<Map.Entry<String, Map<String, Object>>> entries = this.deleteById.entrySet().iterator();
/* 296 */       while (entries.hasNext())
/*     */       {
/* 298 */         Object entry = (Map.Entry)entries.next();
/*     */         
/* 300 */         String deleteId = (String)((Map.Entry)entry).getKey();
/* 301 */         Map<String, Object> map = (Map)((Map.Entry)entry).getValue();
/* 302 */         Long version = null;
/* 303 */         if (map != null) {
/* 304 */           version = (Long)map.get("ver");
/*     */         }
/* 306 */         Slice slice = router.getTargetSlice(deleteId, null, null, null, col);
/* 307 */         if (slice == null) {
/* 308 */           return null;
/*     */         }
/* 310 */         List<String> urls = (List)urlMap.get(slice.getName());
/* 311 */         if (urls == null) {
/* 312 */           return null;
/*     */         }
/* 314 */         String leaderUrl = (String)urls.get(0);
/* 315 */         LBHttpSolrClient.Req request = (LBHttpSolrClient.Req)routes.get(leaderUrl);
/* 316 */         if (request != null) {
/* 317 */           UpdateRequest urequest = (UpdateRequest)request.getRequest();
/* 318 */           urequest.deleteById(deleteId, version);
/*     */         } else {
/* 320 */           UpdateRequest urequest = new UpdateRequest();
/* 321 */           urequest.setParams(params);
/* 322 */           urequest.deleteById(deleteId, version);
/* 323 */           urequest.setCommitWithin(getCommitWithin());
/* 324 */           request = new LBHttpSolrClient.Req(urequest, urls);
/* 325 */           routes.put(leaderUrl, request);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 330 */     return routes;
/*     */   }
/*     */   
/*     */   public void setDocIterator(Iterator<SolrInputDocument> docIterator) {
/* 334 */     this.docIterator = docIterator;
/*     */   }
/*     */   
/*     */   public void setDeleteQuery(List<String> deleteQuery) {
/* 338 */     this.deleteQuery = deleteQuery;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<ContentStream> getContentStreams()
/*     */     throws IOException
/*     */   {
/* 346 */     return ClientUtils.toContentStreams(getXML(), "application/xml; charset=UTF-8");
/*     */   }
/*     */   
/*     */   public String getXML() throws IOException {
/* 350 */     StringWriter writer = new StringWriter();
/* 351 */     writeXML(writer);
/* 352 */     writer.flush();
/*     */     
/*     */ 
/* 355 */     String xml = writer.toString();
/*     */     
/* 357 */     return xml.length() > 0 ? xml : null;
/*     */   }
/*     */   
/*     */   private List<Map<SolrInputDocument, Map<String, Object>>> getDocLists(Map<SolrInputDocument, Map<String, Object>> documents) {
/* 361 */     List<Map<SolrInputDocument, Map<String, Object>>> docLists = new ArrayList();
/* 362 */     Map<SolrInputDocument, Map<String, Object>> docList = null;
/* 363 */     Boolean lastOverwrite; Integer lastCommitWithin; if (this.documents != null)
/*     */     {
/* 365 */       lastOverwrite = Boolean.valueOf(true);
/* 366 */       lastCommitWithin = Integer.valueOf(-1);
/*     */       
/*     */ 
/* 369 */       Set<Map.Entry<SolrInputDocument, Map<String, Object>>> entries = this.documents.entrySet();
/* 370 */       for (Map.Entry<SolrInputDocument, Map<String, Object>> entry : entries) {
/* 371 */         Map<String, Object> map = (Map)entry.getValue();
/* 372 */         Boolean overwrite = null;
/* 373 */         Integer commitWithin = null;
/* 374 */         if (map != null) {
/* 375 */           overwrite = (Boolean)((Map)entry.getValue()).get("ow");
/* 376 */           commitWithin = (Integer)((Map)entry.getValue()).get("cw");
/*     */         }
/* 378 */         if ((overwrite != lastOverwrite) || (commitWithin != lastCommitWithin) || 
/* 379 */           (docLists.size() == 0)) {
/* 380 */           docList = new LinkedHashMap();
/* 381 */           docLists.add(docList);
/*     */         }
/* 383 */         docList.put(entry.getKey(), entry.getValue());
/* 384 */         lastCommitWithin = commitWithin;
/* 385 */         lastOverwrite = overwrite;
/*     */       }
/*     */     }
/*     */     
/* 389 */     if (this.docIterator != null) {
/* 390 */       docList = new LinkedHashMap();
/* 391 */       docLists.add(docList);
/* 392 */       while (this.docIterator.hasNext()) {
/* 393 */         SolrInputDocument doc = (SolrInputDocument)this.docIterator.next();
/* 394 */         if (doc != null) {
/* 395 */           docList.put(doc, null);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 401 */     return docLists;
/*     */   }
/*     */   
/*     */ 
/*     */   public UpdateRequest writeXML(Writer writer)
/*     */     throws IOException
/*     */   {
/* 408 */     List<Map<SolrInputDocument, Map<String, Object>>> getDocLists = getDocLists(this.documents);
/*     */     
/* 410 */     for (Map<SolrInputDocument, Map<String, Object>> docs : getDocLists)
/*     */     {
/* 412 */       if ((docs != null) && (docs.size() > 0))
/*     */       {
/* 414 */         firstDoc = (Map.Entry)docs.entrySet().iterator().next();
/* 415 */         Map<String, Object> map = (Map)firstDoc.getValue();
/* 416 */         Integer cw = null;
/* 417 */         Boolean ow = null;
/* 418 */         if (map != null) {
/* 419 */           cw = (Integer)((Map)firstDoc.getValue()).get("cw");
/* 420 */           ow = (Boolean)((Map)firstDoc.getValue()).get("ow");
/*     */         }
/* 422 */         if (ow == null) ow = Boolean.valueOf(true);
/* 423 */         int commitWithin = (cw != null) && (cw.intValue() != -1) ? cw.intValue() : this.commitWithin;
/* 424 */         boolean overwrite = ow.booleanValue();
/* 425 */         if ((commitWithin > -1) || (overwrite != true)) {
/* 426 */           writer.write("<add commitWithin=\"" + commitWithin + "\" overwrite=\"" + overwrite + "\">");
/*     */         }
/*     */         else {
/* 429 */           writer.write("<add>");
/*     */         }
/*     */         
/*     */ 
/* 433 */         Set<Map.Entry<SolrInputDocument, Map<String, Object>>> entries = docs.entrySet();
/* 434 */         for (Map.Entry<SolrInputDocument, Map<String, Object>> entry : entries) {
/* 435 */           ClientUtils.writeXML((SolrInputDocument)entry.getKey(), writer);
/*     */         }
/*     */         
/* 438 */         writer.write("</add>");
/*     */       }
/*     */     }
/*     */     
/*     */     Map.Entry<SolrInputDocument, Map<String, Object>> firstDoc;
/* 443 */     boolean deleteI = (this.deleteById != null) && (this.deleteById.size() > 0);
/* 444 */     boolean deleteQ = (this.deleteQuery != null) && (this.deleteQuery.size() > 0);
/* 445 */     if ((deleteI) || (deleteQ)) {
/* 446 */       if (this.commitWithin > 0) {
/* 447 */         writer.append("<delete commitWithin=\"" + this.commitWithin + "\">");
/*     */       } else {
/* 449 */         writer.append("<delete>");
/*     */       }
/* 451 */       if (deleteI) {
/* 452 */         for (Map.Entry<String, Map<String, Object>> entry : this.deleteById.entrySet()) {
/* 453 */           writer.append("<id");
/* 454 */           Map<String, Object> map = (Map)entry.getValue();
/* 455 */           if (map != null) {
/* 456 */             Long version = (Long)map.get("ver");
/* 457 */             String route = (String)map.get("_route_");
/* 458 */             if (version != null) {
/* 459 */               writer.append(" version=\"" + version + "\"");
/*     */             }
/*     */             
/* 462 */             if (route != null) {
/* 463 */               writer.append(" _route_=\"" + route + "\"");
/*     */             }
/*     */           }
/* 466 */           writer.append(">");
/*     */           
/* 468 */           XML.escapeCharData((String)entry.getKey(), writer);
/* 469 */           writer.append("</id>");
/*     */         }
/*     */       }
/* 472 */       if (deleteQ) {
/* 473 */         for (String q : this.deleteQuery) {
/* 474 */           writer.append("<query>");
/* 475 */           XML.escapeCharData(q, writer);
/* 476 */           writer.append("</query>");
/*     */         }
/*     */       }
/* 479 */       writer.append("</delete>");
/*     */     }
/* 481 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<SolrInputDocument> getDocuments()
/*     */   {
/* 492 */     if (this.documents == null) return null;
/* 493 */     List<SolrInputDocument> docs = new ArrayList(this.documents.size());
/* 494 */     docs.addAll(this.documents.keySet());
/* 495 */     return docs;
/*     */   }
/*     */   
/*     */   public Map<SolrInputDocument, Map<String, Object>> getDocumentsMap() {
/* 499 */     return this.documents;
/*     */   }
/*     */   
/*     */   public Iterator<SolrInputDocument> getDocIterator() {
/* 503 */     return this.docIterator;
/*     */   }
/*     */   
/*     */   public List<String> getDeleteById() {
/* 507 */     if (this.deleteById == null) return null;
/* 508 */     List<String> deletes = new ArrayList(this.deleteById.keySet());
/* 509 */     return deletes;
/*     */   }
/*     */   
/*     */   public Map<String, Map<String, Object>> getDeleteByIdMap() {
/* 513 */     return this.deleteById;
/*     */   }
/*     */   
/*     */   public List<String> getDeleteQuery() {
/* 517 */     return this.deleteQuery;
/*     */   }
/*     */   
/*     */   public boolean isLastDocInBatch() {
/* 521 */     return this.isLastDocInBatch;
/*     */   }
/*     */   
/*     */   public void lastDocInBatch() {
/* 525 */     this.isLastDocInBatch = true;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\UpdateRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */