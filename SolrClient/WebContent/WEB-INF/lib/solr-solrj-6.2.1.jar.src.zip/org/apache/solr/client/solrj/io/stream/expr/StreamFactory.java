/*     */ package org.apache.solr.client.solrj.io.stream.expr;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.client.solrj.io.comp.ComparatorOrder;
/*     */ import org.apache.solr.client.solrj.io.comp.MultipleFieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.MultipleFieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.ops.StreamOperation;
/*     */ import org.apache.solr.client.solrj.io.stream.TupleStream;
/*     */ import org.apache.solr.client.solrj.io.stream.metrics.Metric;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamFactory
/*     */   implements Serializable
/*     */ {
/*     */   private transient HashMap<String, String> collectionZkHosts;
/*     */   private transient HashMap<String, Class> functionNames;
/*     */   private transient String defaultZkHost;
/*     */   
/*     */   public StreamFactory()
/*     */   {
/*  49 */     this.collectionZkHosts = new HashMap();
/*  50 */     this.functionNames = new HashMap();
/*     */   }
/*     */   
/*     */   public StreamFactory withCollectionZkHost(String collectionName, String zkHost) {
/*  54 */     this.collectionZkHosts.put(collectionName, zkHost);
/*  55 */     return this;
/*     */   }
/*     */   
/*     */   public StreamFactory withDefaultZkHost(String zkHost) {
/*  59 */     this.defaultZkHost = zkHost;
/*  60 */     return this;
/*     */   }
/*     */   
/*     */   public String getDefaultZkHost() {
/*  64 */     return this.defaultZkHost;
/*     */   }
/*     */   
/*     */   public String getCollectionZkHost(String collectionName) {
/*  68 */     if (this.collectionZkHosts.containsKey(collectionName)) {
/*  69 */       return (String)this.collectionZkHosts.get(collectionName);
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */   
/*     */ 
/*  75 */   public Map<String, Class> getFunctionNames() { return this.functionNames; }
/*     */   
/*     */   public StreamFactory withFunctionName(String functionName, Class clazz) {
/*  78 */     this.functionNames.put(functionName, clazz);
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter getOperand(StreamExpression expression, int parameterIndex) {
/*  83 */     if ((null == expression.getParameters()) || (parameterIndex >= expression.getParameters().size())) {
/*  84 */       return null;
/*     */     }
/*     */     
/*  87 */     return (StreamExpressionParameter)expression.getParameters().get(parameterIndex);
/*     */   }
/*     */   
/*     */   public String getValueOperand(StreamExpression expression, int parameterIndex)
/*     */   {
/*  92 */     StreamExpressionParameter parameter = getOperand(expression, parameterIndex);
/*  93 */     if ((null != parameter) && 
/*  94 */       ((parameter instanceof StreamExpressionValue))) {
/*  95 */       return ((StreamExpressionValue)parameter).getValue();
/*     */     }
/*     */     
/*     */ 
/*  99 */     return null;
/*     */   }
/*     */   
/*     */   public List<StreamExpressionNamedParameter> getNamedOperands(StreamExpression expression) {
/* 103 */     List<StreamExpressionNamedParameter> namedParameters = new ArrayList();
/* 104 */     for (StreamExpressionParameter parameter : getOperandsOfType(expression, new Class[] { StreamExpressionNamedParameter.class })) {
/* 105 */       namedParameters.add((StreamExpressionNamedParameter)parameter);
/*     */     }
/*     */     
/* 108 */     return namedParameters;
/*     */   }
/*     */   
/* 111 */   public StreamExpressionNamedParameter getNamedOperand(StreamExpression expression, String name) { List<StreamExpressionNamedParameter> namedParameters = getNamedOperands(expression);
/* 112 */     for (StreamExpressionNamedParameter param : namedParameters) {
/* 113 */       if (param.getName().equals(name)) {
/* 114 */         return param;
/*     */       }
/*     */     }
/*     */     
/* 118 */     return null;
/*     */   }
/*     */   
/*     */   public List<StreamExpression> getExpressionOperands(StreamExpression expression) {
/* 122 */     List<StreamExpression> namedParameters = new ArrayList();
/* 123 */     for (StreamExpressionParameter parameter : getOperandsOfType(expression, new Class[] { StreamExpression.class })) {
/* 124 */       namedParameters.add((StreamExpression)parameter);
/*     */     }
/*     */     
/* 127 */     return namedParameters;
/*     */   }
/*     */   
/* 130 */   public List<StreamExpression> getExpressionOperands(StreamExpression expression, String functionName) { List<StreamExpression> namedParameters = new ArrayList();
/* 131 */     for (StreamExpressionParameter parameter : getOperandsOfType(expression, new Class[] { StreamExpression.class })) {
/* 132 */       StreamExpression expressionOperand = (StreamExpression)parameter;
/* 133 */       if (expressionOperand.getFunctionName().equals(functionName)) {
/* 134 */         namedParameters.add(expressionOperand);
/*     */       }
/*     */     }
/*     */     
/* 138 */     return namedParameters;
/*     */   }
/*     */   
/* 141 */   public List<StreamExpressionParameter> getOperandsOfType(StreamExpression expression, Class... clazzes) { List<StreamExpressionParameter> parameters = new ArrayList();
/*     */     
/*     */ 
/* 144 */     for (StreamExpressionParameter parameter : expression.getParameters()) {
/* 145 */       Class[] arrayOfClass = clazzes;int i = arrayOfClass.length; for (int j = 0;; j++) { if (j >= i) break label88; Class clazz = arrayOfClass[j];
/* 146 */         if (!clazz.isAssignableFrom(parameter.getClass())) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 151 */       parameters.add(parameter);
/*     */     }
/*     */     label88:
/* 154 */     return parameters;
/*     */   }
/*     */   
/*     */   public List<StreamExpression> getExpressionOperandsRepresentingTypes(StreamExpression expression, Class... clazzes) {
/* 158 */     List<StreamExpression> matchingStreamExpressions = new ArrayList();
/* 159 */     List<StreamExpression> allStreamExpressions = getExpressionOperands(expression);
/*     */     
/*     */ 
/* 162 */     for (StreamExpression streamExpression : allStreamExpressions) {
/* 163 */       if (this.functionNames.containsKey(streamExpression.getFunctionName())) {
/* 164 */         Class[] arrayOfClass = clazzes;int i = arrayOfClass.length; for (int j = 0;; j++) { if (j >= i) break label118; Class clazz = arrayOfClass[j];
/* 165 */           if (!clazz.isAssignableFrom((Class)this.functionNames.get(streamExpression.getFunctionName()))) {
/*     */             break;
/*     */           }
/*     */         }
/*     */         
/* 170 */         matchingStreamExpressions.add(streamExpression);
/*     */       }
/*     */     }
/*     */     label118:
/* 174 */     return matchingStreamExpressions;
/*     */   }
/*     */   
/*     */ 
/* 178 */   public TupleStream constructStream(String expressionClause) throws IOException { return constructStream(StreamExpressionParser.parse(expressionClause)); }
/*     */   
/*     */   public TupleStream constructStream(StreamExpression expression) throws IOException {
/* 181 */     String function = expression.getFunctionName();
/* 182 */     if (this.functionNames.containsKey(function)) {
/* 183 */       Class clazz = (Class)this.functionNames.get(function);
/* 184 */       if ((Expressible.class.isAssignableFrom(clazz)) && (TupleStream.class.isAssignableFrom(clazz))) {
/* 185 */         TupleStream stream = (TupleStream)createInstance((Class)this.functionNames.get(function), new Class[] { StreamExpression.class, StreamFactory.class }, new Object[] { expression, this });
/* 186 */         return stream;
/*     */       }
/*     */     }
/*     */     
/* 190 */     throw new IOException(String.format(Locale.ROOT, "Invalid stream expression %s - function '%s' is unknown (not mapped to a valid TupleStream)", new Object[] { expression, expression.getFunctionName() }));
/*     */   }
/*     */   
/*     */ 
/* 194 */   public Metric constructMetric(String expressionClause) throws IOException { return constructMetric(StreamExpressionParser.parse(expressionClause)); }
/*     */   
/*     */   public Metric constructMetric(StreamExpression expression) throws IOException {
/* 197 */     String function = expression.getFunctionName();
/* 198 */     if (this.functionNames.containsKey(function)) {
/* 199 */       Class clazz = (Class)this.functionNames.get(function);
/* 200 */       if ((Expressible.class.isAssignableFrom(clazz)) && (Metric.class.isAssignableFrom(clazz))) {
/* 201 */         Metric metric = (Metric)createInstance((Class)this.functionNames.get(function), new Class[] { StreamExpression.class, StreamFactory.class }, new Object[] { expression, this });
/* 202 */         return metric;
/*     */       }
/*     */     }
/*     */     
/* 206 */     throw new IOException(String.format(Locale.ROOT, "Invalid metric expression %s - function '%s' is unknown (not mapped to a valid Metric)", new Object[] { expression, expression.getFunctionName() }));
/*     */   }
/*     */   
/*     */   public StreamComparator constructComparator(String comparatorString, Class comparatorType) throws IOException {
/* 210 */     if (comparatorString.contains(",")) {
/* 211 */       String[] parts = comparatorString.split(",");
/* 212 */       StreamComparator[] comps = new StreamComparator[parts.length];
/* 213 */       for (int idx = 0; idx < parts.length; idx++) {
/* 214 */         comps[idx] = constructComparator(parts[idx].trim(), comparatorType);
/*     */       }
/* 216 */       return new MultipleFieldComparator(comps);
/*     */     }
/* 218 */     if (comparatorString.contains("="))
/*     */     {
/* 220 */       String[] parts = comparatorString.split("[ =]");
/*     */       
/* 222 */       if (parts.length < 3) {
/* 223 */         throw new IOException(String.format(Locale.ROOT, "Invalid comparator expression %s - expecting 'left=right order'", new Object[] { comparatorString }));
/*     */       }
/*     */       
/* 226 */       String leftFieldName = null;
/* 227 */       String rightFieldName = null;
/* 228 */       String order = null;
/* 229 */       for (String part : parts)
/*     */       {
/* 231 */         if ((null != part) && (0 != part.trim().length()))
/*     */         {
/*     */ 
/* 234 */           if (null == leftFieldName) {
/* 235 */             leftFieldName = part.trim();
/*     */           }
/* 237 */           else if (null == rightFieldName) {
/* 238 */             rightFieldName = part.trim();
/*     */           }
/* 240 */           else if (null == order) {
/* 241 */             order = part.trim();
/* 242 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 246 */       if ((null == leftFieldName) || (null == rightFieldName) || (null == order)) {
/* 247 */         throw new IOException(String.format(Locale.ROOT, "Invalid comparator expression %s - expecting 'left=right order'", new Object[] { comparatorString }));
/*     */       }
/*     */       
/* 250 */       return (StreamComparator)createInstance(comparatorType, new Class[] { String.class, String.class, ComparatorOrder.class }, new Object[] { leftFieldName, rightFieldName, ComparatorOrder.fromString(order) });
/*     */     }
/*     */     
/*     */ 
/* 254 */     String[] parts = comparatorString.split(" ");
/* 255 */     if (2 != parts.length) {
/* 256 */       throw new IOException(String.format(Locale.ROOT, "Invalid comparator expression %s - expecting 'field order'", new Object[] { comparatorString }));
/*     */     }
/*     */     
/* 259 */     String fieldName = parts[0].trim();
/* 260 */     String order = parts[1].trim();
/*     */     
/* 262 */     return (StreamComparator)createInstance(comparatorType, new Class[] { String.class, ComparatorOrder.class }, new Object[] { fieldName, ComparatorOrder.fromString(order) });
/*     */   }
/*     */   
/*     */   public StreamEqualitor constructEqualitor(String equalitorString, Class equalitorType) throws IOException
/*     */   {
/* 267 */     if (equalitorString.contains(",")) {
/* 268 */       String[] parts = equalitorString.split(",");
/* 269 */       StreamEqualitor[] eqs = new StreamEqualitor[parts.length];
/* 270 */       for (int idx = 0; idx < parts.length; idx++) {
/* 271 */         eqs[idx] = constructEqualitor(parts[idx].trim(), equalitorType);
/*     */       }
/* 273 */       return new MultipleFieldEqualitor(eqs);
/*     */     }
/*     */     
/*     */     String rightFieldName;
/*     */     String rightFieldName;
/*     */     String leftFieldName;
/* 279 */     if (equalitorString.contains("=")) {
/* 280 */       String[] parts = equalitorString.split("=");
/* 281 */       if (2 != parts.length) {
/* 282 */         throw new IOException(String.format(Locale.ROOT, "Invalid equalitor expression %s - expecting fieldName=fieldName", new Object[] { equalitorString }));
/*     */       }
/*     */       
/* 285 */       String leftFieldName = parts[0].trim();
/* 286 */       rightFieldName = parts[1].trim();
/*     */     }
/*     */     else {
/* 289 */       leftFieldName = rightFieldName = equalitorString.trim();
/*     */     }
/*     */     
/* 292 */     return (StreamEqualitor)createInstance(equalitorType, new Class[] { String.class, String.class }, new Object[] { leftFieldName, rightFieldName });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 297 */   public Metric constructOperation(String expressionClause) throws IOException { return constructMetric(StreamExpressionParser.parse(expressionClause)); }
/*     */   
/*     */   public StreamOperation constructOperation(StreamExpression expression) throws IOException {
/* 300 */     String function = expression.getFunctionName();
/* 301 */     if (this.functionNames.containsKey(function)) {
/* 302 */       Class clazz = (Class)this.functionNames.get(function);
/* 303 */       if ((Expressible.class.isAssignableFrom(clazz)) && (StreamOperation.class.isAssignableFrom(clazz))) {
/* 304 */         return (StreamOperation)createInstance((Class)this.functionNames.get(function), new Class[] { StreamExpression.class, StreamFactory.class }, new Object[] { expression, this });
/*     */       }
/*     */     }
/*     */     
/* 308 */     throw new IOException(String.format(Locale.ROOT, "Invalid operation expression %s - function '%s' is unknown (not mapped to a valid StreamOperation)", new Object[] { expression, expression.getFunctionName() }));
/*     */   }
/*     */   
/*     */   public <T> T createInstance(Class<T> clazz, Class<?>[] paramTypes, Object[] params) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 315 */       Constructor<T> ctor = clazz.getConstructor(paramTypes);
/* 316 */       return (T)ctor.newInstance(params);
/*     */     }
/*     */     catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
/* 319 */       if (null != e.getMessage()) {
/* 320 */         throw new IOException(String.format(Locale.ROOT, "Unable to construct instance of %s caused by %s", new Object[] { clazz.getName(), e.getMessage() }), e);
/*     */       }
/*     */       
/* 323 */       throw new IOException(String.format(Locale.ROOT, "Unable to construct instance of %s", new Object[] { clazz.getName() }), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFunctionName(Class clazz) throws IOException
/*     */   {
/* 329 */     for (Map.Entry<String, Class> entry : this.functionNames.entrySet()) {
/* 330 */       if (entry.getValue() == clazz) {
/* 331 */         return (String)entry.getKey();
/*     */       }
/*     */     }
/*     */     
/* 335 */     throw new IOException(String.format(Locale.ROOT, "Unable to find function name for class '%s'", new Object[] { clazz.getName() }));
/*     */   }
/*     */   
/*     */   public Object constructPrimitiveObject(String original) {
/* 339 */     String lower = original.trim().toLowerCase(Locale.ROOT);
/*     */     
/* 341 */     if ("null".equals(lower)) return null;
/* 342 */     if (("true".equals(lower)) || ("false".equals(lower))) return Boolean.valueOf(Boolean.parseBoolean(lower));
/* 343 */     try { return Long.valueOf(original);
/* 344 */     } catch (Exception localException) { try { if (original.matches(".{1,8}")) return Float.valueOf(original); } catch (Exception localException1) {}
/* 345 */       try { if (original.matches(".{1,17}")) return Double.valueOf(original);
/*     */       } catch (Exception localException2) {}
/*     */     }
/* 348 */     return original;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */