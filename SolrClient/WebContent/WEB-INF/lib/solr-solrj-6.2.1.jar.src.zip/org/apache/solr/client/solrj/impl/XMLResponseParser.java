/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.solr.client.solrj.ResponseParser;
/*     */ import org.apache.solr.common.EmptyEntityResolver;
/*     */ import org.apache.solr.common.SolrDocument;
/*     */ import org.apache.solr.common.SolrDocumentList;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SimpleOrderedMap;
/*     */ import org.apache.solr.common.util.XMLErrorLogger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLResponseParser
/*     */   extends ResponseParser
/*     */ {
/*     */   public static final String XML_CONTENT_TYPE = "application/xml; charset=UTF-8";
/*  51 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*  52 */   private static final XMLErrorLogger xmllog = new XMLErrorLogger(log);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   static final XMLInputFactory factory = XMLInputFactory.newInstance();
/*  59 */   static { EmptyEntityResolver.configureXMLInputFactory(factory);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  68 */       factory.setProperty("reuse-instance", Boolean.FALSE);
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/*  73 */       log.debug("Unable to set the 'reuse-instance' property for the input factory: " + factory);
/*     */     }
/*  75 */     factory.setXMLReporter(xmllog);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWriterType()
/*     */   {
/*  83 */     return "xml";
/*     */   }
/*     */   
/*     */   public String getContentType()
/*     */   {
/*  88 */     return "application/xml; charset=UTF-8";
/*     */   }
/*     */   
/*     */   public NamedList<Object> processResponse(Reader in)
/*     */   {
/*  93 */     XMLStreamReader parser = null;
/*     */     try {
/*  95 */       parser = factory.createXMLStreamReader(in);
/*     */     } catch (XMLStreamException e) {
/*  97 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*     */     }
/*     */     
/* 100 */     return processResponse(parser);
/*     */   }
/*     */   
/*     */ 
/*     */   public NamedList<Object> processResponse(InputStream in, String encoding)
/*     */   {
/* 106 */     XMLStreamReader parser = null;
/*     */     try {
/* 108 */       parser = factory.createXMLStreamReader(in, encoding);
/*     */     } catch (XMLStreamException e) {
/* 110 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*     */     }
/*     */     
/* 113 */     return processResponse(parser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private NamedList<Object> processResponse(XMLStreamReader parser)
/*     */   {
/*     */     try
/*     */     {
/* 122 */       NamedList<Object> response = null;
/* 123 */       for (int event = parser.next(); 
/* 124 */           event != 8; 
/* 125 */           event = parser.next())
/*     */       {
/* 127 */         switch (event)
/*     */         {
/*     */         case 1: 
/* 130 */           if (response != null) {
/* 131 */             throw new Exception("already read the response!");
/*     */           }
/*     */           
/*     */ 
/* 135 */           String name = parser.getLocalName();
/* 136 */           if ((name.equals("response")) || (name.equals("result"))) {
/* 137 */             response = readNamedList(parser);
/*     */           } else {
/* 139 */             if (name.equals("solr")) {
/* 140 */               return new SimpleOrderedMap();
/*     */             }
/*     */             
/*     */ 
/* 144 */             throw new Exception("really needs to be response or result.  not:" + parser.getLocalName());
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/* 149 */       return response;
/*     */     }
/*     */     catch (Exception ex) {
/* 152 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", ex);
/*     */     }
/*     */     finally {
/*     */       try {
/* 156 */         parser.close();
/*     */       }
/*     */       catch (Exception localException3) {}
/*     */     }
/*     */   }
/*     */   
/*     */   protected static abstract enum KnownType
/*     */   {
/* 164 */     STR(true), 
/* 165 */     INT(true), 
/* 166 */     FLOAT(true), 
/* 167 */     DOUBLE(true), 
/* 168 */     LONG(true), 
/* 169 */     BOOL(true), 
/* 170 */     NULL(true), 
/* 171 */     DATE(true), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */     ARR(false), 
/* 185 */     LST(false), 
/* 186 */     RESULT(false), 
/* 187 */     DOC(false);
/*     */     
/*     */     final boolean isLeaf;
/*     */     
/*     */     private KnownType(boolean isLeaf)
/*     */     {
/* 193 */       this.isLeaf = isLeaf;
/*     */     }
/*     */     
/*     */     public abstract Object read(String paramString);
/*     */     
/*     */     public static KnownType get(String v)
/*     */     {
/* 200 */       if (v != null) {
/*     */         try {
/* 202 */           return valueOf(v.toUpperCase(Locale.ROOT));
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/* 206 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected NamedList<Object> readNamedList(XMLStreamReader parser) throws XMLStreamException
/*     */   {
/* 212 */     if (1 != parser.getEventType()) {
/* 213 */       throw new RuntimeException("must be start element, not: " + parser.getEventType());
/*     */     }
/*     */     
/* 216 */     StringBuilder builder = new StringBuilder();
/* 217 */     NamedList<Object> nl = new SimpleOrderedMap();
/* 218 */     KnownType type = null;
/* 219 */     String name = null;
/*     */     
/*     */ 
/* 222 */     int depth = 0;
/*     */     for (;;)
/*     */     {
/* 225 */       switch (parser.next()) {
/*     */       case 1: 
/* 227 */         depth++;
/* 228 */         builder.setLength(0);
/* 229 */         type = KnownType.get(parser.getLocalName());
/* 230 */         if (type == null) {
/* 231 */           throw new RuntimeException("this must be known type! not: " + parser.getLocalName());
/*     */         }
/*     */         
/* 234 */         name = null;
/* 235 */         int cnt = parser.getAttributeCount();
/* 236 */         for (int i = 0; i < cnt; i++) {
/* 237 */           if ("name".equals(parser.getAttributeLocalName(i))) {
/* 238 */             name = parser.getAttributeValue(i);
/* 239 */             break;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 249 */         if (!type.isLeaf) {
/* 250 */           switch (type) {
/* 251 */           case LST:  nl.add(name, readNamedList(parser));depth--; break;
/* 252 */           case ARR:  nl.add(name, readArray(parser));depth--; break;
/* 253 */           case RESULT:  nl.add(name, readDocuments(parser));depth--; break;
/* 254 */           case DOC:  nl.add(name, readDocument(parser));depth--; break;
/*     */           default: 
/* 256 */             throw new XMLStreamException("branch element not handled!", parser.getLocation());
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 2: 
/* 261 */         depth--; if (depth < 0) {
/* 262 */           return nl;
/*     */         }
/*     */         
/* 265 */         nl.add(name, type.read(builder.toString().trim()));
/* 266 */         break;
/*     */       
/*     */       case 4: 
/*     */       case 6: 
/*     */       case 12: 
/* 271 */         builder.append(parser.getText());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<Object> readArray(XMLStreamReader parser)
/*     */     throws XMLStreamException
/*     */   {
/* 279 */     if (1 != parser.getEventType()) {
/* 280 */       throw new RuntimeException("must be start element, not: " + parser.getEventType());
/*     */     }
/* 282 */     if (!"arr".equals(parser.getLocalName().toLowerCase(Locale.ROOT))) {
/* 283 */       throw new RuntimeException("must be 'arr', not: " + parser.getLocalName());
/*     */     }
/*     */     
/* 286 */     StringBuilder builder = new StringBuilder();
/* 287 */     KnownType type = null;
/*     */     
/* 289 */     List<Object> vals = new ArrayList();
/*     */     
/* 291 */     int depth = 0;
/*     */     for (;;)
/*     */     {
/* 294 */       switch (parser.next()) {
/*     */       case 1: 
/* 296 */         depth++;
/* 297 */         KnownType t = KnownType.get(parser.getLocalName());
/* 298 */         if (t == null) {
/* 299 */           throw new RuntimeException("this must be known type! not: " + parser.getLocalName());
/*     */         }
/* 301 */         if (type == null) {
/* 302 */           type = t;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 309 */         type = t;
/*     */         
/* 311 */         builder.setLength(0);
/*     */         
/* 313 */         if (!type.isLeaf) {
/* 314 */           switch (type) {
/* 315 */           case LST:  vals.add(readNamedList(parser));depth--; break;
/* 316 */           case ARR:  vals.add(readArray(parser));depth--; break;
/* 317 */           case RESULT:  vals.add(readDocuments(parser));depth--; break;
/* 318 */           case DOC:  vals.add(readDocument(parser));depth--; break;
/*     */           default: 
/* 320 */             throw new XMLStreamException("branch element not handled!", parser.getLocation());
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 2: 
/* 325 */         depth--; if (depth < 0) {
/* 326 */           return vals;
/*     */         }
/*     */         
/* 329 */         Object val = type.read(builder.toString().trim());
/* 330 */         if ((val == null) && (type != KnownType.NULL)) {
/* 331 */           throw new XMLStreamException("error reading value:" + type, parser.getLocation());
/*     */         }
/* 333 */         vals.add(val);
/* 334 */         break;
/*     */       
/*     */       case 4: 
/*     */       case 6: 
/*     */       case 12: 
/* 339 */         builder.append(parser.getText());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected SolrDocumentList readDocuments(XMLStreamReader parser)
/*     */     throws XMLStreamException
/*     */   {
/* 347 */     SolrDocumentList docs = new SolrDocumentList();
/*     */     
/*     */ 
/* 350 */     for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 351 */       String n = parser.getAttributeLocalName(i);
/* 352 */       String v = parser.getAttributeValue(i);
/* 353 */       if ("numFound".equals(n)) {
/* 354 */         docs.setNumFound(Long.parseLong(v));
/*     */       }
/* 356 */       else if ("start".equals(n)) {
/* 357 */         docs.setStart(Long.parseLong(v));
/*     */       }
/* 359 */       else if ("maxScore".equals(n)) {
/* 360 */         docs.setMaxScore(Float.valueOf(Float.parseFloat(v)));
/*     */       }
/*     */     }
/*     */     int event;
/*     */     do
/*     */     {
/*     */       for (;;) {
/* 367 */         event = parser.next();
/* 368 */         if (1 != event) break;
/* 369 */         if (!"doc".equals(parser.getLocalName())) {
/* 370 */           throw new RuntimeException("should be doc! " + parser.getLocalName() + " :: " + parser.getLocation());
/*     */         }
/* 372 */         docs.add(readDocument(parser));
/*     */       }
/* 374 */     } while (2 != event);
/* 375 */     return docs;
/*     */   }
/*     */   
/*     */ 
/*     */   protected SolrDocument readDocument(XMLStreamReader parser)
/*     */     throws XMLStreamException
/*     */   {
/* 382 */     if (1 != parser.getEventType()) {
/* 383 */       throw new RuntimeException("must be start element, not: " + parser.getEventType());
/*     */     }
/* 385 */     if (!"doc".equals(parser.getLocalName().toLowerCase(Locale.ROOT))) {
/* 386 */       throw new RuntimeException("must be 'lst', not: " + parser.getLocalName());
/*     */     }
/*     */     
/* 389 */     SolrDocument doc = new SolrDocument();
/* 390 */     StringBuilder builder = new StringBuilder();
/* 391 */     KnownType type = null;
/* 392 */     String name = null;
/*     */     
/*     */ 
/* 395 */     int depth = 0;
/*     */     for (;;)
/*     */     {
/* 398 */       switch (parser.next()) {
/*     */       case 1: 
/* 400 */         depth++;
/* 401 */         builder.setLength(0);
/* 402 */         type = KnownType.get(parser.getLocalName());
/* 403 */         if (type == null) {
/* 404 */           throw new RuntimeException("this must be known type! not: " + parser.getLocalName());
/*     */         }
/*     */         
/* 407 */         name = null;
/* 408 */         int cnt = parser.getAttributeCount();
/* 409 */         for (int i = 0; i < cnt; i++) {
/* 410 */           if ("name".equals(parser.getAttributeLocalName(i))) {
/* 411 */             name = parser.getAttributeValue(i);
/* 412 */             break;
/*     */           }
/*     */         }
/*     */         
/*     */         int event;
/* 417 */         while (type == KnownType.DOC) {
/* 418 */           doc.addChildDocument(readDocument(parser));
/* 419 */           event = parser.next();
/* 420 */           if (event == 2) {
/* 421 */             return doc;
/*     */           }
/*     */         }
/*     */         
/* 425 */         if (name == null) {
/* 426 */           throw new XMLStreamException("requires 'name' attribute: " + parser.getLocalName(), parser.getLocation());
/*     */         }
/*     */         
/*     */ 
/* 430 */         if (type == KnownType.ARR) {
/* 431 */           for (Object val : readArray(parser)) {
/* 432 */             doc.addField(name, val);
/*     */           }
/* 434 */           depth--;
/* 435 */         } else if (type == KnownType.LST) {
/* 436 */           doc.addField(name, readNamedList(parser));
/* 437 */           depth--;
/* 438 */         } else if (!type.isLeaf) {
/* 439 */           System.out.println("nbot leaf!:" + type);
/*     */           
/* 441 */           throw new XMLStreamException("must be value or array", parser.getLocation());
/*     */         }
/*     */         
/*     */         break;
/*     */       case 2: 
/* 446 */         depth--; if (depth < 0) {
/* 447 */           return doc;
/*     */         }
/*     */         
/* 450 */         Object val = type.read(builder.toString().trim());
/* 451 */         if (val == null) {
/* 452 */           throw new XMLStreamException("error reading value:" + type, parser.getLocation());
/*     */         }
/* 454 */         doc.addField(name, val);
/* 455 */         break;
/*     */       
/*     */       case 4: 
/*     */       case 6: 
/*     */       case 12: 
/* 460 */         builder.append(parser.getText());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\XMLResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */