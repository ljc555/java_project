/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.beans.DocumentObjectBinder;
/*     */ import org.apache.solr.common.SolrDocumentList;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SimpleOrderedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryResponse
/*     */   extends SolrResponseBase
/*     */ {
/*  43 */   private NamedList<Object> _header = null;
/*  44 */   private SolrDocumentList _results = null;
/*  45 */   private NamedList<ArrayList> _sortvalues = null;
/*  46 */   private NamedList<Object> _facetInfo = null;
/*  47 */   private NamedList<Object> _debugInfo = null;
/*  48 */   private NamedList<Object> _highlightingInfo = null;
/*  49 */   private NamedList<Object> _spellInfo = null;
/*  50 */   private List<NamedList<Object>> _clusterInfo = null;
/*  51 */   private Map<String, NamedList<Object>> _suggestInfo = null;
/*  52 */   private NamedList<Object> _statsInfo = null;
/*  53 */   private NamedList<NamedList<Number>> _termsInfo = null;
/*  54 */   private String _cursorMarkNext = null;
/*     */   
/*     */ 
/*  57 */   private NamedList<Object> _groupedInfo = null;
/*  58 */   private GroupResponse _groupResponse = null;
/*     */   
/*  60 */   private NamedList<Object> _expandedInfo = null;
/*  61 */   private Map<String, SolrDocumentList> _expandedResults = null;
/*     */   
/*     */ 
/*  64 */   private Map<String, Integer> _facetQuery = null;
/*  65 */   private List<FacetField> _facetFields = null;
/*  66 */   private List<FacetField> _limitingFacets = null;
/*  67 */   private List<FacetField> _facetDates = null;
/*  68 */   private List<RangeFacet> _facetRanges = null;
/*  69 */   private NamedList<List<PivotField>> _facetPivot = null;
/*  70 */   private List<IntervalFacet> _intervalFacets = null;
/*     */   
/*     */ 
/*  73 */   private Map<String, Map<String, List<String>>> _highlighting = null;
/*     */   
/*     */ 
/*  76 */   private SpellCheckResponse _spellResponse = null;
/*     */   
/*     */ 
/*  79 */   private ClusteringResponse _clusterResponse = null;
/*     */   
/*     */ 
/*  82 */   private SuggesterResponse _suggestResponse = null;
/*     */   
/*     */ 
/*  85 */   private TermsResponse _termsResponse = null;
/*     */   
/*     */ 
/*  88 */   private Map<String, FieldStatsInfo> _fieldStatsInfo = null;
/*     */   
/*     */ 
/*  91 */   private Map<String, Object> _debugMap = null;
/*  92 */   private Map<String, String> _explainMap = null;
/*     */   
/*     */   private final transient SolrClient solrClient;
/*     */   
/*     */   public QueryResponse()
/*     */   {
/*  98 */     this.solrClient = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QueryResponse(NamedList<Object> res, SolrClient solrClient)
/*     */   {
/* 105 */     setResponse(res);
/* 106 */     this.solrClient = solrClient;
/*     */   }
/*     */   
/*     */   public QueryResponse(SolrClient solrClient) {
/* 110 */     this.solrClient = solrClient;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setResponse(NamedList<Object> res)
/*     */   {
/* 116 */     super.setResponse(res);
/*     */     
/*     */ 
/* 119 */     for (int i = 0; i < res.size(); i++) {
/* 120 */       String n = res.getName(i);
/* 121 */       if ("responseHeader".equals(n)) {
/* 122 */         this._header = ((NamedList)res.getVal(i));
/*     */       }
/* 124 */       else if ("response".equals(n)) {
/* 125 */         this._results = ((SolrDocumentList)res.getVal(i));
/*     */       }
/* 127 */       else if ("sort_values".equals(n)) {
/* 128 */         this._sortvalues = ((NamedList)res.getVal(i));
/*     */       }
/* 130 */       else if ("facet_counts".equals(n)) {
/* 131 */         this._facetInfo = ((NamedList)res.getVal(i));
/*     */ 
/*     */ 
/*     */       }
/* 135 */       else if ("debug".equals(n)) {
/* 136 */         this._debugInfo = ((NamedList)res.getVal(i));
/* 137 */         extractDebugInfo(this._debugInfo);
/*     */       }
/* 139 */       else if ("grouped".equals(n)) {
/* 140 */         this._groupedInfo = ((NamedList)res.getVal(i));
/* 141 */         extractGroupedInfo(this._groupedInfo);
/*     */       }
/* 143 */       else if ("expanded".equals(n)) {
/* 144 */         NamedList map = (NamedList)res.getVal(i);
/* 145 */         this._expandedResults = map.asMap(1);
/*     */       }
/* 147 */       else if ("highlighting".equals(n)) {
/* 148 */         this._highlightingInfo = ((NamedList)res.getVal(i));
/* 149 */         extractHighlightingInfo(this._highlightingInfo);
/*     */       }
/* 151 */       else if ("spellcheck".equals(n)) {
/* 152 */         this._spellInfo = ((NamedList)res.getVal(i));
/* 153 */         extractSpellCheckInfo(this._spellInfo);
/*     */       }
/* 155 */       else if ("clusters".equals(n)) {
/* 156 */         this._clusterInfo = ((ArrayList)res.getVal(i));
/* 157 */         extractClusteringInfo(this._clusterInfo);
/*     */       }
/* 159 */       else if ("suggest".equals(n)) {
/* 160 */         this._suggestInfo = ((Map)res.getVal(i));
/* 161 */         extractSuggesterInfo(this._suggestInfo);
/*     */       }
/* 163 */       else if ("stats".equals(n)) {
/* 164 */         this._statsInfo = ((NamedList)res.getVal(i));
/* 165 */         extractStatsInfo(this._statsInfo);
/*     */       }
/* 167 */       else if ("terms".equals(n)) {
/* 168 */         this._termsInfo = ((NamedList)res.getVal(i));
/* 169 */         extractTermsInfo(this._termsInfo);
/*     */       }
/* 171 */       else if ("nextCursorMark".equals(n)) {
/* 172 */         this._cursorMarkNext = ((String)res.getVal(i));
/*     */       }
/*     */     }
/* 175 */     if (this._facetInfo != null) extractFacetInfo(this._facetInfo);
/*     */   }
/*     */   
/*     */   private void extractSpellCheckInfo(NamedList<Object> spellInfo) {
/* 179 */     this._spellResponse = new SpellCheckResponse(spellInfo);
/*     */   }
/*     */   
/*     */   private void extractClusteringInfo(List<NamedList<Object>> clusterInfo) {
/* 183 */     this._clusterResponse = new ClusteringResponse(clusterInfo);
/*     */   }
/*     */   
/*     */   private void extractSuggesterInfo(Map<String, NamedList<Object>> suggestInfo) {
/* 187 */     this._suggestResponse = new SuggesterResponse(suggestInfo);
/*     */   }
/*     */   
/*     */   private void extractTermsInfo(NamedList<NamedList<Number>> termsInfo) {
/* 191 */     this._termsResponse = new TermsResponse(termsInfo);
/*     */   }
/*     */   
/*     */   private void extractStatsInfo(NamedList<Object> info) {
/* 195 */     this._fieldStatsInfo = extractFieldStatsInfo(info);
/*     */   }
/*     */   
/*     */   private Map<String, FieldStatsInfo> extractFieldStatsInfo(NamedList<Object> info) {
/* 199 */     if (info != null) {
/* 200 */       Map<String, FieldStatsInfo> fieldStatsInfoMap = new TreeMap();
/* 201 */       NamedList<NamedList<Object>> ff = (NamedList)info.get("stats_fields");
/* 202 */       if (ff != null) {
/* 203 */         for (Map.Entry<String, NamedList<Object>> entry : ff) {
/* 204 */           NamedList<Object> v = (NamedList)entry.getValue();
/* 205 */           if (v != null) {
/* 206 */             fieldStatsInfoMap.put(entry.getKey(), new FieldStatsInfo(v, 
/* 207 */               (String)entry.getKey()));
/*     */           }
/*     */         }
/*     */       }
/* 211 */       return fieldStatsInfoMap;
/*     */     }
/* 213 */     return null;
/*     */   }
/*     */   
/*     */   private void extractDebugInfo(NamedList<Object> debug)
/*     */   {
/* 218 */     this._debugMap = new LinkedHashMap();
/* 219 */     for (Iterator localIterator = debug.iterator(); localIterator.hasNext();) { info = (Map.Entry)localIterator.next();
/* 220 */       this._debugMap.put(info.getKey(), info.getValue());
/*     */     }
/*     */     
/*     */     Map.Entry<String, Object> info;
/* 224 */     this._explainMap = new HashMap();
/* 225 */     Object explain = (NamedList)this._debugMap.get("explain");
/* 226 */     if (explain != null) {
/* 227 */       for (Map.Entry<String, String> info : (NamedList)explain) {
/* 228 */         String key = (String)info.getKey();
/* 229 */         this._explainMap.put(key, info.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void extractGroupedInfo(NamedList<Object> info) {
/* 235 */     if (info != null) {
/* 236 */       this._groupResponse = new GroupResponse();
/* 237 */       int size = info.size();
/* 238 */       for (int i = 0; i < size; i++) {
/* 239 */         String fieldName = info.getName(i);
/* 240 */         Object fieldGroups = info.getVal(i);
/* 241 */         SimpleOrderedMap<Object> simpleOrderedMap = (SimpleOrderedMap)fieldGroups;
/*     */         
/* 243 */         Object oMatches = simpleOrderedMap.get("matches");
/* 244 */         Object oNGroups = simpleOrderedMap.get("ngroups");
/* 245 */         Object oGroups = simpleOrderedMap.get("groups");
/* 246 */         Object queryCommand = simpleOrderedMap.get("doclist");
/* 247 */         if (oMatches != null)
/*     */         {
/*     */ 
/*     */ 
/* 251 */           if (oGroups != null) {
/* 252 */             Integer iMatches = (Integer)oMatches;
/* 253 */             ArrayList<Object> groupsArr = (ArrayList)oGroups;
/*     */             Integer iNGroups;
/* 255 */             GroupCommand groupedCommand; GroupCommand groupedCommand; if (oNGroups != null) {
/* 256 */               iNGroups = (Integer)oNGroups;
/* 257 */               groupedCommand = new GroupCommand(fieldName, iMatches.intValue(), iNGroups.intValue());
/*     */             } else {
/* 259 */               groupedCommand = new GroupCommand(fieldName, iMatches.intValue());
/*     */             }
/*     */             
/* 262 */             for (Object oGrp : groupsArr) {
/* 263 */               SimpleOrderedMap grpMap = (SimpleOrderedMap)oGrp;
/* 264 */               Object sGroupValue = grpMap.get("groupValue");
/* 265 */               SolrDocumentList doclist = (SolrDocumentList)grpMap.get("doclist");
/* 266 */               Group group = new Group(sGroupValue != null ? sGroupValue.toString() : null, doclist);
/* 267 */               groupedCommand.add(group);
/*     */             }
/*     */             
/* 270 */             this._groupResponse.add(groupedCommand);
/* 271 */           } else if (queryCommand != null) {
/* 272 */             Integer iMatches = (Integer)oMatches;
/*     */             GroupCommand groupCommand;
/* 274 */             GroupCommand groupCommand; if (oNGroups != null) {
/* 275 */               Integer iNGroups = (Integer)oNGroups;
/* 276 */               groupCommand = new GroupCommand(fieldName, iMatches.intValue(), iNGroups.intValue());
/*     */             } else {
/* 278 */               groupCommand = new GroupCommand(fieldName, iMatches.intValue());
/*     */             }
/* 280 */             SolrDocumentList docList = (SolrDocumentList)queryCommand;
/* 281 */             groupCommand.add(new Group(fieldName, docList));
/* 282 */             this._groupResponse.add(groupCommand);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void extractHighlightingInfo(NamedList<Object> info) {
/* 290 */     this._highlighting = new HashMap();
/* 291 */     for (Map.Entry<String, Object> doc : info) {
/* 292 */       fieldMap = new HashMap();
/* 293 */       this._highlighting.put(doc.getKey(), fieldMap);
/*     */       
/* 295 */       NamedList<List<String>> fnl = (NamedList)doc.getValue();
/* 296 */       for (Map.Entry<String, List<String>> field : fnl) {
/* 297 */         fieldMap.put(field.getKey(), field.getValue());
/*     */       }
/*     */     }
/*     */     Map<String, List<String>> fieldMap;
/*     */   }
/*     */   
/*     */   private void extractFacetInfo(NamedList<Object> info)
/*     */   {
/* 305 */     this._facetQuery = new LinkedHashMap();
/* 306 */     NamedList<Integer> fq = (NamedList)info.get("facet_queries");
/* 307 */     if (fq != null) {
/* 308 */       for (Map.Entry<String, Integer> entry : fq) {
/* 309 */         this._facetQuery.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 315 */     Object ff = (NamedList)info.get("facet_fields");
/* 316 */     long minsize; Iterator localIterator2; if (ff != null) {
/* 317 */       this._facetFields = new ArrayList(((NamedList)ff).size());
/* 318 */       this._limitingFacets = new ArrayList(((NamedList)ff).size());
/*     */       
/* 320 */       minsize = this._results == null ? Long.MAX_VALUE : this._results.getNumFound();
/* 321 */       for (localIterator2 = ((NamedList)ff).iterator(); localIterator2.hasNext();) { facet = (Map.Entry)localIterator2.next();
/* 322 */         FacetField f = new FacetField((String)facet.getKey());
/* 323 */         for (Map.Entry<String, Number> entry : (NamedList)facet.getValue()) {
/* 324 */           f.add((String)entry.getKey(), ((Number)entry.getValue()).longValue());
/*     */         }
/*     */         
/* 327 */         this._facetFields.add(f);
/* 328 */         FacetField nl = f.getLimitingFields(minsize);
/* 329 */         if (nl.getValueCount() > 0) {
/* 330 */           this._limitingFacets.add(nl);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     Map.Entry<String, NamedList<Number>> facet;
/* 336 */     NamedList<NamedList<Object>> rf = (NamedList)info.get("facet_ranges");
/* 337 */     if (rf != null) {
/* 338 */       this._facetRanges = extractRangeFacets(rf);
/*     */     }
/*     */     
/*     */ 
/* 342 */     NamedList pf = (NamedList)info.get("facet_pivot");
/* 343 */     if (pf != null) {
/* 344 */       this._facetPivot = new NamedList();
/* 345 */       for (int i = 0; i < pf.size(); i++) {
/* 346 */         this._facetPivot.add(pf.getName(i), readPivots((List)pf.getVal(i)));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 351 */     Object intervalsNL = (NamedList)info.get("facet_intervals");
/* 352 */     if (intervalsNL != null) {
/* 353 */       this._intervalFacets = new ArrayList(((NamedList)intervalsNL).size());
/* 354 */       for (Map.Entry<String, NamedList<Object>> intervalField : (NamedList)intervalsNL) {
/* 355 */         String field = (String)intervalField.getKey();
/* 356 */         List<IntervalFacet.Count> counts = new ArrayList(((NamedList)intervalField.getValue()).size());
/* 357 */         for (Map.Entry<String, Object> interval : (NamedList)intervalField.getValue()) {
/* 358 */           counts.add(new IntervalFacet.Count((String)interval.getKey(), ((Integer)interval.getValue()).intValue()));
/*     */         }
/* 360 */         this._intervalFacets.add(new IntervalFacet(field, counts));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private List<RangeFacet> extractRangeFacets(NamedList<NamedList<Object>> rf) {
/* 366 */     List<RangeFacet> facetRanges = new ArrayList(rf.size());
/*     */     
/* 368 */     for (Map.Entry<String, NamedList<Object>> facet : rf) {
/* 369 */       NamedList<Object> values = (NamedList)facet.getValue();
/* 370 */       Object rawGap = values.get("gap");
/*     */       RangeFacet rangeFacet;
/*     */       Date start;
/* 373 */       RangeFacet rangeFacet; if ((rawGap instanceof Number)) {
/* 374 */         Number gap = (Number)rawGap;
/* 375 */         Number start = (Number)values.get("start");
/* 376 */         Number end = (Number)values.get("end");
/*     */         
/* 378 */         Number before = (Number)values.get("before");
/* 379 */         Number after = (Number)values.get("after");
/* 380 */         Number between = (Number)values.get("between");
/*     */         
/* 382 */         rangeFacet = new RangeFacet.Numeric((String)facet.getKey(), start, end, gap, before, after, between);
/*     */       } else {
/* 384 */         String gap = (String)rawGap;
/* 385 */         start = (Date)values.get("start");
/* 386 */         Date end = (Date)values.get("end");
/*     */         
/* 388 */         Number before = (Number)values.get("before");
/* 389 */         Number after = (Number)values.get("after");
/* 390 */         Number between = (Number)values.get("between");
/*     */         
/* 392 */         rangeFacet = new RangeFacet.Date((String)facet.getKey(), start, end, gap, before, after, between);
/*     */       }
/*     */       
/* 395 */       NamedList<Integer> counts = (NamedList)values.get("counts");
/* 396 */       for (Map.Entry<String, Integer> entry : counts) {
/* 397 */         rangeFacet.addCount((String)entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       }
/*     */       
/* 400 */       facetRanges.add(rangeFacet);
/*     */     }
/* 402 */     return facetRanges;
/*     */   }
/*     */   
/*     */   protected List<PivotField> readPivots(List<NamedList> list)
/*     */   {
/* 407 */     ArrayList<PivotField> values = new ArrayList(list.size());
/* 408 */     for (NamedList nl : list)
/*     */     {
/* 410 */       assert ("field".equals(nl.getName(0)));
/* 411 */       String f = (String)nl.getVal(0);
/* 412 */       assert ("value".equals(nl.getName(1)));
/* 413 */       Object v = nl.getVal(1);
/* 414 */       assert ("count".equals(nl.getName(2)));
/* 415 */       int cnt = ((Integer)nl.getVal(2)).intValue();
/*     */       
/* 417 */       List<PivotField> subPivots = null;
/* 418 */       Map<String, FieldStatsInfo> fieldStatsInfos = null;
/* 419 */       Map<String, Integer> queryCounts = null;
/* 420 */       List<RangeFacet> ranges = null;
/*     */       
/* 422 */       if (4 <= nl.size()) {
/* 423 */         for (int index = 3; index < nl.size(); index++) {
/* 424 */           String key = nl.getName(index);
/* 425 */           Object val = nl.getVal(index);
/* 426 */           switch (key)
/*     */           {
/*     */           case "pivot": 
/* 429 */             assert (null != val) : "Server sent back 'null' for sub pivots?";
/* 430 */             assert ((val instanceof List)) : "Server sent non-List for sub pivots?";
/*     */             
/* 432 */             subPivots = readPivots((List)val);
/* 433 */             break;
/*     */           
/*     */           case "stats": 
/* 436 */             assert (null != val) : "Server sent back 'null' for stats?";
/* 437 */             assert ((val instanceof NamedList)) : "Server sent non-NamedList for stats?";
/*     */             
/* 439 */             fieldStatsInfos = extractFieldStatsInfo((NamedList)val);
/* 440 */             break;
/*     */           
/*     */ 
/*     */           case "queries": 
/* 444 */             queryCounts = new LinkedHashMap();
/* 445 */             NamedList<Integer> fq = (NamedList)val;
/* 446 */             if (fq != null)
/* 447 */               for (Map.Entry<String, Integer> entry : fq)
/* 448 */                 queryCounts.put(entry.getKey(), entry.getValue());
/* 449 */             break;
/*     */           
/*     */ 
/*     */ 
/*     */           case "ranges": 
/* 454 */             ranges = extractRangeFacets((NamedList)val);
/* 455 */             break;
/*     */           
/*     */           default: 
/* 458 */             throw new RuntimeException("unknown key in pivot: " + key + " [" + val + "]");
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       
/* 464 */       values.add(new PivotField(f, v, cnt, subPivots, fieldStatsInfos, queryCounts, ranges));
/*     */     }
/* 466 */     return values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeFacets()
/*     */   {
/* 476 */     this._facetFields = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NamedList<Object> getHeader()
/*     */   {
/* 483 */     return this._header;
/*     */   }
/*     */   
/*     */   public SolrDocumentList getResults() {
/* 487 */     return this._results;
/*     */   }
/*     */   
/*     */   public NamedList<ArrayList> getSortValues() {
/* 491 */     return this._sortvalues;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getDebugMap() {
/* 495 */     return this._debugMap;
/*     */   }
/*     */   
/*     */   public Map<String, String> getExplainMap() {
/* 499 */     return this._explainMap;
/*     */   }
/*     */   
/*     */   public Map<String, Integer> getFacetQuery() {
/* 503 */     return this._facetQuery;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, SolrDocumentList> getExpandedResults()
/*     */   {
/* 513 */     return this._expandedResults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GroupResponse getGroupResponse()
/*     */   {
/* 528 */     return this._groupResponse;
/*     */   }
/*     */   
/*     */   public Map<String, Map<String, List<String>>> getHighlighting() {
/* 532 */     return this._highlighting;
/*     */   }
/*     */   
/*     */   public SpellCheckResponse getSpellCheckResponse() {
/* 536 */     return this._spellResponse;
/*     */   }
/*     */   
/*     */   public ClusteringResponse getClusteringResponse() {
/* 540 */     return this._clusterResponse;
/*     */   }
/*     */   
/*     */   public SuggesterResponse getSuggesterResponse() {
/* 544 */     return this._suggestResponse;
/*     */   }
/*     */   
/*     */   public TermsResponse getTermsResponse() {
/* 548 */     return this._termsResponse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<FacetField> getFacetFields()
/*     */   {
/* 555 */     return this._facetFields;
/*     */   }
/*     */   
/*     */   public List<FacetField> getFacetDates() {
/* 559 */     return this._facetDates;
/*     */   }
/*     */   
/*     */   public List<RangeFacet> getFacetRanges() {
/* 563 */     return this._facetRanges;
/*     */   }
/*     */   
/*     */   public NamedList<List<PivotField>> getFacetPivot() {
/* 567 */     return this._facetPivot;
/*     */   }
/*     */   
/*     */   public List<IntervalFacet> getIntervalFacets() {
/* 571 */     return this._intervalFacets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FacetField getFacetField(String name)
/*     */   {
/* 580 */     if (this._facetFields == null) return null;
/* 581 */     for (FacetField f : this._facetFields) {
/* 582 */       if (f.getName().equals(name)) return f;
/*     */     }
/* 584 */     return null;
/*     */   }
/*     */   
/*     */   public FacetField getFacetDate(String name) {
/* 588 */     if (this._facetDates == null)
/* 589 */       return null;
/* 590 */     for (FacetField f : this._facetDates)
/* 591 */       if (f.getName().equals(name))
/* 592 */         return f;
/* 593 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FacetField> getLimitingFacets()
/*     */   {
/* 604 */     return this._limitingFacets;
/*     */   }
/*     */   
/*     */   public <T> List<T> getBeans(Class<T> type) {
/* 608 */     return this.solrClient == null ? new DocumentObjectBinder()
/* 609 */       .getBeans(type, this._results) : this.solrClient
/* 610 */       .getBinder().getBeans(type, this._results);
/*     */   }
/*     */   
/*     */   public Map<String, FieldStatsInfo> getFieldStatsInfo() {
/* 614 */     return this._fieldStatsInfo;
/*     */   }
/*     */   
/*     */   public String getNextCursorMark() {
/* 618 */     return this._cursorMarkNext;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\QueryResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */