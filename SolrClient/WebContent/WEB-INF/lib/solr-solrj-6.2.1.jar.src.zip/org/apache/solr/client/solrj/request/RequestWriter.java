/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ import org.apache.solr.common.util.ContentStreamBase.StringStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestWriter
/*     */ {
/*  41 */   public static final Charset UTF_8 = StandardCharsets.UTF_8;
/*     */   
/*     */   public Collection<ContentStream> getContentStreams(SolrRequest req) throws IOException {
/*  44 */     if ((req instanceof UpdateRequest)) {
/*  45 */       UpdateRequest updateRequest = (UpdateRequest)req;
/*  46 */       if (isEmpty(updateRequest)) return null;
/*  47 */       List<ContentStream> l = new ArrayList();
/*  48 */       l.add(new LazyContentStream(updateRequest));
/*  49 */       return l;
/*     */     }
/*  51 */     return req.getContentStreams();
/*     */   }
/*     */   
/*     */   private boolean isEmpty(UpdateRequest updateRequest) {
/*  55 */     return (isNull(updateRequest.getDocuments())) && 
/*  56 */       (isNull(updateRequest.getDeleteByIdMap())) && 
/*  57 */       (isNull(updateRequest.getDeleteQuery())) && 
/*  58 */       (updateRequest.getDocIterator() == null);
/*     */   }
/*     */   
/*     */   public String getPath(SolrRequest req) {
/*  62 */     return req.getPath();
/*     */   }
/*     */   
/*     */   public ContentStream getContentStream(UpdateRequest req) throws IOException {
/*  66 */     return new ContentStreamBase.StringStream(req.getXML());
/*     */   }
/*     */   
/*     */   public void write(SolrRequest request, OutputStream os) throws IOException {
/*  70 */     if ((request instanceof UpdateRequest)) {
/*  71 */       UpdateRequest updateRequest = (UpdateRequest)request;
/*  72 */       BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, UTF_8));
/*  73 */       updateRequest.writeXML(writer);
/*  74 */       writer.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getUpdateContentType() {
/*  79 */     return "application/xml; charset=UTF-8";
/*     */   }
/*     */   
/*     */   public class LazyContentStream implements ContentStream
/*     */   {
/*  84 */     ContentStream contentStream = null;
/*  85 */     UpdateRequest req = null;
/*     */     
/*     */     public LazyContentStream(UpdateRequest req) {
/*  88 */       this.req = req;
/*     */     }
/*     */     
/*     */     private ContentStream getDelegate() {
/*  92 */       if (this.contentStream == null) {
/*     */         try {
/*  94 */           this.contentStream = RequestWriter.this.getContentStream(this.req);
/*     */         } catch (IOException e) {
/*  96 */           throw new RuntimeException("Unable to write xml into a stream", e);
/*     */         }
/*     */       }
/*  99 */       return this.contentStream;
/*     */     }
/*     */     
/*     */     public String getName()
/*     */     {
/* 104 */       return getDelegate().getName();
/*     */     }
/*     */     
/*     */     public String getSourceInfo()
/*     */     {
/* 109 */       return getDelegate().getSourceInfo();
/*     */     }
/*     */     
/*     */     public String getContentType()
/*     */     {
/* 114 */       return RequestWriter.this.getUpdateContentType();
/*     */     }
/*     */     
/*     */     public Long getSize()
/*     */     {
/* 119 */       return getDelegate().getSize();
/*     */     }
/*     */     
/*     */     public InputStream getStream() throws IOException
/*     */     {
/* 124 */       return getDelegate().getStream();
/*     */     }
/*     */     
/*     */     public Reader getReader() throws IOException
/*     */     {
/* 129 */       return getDelegate().getReader();
/*     */     }
/*     */     
/*     */     public void writeTo(OutputStream os) throws IOException {
/* 133 */       RequestWriter.this.write(this.req, os);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isNull(List l)
/*     */   {
/* 139 */     return (l == null) || (l.isEmpty());
/*     */   }
/*     */   
/*     */   protected boolean isNull(Map l) {
/* 143 */     return (l == null) || (l.isEmpty());
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\RequestWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */