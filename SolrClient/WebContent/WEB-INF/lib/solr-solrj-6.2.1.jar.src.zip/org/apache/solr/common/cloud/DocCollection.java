/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.noggit.JSONUtil;
/*     */ import org.noggit.JSONWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocCollection
/*     */   extends ZkNodeProps
/*     */   implements Iterable<Slice>
/*     */ {
/*     */   public static final String DOC_ROUTER = "router";
/*     */   public static final String SHARDS = "shards";
/*     */   public static final String STATE_FORMAT = "stateFormat";
/*     */   public static final String RULE = "rule";
/*     */   public static final String SNITCH = "snitch";
/*     */   private final int znodeVersion;
/*     */   private final String name;
/*     */   private final Map<String, Slice> slices;
/*     */   private final Map<String, Slice> activeSlices;
/*     */   private final DocRouter router;
/*     */   private final String znode;
/*     */   private final Integer replicationFactor;
/*     */   private final Integer maxShardsPerNode;
/*     */   private final Boolean autoAddReplicas;
/*     */   
/*     */   public DocCollection(String name, Map<String, Slice> slices, Map<String, Object> props, DocRouter router)
/*     */   {
/*  63 */     this(name, slices, props, router, Integer.MAX_VALUE, "/clusterstate.json");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocCollection(String name, Map<String, Slice> slices, Map<String, Object> props, DocRouter router, int zkVersion, String znode)
/*     */   {
/*  72 */     super(props == null ? (props = new HashMap()) : props);
/*     */     
/*  74 */     this.znodeVersion = (zkVersion == -1 ? Integer.MAX_VALUE : zkVersion);
/*  75 */     this.name = name;
/*     */     
/*  77 */     this.slices = slices;
/*  78 */     this.activeSlices = new HashMap();
/*  79 */     this.replicationFactor = ((Integer)verifyProp(props, "replicationFactor"));
/*  80 */     this.maxShardsPerNode = ((Integer)verifyProp(props, "maxShardsPerNode"));
/*  81 */     Boolean autoAddReplicas = (Boolean)verifyProp(props, "autoAddReplicas");
/*  82 */     this.autoAddReplicas = Boolean.valueOf(autoAddReplicas == null ? false : autoAddReplicas.booleanValue());
/*  83 */     verifyProp(props, "rule");
/*  84 */     verifyProp(props, "snitch");
/*  85 */     Iterator<Map.Entry<String, Slice>> iter = slices.entrySet().iterator();
/*     */     
/*  87 */     while (iter.hasNext()) {
/*  88 */       Map.Entry<String, Slice> slice = (Map.Entry)iter.next();
/*  89 */       if (((Slice)slice.getValue()).getState() == Slice.State.ACTIVE)
/*  90 */         this.activeSlices.put(slice.getKey(), slice.getValue());
/*     */     }
/*  92 */     this.router = router;
/*  93 */     this.znode = (znode == null ? "/clusterstate.json" : znode);
/*  94 */     assert ((name != null) && (slices != null));
/*     */   }
/*     */   
/*     */   public static Object verifyProp(Map<String, Object> props, String propName) {
/*  98 */     Object o = props.get(propName);
/*  99 */     if (o == null) return null;
/* 100 */     switch (propName) {
/*     */     case "replicationFactor": 
/*     */     case "maxShardsPerNode": 
/* 103 */       return Integer.valueOf(Integer.parseInt(o.toString()));
/*     */     case "autoAddReplicas": 
/* 105 */       return Boolean.valueOf(Boolean.parseBoolean(o.toString()));
/*     */     case "rule": 
/*     */     case "snitch": 
/* 108 */       return (List)o;
/*     */     }
/* 110 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocCollection copyWithSlices(Map<String, Slice> slices)
/*     */   {
/* 120 */     return new DocCollection(getName(), slices, this.propMap, this.router, this.znodeVersion, this.znode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 127 */     return this.name;
/*     */   }
/*     */   
/*     */   public Slice getSlice(String sliceName) {
/* 131 */     return (Slice)this.slices.get(sliceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<Slice> getSlices()
/*     */   {
/* 138 */     return this.slices.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Slice> getActiveSlices()
/*     */   {
/* 146 */     return this.activeSlices.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Slice> getSlicesMap()
/*     */   {
/* 153 */     return this.slices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Slice> getActiveSlicesMap()
/*     */   {
/* 160 */     return this.activeSlices;
/*     */   }
/*     */   
/*     */   public int getZNodeVersion() {
/* 164 */     return this.znodeVersion;
/*     */   }
/*     */   
/*     */   public int getStateFormat() {
/* 168 */     return "/clusterstate.json".equals(this.znode) ? 1 : 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Integer getReplicationFactor()
/*     */   {
/* 175 */     return this.replicationFactor;
/*     */   }
/*     */   
/*     */   public boolean getAutoAddReplicas() {
/* 179 */     return this.autoAddReplicas.booleanValue();
/*     */   }
/*     */   
/*     */   public int getMaxShardsPerNode() {
/* 183 */     if (this.maxShardsPerNode == null) {
/* 184 */       throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "maxShardsPerNode is not in the cluster state.");
/*     */     }
/* 186 */     return this.maxShardsPerNode.intValue();
/*     */   }
/*     */   
/*     */   public String getZNode() {
/* 190 */     return this.znode;
/*     */   }
/*     */   
/*     */   public DocRouter getRouter()
/*     */   {
/* 195 */     return this.router;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 200 */     return "DocCollection(" + this.name + "/" + this.znode + "/" + this.znodeVersion + ")=" + JSONUtil.toJSON(this);
/*     */   }
/*     */   
/*     */   public void write(JSONWriter jsonWriter)
/*     */   {
/* 205 */     LinkedHashMap<String, Object> all = new LinkedHashMap(this.slices.size() + 1);
/* 206 */     all.putAll(this.propMap);
/* 207 */     all.put("shards", this.slices);
/* 208 */     jsonWriter.write(all);
/*     */   }
/*     */   
/*     */   public Replica getReplica(String coreNodeName) {
/* 212 */     for (Slice slice : this.slices.values()) {
/* 213 */       Replica replica = slice.getReplica(coreNodeName);
/* 214 */       if (replica != null) return replica;
/*     */     }
/* 216 */     return null;
/*     */   }
/*     */   
/*     */   public Replica getLeader(String sliceName) {
/* 220 */     Slice slice = getSlice(sliceName);
/* 221 */     if (slice == null) return null;
/* 222 */     return slice.getLeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isFullyActive(Set<String> liveNodes, DocCollection collectionState, int expectedShards, int expectedReplicas)
/*     */   {
/* 232 */     Objects.requireNonNull(liveNodes);
/* 233 */     if (collectionState == null)
/* 234 */       return false;
/* 235 */     int activeShards = 0;
/* 236 */     for (Slice slice : collectionState) {
/* 237 */       int activeReplicas = 0;
/* 238 */       for (Replica replica : slice) {
/* 239 */         if (!replica.isActive(liveNodes))
/* 240 */           return false;
/* 241 */         activeReplicas++;
/*     */       }
/* 243 */       if (activeReplicas != expectedReplicas)
/* 244 */         return false;
/* 245 */       activeShards++;
/*     */     }
/* 247 */     return activeShards == expectedShards;
/*     */   }
/*     */   
/*     */   public Iterator<Slice> iterator()
/*     */   {
/* 252 */     return this.slices.values().iterator();
/*     */   }
/*     */   
/*     */   public List<Replica> getReplicas() {
/* 256 */     List<Replica> replicas = new ArrayList();
/* 257 */     for (Slice slice : this) {
/* 258 */       replicas.addAll(slice.getReplicas());
/*     */     }
/* 260 */     return replicas;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getShardId(String nodeName, String coreName)
/*     */   {
/* 267 */     for (Iterator localIterator1 = iterator(); localIterator1.hasNext();) { slice = (Slice)localIterator1.next();
/* 268 */       for (Replica replica : slice)
/* 269 */         if ((Objects.equals(replica.getNodeName(), nodeName)) && (Objects.equals(replica.getCoreName(), coreName)))
/* 270 */           return slice.getName();
/*     */     }
/*     */     Slice slice;
/* 273 */     return null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object that)
/*     */   {
/* 278 */     if (!(that instanceof DocCollection))
/* 279 */       return false;
/* 280 */     DocCollection other = (DocCollection)that;
/* 281 */     return (super.equals(that)) && (Objects.equals(this.znode, other.znode)) && (this.znodeVersion == other.znodeVersion);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\DocCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */