/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ import org.apache.solr.common.util.SimpleOrderedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuggesterResponse
/*    */ {
/*    */   private static final String SUGGESTIONS_NODE_NAME = "suggestions";
/*    */   private static final String TERM_NODE_NAME = "term";
/*    */   private static final String WEIGHT_NODE_NAME = "weight";
/*    */   private static final String PAYLOAD_NODE_NAME = "payload";
/* 36 */   private final Map<String, List<Suggestion>> suggestionsPerDictionary = new LinkedHashMap();
/*    */   
/*    */   public SuggesterResponse(Map<String, NamedList<Object>> suggestInfo) {
/* 39 */     for (Map.Entry<String, NamedList<Object>> entry : suggestInfo.entrySet()) {
/* 40 */       SimpleOrderedMap suggestionsNode = (SimpleOrderedMap)((NamedList)entry.getValue()).getVal(0);
/*    */       
/* 42 */       List<Suggestion> suggestionList = new LinkedList();
/* 43 */       if (suggestionsNode != null)
/*    */       {
/* 45 */         List<SimpleOrderedMap> suggestionListToParse = (List)suggestionsNode.get("suggestions");
/* 46 */         for (SimpleOrderedMap suggestion : suggestionListToParse) {
/* 47 */           String term = (String)suggestion.get("term");
/* 48 */           long weight = ((Long)suggestion.get("weight")).longValue();
/* 49 */           String payload = (String)suggestion.get("payload");
/*    */           
/* 51 */           Suggestion parsedSuggestion = new Suggestion(term, weight, payload);
/* 52 */           suggestionList.add(parsedSuggestion);
/*    */         }
/* 54 */         this.suggestionsPerDictionary.put(entry.getKey(), suggestionList);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, List<Suggestion>> getSuggestions()
/*    */   {
/* 65 */     return this.suggestionsPerDictionary;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, List<String>> getSuggestedTerms()
/*    */   {
/* 75 */     Map<String, List<String>> suggestedTermsPerDictionary = new LinkedHashMap();
/* 76 */     for (Map.Entry<String, List<Suggestion>> entry : this.suggestionsPerDictionary.entrySet()) {
/* 77 */       List<Suggestion> suggestions = (List)entry.getValue();
/* 78 */       List<String> suggestionTerms = new LinkedList();
/* 79 */       for (Suggestion s : suggestions) {
/* 80 */         suggestionTerms.add(s.getTerm());
/*    */       }
/* 82 */       suggestedTermsPerDictionary.put(entry.getKey(), suggestionTerms);
/*    */     }
/* 84 */     return suggestedTermsPerDictionary;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\SuggesterResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */