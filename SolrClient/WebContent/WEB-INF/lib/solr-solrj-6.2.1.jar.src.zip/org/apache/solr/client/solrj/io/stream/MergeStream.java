/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MergeStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PushBackStream[] streams;
/*     */   private StreamComparator comp;
/*     */   
/*     */   public MergeStream(TupleStream streamA, TupleStream streamB, StreamComparator comp)
/*     */     throws IOException
/*     */   {
/*  48 */     init(comp, new TupleStream[] { streamA, streamB });
/*     */   }
/*     */   
/*     */   public MergeStream(StreamComparator comp, TupleStream... streams) throws IOException {
/*  52 */     init(comp, streams);
/*     */   }
/*     */   
/*     */   public MergeStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  57 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  58 */     StreamExpressionNamedParameter onExpression = factory.getNamedOperand(expression, "on");
/*     */     
/*     */ 
/*  61 */     if (expression.getParameters().size() != streamExpressions.size() + 1) {
/*  62 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  65 */     if (streamExpressions.size() < 2) {
/*  66 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting at least two streams but found %d (must be PushBackStream types)", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  69 */     if ((null == onExpression) || (!(onExpression.getParameter() instanceof StreamExpressionValue))) {
/*  70 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'on' parameter listing fields to merge on but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  73 */     TupleStream[] streams = new TupleStream[streamExpressions.size()];
/*  74 */     for (int idx = 0; idx < streamExpressions.size(); idx++) {
/*  75 */       streams[idx] = factory.constructStream((StreamExpression)streamExpressions.get(idx));
/*     */     }
/*     */     
/*  78 */     init(factory.constructComparator(((StreamExpressionValue)onExpression.getParameter()).getValue(), FieldComparator.class), streams);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init(StreamComparator comp, TupleStream... streams)
/*     */     throws IOException
/*     */   {
/*  86 */     for (TupleStream stream : streams) {
/*  87 */       if (!comp.isDerivedFrom(stream.getStreamSort())) {
/*  88 */         throw new IOException("Invalid MergeStream - all substream comparators (sort) must be a superset of this stream's comparator.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  93 */     this.streams = new PushBackStream[streams.length];
/*  94 */     for (int idx = 0; idx < streams.length; idx++) {
/*  95 */       this.streams[idx] = new PushBackStream(streams[idx]);
/*     */     }
/*  97 */     this.comp = comp;
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 102 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 107 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 110 */     for (PushBackStream stream : this.streams) {
/* 111 */       if (includeStreams) {
/* 112 */         expression.addParameter(stream.toExpression(factory));
/*     */       }
/*     */       else {
/* 115 */         expression.addParameter("<stream>");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 120 */     expression.addParameter(new StreamExpressionNamedParameter("on", this.comp.toExpression(factory)));
/*     */     
/* 122 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 128 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId().toString());
/* 129 */     explanation.setFunctionName(factory.getFunctionName(getClass()));
/* 130 */     explanation.setImplementingClass(getClass().getName());
/* 131 */     explanation.setExpressionType("stream-decorator");
/* 132 */     explanation.setExpression(toExpression(factory, false).toString());
/* 133 */     explanation.addHelper(this.comp.toExplanation(factory));
/*     */     
/* 135 */     for (PushBackStream stream : this.streams) {
/* 136 */       explanation.addChild(stream.toExplanation(factory));
/*     */     }
/*     */     
/* 139 */     return explanation;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 143 */     for (PushBackStream stream : this.streams) {
/* 144 */       stream.setStreamContext(context);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 149 */     List<TupleStream> l = new ArrayList();
/* 150 */     for (PushBackStream stream : this.streams) {
/* 151 */       l.add(stream);
/*     */     }
/* 153 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 157 */     for (PushBackStream stream : this.streams) {
/* 158 */       stream.open();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 163 */     for (PushBackStream stream : this.streams) {
/* 164 */       stream.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tuple read()
/*     */     throws IOException
/*     */   {
/* 175 */     Tuple minimum = null;
/* 176 */     PushBackStream minimumStream = null;
/* 177 */     for (PushBackStream stream : this.streams) {
/* 178 */       Tuple current = stream.read();
/*     */       
/* 180 */       if (current.EOF) {
/* 181 */         stream.pushBack(current);
/*     */ 
/*     */ 
/*     */       }
/* 185 */       else if (null == minimum) {
/* 186 */         minimum = current;
/* 187 */         minimumStream = stream;
/*     */ 
/*     */ 
/*     */       }
/* 191 */       else if (this.comp.compare(current, minimum) < 0)
/*     */       {
/* 193 */         minimumStream.pushBack(minimum);
/*     */         
/* 195 */         minimum = current;
/* 196 */         minimumStream = stream;
/*     */       }
/*     */       else
/*     */       {
/* 200 */         stream.pushBack(current);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 205 */     if (null == minimum)
/*     */     {
/* 207 */       return this.streams[0].read();
/*     */     }
/*     */     
/* 210 */     return minimum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 242 */     return this.comp;
/*     */   }
/*     */   
/*     */   public int getCost()
/*     */   {
/* 247 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\MergeStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */