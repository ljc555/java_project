/*    */ package org.apache.solr.client.solrj.request;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.apache.solr.client.solrj.SolrClient;
/*    */ import org.apache.solr.client.solrj.SolrRequest;
/*    */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*    */ import org.apache.solr.client.solrj.response.UpdateResponse;
/*    */ import org.apache.solr.client.solrj.util.ClientUtils;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ import org.apache.solr.common.util.ContentStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectXmlRequest
/*    */   extends SolrRequest<UpdateResponse>
/*    */   implements IsUpdateRequest
/*    */ {
/*    */   final String xml;
/*    */   private SolrParams params;
/*    */   
/*    */   public DirectXmlRequest(String path, String body)
/*    */   {
/* 41 */     super(SolrRequest.METHOD.POST, path);
/* 42 */     this.xml = body;
/*    */   }
/*    */   
/*    */   public Collection<ContentStream> getContentStreams()
/*    */   {
/* 47 */     return ClientUtils.toContentStreams(this.xml, "application/xml; charset=UTF-8");
/*    */   }
/*    */   
/*    */   protected UpdateResponse createResponse(SolrClient client)
/*    */   {
/* 52 */     return new UpdateResponse();
/*    */   }
/*    */   
/*    */   public SolrParams getParams()
/*    */   {
/* 57 */     return this.params;
/*    */   }
/*    */   
/*    */   public void setParams(SolrParams params)
/*    */   {
/* 62 */     this.params = params;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\DirectXmlRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */