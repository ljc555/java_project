/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.impl.InputStreamResponseParser;
/*     */ import org.apache.solr.client.solrj.request.QueryRequest;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.noggit.JSONParser;
/*     */ import org.noggit.ObjectBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONTupleStream
/*     */ {
/*     */   private List<String> path;
/*     */   private Reader reader;
/*     */   private JSONParser parser;
/*     */   private boolean atDocs;
/*     */   
/*     */   public JSONTupleStream(Reader reader)
/*     */   {
/*  50 */     this.reader = reader;
/*  51 */     this.parser = new JSONParser(reader);
/*     */   }
/*     */   
/*     */   public static JSONTupleStream create(SolrClient server, SolrParams requestParams) throws IOException, SolrServerException
/*     */   {
/*  56 */     String p = requestParams.get("qt");
/*  57 */     if (p != null) {
/*  58 */       ModifiableSolrParams modifiableSolrParams = (ModifiableSolrParams)requestParams;
/*  59 */       modifiableSolrParams.remove("qt");
/*     */     }
/*     */     
/*  62 */     QueryRequest query = new QueryRequest(requestParams);
/*  63 */     query.setPath(p);
/*  64 */     query.setResponseParser(new InputStreamResponseParser("json"));
/*  65 */     query.setMethod(SolrRequest.METHOD.POST);
/*  66 */     NamedList<Object> genericResponse = server.request(query);
/*  67 */     InputStream stream = (InputStream)genericResponse.get("stream");
/*  68 */     InputStreamReader reader = new InputStreamReader(stream, "UTF-8");
/*  69 */     return new JSONTupleStream(reader);
/*     */   }
/*     */   
/*     */   public Map<String, Object> next()
/*     */     throws IOException
/*     */   {
/*  75 */     if (!this.atDocs) {
/*  76 */       boolean found = advanceToDocs();
/*  77 */       this.atDocs = true;
/*  78 */       if (!found) { return null;
/*     */       }
/*     */     }
/*  81 */     int event = this.parser.nextEvent();
/*  82 */     if (event == 10) { return null;
/*     */     }
/*  84 */     Object o = ObjectBuilder.getVal(this.parser);
/*     */     
/*     */ 
/*  87 */     return (Map)o;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  91 */     this.reader.close();
/*     */   }
/*     */   
/*     */   private void expect(int parserEventType) throws IOException
/*     */   {
/*  96 */     int event = this.parser.nextEvent();
/*  97 */     if (event != parserEventType) {
/*  98 */       throw new IOException("JSONTupleStream: expected " + JSONParser.getEventString(parserEventType) + " but got " + JSONParser.getEventString(event));
/*     */     }
/*     */   }
/*     */   
/*     */   private void expect(String mapKey) {}
/*     */   
/*     */   private boolean advanceToMapKey(String key, boolean deepSearch)
/*     */     throws IOException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 109 */       int event = this.parser.nextEvent();
/* 110 */       switch (event) {
/*     */       case 1: 
/* 112 */         if (key != null) {
/* 113 */           String val = this.parser.getString();
/* 114 */           if (key.equals(val))
/* 115 */             return true;
/* 116 */           if ("error".equals(val))
/* 117 */             handleError();
/*     */         }
/* 119 */         break;
/*     */       
/*     */       case 8: 
/* 122 */         return false;
/*     */       case 7: 
/* 124 */         if (deepSearch) {
/* 125 */           boolean found = advanceToMapKey(key, true);
/* 126 */           if (found) {
/* 127 */             return true;
/*     */           }
/*     */         } else {
/* 130 */           advanceToMapKey(null, false);
/*     */         }
/* 132 */         break;
/*     */       case 9: 
/* 134 */         skipArray(key, deepSearch);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleError() throws IOException
/*     */   {
/*     */     for (;;) {
/* 142 */       int event = this.parser.nextEvent();
/* 143 */       if (event == 1) {
/* 144 */         String val = this.parser.getString();
/* 145 */         if ("msg".equals(val)) {
/* 146 */           event = this.parser.nextEvent();
/* 147 */           if (event == 1) {
/* 148 */             String msg = this.parser.getString();
/* 149 */             if (msg != null) {
/* 150 */               throw new SolrStream.HandledException(msg);
/*     */             }
/*     */           }
/*     */         }
/* 154 */       } else if (event == 8) {
/* 155 */         throw new IOException("");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void skipArray(String key, boolean deepSearch) throws IOException {
/*     */     for (;;) {
/* 162 */       int event = this.parser.nextEvent();
/* 163 */       switch (event) {
/*     */       case 7: 
/* 165 */         advanceToMapKey(key, deepSearch);
/* 166 */         break;
/*     */       case 9: 
/* 168 */         skipArray(key, deepSearch);
/* 169 */         break;
/*     */       case 10: 
/* 171 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean advanceToDocs() throws IOException
/*     */   {
/* 178 */     expect(7);
/* 179 */     boolean found = advanceToMapKey("docs", true);
/* 180 */     expect(9);
/* 181 */     return found;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\JSONTupleStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */