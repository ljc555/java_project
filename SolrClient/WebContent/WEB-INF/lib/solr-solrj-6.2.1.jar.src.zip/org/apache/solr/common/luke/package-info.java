package org.apache.solr.common.luke;

interface package-info {}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\luke\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */