/*    */ package org.apache.solr.client.solrj.io.ops;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceOperation
/*    */   implements StreamOperation
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private StreamOperation replacer;
/*    */   
/*    */   public ReplaceOperation(StreamExpression expression, StreamFactory factory)
/*    */     throws IOException
/*    */   {
/* 51 */     this(null, expression, factory);
/*    */   }
/*    */   
/*    */   public ReplaceOperation(String forField, StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 56 */     StreamExpressionNamedParameter withValue = factory.getNamedOperand(expression, "withValue");
/* 57 */     StreamExpressionNamedParameter withField = factory.getNamedOperand(expression, "withField");
/*    */     
/* 59 */     if ((null != withValue) && (null == withField)) {
/* 60 */       this.replacer = new ReplaceWithValueOperation(forField, expression, factory);
/*    */     }
/* 62 */     else if ((null != withField) && (null == withValue)) {
/* 63 */       this.replacer = new ReplaceWithFieldOperation(forField, expression, factory);
/*    */     } else {
/* 65 */       if ((null != withValue) && (null != withField)) {
/* 66 */         throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting either withValue or withField parameter but found both", new Object[] { expression }));
/*    */       }
/*    */       
/* 69 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting withValue or withField parameter but found neither", new Object[] { expression }));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void operate(Tuple tuple)
/*    */   {
/* 76 */     this.replacer.operate(tuple);
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*    */   {
/* 81 */     return this.replacer.toExpression(factory);
/*    */   }
/*    */   
/*    */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*    */   {
/* 86 */     return this.replacer.toExplanation(factory);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\ReplaceOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */