/*     */ package org.apache.solr.client.solrj.io.stream.expr;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamExpression
/*     */   implements StreamExpressionParameter
/*     */ {
/*     */   private String functionName;
/*     */   private List<StreamExpressionParameter> parameters;
/*     */   
/*     */   public StreamExpression(String functionName)
/*     */   {
/*  30 */     this.functionName = functionName;
/*  31 */     this.parameters = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*  35 */   public String getFunctionName() { return this.functionName; }
/*     */   
/*     */   public void setFunctionName(String functionName) {
/*  38 */     if (null == functionName) {
/*  39 */       throw new IllegalArgumentException("Null functionName is not allowed.");
/*     */     }
/*     */     
/*  42 */     this.functionName = functionName;
/*     */   }
/*     */   
/*  45 */   public StreamExpression withFunctionName(String functionName) { setFunctionName(functionName);
/*  46 */     return this;
/*     */   }
/*     */   
/*     */   public void addParameter(StreamExpressionParameter parameter) {
/*  50 */     this.parameters.add(parameter);
/*     */   }
/*     */   
/*  53 */   public void addParameter(String parameter) { addParameter(new StreamExpressionValue(parameter)); }
/*     */   
/*     */   public StreamExpression withParameter(StreamExpressionParameter parameter)
/*     */   {
/*  57 */     this.parameters.add(parameter);
/*  58 */     return this;
/*     */   }
/*     */   
/*  61 */   public StreamExpression withParameter(String parameter) { return withParameter(new StreamExpressionValue(parameter)); }
/*     */   
/*     */ 
/*     */ 
/*  65 */   public List<StreamExpressionParameter> getParameters() { return this.parameters; }
/*     */   
/*     */   public void setParameters(List<StreamExpressionParameter> parameters) {
/*  68 */     if (null == parameters) {
/*  69 */       throw new IllegalArgumentException("Null parameter list is not allowed.");
/*     */     }
/*     */     
/*  72 */     this.parameters = parameters;
/*     */   }
/*     */   
/*  75 */   public StreamExpression withParameters(List<StreamExpressionParameter> parameters) { setParameters(parameters);
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  81 */     StringBuilder sb = new StringBuilder(this.functionName);
/*     */     
/*  83 */     sb.append("(");
/*  84 */     for (int idx = 0; idx < this.parameters.size(); idx++) {
/*  85 */       if (0 != idx) sb.append(",");
/*  86 */       sb.append(this.parameters.get(idx));
/*     */     }
/*  88 */     sb.append(")");
/*     */     
/*  90 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other)
/*     */   {
/*  95 */     if (other.getClass() != StreamExpression.class) {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     StreamExpression check = (StreamExpression)other;
/*     */     
/* 101 */     if ((null == this.functionName) && (null != check.functionName)) {
/* 102 */       return false;
/*     */     }
/* 104 */     if ((null != this.functionName) && (null == check.functionName)) {
/* 105 */       return false;
/*     */     }
/*     */     
/* 108 */     if ((null != this.functionName) && (null != check.functionName) && (!this.functionName.equals(check.functionName))) {
/* 109 */       return false;
/*     */     }
/*     */     
/* 112 */     if (this.parameters.size() != check.parameters.size()) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     for (int idx = 0; idx < this.parameters.size(); idx++) {
/* 117 */       StreamExpressionParameter left = (StreamExpressionParameter)this.parameters.get(idx);
/* 118 */       StreamExpressionParameter right = (StreamExpressionParameter)check.parameters.get(idx);
/* 119 */       if (!left.equals(right)) {
/* 120 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 124 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */