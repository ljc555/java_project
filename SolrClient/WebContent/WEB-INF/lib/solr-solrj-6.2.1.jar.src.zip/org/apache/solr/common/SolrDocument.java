/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrDocument
/*     */   extends SolrDocumentBase<Object, SolrDocument>
/*     */   implements Iterable<Map.Entry<String, Object>>
/*     */ {
/*     */   private final Map<String, Object> _fields;
/*     */   private List<SolrDocument> _childDocuments;
/*     */   
/*     */   public SolrDocument()
/*     */   {
/*  50 */     this._fields = new LinkedHashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getFieldNames()
/*     */   {
/*  59 */     return keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  72 */     this._fields.clear();
/*     */     
/*  74 */     if (this._childDocuments != null) {
/*  75 */       this._childDocuments.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeFields(String name)
/*     */   {
/*  84 */     return remove(name) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setField(String name, Object value)
/*     */   {
/*  95 */     if ((value instanceof Object[])) {
/*  96 */       value = new ArrayList(Arrays.asList((Object[])value));
/*     */     }
/*  98 */     else if (!(value instanceof Collection))
/*     */     {
/*     */ 
/* 101 */       if (!(value instanceof NamedList))
/*     */       {
/*     */ 
/* 104 */         if ((value instanceof Iterable)) {
/* 105 */           ArrayList<Object> lst = new ArrayList();
/* 106 */           for (Object o : (Iterable)value) {
/* 107 */             lst.add(o);
/*     */           }
/* 109 */           value = lst;
/*     */         } } }
/* 111 */     this._fields.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addField(String name, Object value)
/*     */   {
/* 129 */     Object existing = this._fields.get(name);
/* 130 */     Object localObject1; if (existing == null) {
/* 131 */       if ((value instanceof Collection)) {
/* 132 */         Collection<Object> c = new ArrayList(3);
/* 133 */         for (localObject1 = ((Collection)value).iterator(); ((Iterator)localObject1).hasNext();) { Object o = ((Iterator)localObject1).next();
/* 134 */           c.add(o);
/*     */         }
/* 136 */         setField(name, c);
/*     */       } else {
/* 138 */         setField(name, value);
/*     */       }
/* 140 */       return;
/*     */     }
/*     */     
/* 143 */     Collection<Object> vals = null;
/* 144 */     if ((existing instanceof Collection)) {
/* 145 */       vals = (Collection)existing;
/*     */     }
/*     */     else {
/* 148 */       vals = new ArrayList(3);
/* 149 */       vals.add(existing);
/*     */     }
/*     */     
/*     */     Object o;
/* 153 */     if ((value instanceof Iterable)) {
/* 154 */       for (localObject1 = ((Iterable)value).iterator(); ((Iterator)localObject1).hasNext();) { o = ((Iterator)localObject1).next();
/* 155 */         vals.add(o);
/*     */       }
/*     */     }
/* 158 */     else if ((value instanceof Object[])) {
/* 159 */       localObject1 = (Object[])value;o = localObject1.length; for (Object localObject2 = 0; localObject2 < o; localObject2++) { Object o = localObject1[localObject2];
/* 160 */         vals.add(o);
/*     */       }
/*     */     }
/*     */     else {
/* 164 */       vals.add(value);
/*     */     }
/* 166 */     this._fields.put(name, vals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getFirstValue(String name)
/*     */   {
/* 177 */     Object v = this._fields.get(name);
/* 178 */     if ((v == null) || (!(v instanceof Collection))) return v;
/* 179 */     Collection c = (Collection)v;
/* 180 */     if (c.size() > 0) {
/* 181 */       return c.iterator().next();
/*     */     }
/* 183 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getFieldValue(String name)
/*     */   {
/* 191 */     return this._fields.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Object> getFieldValues(String name)
/*     */   {
/* 200 */     Object v = this._fields.get(name);
/* 201 */     if ((v instanceof Collection)) {
/* 202 */       return (Collection)v;
/*     */     }
/* 204 */     if (v != null) {
/* 205 */       ArrayList<Object> arr = new ArrayList(1);
/* 206 */       arr.add(v);
/* 207 */       return arr;
/*     */     }
/* 209 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 215 */     return "SolrDocument" + this._fields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Map.Entry<String, Object>> iterator()
/*     */   {
/* 223 */     return this._fields.entrySet().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Collection<Object>> getFieldValuesMap()
/*     */   {
/* 235 */     new Map()
/*     */     {
/*     */       public Collection<Object> get(Object key)
/*     */       {
/* 239 */         return SolrDocument.this.getFieldValues((String)key);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 244 */       public boolean containsKey(Object key) { return SolrDocument.this._fields.containsKey(key); }
/*     */       
/* 246 */       public Set<String> keySet() { return SolrDocument.this._fields.keySet(); }
/*     */       
/* 248 */       public int size() { return SolrDocument.this._fields.size(); }
/*     */       
/* 250 */       public boolean isEmpty() { return SolrDocument.this._fields.isEmpty(); }
/*     */       
/*     */ 
/*     */ 
/* 254 */       public void clear() { throw new UnsupportedOperationException(); }
/*     */       
/* 256 */       public boolean containsValue(Object value) { throw new UnsupportedOperationException(); }
/*     */       
/* 258 */       public Set<Map.Entry<String, Collection<Object>>> entrySet() { throw new UnsupportedOperationException(); }
/*     */       
/* 260 */       public void putAll(Map<? extends String, ? extends Collection<Object>> t) { throw new UnsupportedOperationException(); }
/*     */       
/* 262 */       public Collection<Collection<Object>> values() { throw new UnsupportedOperationException(); }
/*     */       
/* 264 */       public Collection<Object> put(String key, Collection<Object> value) { throw new UnsupportedOperationException(); }
/*     */       
/* 266 */       public Collection<Object> remove(Object key) { throw new UnsupportedOperationException(); }
/*     */       
/* 268 */       public String toString() { return SolrDocument.this._fields.toString(); }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getFieldValueMap()
/*     */   {
/* 276 */     new Map()
/*     */     {
/*     */       public Object get(Object key)
/*     */       {
/* 280 */         return SolrDocument.this.getFirstValue((String)key);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 285 */       public boolean containsKey(Object key) { return SolrDocument.this._fields.containsKey(key); }
/*     */       
/* 287 */       public Set<String> keySet() { return SolrDocument.this._fields.keySet(); }
/*     */       
/* 289 */       public int size() { return SolrDocument.this._fields.size(); }
/*     */       
/* 291 */       public boolean isEmpty() { return SolrDocument.this._fields.isEmpty(); }
/*     */       
/*     */ 
/*     */ 
/* 295 */       public void clear() { throw new UnsupportedOperationException(); }
/*     */       
/* 297 */       public boolean containsValue(Object value) { throw new UnsupportedOperationException(); }
/*     */       
/* 299 */       public Set<Map.Entry<String, Object>> entrySet() { throw new UnsupportedOperationException(); }
/*     */       
/* 301 */       public void putAll(Map<? extends String, ? extends Object> t) { throw new UnsupportedOperationException(); }
/*     */       
/* 303 */       public Collection<Object> values() { throw new UnsupportedOperationException(); }
/*     */       
/* 305 */       public Collection<Object> put(String key, Object value) { throw new UnsupportedOperationException(); }
/*     */       
/* 307 */       public Collection<Object> remove(Object key) { throw new UnsupportedOperationException(); }
/*     */       
/* 309 */       public String toString() { return SolrDocument.this._fields.toString(); }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 319 */     return this._fields.containsKey(key);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 324 */     return this._fields.containsValue(value);
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet()
/*     */   {
/* 329 */     return this._fields.entrySet();
/*     */   }
/*     */   
/*     */   public Object get(Object key)
/*     */   {
/* 334 */     return this._fields.get(key);
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 339 */     return this._fields.isEmpty();
/*     */   }
/*     */   
/*     */   public Set<String> keySet()
/*     */   {
/* 344 */     return this._fields.keySet();
/*     */   }
/*     */   
/*     */   public Object put(String key, Object value)
/*     */   {
/* 349 */     return this._fields.put(key, value);
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends Object> t)
/*     */   {
/* 354 */     this._fields.putAll(t);
/*     */   }
/*     */   
/*     */   public Object remove(Object key)
/*     */   {
/* 359 */     return this._fields.remove(key);
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 364 */     return this._fields.size();
/*     */   }
/*     */   
/*     */   public Collection<Object> values()
/*     */   {
/* 369 */     return this._fields.values();
/*     */   }
/*     */   
/*     */   public void addChildDocument(SolrDocument child)
/*     */   {
/* 374 */     if (this._childDocuments == null) {
/* 375 */       this._childDocuments = new ArrayList();
/*     */     }
/* 377 */     this._childDocuments.add(child);
/*     */   }
/*     */   
/*     */   public void addChildDocuments(Collection<SolrDocument> children)
/*     */   {
/* 382 */     for (SolrDocument child : children) {
/* 383 */       addChildDocument(child);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public List<SolrDocument> getChildDocuments()
/*     */   {
/* 390 */     return this._childDocuments;
/*     */   }
/*     */   
/*     */   public boolean hasChildDocuments()
/*     */   {
/* 395 */     boolean isEmpty = (this._childDocuments == null) || (this._childDocuments.isEmpty());
/* 396 */     return !isEmpty;
/*     */   }
/*     */   
/*     */   public int getChildDocumentCount()
/*     */   {
/* 401 */     return this._childDocuments.size();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */