/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntervalFacet
/*    */ {
/*    */   private final String field;
/*    */   private final List<Count> intervals;
/*    */   
/*    */   IntervalFacet(String field, List<Count> values)
/*    */   {
/* 38 */     this.field = field;
/* 39 */     this.intervals = values;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getField()
/*    */   {
/* 46 */     return this.field;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<Count> getIntervals()
/*    */   {
/* 53 */     return this.intervals;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class Count
/*    */   {
/*    */     private final String key;
/*    */     
/*    */ 
/*    */ 
/*    */     private final int count;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     Count(String key, int count)
/*    */     {
/* 73 */       this.key = key;
/* 74 */       this.count = count;
/*    */     }
/*    */     
/*    */     public String getKey() {
/* 78 */       return this.key;
/*    */     }
/*    */     
/*    */     public int getCount() {
/* 82 */       return this.count;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\IntervalFacet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */