/*     */ package org.apache.solr.client.solrj.io.stream.expr;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamExpressionParser
/*     */ {
/*  30 */   static char[] wordChars = { '_', '.', '-' };
/*     */   
/*     */   static {
/*  33 */     Arrays.sort(wordChars);
/*     */   }
/*     */   
/*     */   public static StreamExpression parse(String clause) {
/*  37 */     StreamExpressionParameter expr = generateStreamExpression(clause);
/*  38 */     if ((null != expr) && ((expr instanceof StreamExpression))) {
/*  39 */       return (StreamExpression)expr;
/*     */     }
/*     */     
/*  42 */     return null;
/*     */   }
/*     */   
/*     */   private static StreamExpressionParameter generateStreamExpression(String clause) {
/*  46 */     String working = clause.trim();
/*     */     
/*  48 */     if (!isExpressionClause(working)) {
/*  49 */       throw new IllegalArgumentException(String.format(Locale.ROOT, "'%s' is not a proper expression clause", new Object[] { working }));
/*     */     }
/*     */     
/*     */ 
/*  53 */     int firstOpenParen = findNextClear(working, 0, '(');
/*  54 */     StreamExpression expression = new StreamExpression(working.substring(0, firstOpenParen).trim());
/*     */     
/*     */ 
/*  57 */     working = working.substring(firstOpenParen + 1, working.length() - 1).trim();
/*  58 */     List<String> parts = splitOn(working, ',');
/*     */     
/*  60 */     for (int idx = 0; idx < parts.size(); idx++) {
/*  61 */       String part = ((String)parts.get(idx)).trim();
/*  62 */       if (isExpressionClause(part)) {
/*  63 */         StreamExpressionParameter parameter = generateStreamExpression(part);
/*  64 */         if (null != parameter) {
/*  65 */           expression.addParameter(parameter);
/*     */         }
/*     */       }
/*  68 */       else if (isNamedParameterClause(part)) {
/*  69 */         StreamExpressionNamedParameter parameter = generateNamedParameterExpression(part);
/*  70 */         if (null != parameter) {
/*  71 */           expression.addParameter(parameter);
/*     */         }
/*     */       }
/*     */       else {
/*  75 */         expression.addParameter(new StreamExpressionValue(part));
/*     */       }
/*     */     }
/*     */     
/*  79 */     return expression;
/*     */   }
/*     */   
/*     */   private static StreamExpressionNamedParameter generateNamedParameterExpression(String clause) {
/*  83 */     String working = clause.trim();
/*     */     
/*     */ 
/*  86 */     if (!isNamedParameterClause(working)) {
/*  87 */       throw new IllegalArgumentException(String.format(Locale.ROOT, "'%s' is not a proper named parameter clause", new Object[] { working }));
/*     */     }
/*     */     
/*     */ 
/*  91 */     int firstOpenEquals = findNextClear(working, 0, '=');
/*  92 */     StreamExpressionNamedParameter namedParameter = new StreamExpressionNamedParameter(working.substring(0, firstOpenEquals).trim());
/*     */     
/*     */ 
/*  95 */     String parameter = working.substring(firstOpenEquals + 1, working.length());
/*  96 */     if (isExpressionClause(parameter)) {
/*  97 */       namedParameter.setParameter(generateStreamExpression(parameter));
/*     */     }
/*     */     else
/*     */     {
/* 101 */       if ((parameter.startsWith("\"")) && (parameter.endsWith("\""))) {
/* 102 */         parameter = parameter.substring(1, parameter.length() - 1).trim();
/* 103 */         if (0 == parameter.length()) {
/* 104 */           throw new IllegalArgumentException(String.format(Locale.ROOT, "'%s' is not a proper named parameter clause", new Object[] { working }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 109 */       if (parameter.contains("\\\"")) {
/* 110 */         parameter = parameter.replace("\\\"", "\"");
/* 111 */         if (0 == parameter.length()) {
/* 112 */           throw new IllegalArgumentException(String.format(Locale.ROOT, "'%s' is not a proper named parameter clause", new Object[] { working }));
/*     */         }
/*     */       }
/*     */       
/* 116 */       namedParameter.setParameter(new StreamExpressionValue(parameter));
/*     */     }
/*     */     
/* 119 */     return namedParameter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isExpressionClause(String clause)
/*     */   {
/* 131 */     if (!isBalanced(clause)) { return false;
/*     */     }
/*     */     
/* 134 */     int firstOpenParen = findNextClear(clause, 0, '(');
/* 135 */     if ((firstOpenParen <= 0) || (firstOpenParen == clause.length() - 1)) return false;
/* 136 */     String functionName = clause.substring(0, firstOpenParen).trim();
/* 137 */     if (!wordToken(functionName)) { return false;
/*     */     }
/*     */     
/* 140 */     return clause.endsWith(")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean isNamedParameterClause(String clause)
/*     */   {
/* 147 */     int firstOpenEquals = findNextClear(clause, 0, '=');
/* 148 */     if ((firstOpenEquals <= 0) || (firstOpenEquals == clause.length() - 1)) return false;
/* 149 */     String name = clause.substring(0, firstOpenEquals);
/* 150 */     if (!wordToken(name)) { return false;
/*     */     }
/* 152 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int findNextClear(String clause, int startingIdx, char findThis)
/*     */   {
/* 159 */     int openParens = 0;
/* 160 */     boolean isDoubleQuote = false;
/* 161 */     boolean isSingleQuote = false;
/* 162 */     boolean isEscaped = false;
/*     */     
/* 164 */     for (int idx = startingIdx; idx < clause.length(); idx++) {
/* 165 */       char c = clause.charAt(idx);
/*     */       
/*     */ 
/* 168 */       if ((c == findThis) && (!isEscaped) && (!isSingleQuote) && (!isDoubleQuote) && (0 == openParens)) {
/* 169 */         return idx;
/*     */       }
/*     */       
/*     */ 
/* 173 */       switch (c)
/*     */       {
/*     */       case '\\': 
/* 176 */         isEscaped = !isEscaped;
/* 177 */         break;
/*     */       
/*     */ 
/*     */       case '"': 
/* 181 */         if ((!isEscaped) && (!isSingleQuote)) {
/* 182 */           isDoubleQuote = !isDoubleQuote;
/*     */         }
/* 184 */         isEscaped = false;
/* 185 */         break;
/*     */       
/*     */ 
/*     */       case '\'': 
/* 189 */         if ((!isEscaped) && (!isDoubleQuote)) {
/* 190 */           isSingleQuote = !isSingleQuote;
/*     */         }
/* 192 */         isEscaped = false;
/* 193 */         break;
/*     */       
/*     */ 
/*     */       case '(': 
/* 197 */         if ((!isEscaped) && (!isSingleQuote) && (!isDoubleQuote)) {
/* 198 */           openParens++;
/*     */         }
/* 200 */         isEscaped = false;
/* 201 */         break;
/*     */       
/*     */ 
/*     */       case ')': 
/* 205 */         if ((!isEscaped) && (!isSingleQuote) && (!isDoubleQuote)) {
/* 206 */           openParens--;
/*     */         }
/* 208 */         isEscaped = false;
/* 209 */         break;
/*     */       default: 
/* 211 */         isEscaped = false;
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 216 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<String> splitOn(String clause, char splitOnThis)
/*     */   {
/* 226 */     String working = clause.trim();
/*     */     
/* 228 */     List<String> parts = new ArrayList();
/*     */     for (;;)
/*     */     {
/* 231 */       int nextIdx = findNextClear(working, 0, splitOnThis);
/*     */       
/* 233 */       if (nextIdx < 0) {
/* 234 */         parts.add(working);
/* 235 */         break;
/*     */       }
/*     */       
/* 238 */       parts.add(working.substring(0, nextIdx));
/*     */       
/*     */ 
/* 241 */       if (nextIdx + 1 == working.length()) {
/*     */         break;
/*     */       }
/*     */       
/* 245 */       working = working.substring(nextIdx + 1).trim();
/*     */     }
/*     */     
/* 248 */     return parts;
/*     */   }
/*     */   
/*     */   private static boolean isBalanced(String clause)
/*     */   {
/* 253 */     int openParens = 0;
/* 254 */     boolean isDoubleQuote = false;
/* 255 */     boolean isSingleQuote = false;
/* 256 */     boolean isEscaped = false;
/*     */     
/* 258 */     for (int idx = 0; idx < clause.length(); idx++) {
/* 259 */       char c = clause.charAt(idx);
/*     */       
/* 261 */       switch (c)
/*     */       {
/*     */       case '\\': 
/* 264 */         isEscaped = !isEscaped;
/* 265 */         break;
/*     */       
/*     */ 
/*     */       case '"': 
/* 269 */         if ((!isEscaped) && (!isSingleQuote)) {
/* 270 */           isDoubleQuote = !isDoubleQuote;
/*     */         }
/* 272 */         isEscaped = false;
/* 273 */         break;
/*     */       
/*     */ 
/*     */       case '\'': 
/* 277 */         if ((!isEscaped) && (!isDoubleQuote)) {
/* 278 */           isSingleQuote = !isSingleQuote;
/*     */         }
/* 280 */         isEscaped = false;
/* 281 */         break;
/*     */       
/*     */ 
/*     */       case '(': 
/* 285 */         if ((!isEscaped) && (!isSingleQuote) && (!isDoubleQuote)) {
/* 286 */           openParens++;
/*     */         }
/* 288 */         isEscaped = false;
/* 289 */         break;
/*     */       
/*     */ 
/*     */       case ')': 
/* 293 */         if ((!isEscaped) && (!isSingleQuote) && (!isDoubleQuote)) {
/* 294 */           openParens--;
/*     */           
/*     */ 
/* 297 */           if (openParens < 0) {
/* 298 */             return false;
/*     */           }
/*     */         }
/* 301 */         isEscaped = false;
/* 302 */         break;
/*     */       
/*     */       default: 
/* 305 */         isEscaped = false;
/*     */       }
/*     */       
/*     */     }
/* 309 */     return 0 == openParens;
/*     */   }
/*     */   
/*     */   public static boolean wordToken(String token) {
/* 313 */     for (int i = 0; i < token.length(); i++) {
/* 314 */       char c = token.charAt(i);
/* 315 */       if ((!Character.isLetterOrDigit(c)) && (Arrays.binarySearch(wordChars, c) < 0)) {
/* 316 */         return false;
/*     */       }
/*     */     }
/* 319 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamExpressionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */