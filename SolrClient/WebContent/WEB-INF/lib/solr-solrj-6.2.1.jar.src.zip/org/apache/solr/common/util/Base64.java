/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*  30 */   private static final char[] intToBase64 = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private static final byte[] base64ToInt = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String byteArrayToBase64(byte[] a)
/*     */   {
/*  56 */     return byteArrayToBase64(a, 0, a.length);
/*     */   }
/*     */   
/*     */   public static String byteArrayToBase64(byte[] a, int offset, int len) {
/*  60 */     int aLen = len;
/*  61 */     int numFullGroups = aLen / 3;
/*  62 */     int numBytesInPartialGroup = aLen - 3 * numFullGroups;
/*  63 */     int resultLen = 4 * ((aLen + 2) / 3);
/*  64 */     StringBuilder result = new StringBuilder(resultLen);
/*  65 */     char[] intToAlpha = intToBase64;
/*     */     
/*     */ 
/*  68 */     int inCursor = offset;
/*  69 */     for (int i = 0; i < numFullGroups; i++) {
/*  70 */       int byte0 = a[(inCursor++)] & 0xFF;
/*  71 */       int byte1 = a[(inCursor++)] & 0xFF;
/*  72 */       int byte2 = a[(inCursor++)] & 0xFF;
/*  73 */       result.append(intToAlpha[(byte0 >> 2)]);
/*  74 */       result.append(intToAlpha[(byte0 << 4 & 0x3F | byte1 >> 4)]);
/*  75 */       result.append(intToAlpha[(byte1 << 2 & 0x3F | byte2 >> 6)]);
/*  76 */       result.append(intToAlpha[(byte2 & 0x3F)]);
/*     */     }
/*     */     
/*     */ 
/*  80 */     if (numBytesInPartialGroup != 0) {
/*  81 */       int byte0 = a[(inCursor++)] & 0xFF;
/*  82 */       result.append(intToAlpha[(byte0 >> 2)]);
/*  83 */       if (numBytesInPartialGroup == 1) {
/*  84 */         result.append(intToAlpha[(byte0 << 4 & 0x3F)]);
/*  85 */         result.append("==");
/*     */       }
/*     */       else {
/*  88 */         int byte1 = a[(inCursor++)] & 0xFF;
/*  89 */         result.append(intToAlpha[(byte0 << 4 & 0x3F | byte1 >> 4)]);
/*  90 */         result.append(intToAlpha[(byte1 << 2 & 0x3F)]);
/*  91 */         result.append('=');
/*     */       }
/*     */     }
/*  94 */     return result.toString();
/*     */   }
/*     */   
/*     */   public static byte[] base64ToByteArray(String s) {
/*  98 */     byte[] alphaToInt = base64ToInt;
/*  99 */     int sLen = s.length();
/* 100 */     int numGroups = sLen / 4;
/* 101 */     if (4 * numGroups != sLen) {
/* 102 */       throw new IllegalArgumentException("String length must be a multiple of four.");
/*     */     }
/* 104 */     int missingBytesInLastGroup = 0;
/* 105 */     int numFullGroups = numGroups;
/* 106 */     if (sLen != 0) {
/* 107 */       if (s.charAt(sLen - 1) == '=') {
/* 108 */         missingBytesInLastGroup++;
/* 109 */         numFullGroups--;
/*     */       }
/* 111 */       if (s.charAt(sLen - 2) == '=')
/* 112 */         missingBytesInLastGroup++;
/*     */     }
/* 114 */     byte[] result = new byte[3 * numGroups - missingBytesInLastGroup];
/*     */     
/*     */ 
/* 117 */     int inCursor = 0;int outCursor = 0;
/* 118 */     for (int i = 0; i < numFullGroups; i++) {
/* 119 */       int ch0 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 120 */       int ch1 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 121 */       int ch2 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 122 */       int ch3 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 123 */       result[(outCursor++)] = ((byte)(ch0 << 2 | ch1 >> 4));
/* 124 */       result[(outCursor++)] = ((byte)(ch1 << 4 | ch2 >> 2));
/* 125 */       result[(outCursor++)] = ((byte)(ch2 << 6 | ch3));
/*     */     }
/*     */     
/*     */ 
/* 129 */     if (missingBytesInLastGroup != 0) {
/* 130 */       int ch0 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 131 */       int ch1 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 132 */       result[(outCursor++)] = ((byte)(ch0 << 2 | ch1 >> 4));
/*     */       
/* 134 */       if (missingBytesInLastGroup == 1) {
/* 135 */         int ch2 = base64toInt(s.charAt(inCursor++), alphaToInt);
/* 136 */         result[(outCursor++)] = ((byte)(ch1 << 4 | ch2 >> 2));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 141 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int base64toInt(char c, byte[] alphaToInt)
/*     */   {
/* 152 */     int result = alphaToInt[c];
/* 153 */     if (result < 0)
/* 154 */       throw new IllegalArgumentException("Illegal character " + c);
/* 155 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\Base64.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */