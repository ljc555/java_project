/*    */ package org.apache.solr.client.solrj.io.stream;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ import java.io.Writer;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TupleStream
/*    */   implements Closeable, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 36 */   private UUID streamNodeId = UUID.randomUUID();
/*    */   
/*    */ 
/*    */ 
/*    */   public static void writeStreamOpen(Writer out)
/*    */     throws IOException
/*    */   {
/* 43 */     out.write("{\"docs\":[");
/*    */   }
/*    */   
/*    */   public static void writeStreamClose(Writer out) throws IOException {
/* 47 */     out.write("]}");
/*    */   }
/*    */   
/*    */   public abstract void setStreamContext(StreamContext paramStreamContext);
/*    */   
/*    */   public abstract List<TupleStream> children();
/*    */   
/*    */   public abstract void open() throws IOException;
/*    */   
/*    */   public abstract void close() throws IOException;
/*    */   
/*    */   public abstract Tuple read() throws IOException;
/*    */   
/*    */   public abstract StreamComparator getStreamSort();
/*    */   
/*    */   public abstract Explanation toExplanation(StreamFactory paramStreamFactory) throws IOException;
/*    */   
/*    */   public int getCost() {
/* 65 */     return 0;
/*    */   }
/*    */   
/*    */   public UUID getStreamNodeId() {
/* 69 */     return this.streamNodeId;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\TupleStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */