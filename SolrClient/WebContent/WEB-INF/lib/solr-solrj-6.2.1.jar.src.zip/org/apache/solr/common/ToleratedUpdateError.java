/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.solr.common.util.SimpleOrderedMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ToleratedUpdateError
/*     */ {
/*  32 */   private static final String META_PRE = ToleratedUpdateError.class.getName() + "--";
/*  33 */   private static final int META_PRE_LEN = META_PRE.length();
/*     */   
/*     */   private final CmdType type;
/*     */   
/*     */   private final String id;
/*     */   
/*     */   private final String message;
/*     */   
/*     */   public static int getEffectiveMaxErrors(int maxErrors)
/*     */   {
/*  43 */     assert (-1 <= maxErrors);
/*  44 */     return -1 == maxErrors ? Integer.MAX_VALUE : maxErrors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getUserFriendlyMaxErrors(int maxErrors)
/*     */   {
/*  55 */     assert (-1 <= maxErrors);
/*  56 */     return Integer.MAX_VALUE == maxErrors ? -1 : maxErrors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<SimpleOrderedMap<String>> formatForResponseHeader(List<ToleratedUpdateError> errs)
/*     */   {
/*  65 */     List<SimpleOrderedMap<String>> result = new ArrayList(errs.size());
/*  66 */     for (ToleratedUpdateError e : errs) {
/*  67 */       result.add(e.getSimpleMap());
/*     */     }
/*  69 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ToleratedUpdateError parseMap(SimpleOrderedMap<String> data)
/*     */   {
/*  77 */     String id = (String)data.get("id");
/*  78 */     String message = (String)data.get("message");
/*  79 */     String t = (String)data.get("type");
/*  80 */     if ((null == t) || (null == id) || (null == message)) {
/*  81 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Map does not represent a ToleratedUpdateError, must contain 'type', 'id', and 'message'");
/*     */     }
/*     */     try {
/*  84 */       return new ToleratedUpdateError(CmdType.valueOf(t), id, message);
/*     */     } catch (IllegalArgumentException iae) {
/*  86 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Invalid type for ToleratedUpdateError: " + t, iae);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ToleratedUpdateError parseMetadataIfToleratedUpdateError(String metadataKey, String metadataVal)
/*     */   {
/*  97 */     if (!metadataKey.startsWith(META_PRE)) {
/*  98 */       return null;
/*     */     }
/* 100 */     int typeEnd = metadataKey.indexOf(':', META_PRE_LEN);
/* 101 */     if (typeEnd < 0) {
/* 102 */       return null;
/*     */     }
/* 104 */     return new ToleratedUpdateError(CmdType.valueOf(metadataKey.substring(META_PRE_LEN, typeEnd)), metadataKey
/* 105 */       .substring(typeEnd + 1), metadataVal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToleratedUpdateError(CmdType type, String id, String message)
/*     */   {
/* 113 */     assert (null != type);
/* 114 */     this.type = type;
/*     */     
/* 116 */     assert (null != id);
/* 117 */     this.id = id;
/*     */     
/* 119 */     assert (null != message);
/* 120 */     this.message = message;
/*     */   }
/*     */   
/*     */   public CmdType getType() {
/* 124 */     return this.type;
/*     */   }
/*     */   
/* 127 */   public String getId() { return this.id; }
/*     */   
/*     */   public String getMessage() {
/* 130 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMetadataKey()
/*     */   {
/* 139 */     return META_PRE + this.type + ":" + this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMetadataValue()
/*     */   {
/* 148 */     return this.message.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleOrderedMap<String> getSimpleMap()
/*     */   {
/* 157 */     SimpleOrderedMap<String> entry = new SimpleOrderedMap();
/* 158 */     entry.add("type", this.type.toString());
/* 159 */     entry.add("id", this.id);
/* 160 */     entry.add("message", this.message);
/* 161 */     return entry;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 165 */     return getMetadataKey() + "=>" + getMetadataValue();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 169 */     int h = getClass().hashCode();
/* 170 */     h = h * 31 + this.type.hashCode();
/* 171 */     h = h * 31 + this.id.hashCode();
/* 172 */     h = h * 31 + this.message.hashCode();
/* 173 */     return h;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 177 */     if ((o instanceof ToleratedUpdateError)) {
/* 178 */       ToleratedUpdateError that = (ToleratedUpdateError)o;
/* 179 */       return (that.type.equals(this.type)) && 
/* 180 */         (that.id.equals(this.id)) && 
/* 181 */         (that.message.equals(this.message));
/*     */     }
/* 183 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static enum CmdType
/*     */   {
/* 190 */     ADD,  DELID,  DELQ;
/*     */     
/*     */     private CmdType() {}
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\ToleratedUpdateError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */