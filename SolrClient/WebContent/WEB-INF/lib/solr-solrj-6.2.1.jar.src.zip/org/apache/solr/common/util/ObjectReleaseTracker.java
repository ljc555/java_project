/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectReleaseTracker
/*     */ {
/*  36 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*  37 */   public static Map<Object, String> OBJECTS = new ConcurrentHashMap();
/*     */   
/*     */   public static boolean track(Object object) {
/*  40 */     StringWriter sw = new StringWriter();
/*  41 */     PrintWriter pw = new PrintWriter(sw);
/*  42 */     new ObjectTrackerException(null).printStackTrace(pw);
/*  43 */     OBJECTS.put(object, sw.toString());
/*  44 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean release(Object object) {
/*  48 */     OBJECTS.remove(object);
/*  49 */     return true;
/*     */   }
/*     */   
/*     */   public static void clear() {
/*  53 */     OBJECTS.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String clearObjectTrackerAndCheckEmpty()
/*     */   {
/*  60 */     String result = checkEmpty();
/*     */     
/*  62 */     OBJECTS.clear();
/*     */     
/*  64 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String checkEmpty()
/*     */   {
/*  71 */     String error = null;
/*  72 */     Set<Map.Entry<Object, String>> entries = OBJECTS.entrySet();
/*     */     
/*  74 */     if (entries.size() > 0) {
/*  75 */       List<String> objects = new ArrayList();
/*  76 */       for (Map.Entry<Object, String> entry : entries) {
/*  77 */         objects.add(entry.getKey().getClass().getSimpleName());
/*     */       }
/*     */       
/*  80 */       error = "ObjectTracker found " + entries.size() + " object(s) that were not released!!! " + objects;
/*     */       
/*  82 */       System.err.println(error);
/*  83 */       for (Map.Entry<Object, String> entry : entries) {
/*  84 */         System.err.println((String)entry.getValue());
/*     */       }
/*     */     }
/*     */     
/*  88 */     return error;
/*     */   }
/*     */   
/*     */   public static void tryClose() {
/*  92 */     Set<Map.Entry<Object, String>> entries = OBJECTS.entrySet();
/*     */     
/*  94 */     if (entries.size() > 0) {
/*  95 */       for (Map.Entry<Object, String> entry : entries) {
/*  96 */         if ((entry.getKey() instanceof Closeable)) {
/*     */           try {
/*  98 */             ((Closeable)entry.getKey()).close();
/*     */           } catch (Throwable t) {
/* 100 */             log.error("", t);
/*     */           }
/* 102 */         } else if ((entry.getKey() instanceof ExecutorService)) {
/*     */           try {
/* 104 */             ExecutorUtil.shutdownAndAwaitTermination((ExecutorService)entry.getKey());
/*     */           } catch (Throwable t) {
/* 106 */             log.error("", t);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ObjectTrackerException
/*     */     extends RuntimeException
/*     */   {}
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\ObjectReleaseTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */