/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HeaderElement;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.NameValuePair;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.entity.ContentProducer;
/*     */ import org.apache.http.entity.EntityTemplate;
/*     */ import org.apache.solr.client.solrj.ResponseParser;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrServerException;
/*     */ import org.apache.solr.client.solrj.request.RequestWriter;
/*     */ import org.apache.solr.client.solrj.request.UpdateRequest;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ExecutorUtil;
/*     */ import org.apache.solr.common.util.IOUtils;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SolrjNamedThreadFactory;
/*     */ import org.apache.solr.common.util.Utils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConcurrentUpdateSolrClient
/*     */   extends SolrClient
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  78 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   private HttpSolrClient client;
/*     */   final BlockingQueue<Update> queue;
/*     */   final ExecutorService scheduler;
/*     */   final Queue<Runner> runners;
/*  83 */   volatile CountDownLatch lock = null;
/*     */   final int threadCount;
/*  85 */   boolean shutdownExecutor = false;
/*  86 */   int pollQueueTime = 250;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean streamDeletes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean internalHttpClient;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ConcurrentUpdateSolrClient(String solrServerUrl, int queueSize, int threadCount)
/*     */   {
/* 105 */     this(solrServerUrl, null, queueSize, threadCount);
/* 106 */     this.shutdownExecutor = true;
/* 107 */     this.internalHttpClient = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ConcurrentUpdateSolrClient(String solrServerUrl, HttpClient client, int queueSize, int threadCount)
/*     */   {
/* 116 */     this(solrServerUrl, client, queueSize, threadCount, ExecutorUtil.newMDCAwareCachedThreadPool(new SolrjNamedThreadFactory("concurrentUpdateScheduler")));
/*     */     
/* 118 */     this.shutdownExecutor = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ConcurrentUpdateSolrClient(String solrServerUrl, HttpClient client, int queueSize, int threadCount, ExecutorService es)
/*     */   {
/* 129 */     this(solrServerUrl, client, queueSize, threadCount, es, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ConcurrentUpdateSolrClient(String solrServerUrl, HttpClient client, int queueSize, int threadCount, ExecutorService es, boolean streamDeletes)
/*     */   {
/* 141 */     this.internalHttpClient = (client == null);
/* 142 */     this.client = new HttpSolrClient.Builder(solrServerUrl)
/* 143 */       .withHttpClient(client)
/* 144 */       .build();
/* 145 */     this.client.setFollowRedirects(false);
/* 146 */     this.queue = new LinkedBlockingQueue(queueSize);
/* 147 */     this.threadCount = threadCount;
/* 148 */     this.runners = new LinkedList();
/* 149 */     this.streamDeletes = streamDeletes;
/*     */     
/* 151 */     if (es != null) {
/* 152 */       this.scheduler = es;
/* 153 */       this.shutdownExecutor = false;
/*     */     } else {
/* 155 */       this.scheduler = ExecutorUtil.newMDCAwareCachedThreadPool(new SolrjNamedThreadFactory("concurrentUpdateScheduler"));
/* 156 */       this.shutdownExecutor = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<String> getQueryParams() {
/* 161 */     return this.client.getQueryParams();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQueryParams(Set<String> queryParams)
/*     */   {
/* 169 */     this.client.setQueryParams(queryParams);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void addRunner()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: ldc 31
/*     */     //   2: aload_0
/*     */     //   3: getfield 1	org/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient:client	Lorg/apache/solr/client/solrj/impl/HttpSolrClient;
/*     */     //   6: invokevirtual 32	org/apache/solr/client/solrj/impl/HttpSolrClient:getBaseURL	()Ljava/lang/String;
/*     */     //   9: invokestatic 33	org/slf4j/MDC:put	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   12: new 34	org/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient$Runner
/*     */     //   15: dup
/*     */     //   16: aload_0
/*     */     //   17: invokespecial 35	org/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient$Runner:<init>	(Lorg/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient;)V
/*     */     //   20: astore_1
/*     */     //   21: aload_0
/*     */     //   22: getfield 26	org/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient:runners	Ljava/util/Queue;
/*     */     //   25: aload_1
/*     */     //   26: invokeinterface 36 2 0
/*     */     //   31: pop
/*     */     //   32: aload_0
/*     */     //   33: getfield 28	org/apache/solr/client/solrj/impl/ConcurrentUpdateSolrClient:scheduler	Ljava/util/concurrent/ExecutorService;
/*     */     //   36: aload_1
/*     */     //   37: invokeinterface 37 2 0
/*     */     //   42: ldc 31
/*     */     //   44: invokestatic 38	org/slf4j/MDC:remove	(Ljava/lang/String;)V
/*     */     //   47: goto +11 -> 58
/*     */     //   50: astore_2
/*     */     //   51: ldc 31
/*     */     //   53: invokestatic 38	org/slf4j/MDC:remove	(Ljava/lang/String;)V
/*     */     //   56: aload_2
/*     */     //   57: athrow
/*     */     //   58: return
/*     */     // Line number table:
/*     */     //   Java source line #359	-> byte code offset #0
/*     */     //   Java source line #361	-> byte code offset #12
/*     */     //   Java source line #362	-> byte code offset #21
/*     */     //   Java source line #363	-> byte code offset #32
/*     */     //   Java source line #365	-> byte code offset #42
/*     */     //   Java source line #366	-> byte code offset #47
/*     */     //   Java source line #365	-> byte code offset #50
/*     */     //   Java source line #367	-> byte code offset #58
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	59	0	this	ConcurrentUpdateSolrClient
/*     */     //   20	17	1	r	Runner
/*     */     //   50	7	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   12	42	50	finally
/*     */   }
/*     */   
/*     */   class Runner
/*     */     implements Runnable
/*     */   {
/*     */     Runner() {}
/*     */     
/*     */     public void run()
/*     */     {
/* 178 */       ConcurrentUpdateSolrClient.log.debug("starting runner: {}", this);
/*     */       
/*     */ 
/*     */       for (;;)
/*     */       {
/*     */         try
/*     */         {
/* 185 */           sendUpdateStream();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */           synchronized (ConcurrentUpdateSolrClient.this.runners)
/*     */           {
/* 196 */             if ((ConcurrentUpdateSolrClient.this.runners.size() != 1) || (ConcurrentUpdateSolrClient.this.queue.isEmpty()) || (ConcurrentUpdateSolrClient.this.scheduler.isShutdown()))
/*     */             {
/*     */ 
/* 199 */               ConcurrentUpdateSolrClient.this.runners.remove(this);
/* 200 */               if (ConcurrentUpdateSolrClient.this.runners.isEmpty())
/*     */               {
/* 202 */                 ConcurrentUpdateSolrClient.this.runners.notifyAll();
/*     */               }
/* 204 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 188 */           if ((e instanceof OutOfMemoryError)) {
/* 189 */             throw ((OutOfMemoryError)e);
/*     */           }
/* 191 */           ConcurrentUpdateSolrClient.this.handleError(e);
/*     */           
/*     */ 
/* 194 */           synchronized (ConcurrentUpdateSolrClient.this.runners)
/*     */           {
/* 196 */             if ((ConcurrentUpdateSolrClient.this.runners.size() != 1) || (ConcurrentUpdateSolrClient.this.queue.isEmpty()) || (ConcurrentUpdateSolrClient.this.scheduler.isShutdown()))
/*     */             {
/*     */ 
/* 199 */               ConcurrentUpdateSolrClient.this.runners.remove(this);
/* 200 */               if (ConcurrentUpdateSolrClient.this.runners.isEmpty())
/*     */               {
/* 202 */                 ConcurrentUpdateSolrClient.this.runners.notifyAll();
/*     */               }
/* 204 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/* 194 */           synchronized (ConcurrentUpdateSolrClient.this.runners)
/*     */           {
/* 196 */             if ((ConcurrentUpdateSolrClient.this.runners.size() != 1) || (ConcurrentUpdateSolrClient.this.queue.isEmpty()) || (ConcurrentUpdateSolrClient.this.scheduler.isShutdown()))
/*     */             {
/*     */ 
/* 199 */               ConcurrentUpdateSolrClient.this.runners.remove(this);
/* 200 */               if (ConcurrentUpdateSolrClient.this.runners.isEmpty())
/*     */               {
/* 202 */                 ConcurrentUpdateSolrClient.this.runners.notifyAll();
/*     */               }
/* 204 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 211 */       ConcurrentUpdateSolrClient.log.debug("finished: {}", this);
/*     */     }
/*     */     
/*     */     void sendUpdateStream()
/*     */       throws Exception
/*     */     {
/*     */       for (;;)
/*     */       {
/* 219 */         if (!ConcurrentUpdateSolrClient.this.queue.isEmpty()) {
/* 220 */           HttpPost method = null;
/* 221 */           HttpResponse response = null;
/*     */           
/* 223 */           InputStream rspBody = null;
/*     */           try
/*     */           {
/* 226 */             final ConcurrentUpdateSolrClient.Update update = (ConcurrentUpdateSolrClient.Update)ConcurrentUpdateSolrClient.this.queue.poll(ConcurrentUpdateSolrClient.this.pollQueueTime, TimeUnit.MILLISECONDS);
/* 227 */             if (update == null)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */                 if (response != null) {
/* 347 */                   Utils.consumeFully(response.getEntity());
/*     */                 }
/*     */               } catch (Exception e) {
/* 350 */                 ConcurrentUpdateSolrClient.log.error("Error consuming and closing http response stream.", e);
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 230 */               String contentType = ConcurrentUpdateSolrClient.this.client.requestWriter.getUpdateContentType();
/* 231 */               final boolean isXml = "application/xml; charset=UTF-8".equals(contentType);
/*     */               
/* 233 */               final ModifiableSolrParams origParams = new ModifiableSolrParams(update.getRequest().getParams());
/*     */               
/* 235 */               EntityTemplate template = new EntityTemplate(new ContentProducer()
/*     */               {
/*     */                 public void writeTo(OutputStream out) throws IOException
/*     */                 {
/*     */                   try {
/* 240 */                     if (isXml) {
/* 241 */                       out.write("<stream>".getBytes(StandardCharsets.UTF_8));
/*     */                     }
/* 243 */                     ConcurrentUpdateSolrClient.Update upd = update;
/* 244 */                     while (upd != null) {
/* 245 */                       UpdateRequest req = upd.getRequest();
/* 246 */                       SolrParams currentParams = new ModifiableSolrParams(req.getParams());
/* 247 */                       if (!origParams.toNamedList().equals(currentParams.toNamedList())) {
/* 248 */                         ConcurrentUpdateSolrClient.this.queue.add(upd);
/* 249 */                         break;
/*     */                       }
/*     */                       
/* 252 */                       ConcurrentUpdateSolrClient.this.client.requestWriter.write(req, out);
/* 253 */                       if (isXml)
/*     */                       {
/* 255 */                         SolrParams params = req.getParams();
/* 256 */                         if (params != null) {
/* 257 */                           String fmt = null;
/* 258 */                           if (params.getBool("optimize", false)) {
/* 259 */                             fmt = "<optimize waitSearcher=\"%s\" />";
/* 260 */                           } else if (params.getBool("commit", false)) {
/* 261 */                             fmt = "<commit waitSearcher=\"%s\" />";
/*     */                           }
/* 263 */                           if (fmt != null)
/*     */                           {
/*     */ 
/*     */ 
/* 267 */                             byte[] content = String.format(Locale.ROOT, fmt, new Object[] { params.getBool("waitSearcher", false) + "" }).getBytes(StandardCharsets.UTF_8);
/* 268 */                             out.write(content);
/*     */                           }
/*     */                         }
/*     */                       }
/* 272 */                       out.flush();
/*     */                       
/* 274 */                       if ((ConcurrentUpdateSolrClient.this.pollQueueTime > 0) && (ConcurrentUpdateSolrClient.this.threadCount == 1) && (req.isLastDocInBatch()))
/*     */                       {
/* 276 */                         upd = (ConcurrentUpdateSolrClient.Update)ConcurrentUpdateSolrClient.this.queue.poll(0L, TimeUnit.MILLISECONDS);
/*     */                       } else {
/* 278 */                         upd = (ConcurrentUpdateSolrClient.Update)ConcurrentUpdateSolrClient.this.queue.poll(ConcurrentUpdateSolrClient.this.pollQueueTime, TimeUnit.MILLISECONDS);
/*     */                       }
/*     */                     }
/*     */                     
/*     */ 
/* 283 */                     if (isXml) {
/* 284 */                       out.write("</stream>".getBytes(StandardCharsets.UTF_8));
/*     */                     }
/*     */                   }
/*     */                   catch (InterruptedException e) {
/* 288 */                     Thread.currentThread().interrupt();
/* 289 */                     ConcurrentUpdateSolrClient.log.warn("", e);
/*     */                   }
/*     */                   
/*     */                 }
/*     */                 
/*     */ 
/* 295 */               });
/* 296 */               ModifiableSolrParams requestParams = new ModifiableSolrParams(origParams);
/* 297 */               requestParams.set("wt", new String[] { ConcurrentUpdateSolrClient.this.client.parser.getWriterType() });
/* 298 */               requestParams.set("version", new String[] { ConcurrentUpdateSolrClient.this.client.parser.getVersion() });
/*     */               
/* 300 */               String basePath = ConcurrentUpdateSolrClient.this.client.getBaseURL();
/* 301 */               if (update.getCollection() != null) {
/* 302 */                 basePath = basePath + "/" + update.getCollection();
/*     */               }
/*     */               
/* 305 */               method = new HttpPost(basePath + "/update" + requestParams.toQueryString());
/*     */               
/* 307 */               method.setEntity(template);
/* 308 */               method.addHeader("User-Agent", HttpSolrClient.AGENT);
/* 309 */               method.addHeader("Content-Type", contentType);
/*     */               
/* 311 */               response = ConcurrentUpdateSolrClient.this.client.getHttpClient().execute(method);
/* 312 */               rspBody = response.getEntity().getContent();
/* 313 */               int statusCode = response.getStatusLine().getStatusCode();
/* 314 */               if (statusCode != 200) {
/* 315 */                 StringBuilder msg = new StringBuilder();
/* 316 */                 msg.append(response.getStatusLine().getReasonPhrase());
/* 317 */                 msg.append("\n\n\n\n");
/* 318 */                 msg.append("request: ").append(method.getURI());
/*     */                 
/* 320 */                 SolrException solrExc = new SolrException(SolrException.ErrorCode.getErrorCode(statusCode), msg.toString());
/*     */                 try
/*     */                 {
/* 323 */                   String encoding = "UTF-8";
/* 324 */                   if (response.getEntity().getContentType().getElements().length > 0) {
/* 325 */                     NameValuePair param = response.getEntity().getContentType().getElements()[0].getParameterByName("charset");
/* 326 */                     if (param != null) {
/* 327 */                       encoding = param.getValue();
/*     */                     }
/*     */                   }
/* 330 */                   NamedList<Object> resp = ConcurrentUpdateSolrClient.this.client.parser.processResponse(rspBody, encoding);
/* 331 */                   NamedList<Object> error = (NamedList)resp.get("error");
/* 332 */                   if (error != null) {
/* 333 */                     solrExc.setMetadata((NamedList)error.get("metadata"));
/*     */                   }
/*     */                 }
/*     */                 catch (Exception exc) {
/* 337 */                   ConcurrentUpdateSolrClient.log.warn("Failed to parse error response from " + ConcurrentUpdateSolrClient.this.client.getBaseURL() + " due to: " + exc);
/*     */                 }
/*     */                 
/* 340 */                 ConcurrentUpdateSolrClient.this.handleError(solrExc);
/*     */               } else {
/* 342 */                 ConcurrentUpdateSolrClient.this.onSuccess(response);
/*     */               }
/*     */               try
/*     */               {
/* 346 */                 if (response != null) {
/* 347 */                   Utils.consumeFully(response.getEntity());
/*     */                 }
/*     */               } catch (Exception e) {
/* 350 */                 ConcurrentUpdateSolrClient.log.error("Error consuming and closing http response stream.", e);
/*     */               }
/*     */             }
/*     */           }
/*     */           finally
/*     */           {
/*     */             try
/*     */             {
/* 346 */               if (response != null) {
/* 347 */                 Utils.consumeFully(response.getEntity());
/*     */               }
/*     */             } catch (Exception e) {
/* 350 */               ConcurrentUpdateSolrClient.log.error("Error consuming and closing http response stream.", e);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class Update
/*     */   {
/*     */     UpdateRequest request;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     String collection;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Update(UpdateRequest request, String collection)
/*     */     {
/* 381 */       this.request = request;
/* 382 */       this.collection = collection;
/*     */     }
/*     */     
/*     */ 
/*     */     public UpdateRequest getRequest()
/*     */     {
/* 388 */       return this.request;
/*     */     }
/*     */     
/* 391 */     public void setRequest(UpdateRequest request) { this.request = request; }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getCollection()
/*     */     {
/* 397 */       return this.collection;
/*     */     }
/*     */     
/* 400 */     public void setCollection(String collection) { this.collection = collection; }
/*     */   }
/*     */   
/*     */ 
/*     */   public NamedList<Object> request(SolrRequest request, String collection)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 407 */     if (!(request instanceof UpdateRequest)) {
/* 408 */       return this.client.request(request, collection);
/*     */     }
/* 410 */     UpdateRequest req = (UpdateRequest)request;
/*     */     
/*     */ 
/* 413 */     if (this.streamDeletes) {
/* 414 */       if (((req.getDocuments() == null) || (req.getDocuments().isEmpty())) && 
/* 415 */         ((req.getDeleteById() == null) || (req.getDeleteById().isEmpty())) && 
/* 416 */         ((req.getDeleteByIdMap() == null) || (req.getDeleteByIdMap().isEmpty())) && 
/* 417 */         (req.getDeleteQuery() == null)) {
/* 418 */         blockUntilFinished();
/* 419 */         return this.client.request(request, collection);
/*     */       }
/*     */       
/*     */     }
/* 423 */     else if ((req.getDocuments() == null) || (req.getDocuments().isEmpty())) {
/* 424 */       blockUntilFinished();
/* 425 */       return this.client.request(request, collection);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 430 */     SolrParams params = req.getParams();
/* 431 */     if (params != null)
/*     */     {
/* 433 */       if (params.getBool("waitSearcher", false)) {
/* 434 */         log.info("blocking for commit/optimize");
/* 435 */         blockUntilFinished();
/* 436 */         return this.client.request(request, collection);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 441 */       CountDownLatch tmpLock = this.lock;
/* 442 */       if (tmpLock != null) {
/* 443 */         tmpLock.await();
/*     */       }
/*     */       
/* 446 */       Update update = new Update(req, collection);
/* 447 */       boolean success = this.queue.offer(update);
/*     */       for (;;)
/*     */       {
/* 450 */         synchronized (this.runners)
/*     */         {
/*     */ 
/*     */ 
/* 454 */           if ((this.runners.isEmpty()) || ((this.queue.remainingCapacity() < this.queue.size()) && (this.runners.size() < this.threadCount)))
/*     */           {
/*     */ 
/* 457 */             addRunner();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/* 463 */           else if (success) {
/*     */             break;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 479 */         if (!success) {
/* 480 */           success = this.queue.offer(update, 100L, TimeUnit.MILLISECONDS);
/*     */         }
/*     */       }
/*     */     } catch (InterruptedException e) {
/* 484 */       log.error("interrupted", e);
/* 485 */       throw new IOException(e.getLocalizedMessage());
/*     */     }
/*     */     
/*     */ 
/* 489 */     NamedList<Object> dummy = new NamedList();
/* 490 */     dummy.add("NOTE", "the request is processed in a background stream");
/* 491 */     return dummy;
/*     */   }
/*     */   
/*     */   public synchronized void blockUntilFinished() {
/* 495 */     this.lock = new CountDownLatch(1);
/*     */     try {
/* 497 */       synchronized (this.runners)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 502 */         while (!this.runners.isEmpty()) {
/*     */           try {
/* 504 */             this.runners.wait(250L);
/*     */           } catch (InterruptedException e) {
/* 506 */             Thread.interrupted();
/*     */           }
/*     */           
/* 509 */           if (this.scheduler.isShutdown()) {
/*     */             break;
/*     */           }
/*     */           
/* 513 */           int queueSize = this.queue.size();
/* 514 */           if ((queueSize > 0) && (this.runners.isEmpty()))
/*     */           {
/* 516 */             log.warn("No more runners, but queue still has " + queueSize + " adding more runners to process remaining requests on queue");
/*     */             
/* 518 */             addRunner();
/*     */           }
/*     */         }
/*     */       }
/*     */     } finally {
/* 523 */       this.lock.countDown();
/* 524 */       this.lock = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleError(Throwable ex) {
/* 529 */     log.error("error", ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onSuccess(HttpResponse resp) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 541 */     if (this.internalHttpClient) IOUtils.closeQuietly(this.client);
/* 542 */     if (this.shutdownExecutor) {
/* 543 */       this.scheduler.shutdown();
/*     */       try {
/* 545 */         if (!this.scheduler.awaitTermination(60L, TimeUnit.SECONDS)) {
/* 546 */           this.scheduler.shutdownNow();
/* 547 */           if (!this.scheduler.awaitTermination(60L, TimeUnit.SECONDS))
/* 548 */             log.error("ExecutorService did not terminate");
/*     */         }
/*     */       } catch (InterruptedException ie) {
/* 551 */         this.scheduler.shutdownNow();
/* 552 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(int timeout) {
/* 558 */     HttpClientUtil.setConnectionTimeout(this.client.getHttpClient(), timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSoTimeout(int timeout)
/*     */   {
/* 566 */     HttpClientUtil.setSoTimeout(this.client.getHttpClient(), timeout);
/*     */   }
/*     */   
/*     */   public void shutdownNow() {
/* 570 */     if (this.internalHttpClient) IOUtils.closeQuietly(this.client);
/* 571 */     if (this.shutdownExecutor) {
/* 572 */       this.scheduler.shutdownNow();
/*     */       try {
/* 574 */         if (!this.scheduler.awaitTermination(30L, TimeUnit.SECONDS))
/* 575 */           log.error("ExecutorService did not terminate");
/*     */       } catch (InterruptedException ie) {
/* 577 */         this.scheduler.shutdownNow();
/* 578 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setParser(ResponseParser responseParser) {
/* 584 */     this.client.setParser(responseParser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPollQueueTime(int pollQueueTime)
/*     */   {
/* 593 */     this.pollQueueTime = pollQueueTime;
/*     */   }
/*     */   
/*     */   public void setRequestWriter(RequestWriter requestWriter) {
/* 597 */     this.client.setRequestWriter(requestWriter);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Builder
/*     */   {
/*     */     private String baseSolrUrl;
/*     */     
/*     */     private HttpClient httpClient;
/*     */     
/*     */     private int queueSize;
/*     */     
/*     */     private int threadCount;
/*     */     
/*     */     private ExecutorService executorService;
/*     */     
/*     */     private boolean streamDeletes;
/*     */     
/*     */     public Builder(String baseSolrUrl)
/*     */     {
/* 617 */       this.baseSolrUrl = baseSolrUrl;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder withHttpClient(HttpClient httpClient)
/*     */     {
/* 624 */       this.httpClient = httpClient;
/* 625 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder withQueueSize(int queueSize)
/*     */     {
/* 632 */       if (queueSize <= 0) {
/* 633 */         throw new IllegalArgumentException("queueSize must be a positive integer.");
/*     */       }
/* 635 */       this.queueSize = queueSize;
/* 636 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder withThreadCount(int threadCount)
/*     */     {
/* 643 */       if (threadCount <= 0) {
/* 644 */         throw new IllegalArgumentException("threadCount must be a positive integer.");
/*     */       }
/*     */       
/* 647 */       this.threadCount = threadCount;
/* 648 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder withExecutorService(ExecutorService executorService)
/*     */     {
/* 655 */       this.executorService = executorService;
/* 656 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder alwaysStreamDeletes()
/*     */     {
/* 663 */       this.streamDeletes = true;
/* 664 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Builder neverStreamDeletes()
/*     */     {
/* 671 */       this.streamDeletes = false;
/* 672 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ConcurrentUpdateSolrClient build()
/*     */     {
/* 679 */       if (this.baseSolrUrl == null) {
/* 680 */         throw new IllegalArgumentException("Cannot create HttpSolrClient without a valid baseSolrUrl!");
/*     */       }
/*     */       
/* 683 */       return new ConcurrentUpdateSolrClient(this.baseSolrUrl, this.httpClient, this.queueSize, this.threadCount, this.executorService, this.streamDeletes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\ConcurrentUpdateSolrClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */