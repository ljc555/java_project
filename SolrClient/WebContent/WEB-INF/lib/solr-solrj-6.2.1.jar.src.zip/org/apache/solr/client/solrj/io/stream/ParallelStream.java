/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.common.cloud.ClusterState;
/*     */ import org.apache.solr.common.cloud.Replica;
/*     */ import org.apache.solr.common.cloud.Replica.State;
/*     */ import org.apache.solr.common.cloud.Slice;
/*     */ import org.apache.solr.common.cloud.ZkCoreNodeProps;
/*     */ import org.apache.solr.common.cloud.ZkStateReader;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParallelStream
/*     */   extends CloudSolrStream
/*     */   implements Expressible
/*     */ {
/*     */   private TupleStream tupleStream;
/*     */   private int workers;
/*     */   private transient StreamFactory streamFactory;
/*     */   
/*     */   public ParallelStream(String zkHost, String collection, TupleStream tupleStream, int workers, StreamComparator comp)
/*     */     throws IOException
/*     */   {
/*  66 */     init(zkHost, collection, tupleStream, workers, comp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParallelStream(String zkHost, String collection, String expressionString, int workers, StreamComparator comp)
/*     */     throws IOException
/*     */   {
/*  75 */     TupleStream tStream = this.streamFactory.constructStream(expressionString);
/*  76 */     init(zkHost, collection, tStream, workers, comp);
/*     */   }
/*     */   
/*     */   public void setStreamFactory(StreamFactory streamFactory) {
/*  80 */     this.streamFactory = streamFactory;
/*     */   }
/*     */   
/*     */   public ParallelStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  85 */     String collectionName = factory.getValueOperand(expression, 0);
/*  86 */     StreamExpressionNamedParameter workersParam = factory.getNamedOperand(expression, "workers");
/*  87 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  88 */     StreamExpressionNamedParameter sortExpression = factory.getNamedOperand(expression, "sort");
/*  89 */     StreamExpressionNamedParameter zkHostExpression = factory.getNamedOperand(expression, "zkHost");
/*     */     
/*     */ 
/*     */ 
/*  93 */     if (expression.getParameters().size() != streamExpressions.size() + 3 + (null != zkHostExpression ? 1 : 0)) {
/*  94 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/*  98 */     if (null == collectionName) {
/*  99 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - collectionName expected as first operand", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/* 103 */     if ((null == workersParam) || (null == workersParam.getParameter()) || (!(workersParam.getParameter() instanceof StreamExpressionValue))) {
/* 104 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single 'workers' parameter of type positive integer but didn't find one", new Object[] { expression }));
/*     */     }
/* 106 */     String workersStr = ((StreamExpressionValue)workersParam.getParameter()).getValue();
/* 107 */     int workersInt = 0;
/*     */     try {
/* 109 */       workersInt = Integer.parseInt(workersStr);
/* 110 */       if (workersInt <= 0) {
/* 111 */         throw new IOException(String.format(Locale.ROOT, "invalid expression %s - workers '%s' must be greater than 0.", new Object[] { expression, workersStr }));
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 115 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - workers '%s' is not a valid integer.", new Object[] { expression, workersStr }));
/*     */     }
/*     */     
/*     */ 
/* 119 */     if (1 != streamExpressions.size()) {
/* 120 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*     */ 
/* 124 */     if ((null == sortExpression) || (!(sortExpression.getParameter() instanceof StreamExpressionValue))) {
/* 125 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'sort' parameter telling us how to join the parallel streams but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/* 129 */     String zkHost = null;
/* 130 */     if (null == zkHostExpression) {
/* 131 */       zkHost = factory.getCollectionZkHost(collectionName);
/* 132 */       if (zkHost == null) {
/* 133 */         zkHost = factory.getDefaultZkHost();
/*     */       }
/*     */     }
/* 136 */     else if ((zkHostExpression.getParameter() instanceof StreamExpressionValue)) {
/* 137 */       zkHost = ((StreamExpressionValue)zkHostExpression.getParameter()).getValue();
/*     */     }
/* 139 */     if (null == zkHost) {
/* 140 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - zkHost not found for collection '%s'", new Object[] { expression, collectionName }));
/*     */     }
/*     */     
/*     */ 
/* 144 */     TupleStream stream = factory.constructStream((StreamExpression)streamExpressions.get(0));
/* 145 */     StreamComparator comp = factory.constructComparator(((StreamExpressionValue)sortExpression.getParameter()).getValue(), FieldComparator.class);
/* 146 */     this.streamFactory = factory;
/* 147 */     init(zkHost, collectionName, stream, workersInt, comp);
/*     */   }
/*     */   
/*     */   private void init(String zkHost, String collection, TupleStream tupleStream, int workers, StreamComparator comp) throws IOException {
/* 151 */     this.zkHost = zkHost;
/* 152 */     this.collection = collection;
/* 153 */     this.workers = workers;
/* 154 */     this.comp = comp;
/* 155 */     this.tupleStream = tupleStream;
/*     */     
/*     */ 
/* 158 */     if (!(tupleStream instanceof Expressible)) {
/* 159 */       throw new IOException("Unable to create ParallelStream with a non-expressible TupleStream.");
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 165 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 170 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 173 */     expression.addParameter(this.collection);
/*     */     
/*     */ 
/* 176 */     expression.addParameter(new StreamExpressionNamedParameter("workers", Integer.toString(this.workers)));
/*     */     
/* 178 */     if (includeStreams) {
/* 179 */       if ((this.tupleStream instanceof Expressible)) {
/* 180 */         expression.addParameter(((Expressible)this.tupleStream).toExpression(factory));
/*     */       }
/*     */       else {
/* 183 */         throw new IOException("This ParallelStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 187 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 191 */     expression.addParameter(new StreamExpressionNamedParameter("sort", this.comp.toExpression(factory)));
/*     */     
/*     */ 
/* 194 */     expression.addParameter(new StreamExpressionNamedParameter("zkHost", this.zkHost));
/*     */     
/* 196 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 202 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId().toString());
/*     */     
/* 204 */     explanation.setFunctionName(factory.getFunctionName(getClass()));
/* 205 */     explanation.setImplementingClass(getClass().getName());
/* 206 */     explanation.setExpressionType("stream-decorator");
/* 207 */     explanation.setExpression(toExpression(factory, false).toString());
/*     */     
/*     */ 
/* 210 */     for (int idx = 0; idx < this.workers; idx++) {
/* 211 */       explanation.addChild(this.tupleStream.toExplanation(factory));
/*     */     }
/*     */     
/* 214 */     return explanation;
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 218 */     List l = new ArrayList();
/* 219 */     l.add(this.tupleStream);
/* 220 */     return l;
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException {
/* 224 */     Tuple tuple = _read();
/*     */     
/* 226 */     if (tuple.EOF) {
/* 227 */       Map m = new HashMap();
/* 228 */       m.put("EOF", Boolean.valueOf(true));
/* 229 */       Tuple t = new Tuple(m);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */       return t;
/*     */     }
/*     */     
/* 248 */     return tuple;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext streamContext) {
/* 252 */     this.streamContext = streamContext;
/* 253 */     if (this.streamFactory == null) {
/* 254 */       this.streamFactory = streamContext.getStreamFactory();
/*     */     }
/* 256 */     this.tupleStream.setStreamContext(streamContext);
/*     */   }
/*     */   
/*     */   protected void constructStreams() throws IOException
/*     */   {
/*     */     try {
/* 262 */       Object pushStream = ((Expressible)this.tupleStream).toExpression(this.streamFactory);
/*     */       
/* 264 */       ZkStateReader zkStateReader = this.cloudSolrClient.getZkStateReader();
/* 265 */       ClusterState clusterState = zkStateReader.getClusterState();
/* 266 */       Set<String> liveNodes = clusterState.getLiveNodes();
/* 267 */       Collection<Slice> slices = clusterState.getActiveSlices(this.collection);
/* 268 */       List<Replica> shuffler = new ArrayList();
/* 269 */       for (Slice slice : slices) {
/* 270 */         Collection<Replica> replicas = slice.getReplicas();
/* 271 */         for (Replica replica : replicas) {
/* 272 */           if ((replica.getState() == Replica.State.ACTIVE) && (liveNodes.contains(replica.getNodeName()))) {
/* 273 */             shuffler.add(replica);
/*     */           }
/*     */         }
/*     */       }
/* 277 */       if (this.workers > shuffler.size()) {
/* 278 */         throw new IOException("Number of workers exceeds nodes in the worker collection");
/*     */       }
/*     */       
/* 281 */       Collections.shuffle(shuffler, new Random());
/*     */       
/* 283 */       for (int w = 0; w < this.workers; w++) {
/* 284 */         ModifiableSolrParams paramsLoc = new ModifiableSolrParams();
/* 285 */         paramsLoc.set("distrib", new String[] { "false" });
/* 286 */         paramsLoc.set("numWorkers", this.workers);
/* 287 */         paramsLoc.set("workerID", w);
/*     */         
/* 289 */         paramsLoc.set("expr", new String[] { pushStream.toString() });
/* 290 */         paramsLoc.set("qt", new String[] { "/stream" });
/* 291 */         Replica rep = (Replica)shuffler.get(w);
/* 292 */         ZkCoreNodeProps zkProps = new ZkCoreNodeProps(rep);
/* 293 */         String url = zkProps.getCoreUrl();
/* 294 */         SolrStream solrStream = new SolrStream(url, paramsLoc);
/* 295 */         this.solrStreams.add(solrStream);
/*     */       }
/*     */       
/* 298 */       if ((!$assertionsDisabled) && (this.solrStreams.size() != this.workers)) throw new AssertionError();
/*     */     }
/*     */     catch (Exception e) {
/* 301 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\ParallelStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */