/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultZkCredentialsProvider
/*    */   implements ZkCredentialsProvider
/*    */ {
/*    */   private Collection<ZkCredentialsProvider.ZkCredentials> zkCredentials;
/*    */   
/*    */   public Collection<ZkCredentialsProvider.ZkCredentials> getCredentials()
/*    */   {
/* 28 */     if (this.zkCredentials == null) {
/* 29 */       synchronized (this) {
/* 30 */         if (this.zkCredentials == null) this.zkCredentials = createCredentials();
/*    */       }
/*    */     }
/* 33 */     return this.zkCredentials;
/*    */   }
/*    */   
/*    */   protected Collection<ZkCredentialsProvider.ZkCredentials> createCredentials() {
/* 37 */     return new ArrayList();
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\DefaultZkCredentialsProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */