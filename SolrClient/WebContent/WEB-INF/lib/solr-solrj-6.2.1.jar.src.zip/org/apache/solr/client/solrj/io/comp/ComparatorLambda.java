package org.apache.solr.client.solrj.io.comp;

import java.io.Serializable;
import org.apache.solr.client.solrj.io.Tuple;

public abstract interface ComparatorLambda
  extends Serializable
{
  public abstract int compare(Tuple paramTuple1, Tuple paramTuple2);
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\comp\ComparatorLambda.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */