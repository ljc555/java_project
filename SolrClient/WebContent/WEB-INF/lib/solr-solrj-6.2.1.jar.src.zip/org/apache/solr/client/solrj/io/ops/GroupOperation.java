/*     */ package org.apache.solr.client.solrj.io.ops;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupOperation
/*     */   implements ReduceOperation
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   private UUID operationNodeId = UUID.randomUUID();
/*     */   private PriorityQueue<Tuple> priorityQueue;
/*     */   private Comparator comp;
/*     */   private StreamComparator streamComparator;
/*     */   private int size;
/*     */   
/*     */   public GroupOperation(StreamExpression expression, StreamFactory factory)
/*     */     throws IOException
/*     */   {
/*  54 */     StreamExpressionNamedParameter nParam = factory.getNamedOperand(expression, "n");
/*  55 */     StreamExpressionNamedParameter sortExpression = factory.getNamedOperand(expression, "sort");
/*     */     
/*  57 */     StreamComparator streamComparator = factory.constructComparator(((StreamExpressionValue)sortExpression.getParameter()).getValue(), FieldComparator.class);
/*  58 */     String nStr = ((StreamExpressionValue)nParam.getParameter()).getValue();
/*  59 */     int nInt = 0;
/*     */     try
/*     */     {
/*  62 */       nInt = Integer.parseInt(nStr);
/*  63 */       if (nInt <= 0) {
/*  64 */         throw new IOException(String.format(Locale.ROOT, "invalid expression %s - topN '%s' must be greater than 0.", new Object[] { expression, nStr }));
/*     */       }
/*     */     } catch (NumberFormatException e) {
/*  67 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - topN '%s' is not a valid integer.", new Object[] { expression, nStr }));
/*     */     }
/*     */     
/*  70 */     init(streamComparator, nInt);
/*     */   }
/*     */   
/*     */   public GroupOperation(StreamComparator streamComparator, int size) {
/*  74 */     init(streamComparator, size);
/*     */   }
/*     */   
/*     */   private void init(StreamComparator streamComparator, int size) {
/*  78 */     this.size = size;
/*  79 */     this.streamComparator = streamComparator;
/*  80 */     this.comp = new ReverseComp(streamComparator);
/*  81 */     this.priorityQueue = new PriorityQueue(size, this.comp);
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException {
/*  85 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*  87 */     expression.addParameter(new StreamExpressionNamedParameter("n", Integer.toString(this.size)));
/*     */     
/*     */ 
/*  90 */     expression.addParameter(new StreamExpressionNamedParameter("sort", this.streamComparator.toExpression(factory)));
/*  91 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/*  96 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 101 */       new Explanation(this.operationNodeId.toString()).withExpressionType("operation").withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString()).withHelpers(new Explanation[] {this.streamComparator
/* 102 */       .toExplanation(factory) });
/*     */   }
/*     */   
/*     */   public Tuple reduce()
/*     */   {
/* 107 */     Map map = new HashMap();
/* 108 */     List<Map> list = new ArrayList();
/* 109 */     LinkedList ll = new LinkedList();
/* 110 */     while (this.priorityQueue.size() > 0) {
/* 111 */       ll.addFirst(((Tuple)this.priorityQueue.poll()).getMap());
/*     */     }
/*     */     
/*     */ 
/* 115 */     list.addAll(ll);
/* 116 */     Map groupHead = (Map)list.get(0);
/* 117 */     map.putAll(groupHead);
/* 118 */     map.put("group", list);
/* 119 */     return new Tuple(map);
/*     */   }
/*     */   
/*     */   public void operate(Tuple tuple) {
/* 123 */     if (this.priorityQueue.size() >= this.size) {
/* 124 */       Tuple peek = (Tuple)this.priorityQueue.peek();
/* 125 */       if (this.streamComparator.compare(tuple, peek) < 0) {
/* 126 */         this.priorityQueue.poll();
/* 127 */         this.priorityQueue.add(tuple);
/*     */       }
/*     */     } else {
/* 130 */       this.priorityQueue.add(tuple);
/*     */     }
/*     */   }
/*     */   
/*     */   class ReverseComp implements Comparator<Tuple>, Serializable {
/*     */     private StreamComparator comp;
/*     */     
/*     */     public ReverseComp(StreamComparator comp) {
/* 138 */       this.comp = comp;
/*     */     }
/*     */     
/*     */     public int compare(Tuple t1, Tuple t2)
/*     */     {
/* 143 */       return this.comp.compare(t1, t2) * -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\GroupOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */