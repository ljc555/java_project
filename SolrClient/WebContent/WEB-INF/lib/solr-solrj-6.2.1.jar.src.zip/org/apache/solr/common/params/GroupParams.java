package org.apache.solr.common.params;

public abstract interface GroupParams
{
  public static final String GROUP = "group";
  public static final String GROUP_QUERY = "group.query";
  public static final String GROUP_FIELD = "group.field";
  public static final String GROUP_FUNC = "group.func";
  public static final String GROUP_SORT = "group.sort";
  public static final String GROUP_LIMIT = "group.limit";
  public static final String GROUP_OFFSET = "group.offset";
  public static final String GROUP_MAIN = "group.main";
  public static final String GROUP_FORMAT = "group.format";
  public static final String GROUP_CACHE_PERCENTAGE = "group.cache.percent";
  public static final String GROUP_TRUNCATE = "group.truncate";
  public static final String GROUP_TOTAL_COUNT = "group.ngroups";
  public static final String GROUP_FACET = "group.facet";
  public static final String GROUP_DISTRIBUTED_FIRST = "group.distributed.first";
  public static final String GROUP_DISTRIBUTED_SECOND = "group.distributed.second";
  public static final String GROUP_DISTRIBUTED_TOPGROUPS_PREFIX = "group.topgroups.";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\GroupParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */