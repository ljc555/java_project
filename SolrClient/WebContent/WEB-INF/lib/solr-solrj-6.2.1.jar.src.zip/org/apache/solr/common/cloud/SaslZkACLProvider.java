/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.zookeeper.ZooDefs.Ids;
/*    */ import org.apache.zookeeper.data.ACL;
/*    */ import org.apache.zookeeper.data.Id;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaslZkACLProvider
/*    */   extends SecurityAwareZkACLProvider
/*    */ {
/* 35 */   private static String superUser = System.getProperty("solr.authorization.superuser", "solr");
/*    */   
/*    */   protected List<ACL> createNonSecurityACLsToAdd()
/*    */   {
/* 39 */     List<ACL> ret = new ArrayList();
/* 40 */     ret.add(new ACL(31, new Id("sasl", superUser)));
/* 41 */     ret.add(new ACL(1, ZooDefs.Ids.ANYONE_ID_UNSAFE));
/* 42 */     return ret;
/*    */   }
/*    */   
/*    */   protected List<ACL> createSecurityACLsToAdd()
/*    */   {
/* 47 */     List<ACL> ret = new ArrayList();
/* 48 */     ret.add(new ACL(31, new Id("sasl", superUser)));
/* 49 */     return ret;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\SaslZkACLProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */