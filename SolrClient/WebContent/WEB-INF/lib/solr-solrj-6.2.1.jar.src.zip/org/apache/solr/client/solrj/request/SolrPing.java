/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.SolrPingResponse;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrPing
/*     */   extends SolrRequest<SolrPingResponse>
/*     */ {
/*     */   private static final long serialVersionUID = 5828246236669090017L;
/*     */   private ModifiableSolrParams params;
/*     */   
/*     */   public SolrPing()
/*     */   {
/*  47 */     super(SolrRequest.METHOD.GET, "/admin/ping");
/*  48 */     this.params = new ModifiableSolrParams();
/*     */   }
/*     */   
/*     */   public Collection<ContentStream> getContentStreams()
/*     */   {
/*  53 */     return null;
/*     */   }
/*     */   
/*     */   protected SolrPingResponse createResponse(SolrClient client)
/*     */   {
/*  58 */     return new SolrPingResponse();
/*     */   }
/*     */   
/*     */   public ModifiableSolrParams getParams()
/*     */   {
/*  63 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrPing removeAction()
/*     */   {
/*  74 */     this.params.remove("action");
/*  75 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrPing setActionDisable()
/*     */   {
/*  85 */     this.params.set("action", new String[] { "disable" });
/*  86 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrPing setActionEnable()
/*     */   {
/*  96 */     this.params.set("action", new String[] { "enable" });
/*  97 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrPing setActionPing()
/*     */   {
/* 107 */     this.params.set("action", new String[] { "ping" });
/* 108 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\SolrPing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */