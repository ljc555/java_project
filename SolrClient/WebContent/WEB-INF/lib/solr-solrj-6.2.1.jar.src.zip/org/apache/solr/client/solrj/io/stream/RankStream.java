/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RankStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private TupleStream stream;
/*     */   private StreamComparator comp;
/*     */   private int size;
/*     */   private transient PriorityQueue<Tuple> top;
/*  53 */   private transient boolean finished = false;
/*     */   private transient LinkedList<Tuple> topList;
/*     */   
/*     */   public RankStream(TupleStream tupleStream, int size, StreamComparator comp) throws IOException {
/*  57 */     init(tupleStream, size, comp);
/*     */   }
/*     */   
/*     */   public RankStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  62 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  63 */     StreamExpressionNamedParameter nParam = factory.getNamedOperand(expression, "n");
/*  64 */     StreamExpressionNamedParameter sortExpression = factory.getNamedOperand(expression, "sort");
/*     */     
/*     */ 
/*  67 */     if (expression.getParameters().size() != streamExpressions.size() + 2) {
/*  68 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  71 */     if ((null == nParam) || (null == nParam.getParameter()) || (!(nParam.getParameter() instanceof StreamExpressionValue))) {
/*  72 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single 'n' parameter of type positive integer but didn't find one", new Object[] { expression }));
/*     */     }
/*  74 */     String nStr = ((StreamExpressionValue)nParam.getParameter()).getValue();
/*  75 */     int nInt = 0;
/*     */     try {
/*  77 */       nInt = Integer.parseInt(nStr);
/*  78 */       if (nInt <= 0) {
/*  79 */         throw new IOException(String.format(Locale.ROOT, "invalid expression %s - topN '%s' must be greater than 0.", new Object[] { expression, nStr }));
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException e) {
/*  83 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - topN '%s' is not a valid integer.", new Object[] { expression, nStr }));
/*     */     }
/*  85 */     if (1 != streamExpressions.size()) {
/*  86 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*  88 */     if ((null == sortExpression) || (!(sortExpression.getParameter() instanceof StreamExpressionValue))) {
/*  89 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'over' parameter listing fields to unique over but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/*  92 */     TupleStream stream = factory.constructStream((StreamExpression)streamExpressions.get(0));
/*  93 */     StreamComparator comp = factory.constructComparator(((StreamExpressionValue)sortExpression.getParameter()).getValue(), FieldComparator.class);
/*     */     
/*  95 */     init(stream, nInt, comp);
/*     */   }
/*     */   
/*     */   private void init(TupleStream tupleStream, int size, StreamComparator comp) throws IOException {
/*  99 */     this.stream = tupleStream;
/* 100 */     this.comp = comp;
/* 101 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */   public StreamExpression toExpression(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 108 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 113 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 116 */     expression.addParameter(new StreamExpressionNamedParameter("n", Integer.toString(this.size)));
/*     */     
/* 118 */     if (includeStreams)
/*     */     {
/* 120 */       if ((this.stream instanceof Expressible)) {
/* 121 */         expression.addParameter(((Expressible)this.stream).toExpression(factory));
/*     */       }
/*     */       else {
/* 124 */         throw new IOException("This RankStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 128 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 132 */     expression.addParameter(new StreamExpressionNamedParameter("sort", this.comp.toExpression(factory)));
/*     */     
/* 134 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 140 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.stream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString()).withHelper(this.comp.toExplanation(factory));
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 152 */     this.stream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 156 */     List<TupleStream> l = new ArrayList();
/* 157 */     l.add(this.stream);
/* 158 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 162 */     this.top = new PriorityQueue(this.size, new ReverseComp(this.comp));
/* 163 */     this.topList = new LinkedList();
/* 164 */     this.stream.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 168 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public StreamComparator getComparator() {
/* 172 */     return this.comp;
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException {
/* 176 */     if (!this.finished) {
/*     */       for (;;) {
/* 178 */         Tuple tuple = this.stream.read();
/* 179 */         if (tuple.EOF) {
/* 180 */           this.finished = true;
/* 181 */           int s = this.top.size();
/* 182 */           for (int i = 0; i < s; i++) {
/* 183 */             Tuple t = (Tuple)this.top.poll();
/* 184 */             this.topList.addFirst(t);
/*     */           }
/* 186 */           this.topList.addLast(tuple);
/* 187 */           break;
/*     */         }
/* 189 */         if (this.top.size() >= this.size) {
/* 190 */           Tuple peek = (Tuple)this.top.peek();
/* 191 */           if (this.comp.compare(tuple, peek) < 0) {
/* 192 */             this.top.poll();
/* 193 */             this.top.add(tuple);
/*     */           }
/*     */         } else {
/* 196 */           this.top.add(tuple);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 202 */     return (Tuple)this.topList.pollFirst();
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 207 */     return this.comp;
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 211 */     return 0;
/*     */   }
/*     */   
/*     */   class ReverseComp implements Comparator<Tuple>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private StreamComparator comp;
/*     */     
/*     */     public ReverseComp(StreamComparator comp) {
/* 220 */       this.comp = comp;
/*     */     }
/*     */     
/*     */     public int compare(Tuple t1, Tuple t2) {
/* 224 */       return this.comp.compare(t1, t2) * -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\RankStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */