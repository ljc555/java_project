/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PivotField
/*     */   implements Serializable
/*     */ {
/*     */   final String _field;
/*     */   final Object _value;
/*     */   final int _count;
/*     */   final List<PivotField> _pivot;
/*     */   final Map<String, FieldStatsInfo> _statsInfo;
/*     */   final Map<String, Integer> _querycounts;
/*     */   final List<RangeFacet> _ranges;
/*     */   
/*     */   public PivotField(String f, Object v, int count, List<PivotField> pivot, Map<String, FieldStatsInfo> statsInfo, Map<String, Integer> queryCounts, List<RangeFacet> ranges)
/*     */   {
/*  36 */     this._field = f;
/*  37 */     this._value = v;
/*  38 */     this._count = count;
/*  39 */     this._pivot = pivot;
/*  40 */     this._statsInfo = statsInfo;
/*  41 */     this._querycounts = queryCounts;
/*  42 */     this._ranges = ranges;
/*     */   }
/*     */   
/*     */   public String getField() {
/*  46 */     return this._field;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/*  50 */     return this._value;
/*     */   }
/*     */   
/*     */   public int getCount() {
/*  54 */     return this._count;
/*     */   }
/*     */   
/*     */   public List<PivotField> getPivot() {
/*  58 */     return this._pivot;
/*     */   }
/*     */   
/*     */   public Map<String, FieldStatsInfo> getFieldStatsInfo() {
/*  62 */     return this._statsInfo;
/*     */   }
/*     */   
/*     */   public Map<String, Integer> getFacetQuery() {
/*  66 */     return this._querycounts;
/*     */   }
/*     */   
/*     */   public List<RangeFacet> getFacetRanges() {
/*  70 */     return this._ranges;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  76 */     return this._field + ":" + this._value + " [" + this._count + "] " + this._pivot;
/*     */   }
/*     */   
/*     */   public void write(PrintStream out, int indent)
/*     */   {
/*  81 */     for (int i = 0; i < indent; i++) {
/*  82 */       out.print("  ");
/*     */     }
/*  84 */     out.print(this._field + "=" + this._value + " (" + this._count + ")");
/*  85 */     if (null != this._statsInfo) {
/*  86 */       out.print("->stats:[");
/*  87 */       for (FieldStatsInfo fieldStatsInfo : this._statsInfo.values()) {
/*  88 */         out.print(fieldStatsInfo.toString());
/*  89 */         out.print(",");
/*     */       }
/*  91 */       out.print("]");
/*     */     }
/*  93 */     out.println();
/*  94 */     if (this._querycounts != null) {
/*  95 */       out.println(this._querycounts.toString());
/*     */     }
/*  97 */     if (this._ranges != null) {
/*  98 */       out.println(this._ranges.toString());
/*     */     }
/* 100 */     if (this._pivot != null) {
/* 101 */       for (PivotField p : this._pivot) {
/* 102 */         p.write(out, indent + 1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\PivotField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */