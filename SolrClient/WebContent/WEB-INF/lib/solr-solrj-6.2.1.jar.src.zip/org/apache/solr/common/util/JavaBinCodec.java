/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.EnumFieldValue;
/*     */ import org.apache.solr.common.SolrDocument;
/*     */ import org.apache.solr.common.SolrDocumentList;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.SolrInputField;
/*     */ import org.noggit.CharArr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaBinCodec
/*     */ {
/*     */   public static final byte NULL = 0;
/*     */   public static final byte BOOL_TRUE = 1;
/*     */   public static final byte BOOL_FALSE = 2;
/*     */   public static final byte BYTE = 3;
/*     */   public static final byte SHORT = 4;
/*     */   public static final byte DOUBLE = 5;
/*     */   public static final byte INT = 6;
/*     */   public static final byte LONG = 7;
/*     */   public static final byte FLOAT = 8;
/*     */   public static final byte DATE = 9;
/*     */   public static final byte MAP = 10;
/*     */   public static final byte SOLRDOC = 11;
/*     */   public static final byte SOLRDOCLST = 12;
/*     */   public static final byte BYTEARR = 13;
/*     */   public static final byte ITERATOR = 14;
/*     */   public static final byte END = 15;
/*     */   public static final byte SOLRINPUTDOC = 16;
/*     */   public static final byte SOLRINPUTDOC_CHILDS = 17;
/*     */   public static final byte ENUM_FIELD_VALUE = 18;
/*     */   public static final byte MAP_ENTRY = 19;
/*     */   public static final byte TAG_AND_LEN = 32;
/*     */   public static final byte STR = 32;
/*     */   public static final byte SINT = 64;
/*     */   public static final byte SLONG = 96;
/*     */   public static final byte ARR = -128;
/*     */   public static final byte ORDERED_MAP = -96;
/*     */   public static final byte NAMED_LST = -64;
/*     */   public static final byte EXTERN_STRING = -32;
/*     */   private static final int MAX_UTF8_SIZE_FOR_ARRAY_GROW_STRATEGY = 65536;
/*  97 */   private static byte VERSION = 2;
/*     */   private final ObjectResolver resolver;
/*     */   protected FastOutputStream daos;
/*     */   private StringCache stringCache;
/*     */   private WritableDocFields writableDocFields;
/*     */   private boolean alreadyMarshalled;
/*     */   private boolean alreadyUnmarshalled;
/*     */   byte version;
/*     */   
/* 106 */   public JavaBinCodec() { this.resolver = null;
/* 107 */     this.writableDocFields = null;
/*     */   }
/*     */   
/*     */ 
/* 111 */   public JavaBinCodec(ObjectResolver resolver) { this(resolver, null); }
/*     */   
/*     */   public JavaBinCodec setWritableDocFields(WritableDocFields writableDocFields) {
/* 114 */     this.writableDocFields = writableDocFields;
/* 115 */     return this;
/*     */   }
/*     */   
/*     */   public JavaBinCodec(ObjectResolver resolver, StringCache stringCache)
/*     */   {
/* 120 */     this.resolver = resolver;
/* 121 */     this.stringCache = stringCache;
/*     */   }
/*     */   
/*     */   public ObjectResolver getResolver() {
/* 125 */     return this.resolver;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void marshal(Object nl, java.io.OutputStream os)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	org/apache/solr/common/util/JavaBinCodec:$assertionsDisabled	Z
/*     */     //   3: ifne +18 -> 21
/*     */     //   6: aload_0
/*     */     //   7: getfield 16	org/apache/solr/common/util/JavaBinCodec:alreadyMarshalled	Z
/*     */     //   10: ifeq +11 -> 21
/*     */     //   13: new 17	java/lang/AssertionError
/*     */     //   16: dup
/*     */     //   17: invokespecial 18	java/lang/AssertionError:<init>	()V
/*     */     //   20: athrow
/*     */     //   21: aload_0
/*     */     //   22: aload_2
/*     */     //   23: invokestatic 19	org/apache/solr/common/util/FastOutputStream:wrap	(Ljava/io/OutputStream;)Lorg/apache/solr/common/util/FastOutputStream;
/*     */     //   26: invokevirtual 20	org/apache/solr/common/util/JavaBinCodec:init	(Lorg/apache/solr/common/util/FastOutputStream;)V
/*     */     //   29: aload_0
/*     */     //   30: getfield 21	org/apache/solr/common/util/JavaBinCodec:daos	Lorg/apache/solr/common/util/FastOutputStream;
/*     */     //   33: getstatic 22	org/apache/solr/common/util/JavaBinCodec:VERSION	B
/*     */     //   36: invokevirtual 23	org/apache/solr/common/util/FastOutputStream:writeByte	(I)V
/*     */     //   39: aload_0
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual 24	org/apache/solr/common/util/JavaBinCodec:writeVal	(Ljava/lang/Object;)V
/*     */     //   44: aload_0
/*     */     //   45: getfield 21	org/apache/solr/common/util/JavaBinCodec:daos	Lorg/apache/solr/common/util/FastOutputStream;
/*     */     //   48: invokevirtual 25	org/apache/solr/common/util/FastOutputStream:flushBuffer	()V
/*     */     //   51: aload_0
/*     */     //   52: iconst_1
/*     */     //   53: putfield 16	org/apache/solr/common/util/JavaBinCodec:alreadyMarshalled	Z
/*     */     //   56: goto +18 -> 74
/*     */     //   59: astore_3
/*     */     //   60: aload_0
/*     */     //   61: getfield 21	org/apache/solr/common/util/JavaBinCodec:daos	Lorg/apache/solr/common/util/FastOutputStream;
/*     */     //   64: invokevirtual 25	org/apache/solr/common/util/FastOutputStream:flushBuffer	()V
/*     */     //   67: aload_0
/*     */     //   68: iconst_1
/*     */     //   69: putfield 16	org/apache/solr/common/util/JavaBinCodec:alreadyMarshalled	Z
/*     */     //   72: aload_3
/*     */     //   73: athrow
/*     */     //   74: return
/*     */     // Line number table:
/*     */     //   Java source line #129	-> byte code offset #0
/*     */     //   Java source line #130	-> byte code offset #21
/*     */     //   Java source line #132	-> byte code offset #29
/*     */     //   Java source line #133	-> byte code offset #39
/*     */     //   Java source line #135	-> byte code offset #44
/*     */     //   Java source line #136	-> byte code offset #51
/*     */     //   Java source line #137	-> byte code offset #56
/*     */     //   Java source line #135	-> byte code offset #59
/*     */     //   Java source line #136	-> byte code offset #67
/*     */     //   Java source line #138	-> byte code offset #74
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	75	0	this	JavaBinCodec
/*     */     //   0	75	1	nl	Object
/*     */     //   0	75	2	os	java.io.OutputStream
/*     */     //   59	14	3	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	44	59	finally
/*     */   }
/*     */   
/*     */   public void init(FastOutputStream os)
/*     */   {
/* 142 */     this.daos = os;
/*     */   }
/*     */   
/*     */   public Object unmarshal(InputStream is)
/*     */     throws IOException
/*     */   {
/* 148 */     assert (!this.alreadyUnmarshalled);
/* 149 */     FastInputStream dis = FastInputStream.wrap(is);
/* 150 */     this.version = dis.readByte();
/* 151 */     if (this.version != VERSION) {
/* 152 */       throw new RuntimeException("Invalid version (expected " + VERSION + ", but " + this.version + ") or the data in not in 'javabin' format");
/*     */     }
/*     */     
/*     */ 
/* 156 */     this.alreadyUnmarshalled = true;
/* 157 */     return readVal(dis);
/*     */   }
/*     */   
/*     */   public SimpleOrderedMap<Object> readOrderedMap(DataInputInputStream dis) throws IOException
/*     */   {
/* 162 */     int sz = readSize(dis);
/* 163 */     SimpleOrderedMap<Object> nl = new SimpleOrderedMap();
/* 164 */     for (int i = 0; i < sz; i++) {
/* 165 */       String name = (String)readVal(dis);
/* 166 */       Object val = readVal(dis);
/* 167 */       nl.add(name, val);
/*     */     }
/* 169 */     return nl;
/*     */   }
/*     */   
/*     */   public NamedList<Object> readNamedList(DataInputInputStream dis) throws IOException {
/* 173 */     int sz = readSize(dis);
/* 174 */     NamedList<Object> nl = new NamedList();
/* 175 */     for (int i = 0; i < sz; i++) {
/* 176 */       String name = (String)readVal(dis);
/* 177 */       Object val = readVal(dis);
/* 178 */       nl.add(name, val);
/*     */     }
/* 180 */     return nl;
/*     */   }
/*     */   
/*     */   public void writeNamedList(NamedList<?> nl) throws IOException {
/* 184 */     writeTag((byte)((nl instanceof SimpleOrderedMap) ? -96 : -64), nl.size());
/* 185 */     for (int i = 0; i < nl.size(); i++) {
/* 186 */       String name = nl.getName(i);
/* 187 */       writeExternString(name);
/* 188 */       Object val = nl.getVal(i);
/* 189 */       writeVal(val);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeVal(Object val) throws IOException {
/* 194 */     if (writeKnownType(val)) {
/* 195 */       return;
/*     */     }
/* 197 */     ObjectResolver resolver = null;
/* 198 */     if ((val instanceof ObjectResolver)) {
/* 199 */       resolver = (ObjectResolver)val;
/*     */     }
/*     */     else {
/* 202 */       resolver = this.resolver;
/*     */     }
/* 204 */     if (resolver != null) {
/* 205 */       Object tmpVal = resolver.resolve(val, this);
/* 206 */       if (tmpVal == null) return;
/* 207 */       if (writeKnownType(tmpVal)) { return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 213 */     writeVal(val.getClass().getName() + ':' + val.toString());
/*     */   }
/*     */   
/* 216 */   protected static final Object END_OBJ = new Object();
/*     */   protected byte tagByte;
/*     */   
/*     */   public Object readVal(DataInputInputStream dis) throws IOException
/*     */   {
/* 221 */     this.tagByte = dis.readByte();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */     switch (this.tagByte >>> 5) {
/*     */     case 1: 
/* 229 */       return readStr(dis);
/*     */     case 2: 
/* 231 */       return Integer.valueOf(readSmallInt(dis));
/*     */     case 3: 
/* 233 */       return Long.valueOf(readSmallLong(dis));
/*     */     case 134217724: 
/* 235 */       return readArray(dis);
/*     */     case 134217725: 
/* 237 */       return readOrderedMap(dis);
/*     */     case 134217726: 
/* 239 */       return readNamedList(dis);
/*     */     case 134217727: 
/* 241 */       return readExternString(dis);
/*     */     }
/*     */     
/* 244 */     switch (this.tagByte) {
/*     */     case 0: 
/* 246 */       return null;
/*     */     case 9: 
/* 248 */       return new Date(dis.readLong());
/*     */     case 6: 
/* 250 */       return Integer.valueOf(dis.readInt());
/*     */     case 1: 
/* 252 */       return Boolean.TRUE;
/*     */     case 2: 
/* 254 */       return Boolean.FALSE;
/*     */     case 8: 
/* 256 */       return Float.valueOf(dis.readFloat());
/*     */     case 5: 
/* 258 */       return Double.valueOf(dis.readDouble());
/*     */     case 7: 
/* 260 */       return Long.valueOf(dis.readLong());
/*     */     case 3: 
/* 262 */       return Byte.valueOf(dis.readByte());
/*     */     case 4: 
/* 264 */       return Short.valueOf(dis.readShort());
/*     */     case 10: 
/* 266 */       return readMap(dis);
/*     */     case 11: 
/* 268 */       return readSolrDocument(dis);
/*     */     case 12: 
/* 270 */       return readSolrDocumentList(dis);
/*     */     case 13: 
/* 272 */       return readByteArray(dis);
/*     */     case 14: 
/* 274 */       return readIterator(dis);
/*     */     case 15: 
/* 276 */       return END_OBJ;
/*     */     case 16: 
/* 278 */       return readSolrInputDocument(dis);
/*     */     case 18: 
/* 280 */       return readEnumFieldValue(dis);
/*     */     case 19: 
/* 282 */       return readMapEntry(dis);
/*     */     }
/*     */     
/* 285 */     throw new RuntimeException("Unknown type " + this.tagByte);
/*     */   }
/*     */   
/*     */   public boolean writeKnownType(Object val) throws IOException {
/* 289 */     if (writePrimitive(val)) return true;
/* 290 */     if ((val instanceof NamedList)) {
/* 291 */       writeNamedList((NamedList)val);
/* 292 */       return true;
/*     */     }
/* 294 */     if ((val instanceof SolrDocumentList)) {
/* 295 */       writeSolrDocumentList((SolrDocumentList)val);
/* 296 */       return true;
/*     */     }
/* 298 */     if ((val instanceof Collection)) {
/* 299 */       writeArray((Collection)val);
/* 300 */       return true;
/*     */     }
/* 302 */     if ((val instanceof Object[])) {
/* 303 */       writeArray((Object[])val);
/* 304 */       return true;
/*     */     }
/* 306 */     if ((val instanceof SolrDocument))
/*     */     {
/* 308 */       writeSolrDocument((SolrDocument)val);
/* 309 */       return true;
/*     */     }
/* 311 */     if ((val instanceof SolrInputDocument)) {
/* 312 */       writeSolrInputDocument((SolrInputDocument)val);
/* 313 */       return true;
/*     */     }
/* 315 */     if ((val instanceof Map)) {
/* 316 */       writeMap((Map)val);
/* 317 */       return true;
/*     */     }
/* 319 */     if ((val instanceof Iterator)) {
/* 320 */       writeIterator((Iterator)val);
/* 321 */       return true;
/*     */     }
/* 323 */     if ((val instanceof Path)) {
/* 324 */       writeStr(((Path)val).toAbsolutePath().toString());
/* 325 */       return true;
/*     */     }
/* 327 */     if ((val instanceof Iterable)) {
/* 328 */       writeIterator(((Iterable)val).iterator());
/* 329 */       return true;
/*     */     }
/* 331 */     if ((val instanceof EnumFieldValue)) {
/* 332 */       writeEnumFieldValue((EnumFieldValue)val);
/* 333 */       return true;
/*     */     }
/* 335 */     if ((val instanceof Map.Entry)) {
/* 336 */       writeMapEntry((Map.Entry)val);
/* 337 */       return true;
/*     */     }
/* 339 */     return false;
/*     */   }
/*     */   
/*     */   public void writeTag(byte tag) throws IOException {
/* 343 */     this.daos.writeByte(tag);
/*     */   }
/*     */   
/*     */   public void writeTag(byte tag, int size) throws IOException {
/* 347 */     if ((tag & 0xE0) != 0) {
/* 348 */       if (size < 31) {
/* 349 */         this.daos.writeByte(tag | size);
/*     */       } else {
/* 351 */         this.daos.writeByte(tag | 0x1F);
/* 352 */         writeVInt(size - 31, this.daos);
/*     */       }
/*     */     } else {
/* 355 */       this.daos.writeByte(tag);
/* 356 */       writeVInt(size, this.daos);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeByteArray(byte[] arr, int offset, int len) throws IOException {
/* 361 */     writeTag((byte)13, len);
/* 362 */     this.daos.write(arr, offset, len);
/*     */   }
/*     */   
/*     */   public byte[] readByteArray(DataInputInputStream dis) throws IOException {
/* 366 */     byte[] arr = new byte[readVInt(dis)];
/* 367 */     dis.readFully(arr);
/* 368 */     return arr;
/*     */   }
/*     */   
/*     */ 
/* 372 */   private boolean ignoreWritable = false;
/*     */   byte[] bytes;
/*     */   
/* 375 */   public void writeSolrDocument(SolrDocument doc) throws IOException { List<SolrDocument> children = doc.getChildDocuments();
/* 376 */     int fieldsCount = 0;
/* 377 */     Iterator localIterator; if ((this.writableDocFields == null) || (this.writableDocFields.wantsAllFields()) || (this.ignoreWritable)) {
/* 378 */       fieldsCount = doc.size();
/*     */     } else
/* 380 */       for (localIterator = doc.iterator(); localIterator.hasNext();) { e = (Map.Entry)localIterator.next();
/* 381 */         if (toWrite((String)e.getKey())) fieldsCount++;
/*     */       }
/*     */     Map.Entry<String, Object> e;
/* 384 */     int sz = fieldsCount + (children == null ? 0 : children.size());
/* 385 */     writeTag((byte)11);
/* 386 */     writeTag((byte)-96, sz);
/* 387 */     for (Map.Entry<String, Object> entry : doc) {
/* 388 */       String name = (String)entry.getKey();
/* 389 */       if (toWrite(name)) {
/* 390 */         writeExternString(name);
/* 391 */         Object val = entry.getValue();
/* 392 */         writeVal(val);
/*     */       }
/*     */     }
/* 395 */     if (children != null) {
/*     */       try {
/* 397 */         this.ignoreWritable = true;
/* 398 */         for (SolrDocument child : children) {
/* 399 */           writeSolrDocument(child);
/*     */         }
/*     */       } finally {
/* 402 */         this.ignoreWritable = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean toWrite(String key)
/*     */   {
/* 409 */     return (this.writableDocFields == null) || (this.ignoreWritable) || (this.writableDocFields.isWritable(key));
/*     */   }
/*     */   
/*     */   public SolrDocument readSolrDocument(DataInputInputStream dis) throws IOException {
/* 413 */     this.tagByte = dis.readByte();
/* 414 */     int size = readSize(dis);
/* 415 */     SolrDocument doc = new SolrDocument();
/* 416 */     for (int i = 0; i < size; i++)
/*     */     {
/* 418 */       Object obj = readVal(dis);
/* 419 */       if ((obj instanceof SolrDocument)) {
/* 420 */         doc.addChildDocument((SolrDocument)obj);
/*     */       }
/*     */       else {
/* 423 */         String fieldName = (String)obj;
/*     */         
/* 425 */         Object fieldVal = readVal(dis);
/* 426 */         doc.setField(fieldName, fieldVal);
/*     */       } }
/* 428 */     return doc;
/*     */   }
/*     */   
/*     */   public SolrDocumentList readSolrDocumentList(DataInputInputStream dis) throws IOException {
/* 432 */     SolrDocumentList solrDocs = new SolrDocumentList();
/* 433 */     List list = (List)readVal(dis);
/* 434 */     solrDocs.setNumFound(((Long)list.get(0)).longValue());
/* 435 */     solrDocs.setStart(((Long)list.get(1)).longValue());
/* 436 */     solrDocs.setMaxScore((Float)list.get(2));
/*     */     
/*     */ 
/* 439 */     List<SolrDocument> l = (List)readVal(dis);
/* 440 */     solrDocs.addAll(l);
/* 441 */     return solrDocs;
/*     */   }
/*     */   
/*     */   public void writeSolrDocumentList(SolrDocumentList docs) throws IOException
/*     */   {
/* 446 */     writeTag((byte)12);
/* 447 */     List<Number> l = new ArrayList(3);
/* 448 */     l.add(Long.valueOf(docs.getNumFound()));
/* 449 */     l.add(Long.valueOf(docs.getStart()));
/* 450 */     l.add(docs.getMaxScore());
/* 451 */     writeArray(l);
/* 452 */     writeArray(docs);
/*     */   }
/*     */   
/*     */   public SolrInputDocument readSolrInputDocument(DataInputInputStream dis) throws IOException {
/* 456 */     int sz = readVInt(dis);
/* 457 */     float docBoost = ((Float)readVal(dis)).floatValue();
/* 458 */     SolrInputDocument sdoc = new SolrInputDocument(new String[0]);
/* 459 */     sdoc.setDocumentBoost(docBoost);
/* 460 */     for (int i = 0; i < sz; i++) {
/* 461 */       float boost = 1.0F;
/*     */       
/* 463 */       Object obj = readVal(dis);
/* 464 */       String fieldName; String fieldName; if ((obj instanceof Float)) {
/* 465 */         boost = ((Float)obj).floatValue();
/* 466 */         fieldName = (String)readVal(dis);
/* 467 */       } else { if ((obj instanceof SolrInputDocument)) {
/* 468 */           sdoc.addChildDocument((SolrInputDocument)obj);
/* 469 */           continue;
/*     */         }
/* 471 */         fieldName = (String)obj;
/*     */       }
/* 473 */       Object fieldVal = readVal(dis);
/* 474 */       sdoc.setField(fieldName, fieldVal, boost);
/*     */     }
/* 476 */     return sdoc;
/*     */   }
/*     */   
/*     */   public void writeSolrInputDocument(SolrInputDocument sdoc) throws IOException {
/* 480 */     List<SolrInputDocument> children = sdoc.getChildDocuments();
/* 481 */     int sz = sdoc.size() + (children == null ? 0 : children.size());
/* 482 */     writeTag((byte)16, sz);
/* 483 */     writeFloat(sdoc.getDocumentBoost());
/* 484 */     for (SolrInputField inputField : sdoc.values()) {
/* 485 */       if (inputField.getBoost() != 1.0F) {
/* 486 */         writeFloat(inputField.getBoost());
/*     */       }
/* 488 */       writeExternString(inputField.getName());
/* 489 */       writeVal(inputField.getValue());
/*     */     }
/* 491 */     if (children != null) {
/* 492 */       for (SolrInputDocument child : children) {
/* 493 */         writeSolrInputDocument(child);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<Object, Object> readMap(DataInputInputStream dis)
/*     */     throws IOException
/*     */   {
/* 501 */     int sz = readVInt(dis);
/* 502 */     Map<Object, Object> m = new LinkedHashMap();
/* 503 */     for (int i = 0; i < sz; i++) {
/* 504 */       Object key = readVal(dis);
/* 505 */       Object val = readVal(dis);
/* 506 */       m.put(key, val);
/*     */     }
/*     */     
/* 509 */     return m;
/*     */   }
/*     */   
/*     */   public void writeIterator(Iterator iter) throws IOException {
/* 513 */     writeTag((byte)14);
/* 514 */     while (iter.hasNext()) {
/* 515 */       writeVal(iter.next());
/*     */     }
/* 517 */     writeVal(END_OBJ);
/*     */   }
/*     */   
/*     */   public List<Object> readIterator(DataInputInputStream fis) throws IOException {
/* 521 */     ArrayList<Object> l = new ArrayList();
/*     */     for (;;) {
/* 523 */       Object o = readVal(fis);
/* 524 */       if (o == END_OBJ) break;
/* 525 */       l.add(o);
/*     */     }
/* 527 */     return l;
/*     */   }
/*     */   
/*     */   public void writeArray(List l) throws IOException {
/* 531 */     writeTag((byte)Byte.MIN_VALUE, l.size());
/* 532 */     for (int i = 0; i < l.size(); i++) {
/* 533 */       writeVal(l.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeArray(Collection coll) throws IOException {
/* 538 */     writeTag((byte)Byte.MIN_VALUE, coll.size());
/* 539 */     for (Object o : coll) {
/* 540 */       writeVal(o);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeArray(Object[] arr) throws IOException
/*     */   {
/* 546 */     writeTag((byte)Byte.MIN_VALUE, arr.length);
/* 547 */     for (int i = 0; i < arr.length; i++) {
/* 548 */       Object o = arr[i];
/* 549 */       writeVal(o);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Object> readArray(DataInputInputStream dis) throws IOException {
/* 554 */     int sz = readSize(dis);
/* 555 */     ArrayList<Object> l = new ArrayList(sz);
/* 556 */     for (int i = 0; i < sz; i++) {
/* 557 */       l.add(readVal(dis));
/*     */     }
/* 559 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeEnumFieldValue(EnumFieldValue enumFieldValue)
/*     */     throws IOException
/*     */   {
/* 567 */     writeTag((byte)18);
/* 568 */     writeInt(enumFieldValue.toInt().intValue());
/* 569 */     writeStr(enumFieldValue.toString());
/*     */   }
/*     */   
/*     */   public void writeMapEntry(Map.Entry<Object, Object> val) throws IOException {
/* 573 */     writeTag((byte)19);
/* 574 */     writeVal(val.getKey());
/* 575 */     writeVal(val.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EnumFieldValue readEnumFieldValue(DataInputInputStream dis)
/*     */     throws IOException
/*     */   {
/* 584 */     Integer intValue = (Integer)readVal(dis);
/* 585 */     String stringValue = (String)readVal(dis);
/* 586 */     return new EnumFieldValue(intValue, stringValue);
/*     */   }
/*     */   
/*     */   public Map.Entry<Object, Object> readMapEntry(DataInputInputStream dis) throws IOException
/*     */   {
/* 591 */     final Object key = readVal(dis);
/* 592 */     final Object value = readVal(dis);
/* 593 */     new Map.Entry()
/*     */     {
/*     */       public Object getKey()
/*     */       {
/* 597 */         return key;
/*     */       }
/*     */       
/*     */       public Object getValue()
/*     */       {
/* 602 */         return value;
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 607 */         return "MapEntry[" + key + ":" + value + "]";
/*     */       }
/*     */       
/*     */       public Object setValue(Object value)
/*     */       {
/* 612 */         throw new UnsupportedOperationException();
/*     */       }
/*     */       
/*     */       public int hashCode()
/*     */       {
/* 617 */         int result = 31;
/* 618 */         result *= (31 + getKey().hashCode());
/* 619 */         result *= (31 + getValue().hashCode());
/* 620 */         return result;
/*     */       }
/*     */       
/*     */       public boolean equals(Object obj)
/*     */       {
/* 625 */         if (this == obj) {
/* 626 */           return true;
/*     */         }
/* 628 */         if (!(obj instanceof Map.Entry)) {
/* 629 */           return false;
/*     */         }
/* 631 */         Map.Entry<Object, Object> entry = (Map.Entry)obj;
/* 632 */         return (getKey().equals(entry.getKey())) && (getValue().equals(entry.getValue()));
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeStr(String s)
/*     */     throws IOException
/*     */   {
/* 641 */     if (s == null) {
/* 642 */       writeTag((byte)0);
/* 643 */       return;
/*     */     }
/* 645 */     int end = s.length();
/* 646 */     int maxSize = end * 3;
/*     */     
/* 648 */     if (maxSize <= 65536) {
/* 649 */       if ((this.bytes == null) || (this.bytes.length < maxSize)) this.bytes = new byte[maxSize];
/* 650 */       int sz = ByteUtils.UTF16toUTF8(s, 0, end, this.bytes, 0);
/* 651 */       writeTag((byte)32, sz);
/* 652 */       this.daos.write(this.bytes, 0, sz);
/*     */     }
/*     */     else {
/* 655 */       int sz = ByteUtils.calcUTF16toUTF8Length(s, 0, end);
/* 656 */       writeTag((byte)32, sz);
/* 657 */       if ((this.bytes == null) || (this.bytes.length < 8192)) this.bytes = new byte[' '];
/* 658 */       ByteUtils.writeUTF16toUTF8(s, 0, end, this.daos, this.bytes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 663 */   CharArr arr = new CharArr();
/* 664 */   private StringBytes bytesRef = new StringBytes(this.bytes, 0, 0);
/*     */   
/*     */   public String readStr(DataInputInputStream dis) throws IOException {
/* 667 */     return readStr(dis, null);
/*     */   }
/*     */   
/*     */   public String readStr(DataInputInputStream dis, StringCache stringCache) throws IOException {
/* 671 */     int sz = readSize(dis);
/* 672 */     if ((this.bytes == null) || (this.bytes.length < sz)) this.bytes = new byte[sz];
/* 673 */     dis.readFully(this.bytes, 0, sz);
/* 674 */     if (stringCache != null) {
/* 675 */       return stringCache.get(this.bytesRef.reset(this.bytes, 0, sz));
/*     */     }
/* 677 */     this.arr.reset();
/* 678 */     ByteUtils.UTF8toUTF16(this.bytes, 0, sz, this.arr);
/* 679 */     return this.arr.toString();
/*     */   }
/*     */   
/*     */   public void writeInt(int val) throws IOException
/*     */   {
/* 684 */     if (val > 0) {
/* 685 */       int b = 0x40 | val & 0xF;
/*     */       
/* 687 */       if (val >= 15) {
/* 688 */         b |= 0x10;
/* 689 */         this.daos.writeByte(b);
/* 690 */         writeVInt(val >>> 4, this.daos);
/*     */       } else {
/* 692 */         this.daos.writeByte(b);
/*     */       }
/*     */     }
/*     */     else {
/* 696 */       this.daos.writeByte(6);
/* 697 */       this.daos.writeInt(val);
/*     */     }
/*     */   }
/*     */   
/*     */   public int readSmallInt(DataInputInputStream dis) throws IOException {
/* 702 */     int v = this.tagByte & 0xF;
/* 703 */     if ((this.tagByte & 0x10) != 0)
/* 704 */       v = readVInt(dis) << 4 | v;
/* 705 */     return v;
/*     */   }
/*     */   
/*     */   public void writeLong(long val) throws IOException
/*     */   {
/* 710 */     if ((val & 0xFF00000000000000) == 0L) {
/* 711 */       int b = 0x60 | (int)val & 0xF;
/* 712 */       if (val >= 15L) {
/* 713 */         b |= 0x10;
/* 714 */         this.daos.writeByte(b);
/* 715 */         writeVLong(val >>> 4, this.daos);
/*     */       } else {
/* 717 */         this.daos.writeByte(b);
/*     */       }
/*     */     } else {
/* 720 */       this.daos.writeByte(7);
/* 721 */       this.daos.writeLong(val);
/*     */     }
/*     */   }
/*     */   
/*     */   public long readSmallLong(DataInputInputStream dis) throws IOException {
/* 726 */     long v = this.tagByte & 0xF;
/* 727 */     if ((this.tagByte & 0x10) != 0)
/* 728 */       v = readVLong(dis) << 4 | v;
/* 729 */     return v;
/*     */   }
/*     */   
/*     */   public void writeFloat(float val) throws IOException {
/* 733 */     this.daos.writeByte(8);
/* 734 */     this.daos.writeFloat(val);
/*     */   }
/*     */   
/*     */   public boolean writePrimitive(Object val) throws IOException {
/* 738 */     if (val == null) {
/* 739 */       this.daos.writeByte(0);
/* 740 */       return true; }
/* 741 */     if ((val instanceof String)) {
/* 742 */       writeStr((String)val);
/* 743 */       return true; }
/* 744 */     if ((val instanceof Number))
/*     */     {
/* 746 */       if ((val instanceof Integer)) {
/* 747 */         writeInt(((Integer)val).intValue());
/* 748 */         return true; }
/* 749 */       if ((val instanceof Long)) {
/* 750 */         writeLong(((Long)val).longValue());
/* 751 */         return true; }
/* 752 */       if ((val instanceof Float)) {
/* 753 */         writeFloat(((Float)val).floatValue());
/* 754 */         return true; }
/* 755 */       if ((val instanceof Double)) {
/* 756 */         this.daos.writeByte(5);
/* 757 */         this.daos.writeDouble(((Double)val).doubleValue());
/* 758 */         return true; }
/* 759 */       if ((val instanceof Byte)) {
/* 760 */         this.daos.writeByte(3);
/* 761 */         this.daos.writeByte(((Byte)val).intValue());
/* 762 */         return true; }
/* 763 */       if ((val instanceof Short)) {
/* 764 */         this.daos.writeByte(4);
/* 765 */         this.daos.writeShort(((Short)val).intValue());
/* 766 */         return true;
/*     */       }
/* 768 */       return false;
/*     */     }
/* 770 */     if ((val instanceof Date)) {
/* 771 */       this.daos.writeByte(9);
/* 772 */       this.daos.writeLong(((Date)val).getTime());
/* 773 */       return true; }
/* 774 */     if ((val instanceof Boolean)) {
/* 775 */       if (((Boolean)val).booleanValue()) this.daos.writeByte(1); else
/* 776 */         this.daos.writeByte(2);
/* 777 */       return true; }
/* 778 */     if ((val instanceof byte[])) {
/* 779 */       writeByteArray((byte[])val, 0, ((byte[])val).length);
/* 780 */       return true; }
/* 781 */     if ((val instanceof ByteBuffer)) {
/* 782 */       ByteBuffer buf = (ByteBuffer)val;
/* 783 */       writeByteArray(buf.array(), buf.position(), buf.limit() - buf.position());
/* 784 */       return true; }
/* 785 */     if (val == END_OBJ) {
/* 786 */       writeTag((byte)15);
/* 787 */       return true;
/*     */     }
/* 789 */     return false;
/*     */   }
/*     */   
/*     */   public void writeMap(Map<?, ?> val) throws IOException
/*     */   {
/* 794 */     writeTag((byte)10, val.size());
/* 795 */     for (Map.Entry<?, ?> entry : val.entrySet()) {
/* 796 */       Object key = entry.getKey();
/* 797 */       if ((key instanceof String)) {
/* 798 */         writeExternString((String)key);
/*     */       } else {
/* 800 */         writeVal(key);
/*     */       }
/* 802 */       writeVal(entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public int readSize(DataInputInputStream in) throws IOException
/*     */   {
/* 808 */     int sz = this.tagByte & 0x1F;
/* 809 */     if (sz == 31) sz += readVInt(in);
/* 810 */     return sz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeVInt(int i, FastOutputStream out)
/*     */     throws IOException
/*     */   {
/* 822 */     while ((i & 0xFFFFFF80) != 0) {
/* 823 */       out.writeByte((byte)(i & 0x7F | 0x80));
/* 824 */       i >>>= 7;
/*     */     }
/* 826 */     out.writeByte((byte)i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int readVInt(DataInputInputStream in)
/*     */     throws IOException
/*     */   {
/* 835 */     byte b = in.readByte();
/* 836 */     int i = b & 0x7F;
/* 837 */     for (int shift = 7; (b & 0x80) != 0; shift += 7) {
/* 838 */       b = in.readByte();
/* 839 */       i |= (b & 0x7F) << shift;
/*     */     }
/* 841 */     return i;
/*     */   }
/*     */   
/*     */   public static void writeVLong(long i, FastOutputStream out) throws IOException
/*     */   {
/* 846 */     while ((i & 0xFFFFFFFFFFFFFF80) != 0L) {
/* 847 */       out.writeByte((byte)(int)(i & 0x7F | 0x80));
/* 848 */       i >>>= 7;
/*     */     }
/* 850 */     out.writeByte((byte)(int)i);
/*     */   }
/*     */   
/*     */   public static long readVLong(DataInputInputStream in) throws IOException {
/* 854 */     byte b = in.readByte();
/* 855 */     long i = b & 0x7F;
/* 856 */     for (int shift = 7; (b & 0x80) != 0; shift += 7) {
/* 857 */       b = in.readByte();
/* 858 */       i |= (b & 0x7F) << shift;
/*     */     }
/* 860 */     return i;
/*     */   }
/*     */   
/* 863 */   private int stringsCount = 0;
/*     */   private Map<String, Integer> stringsMap;
/*     */   private List<String> stringsList;
/*     */   
/*     */   public void writeExternString(String s) throws IOException {
/* 868 */     if (s == null) {
/* 869 */       writeTag((byte)0);
/* 870 */       return;
/*     */     }
/* 872 */     Integer idx = this.stringsMap == null ? null : (Integer)this.stringsMap.get(s);
/* 873 */     if (idx == null) idx = Integer.valueOf(0);
/* 874 */     writeTag((byte)-32, idx.intValue());
/* 875 */     if (idx.intValue() == 0) {
/* 876 */       writeStr(s);
/* 877 */       if (this.stringsMap == null) this.stringsMap = new HashMap();
/* 878 */       this.stringsMap.put(s, Integer.valueOf(++this.stringsCount));
/*     */     }
/*     */   }
/*     */   
/*     */   public String readExternString(DataInputInputStream fis) throws IOException
/*     */   {
/* 884 */     int idx = readSize(fis);
/* 885 */     if (idx != 0) {
/* 886 */       return (String)this.stringsList.get(idx - 1);
/*     */     }
/* 888 */     this.tagByte = fis.readByte();
/* 889 */     String s = readStr(fis, this.stringCache);
/* 890 */     if (this.stringsList == null) this.stringsList = new ArrayList();
/* 891 */     this.stringsList.add(s);
/* 892 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static abstract interface ObjectResolver
/*     */   {
/*     */     public abstract Object resolve(Object paramObject, JavaBinCodec paramJavaBinCodec)
/*     */       throws IOException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static abstract interface WritableDocFields
/*     */   {
/*     */     public abstract boolean isWritable(String paramString);
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract boolean wantsAllFields();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class StringCache
/*     */   {
/*     */     private final Cache<JavaBinCodec.StringBytes, String> cache;
/*     */     
/*     */ 
/*     */     public StringCache(Cache<JavaBinCodec.StringBytes, String> cache)
/*     */     {
/* 923 */       this.cache = cache;
/*     */     }
/*     */     
/*     */     public String get(JavaBinCodec.StringBytes b) {
/* 927 */       String result = (String)this.cache.get(b);
/* 928 */       if (result == null)
/*     */       {
/* 930 */         JavaBinCodec.StringBytes copy = new JavaBinCodec.StringBytes(Arrays.copyOfRange(b.bytes, b.offset, b.offset + b.length), 0, b.length);
/* 931 */         CharArr arr = new CharArr();
/* 932 */         ByteUtils.UTF8toUTF16(b.bytes, b.offset, b.length, arr);
/* 933 */         result = arr.toString();
/* 934 */         this.cache.put(copy, result);
/*     */       }
/* 936 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class StringBytes
/*     */   {
/*     */     byte[] bytes;
/*     */     
/*     */     int offset;
/*     */     
/*     */     private int length;
/*     */     
/*     */     private int hash;
/*     */     
/*     */ 
/*     */     public StringBytes(byte[] bytes, int offset, int length)
/*     */     {
/* 955 */       reset(bytes, offset, length);
/*     */     }
/*     */     
/*     */     StringBytes reset(byte[] bytes, int offset, int length) {
/* 959 */       this.bytes = bytes;
/* 960 */       this.offset = offset;
/* 961 */       this.length = length;
/* 962 */       this.hash = (bytes == null ? 0 : Hash.murmurhash3_x86_32(bytes, offset, length, 0));
/* 963 */       return this;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other)
/*     */     {
/* 968 */       if (other == null) {
/* 969 */         return false;
/*     */       }
/* 971 */       if ((other instanceof StringBytes)) {
/* 972 */         return bytesEquals((StringBytes)other);
/*     */       }
/* 974 */       return false;
/*     */     }
/*     */     
/*     */     boolean bytesEquals(StringBytes other) {
/* 978 */       assert (other != null);
/* 979 */       if (this.length == other.length) {
/* 980 */         int otherUpto = other.offset;
/* 981 */         byte[] otherBytes = other.bytes;
/* 982 */         int end = this.offset + this.length;
/* 983 */         for (int upto = this.offset; upto < end; otherUpto++) {
/* 984 */           if (this.bytes[upto] != otherBytes[otherUpto]) {
/* 985 */             return false;
/*     */           }
/* 983 */           upto++;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 988 */         return true;
/*     */       }
/* 990 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 996 */       return this.hash;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\JavaBinCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */