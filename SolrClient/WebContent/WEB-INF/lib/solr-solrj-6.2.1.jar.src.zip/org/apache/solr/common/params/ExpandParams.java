package org.apache.solr.common.params;

public abstract interface ExpandParams
{
  public static final String EXPAND = "expand";
  public static final String EXPAND_SORT = "expand.sort";
  public static final String EXPAND_ROWS = "expand.rows";
  public static final String EXPAND_FIELD = "expand.field";
  public static final String EXPAND_Q = "expand.q";
  public static final String EXPAND_FQ = "expand.fq";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\ExpandParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */