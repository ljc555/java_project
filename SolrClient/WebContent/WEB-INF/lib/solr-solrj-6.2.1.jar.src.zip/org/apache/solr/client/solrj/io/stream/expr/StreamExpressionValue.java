/*    */ package org.apache.solr.client.solrj.io.stream.expr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamExpressionValue
/*    */   implements StreamExpressionParameter
/*    */ {
/*    */   private String value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StreamExpressionValue(String value)
/*    */   {
/* 27 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 31 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 35 */     this.value = value;
/*    */   }
/*    */   
/*    */   public StreamExpressionValue withValue(String value) {
/* 39 */     this.value = value;
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 45 */     return this.value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other)
/*    */   {
/* 50 */     if (other.getClass() != StreamExpressionValue.class) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     StreamExpressionValue check = (StreamExpressionValue)other;
/*    */     
/* 56 */     if ((null == this.value) && (null == check.value)) {
/* 57 */       return true;
/*    */     }
/* 59 */     if ((null == this.value) || (null == check.value)) {
/* 60 */       return false;
/*    */     }
/*    */     
/* 63 */     return this.value.equals(((StreamExpressionValue)other).value);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\StreamExpressionValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */