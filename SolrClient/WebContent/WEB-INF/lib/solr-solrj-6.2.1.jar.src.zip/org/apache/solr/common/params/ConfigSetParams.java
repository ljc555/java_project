/*    */ package org.apache.solr.common.params;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConfigSetParams
/*    */ {
/*    */   public static final String ACTION = "action";
/*    */   
/*    */   public static enum ConfigSetAction
/*    */   {
/* 29 */     CREATE, 
/* 30 */     DELETE, 
/* 31 */     LIST;
/*    */     
/*    */     private ConfigSetAction() {}
/* 34 */     public static ConfigSetAction get(String p) { if (p != null) {
/*    */         try {
/* 36 */           return valueOf(p.toUpperCase(Locale.ROOT));
/*    */         } catch (Exception localException) {}
/*    */       }
/* 39 */       return null;
/*    */     }
/*    */     
/*    */     public boolean isEqual(String s) {
/* 43 */       if (s == null) return false;
/* 44 */       return toString().equals(s.toUpperCase(Locale.ROOT));
/*    */     }
/*    */     
/*    */     public String toLower() {
/* 48 */       return toString().toLowerCase(Locale.ROOT);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\ConfigSetParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */