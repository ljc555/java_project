/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionAdminResponse
/*    */   extends SolrResponseBase
/*    */ {
/*    */   public NamedList<NamedList<Object>> getCollectionStatus()
/*    */   {
/* 29 */     return (NamedList)getResponse().get("success");
/*    */   }
/*    */   
/*    */   public boolean isSuccess()
/*    */   {
/* 34 */     return getResponse().get("success") != null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NamedList<String> getErrorMessages()
/*    */   {
/* 42 */     return (NamedList)getResponse().get("failure");
/*    */   }
/*    */   
/*    */ 
/*    */   public Map<String, NamedList<Integer>> getCollectionCoresStatus()
/*    */   {
/* 48 */     Map<String, NamedList<Integer>> res = new HashMap();
/* 49 */     NamedList<NamedList<Object>> cols = getCollectionStatus();
/* 50 */     if (cols != null) {
/* 51 */       for (Map.Entry<String, NamedList<Object>> e : cols) {
/* 52 */         NamedList<Object> item = (NamedList)e.getValue();
/* 53 */         String core = (String)item.get("core");
/* 54 */         if (core != null) {
/* 55 */           res.put(core, (NamedList)item.get("responseHeader"));
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 60 */     return res;
/*    */   }
/*    */   
/*    */ 
/*    */   public Map<String, NamedList<Integer>> getCollectionNodesStatus()
/*    */   {
/* 66 */     Map<String, NamedList<Integer>> res = new HashMap();
/* 67 */     NamedList<NamedList<Object>> cols = getCollectionStatus();
/* 68 */     if (cols != null) {
/* 69 */       for (Map.Entry<String, NamedList<Object>> e : cols) {
/* 70 */         if (e.getKey() != null) {
/* 71 */           res.put(e.getKey(), (NamedList)((NamedList)e.getValue()).get("responseHeader"));
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 76 */     return res;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\CollectionAdminResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */