/*      */ package org.apache.solr.client.solrj.request;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.Collection;
/*      */ import java.util.Optional;
/*      */ import java.util.Properties;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.apache.solr.client.solrj.SolrClient;
/*      */ import org.apache.solr.client.solrj.SolrRequest;
/*      */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*      */ import org.apache.solr.client.solrj.SolrResponse;
/*      */ import org.apache.solr.client.solrj.SolrServerException;
/*      */ import org.apache.solr.client.solrj.response.CollectionAdminResponse;
/*      */ import org.apache.solr.client.solrj.response.RequestStatusState;
/*      */ import org.apache.solr.client.solrj.util.SolrIdentifierValidator;
/*      */ import org.apache.solr.common.SolrException;
/*      */ import org.apache.solr.common.params.CollectionParams.CollectionAction;
/*      */ import org.apache.solr.common.params.ModifiableSolrParams;
/*      */ import org.apache.solr.common.params.SolrParams;
/*      */ import org.apache.solr.common.util.ContentStream;
/*      */ import org.apache.solr.common.util.NamedList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class CollectionAdminRequest<T extends CollectionAdminResponse>
/*      */   extends SolrRequest<T>
/*      */ {
/*      */   protected final CollectionParams.CollectionAction action;
/*   55 */   private static String PROPERTY_PREFIX = "property.";
/*      */   
/*      */   public CollectionAdminRequest(CollectionParams.CollectionAction action) {
/*   58 */     this("/admin/collections", action);
/*      */   }
/*      */   
/*      */   public CollectionAdminRequest(String path, CollectionParams.CollectionAction action) {
/*   62 */     super(SolrRequest.METHOD.GET, path);
/*   63 */     this.action = action;
/*      */   }
/*      */   
/*      */   public SolrParams getParams()
/*      */   {
/*   68 */     if (this.action == null) {
/*   69 */       throw new RuntimeException("no action specified!");
/*      */     }
/*   71 */     ModifiableSolrParams params = new ModifiableSolrParams();
/*   72 */     params.set("action", new String[] { this.action.toString() });
/*   73 */     return params;
/*      */   }
/*      */   
/*      */   public Collection<ContentStream> getContentStreams() throws IOException
/*      */   {
/*   78 */     return null;
/*      */   }
/*      */   
/*      */   protected void addProperties(ModifiableSolrParams params, Properties props) {
/*   82 */     for (String propertyName : props.stringPropertyNames()) {
/*   83 */       params.set(PROPERTY_PREFIX + propertyName, new String[] { props.getProperty(propertyName) });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static abstract class AsyncCollectionAdminRequest
/*      */     extends CollectionAdminRequest<CollectionAdminResponse>
/*      */   {
/*      */     public AsyncCollectionAdminRequest(CollectionParams.CollectionAction action)
/*      */     {
/*   93 */       super();
/*      */     }
/*      */     
/*      */     protected CollectionAdminResponse createResponse(SolrClient client)
/*      */     {
/*   98 */       return new CollectionAdminResponse();
/*      */     }
/*      */     
/*      */     private static String generateAsyncId() {
/*  102 */       return UUID.randomUUID().toString();
/*      */     }
/*      */     
/*  105 */     protected String asyncId = null;
/*      */     
/*      */     public String getAsyncId() {
/*  108 */       return this.asyncId;
/*      */     }
/*      */     
/*      */ 
/*      */     @Deprecated
/*      */     public AsyncCollectionAdminRequest setAsyncId(String id)
/*      */     {
/*  115 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public String processAsync(SolrClient client)
/*      */       throws IOException, SolrServerException
/*      */     {
/*  124 */       return processAsync(generateAsyncId(), client);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String processAsync(String asyncId, SolrClient client)
/*      */       throws IOException, SolrServerException
/*      */     {
/*  134 */       this.asyncId = asyncId;
/*  135 */       NamedList<Object> resp = client.request(this);
/*  136 */       if (resp.get("error") != null) {
/*  137 */         throw new SolrServerException((String)resp.get("error"));
/*      */       }
/*  139 */       return (String)resp.get("requestid");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public RequestStatusState processAndWait(SolrClient client, long timeoutSeconds)
/*      */       throws SolrServerException, InterruptedException, IOException
/*      */     {
/*  151 */       return processAndWait(generateAsyncId(), client, timeoutSeconds);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public RequestStatusState processAndWait(String asyncId, SolrClient client, long timeoutSeconds)
/*      */       throws IOException, SolrServerException, InterruptedException
/*      */     {
/*  164 */       processAsync(asyncId, client);
/*  165 */       return requestStatus(asyncId).waitFor(client, timeoutSeconds);
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  170 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  171 */       if (this.asyncId != null) {
/*  172 */         params.set("async", new String[] { this.asyncId });
/*      */       }
/*  174 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class AsyncCollectionSpecificAdminRequest extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     
/*      */     public AsyncCollectionSpecificAdminRequest(CollectionParams.CollectionAction action, String collection) {
/*  183 */       super();
/*  184 */       this.collection = collection;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public abstract AsyncCollectionSpecificAdminRequest setCollectionName(String paramString);
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  192 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  193 */       if (this.collection == null)
/*  194 */         throw new IllegalArgumentException("You must call setCollectionName() on this request");
/*  195 */       params.set("name", new String[] { this.collection });
/*  196 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class AsyncShardSpecificAdminRequest extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     protected String shard;
/*      */     
/*      */     public AsyncShardSpecificAdminRequest(CollectionParams.CollectionAction action, String collection, String shard) {
/*  206 */       super();
/*  207 */       this.collection = collection;
/*  208 */       this.shard = shard;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public abstract AsyncShardSpecificAdminRequest setCollectionName(String paramString);
/*      */     
/*      */     @Deprecated
/*      */     public abstract AsyncShardSpecificAdminRequest setShardName(String paramString);
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  219 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  220 */       if (this.collection == null)
/*  221 */         throw new IllegalArgumentException("You must call setCollectionName() on this request");
/*  222 */       if (this.shard == null)
/*  223 */         throw new IllegalArgumentException("You must call setShardName() on this request");
/*  224 */       params.set("collection", new String[] { this.collection });
/*  225 */       params.set("shard", new String[] { this.shard });
/*  226 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class ShardSpecificAdminRequest extends CollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     protected String shard;
/*      */     
/*      */     public ShardSpecificAdminRequest(CollectionParams.CollectionAction action, String collection, String shard) {
/*  236 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public abstract ShardSpecificAdminRequest setCollectionName(String paramString);
/*      */     
/*      */     @Deprecated
/*      */     public abstract ShardSpecificAdminRequest setShardName(String paramString);
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  247 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  248 */       if (this.collection == null)
/*  249 */         throw new IllegalArgumentException("You must call setCollectionName() on this request");
/*  250 */       if (this.shard == null)
/*  251 */         throw new IllegalArgumentException("You must call setShardName() on this request");
/*  252 */       params.set("collection", new String[] { this.collection });
/*  253 */       params.set("shard", new String[] { this.shard });
/*  254 */       return params;
/*      */     }
/*      */     
/*      */     protected SolrResponse createResponse(SolrClient client)
/*      */     {
/*  259 */       return new CollectionAdminResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static abstract class CollectionAdminRoleRequest
/*      */     extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String node;
/*      */     
/*      */     protected String role;
/*      */     
/*      */ 
/*      */     public CollectionAdminRoleRequest(CollectionParams.CollectionAction action, String node, String role)
/*      */     {
/*  274 */       super();
/*      */     }
/*      */     
/*      */     public CollectionAdminRoleRequest setAsyncId(String id)
/*      */     {
/*  279 */       this.asyncId = id;
/*  280 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public abstract CollectionAdminRoleRequest setNode(String paramString);
/*      */     
/*      */     public String getNode() {
/*  287 */       return this.node;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public abstract CollectionAdminRoleRequest setRole(String paramString);
/*      */     
/*      */     public String getRole() {
/*  294 */       return this.role;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  299 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  300 */       params.set("role", new String[] { this.role });
/*  301 */       params.set("node", new String[] { this.node });
/*  302 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Create createCollection(String collection, String config, int numShards, int numReplicas)
/*      */   {
/*  317 */     return new Create(collection, config, numShards, numReplicas, null);
/*      */   }
/*      */   
/*      */   public static class Create
/*      */     extends CollectionAdminRequest.AsyncCollectionSpecificAdminRequest
/*      */   {
/*  323 */     protected String configName = null;
/*  324 */     protected String createNodeSet = null;
/*      */     
/*      */     protected String routerName;
/*      */     
/*      */     protected String shards;
/*      */     protected String routerField;
/*      */     protected Integer numShards;
/*      */     protected Integer maxShardsPerNode;
/*      */     protected Integer replicationFactor;
/*      */     private Properties properties;
/*      */     protected Boolean autoAddReplicas;
/*      */     protected Integer stateFormat;
/*      */     private String[] rule;
/*      */     private String[] snitch;
/*      */     
/*      */     @Deprecated
/*      */     public Create()
/*      */     {
/*  342 */       super(null);
/*      */     }
/*      */     
/*      */     private Create(String collection, String config, int numShards, int numReplicas) {
/*  346 */       super(SolrIdentifierValidator.validateCollectionName(collection));
/*  347 */       this.configName = config;
/*  348 */       this.numShards = Integer.valueOf(numShards);
/*  349 */       this.replicationFactor = Integer.valueOf(numReplicas);
/*      */     }
/*      */     
/*      */     @Deprecated
/*  353 */     public Create setConfigName(String config) { this.configName = config;return this; }
/*  354 */     public Create setCreateNodeSet(String nodeSet) { this.createNodeSet = nodeSet;return this; }
/*  355 */     public Create setRouterName(String routerName) { this.routerName = routerName;return this; }
/*  356 */     public Create setRouterField(String routerField) { this.routerField = routerField;return this; }
/*      */     @Deprecated
/*  358 */     public Create setNumShards(Integer numShards) { this.numShards = numShards;return this; }
/*  359 */     public Create setMaxShardsPerNode(Integer numShards) { this.maxShardsPerNode = numShards;return this; }
/*  360 */     public Create setAutoAddReplicas(boolean autoAddReplicas) { this.autoAddReplicas = Boolean.valueOf(autoAddReplicas);return this; }
/*      */     @Deprecated
/*  362 */     public Create setReplicationFactor(Integer repl) { this.replicationFactor = repl;return this; }
/*  363 */     public Create setStateFormat(Integer stateFormat) { this.stateFormat = stateFormat;return this; }
/*  364 */     public Create setRule(String... s) { this.rule = s;return this; }
/*  365 */     public Create setSnitch(String... s) { this.snitch = s;return this; }
/*      */     
/*  367 */     public String getConfigName() { return this.configName; }
/*  368 */     public String getCreateNodeSet() { return this.createNodeSet; }
/*  369 */     public String getRouterName() { return this.routerName; }
/*  370 */     public String getShards() { return this.shards; }
/*  371 */     public Integer getNumShards() { return this.numShards; }
/*  372 */     public Integer getMaxShardsPerNode() { return this.maxShardsPerNode; }
/*  373 */     public Integer getReplicationFactor() { return this.replicationFactor; }
/*  374 */     public Boolean getAutoAddReplicas() { return this.autoAddReplicas; }
/*  375 */     public Integer getStateFormat() { return this.stateFormat; }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Create setShards(String shards)
/*      */     {
/*  385 */       for (String shard : shards.split(",")) {
/*  386 */         SolrIdentifierValidator.validateShardName(shard);
/*      */       }
/*  388 */       this.shards = shards;
/*  389 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public Create setCollectionName(String collectionName)
/*      */       throws SolrException
/*      */     {
/*  401 */       this.collection = SolrIdentifierValidator.validateCollectionName(collectionName);
/*  402 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Create setAsyncId(String id)
/*      */     {
/*  408 */       this.asyncId = id;
/*  409 */       return this;
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/*  413 */       return this.properties;
/*      */     }
/*      */     
/*      */     public Create setProperties(Properties properties) {
/*  417 */       this.properties = properties;
/*  418 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  423 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*      */       
/*  425 */       params.set("collection.configName", new String[] { this.configName });
/*  426 */       params.set("createNodeSet", new String[] { this.createNodeSet });
/*  427 */       if (this.numShards != null) {
/*  428 */         params.set("numShards", this.numShards.intValue());
/*      */       }
/*  430 */       if (this.maxShardsPerNode != null) {
/*  431 */         params.set("maxShardsPerNode", this.maxShardsPerNode.intValue());
/*      */       }
/*  433 */       params.set("router.name", new String[] { this.routerName });
/*  434 */       params.set("shards", new String[] { this.shards });
/*  435 */       if (this.routerField != null) {
/*  436 */         params.set("router.field", new String[] { this.routerField });
/*      */       }
/*  438 */       if (this.replicationFactor != null) {
/*  439 */         params.set("replicationFactor", this.replicationFactor.intValue());
/*      */       }
/*  441 */       if (this.autoAddReplicas != null) {
/*  442 */         params.set("autoAddReplicas", this.autoAddReplicas.booleanValue());
/*      */       }
/*  444 */       if (this.properties != null) {
/*  445 */         addProperties(params, this.properties);
/*      */       }
/*  447 */       if (this.stateFormat != null) {
/*  448 */         params.set("stateFormat", this.stateFormat.intValue());
/*      */       }
/*  450 */       if (this.rule != null) params.set("rule", this.rule);
/*  451 */       if (this.snitch != null) params.set("snitch", this.snitch);
/*  452 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Reload reloadCollection(String collection)
/*      */   {
/*  461 */     return new Reload(collection, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class Reload
/*      */     extends CollectionAdminRequest.AsyncCollectionSpecificAdminRequest
/*      */   {
/*      */     @Deprecated
/*      */     public Reload()
/*      */     {
/*  472 */       super(null);
/*      */     }
/*      */     
/*      */     private Reload(String collection) {
/*  476 */       super(collection);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Reload setCollectionName(String collection)
/*      */     {
/*  482 */       this.collection = collection;
/*  483 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Reload setAsyncId(String id)
/*      */     {
/*  489 */       this.asyncId = id;
/*  490 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class DeleteNode
/*      */     extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     String node;
/*      */     
/*      */     public DeleteNode(String node)
/*      */     {
/*  501 */       super();
/*  502 */       this.node = node;
/*      */     }
/*      */     
/*      */     public SolrParams getParams() {
/*  506 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*  507 */       params.set("node", new String[] { this.node });
/*  508 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static class ReplaceNode
/*      */     extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     String source;
/*      */     
/*      */     String target;
/*      */     Boolean parallel;
/*      */     
/*      */     public ReplaceNode(String source, String target)
/*      */     {
/*  523 */       super();
/*  524 */       this.source = source;
/*  525 */       this.target = target;
/*      */     }
/*      */     
/*      */     public ReplaceNode setParallel(Boolean flag) {
/*  529 */       this.parallel = flag;
/*  530 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  535 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*  536 */       params.set("source", new String[] { this.source });
/*  537 */       params.set("target", new String[] { this.target });
/*  538 */       if (this.parallel != null) params.set("parallel", new String[] { this.parallel.toString() });
/*  539 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static RebalanceLeaders rebalanceLeaders(String collection)
/*      */   {
/*  548 */     return new RebalanceLeaders(collection);
/*      */   }
/*      */   
/*      */   public static class RebalanceLeaders extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected Integer maxAtOnce;
/*      */     protected Integer maxWaitSeconds;
/*      */     protected String collection;
/*      */     
/*      */     public RebalanceLeaders setMaxAtOnce(Integer maxAtOnce) {
/*  558 */       this.maxAtOnce = maxAtOnce;
/*  559 */       return this;
/*      */     }
/*      */     
/*      */     public RebalanceLeaders setMaxWaitSeconds(Integer maxWaitSeconds) {
/*  563 */       this.maxWaitSeconds = maxWaitSeconds;
/*  564 */       return this;
/*      */     }
/*      */     
/*      */     public Integer getMaxAtOnce() {
/*  568 */       return this.maxAtOnce;
/*      */     }
/*      */     
/*      */     public Integer getMaxWaitSeconds() {
/*  572 */       return this.maxWaitSeconds;
/*      */     }
/*      */     
/*      */     public RebalanceLeaders(String collection) {
/*  576 */       super();
/*  577 */       this.collection = collection;
/*      */     }
/*      */     
/*      */     public RebalanceLeaders setAsyncId(String id)
/*      */     {
/*  582 */       this.asyncId = id;
/*  583 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  588 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*      */       
/*  590 */       params.set("collection", new String[] { this.collection });
/*      */       
/*  592 */       if (this.maxWaitSeconds != null) {
/*  593 */         params.set("maxWaitSeconds", this.maxWaitSeconds.intValue());
/*      */       }
/*      */       
/*  596 */       if (this.maxAtOnce != null) {
/*  597 */         params.set("maxAtOnce", this.maxAtOnce.intValue());
/*      */       }
/*      */       
/*  600 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Delete deleteCollection(String collection)
/*      */   {
/*  609 */     return new Delete(collection, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class Delete
/*      */     extends CollectionAdminRequest.AsyncCollectionSpecificAdminRequest
/*      */   {
/*      */     @Deprecated
/*      */     public Delete()
/*      */     {
/*  620 */       super(null);
/*      */     }
/*      */     
/*      */     private Delete(String collection) {
/*  624 */       super(collection);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Delete setCollectionName(String collection)
/*      */     {
/*  630 */       this.collection = collection;
/*  631 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Delete setAsyncId(String id)
/*      */     {
/*  637 */       this.asyncId = id;
/*  638 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public static Backup backupCollection(String collection, String backupName) {
/*  643 */     return new Backup(collection, backupName);
/*      */   }
/*      */   
/*      */   public static class Backup extends CollectionAdminRequest.AsyncCollectionSpecificAdminRequest
/*      */   {
/*      */     protected final String name;
/*      */     protected Optional<String> repositoryName;
/*      */     protected String location;
/*      */     
/*      */     public Backup(String collection, String name) {
/*  653 */       super(collection);
/*  654 */       this.name = name;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Backup setAsyncId(String id)
/*      */     {
/*  660 */       this.asyncId = id;
/*  661 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Backup setCollectionName(String collection)
/*      */     {
/*  667 */       this.collection = collection;
/*  668 */       return this;
/*      */     }
/*      */     
/*      */     public String getLocation() {
/*  672 */       return this.location;
/*      */     }
/*      */     
/*      */     public Backup setLocation(String location) {
/*  676 */       this.location = location;
/*  677 */       return this;
/*      */     }
/*      */     
/*      */     public Optional<String> getRepositoryName() {
/*  681 */       return this.repositoryName;
/*      */     }
/*      */     
/*      */     public Backup setRepositoryName(String repositoryName) {
/*  685 */       this.repositoryName = Optional.ofNullable(repositoryName);
/*  686 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  691 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*  692 */       params.set("collection", new String[] { this.collection });
/*  693 */       params.set("name", new String[] { this.name });
/*  694 */       params.set("location", new String[] { this.location });
/*  695 */       if (this.repositoryName.isPresent()) {
/*  696 */         params.set("repository", new String[] { (String)this.repositoryName.get() });
/*      */       }
/*  698 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */   public static Restore restoreCollection(String collection, String backupName)
/*      */   {
/*  704 */     return new Restore(collection, backupName);
/*      */   }
/*      */   
/*      */   public static class Restore
/*      */     extends CollectionAdminRequest.AsyncCollectionSpecificAdminRequest
/*      */   {
/*      */     protected final String backupName;
/*      */     protected Optional<String> repositoryName;
/*      */     protected String location;
/*      */     protected String configName;
/*      */     protected Integer maxShardsPerNode;
/*      */     protected Integer replicationFactor;
/*      */     protected Boolean autoAddReplicas;
/*      */     protected Properties properties;
/*      */     
/*      */     public Restore(String collection, String backupName)
/*      */     {
/*  721 */       super(collection);
/*  722 */       this.backupName = backupName;
/*      */     }
/*      */     
/*      */     public Restore setAsyncId(String id)
/*      */     {
/*  727 */       this.asyncId = id;
/*  728 */       return this;
/*      */     }
/*      */     
/*      */     public Restore setCollectionName(String collection)
/*      */     {
/*  733 */       this.collection = collection;
/*  734 */       return this;
/*      */     }
/*      */     
/*      */     public String getLocation() {
/*  738 */       return this.location;
/*      */     }
/*      */     
/*      */     public Restore setLocation(String location) {
/*  742 */       this.location = location;
/*  743 */       return this;
/*      */     }
/*      */     
/*      */     public Optional<String> getRepositoryName() {
/*  747 */       return this.repositoryName;
/*      */     }
/*      */     
/*      */     public Restore setRepositoryName(String repositoryName) {
/*  751 */       this.repositoryName = Optional.ofNullable(repositoryName);
/*  752 */       return this;
/*      */     }
/*      */     
/*      */     public Restore setConfigName(String config) {
/*  756 */       this.configName = config;return this; }
/*  757 */     public String getConfigName() { return this.configName; }
/*      */     
/*  759 */     public Integer getMaxShardsPerNode() { return this.maxShardsPerNode; }
/*  760 */     public Restore setMaxShardsPerNode(int maxShardsPerNode) { this.maxShardsPerNode = Integer.valueOf(maxShardsPerNode);return this; }
/*      */     
/*  762 */     public Integer getReplicationFactor() { return this.replicationFactor; }
/*  763 */     public Restore setReplicationFactor(Integer repl) { this.replicationFactor = repl;return this; }
/*      */     
/*  765 */     public Boolean getAutoAddReplicas() { return this.autoAddReplicas; }
/*  766 */     public Restore setAutoAddReplicas(boolean autoAddReplicas) { this.autoAddReplicas = Boolean.valueOf(autoAddReplicas);return this;
/*      */     }
/*      */     
/*  769 */     public Properties getProperties() { return this.properties; }
/*      */     
/*  771 */     public Restore setProperties(Properties properties) { this.properties = properties;return this;
/*      */     }
/*      */     
/*      */ 
/*      */     public SolrParams getParams()
/*      */     {
/*  777 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*  778 */       params.set("collection", new String[] { this.collection });
/*  779 */       params.set("name", new String[] { this.backupName });
/*  780 */       params.set("location", new String[] { this.location });
/*  781 */       params.set("collection.configName", new String[] { this.configName });
/*  782 */       if (this.maxShardsPerNode != null) {
/*  783 */         params.set("maxShardsPerNode", this.maxShardsPerNode.intValue());
/*      */       }
/*  785 */       if (this.replicationFactor != null) {
/*  786 */         params.set("replicationFactor", this.replicationFactor.intValue());
/*      */       }
/*  788 */       if (this.autoAddReplicas != null) {
/*  789 */         params.set("autoAddReplicas", this.autoAddReplicas.booleanValue());
/*      */       }
/*  791 */       if (this.properties != null) {
/*  792 */         addProperties(params, this.properties);
/*      */       }
/*  794 */       if (this.repositoryName.isPresent()) {
/*  795 */         params.set("repository", new String[] { (String)this.repositoryName.get() });
/*      */       }
/*      */       
/*  798 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static CreateShard createShard(String collection, String shard)
/*      */   {
/*  807 */     return new CreateShard(collection, shard, null);
/*      */   }
/*      */   
/*      */   public static class CreateShard extends CollectionAdminRequest.AsyncShardSpecificAdminRequest
/*      */   {
/*      */     protected String nodeSet;
/*      */     protected Properties properties;
/*      */     
/*      */     public CreateShard setNodeSet(String nodeSet)
/*      */     {
/*  817 */       this.nodeSet = nodeSet;
/*  818 */       return this;
/*      */     }
/*      */     
/*      */     public String getNodeSet() {
/*  822 */       return this.nodeSet;
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/*  826 */       return this.properties;
/*      */     }
/*      */     
/*      */     public CreateShard setProperties(Properties properties) {
/*  830 */       this.properties = properties;
/*  831 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public CreateShard()
/*      */     {
/*  839 */       super(null, null);
/*      */     }
/*      */     
/*      */     private CreateShard(String collection, String shard) {
/*  843 */       super(collection, SolrIdentifierValidator.validateShardName(shard));
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public CreateShard setCollectionName(String collection)
/*      */     {
/*  849 */       this.collection = collection;
/*  850 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public CreateShard setShardName(String shardName)
/*      */     {
/*  863 */       this.shard = SolrIdentifierValidator.validateShardName(shardName);
/*  864 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public CreateShard setAsyncId(String id)
/*      */     {
/*  870 */       this.asyncId = id;
/*  871 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  876 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*  877 */       if (this.nodeSet != null) {
/*  878 */         params.set("createNodeSet", new String[] { this.nodeSet });
/*      */       }
/*  880 */       if (this.properties != null) {
/*  881 */         addProperties(params, this.properties);
/*      */       }
/*  883 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static SplitShard splitShard(String collection)
/*      */   {
/*  893 */     return new SplitShard(collection, null);
/*      */   }
/*      */   
/*      */   public static class SplitShard extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     protected String ranges;
/*      */     protected String splitKey;
/*      */     protected String shard;
/*      */     private Properties properties;
/*      */     
/*      */     private SplitShard(String collection)
/*      */     {
/*  906 */       super();
/*  907 */       this.collection = collection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*  915 */     public SplitShard() { super(); }
/*      */     
/*      */     public SplitShard setRanges(String ranges) {
/*  918 */       this.ranges = ranges;return this; }
/*  919 */     public String getRanges() { return this.ranges; }
/*      */     
/*      */     public SplitShard setSplitKey(String splitKey) {
/*  922 */       this.splitKey = splitKey;
/*  923 */       return this;
/*      */     }
/*      */     
/*      */     public String getSplitKey() {
/*  927 */       return this.splitKey;
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/*  931 */       return this.properties;
/*      */     }
/*      */     
/*      */     public SplitShard setProperties(Properties properties) {
/*  935 */       this.properties = properties;
/*  936 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public SplitShard setCollectionName(String collection) {
/*  941 */       this.collection = collection;
/*  942 */       return this;
/*      */     }
/*      */     
/*      */     public SplitShard setShardName(String shard) {
/*  946 */       this.shard = shard;
/*  947 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public SplitShard setAsyncId(String id)
/*      */     {
/*  953 */       this.asyncId = id;
/*  954 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/*  959 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/*      */       
/*  961 */       if (this.collection == null) {
/*  962 */         throw new IllegalArgumentException("You must set collection name for this request.");
/*      */       }
/*      */       
/*  965 */       params.set("collection", new String[] { this.collection });
/*      */       
/*  967 */       if ((this.shard == null) && (this.splitKey == null)) {
/*  968 */         throw new IllegalArgumentException("You must set shardname OR splitkey for this request.");
/*      */       }
/*      */       
/*  971 */       params.set("shard", new String[] { this.shard });
/*  972 */       params.set("split.key", new String[] { this.splitKey });
/*  973 */       params.set("ranges", new String[] { this.ranges });
/*      */       
/*  975 */       if (this.properties != null) {
/*  976 */         addProperties(params, this.properties);
/*      */       }
/*  978 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DeleteShard deleteShard(String collection, String shard)
/*      */   {
/*  987 */     return new DeleteShard(collection, shard, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class DeleteShard
/*      */     extends CollectionAdminRequest.AsyncShardSpecificAdminRequest
/*      */   {
/*      */     private Boolean deleteInstanceDir;
/*      */     
/*      */     private Boolean deleteDataDir;
/*      */     
/*      */     @Deprecated
/*      */     public DeleteShard()
/*      */     {
/* 1001 */       super(null, null);
/*      */     }
/*      */     
/*      */     private DeleteShard(String collection, String shard) {
/* 1005 */       super(collection, shard);
/*      */     }
/*      */     
/*      */     public Boolean getDeleteInstanceDir() {
/* 1009 */       return this.deleteInstanceDir;
/*      */     }
/*      */     
/*      */     public DeleteShard setDeleteInstanceDir(Boolean deleteInstanceDir) {
/* 1013 */       this.deleteInstanceDir = deleteInstanceDir;
/* 1014 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getDeleteDataDir() {
/* 1018 */       return this.deleteDataDir;
/*      */     }
/*      */     
/*      */     public DeleteShard setDeleteDataDir(Boolean deleteDataDir) {
/* 1022 */       this.deleteDataDir = deleteDataDir;
/* 1023 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteShard setCollectionName(String collection)
/*      */     {
/* 1029 */       this.collection = collection;
/* 1030 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteShard setShardName(String shard)
/*      */     {
/* 1036 */       this.shard = shard;
/* 1037 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteShard setAsyncId(String id)
/*      */     {
/* 1043 */       this.asyncId = id;
/* 1044 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1049 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1050 */       if (this.deleteInstanceDir != null) {
/* 1051 */         params.set("deleteInstanceDir", this.deleteInstanceDir.booleanValue());
/*      */       }
/* 1053 */       if (this.deleteDataDir != null) {
/* 1054 */         params.set("deleteDataDir", this.deleteDataDir.booleanValue());
/*      */       }
/* 1056 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ForceLeader forceLeaderElection(String collection, String shard)
/*      */   {
/* 1068 */     return new ForceLeader(collection, shard, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class ForceLeader
/*      */     extends CollectionAdminRequest.ShardSpecificAdminRequest
/*      */   {
/*      */     @Deprecated
/*      */     public ForceLeader()
/*      */     {
/* 1079 */       super(null, null);
/*      */     }
/*      */     
/*      */     private ForceLeader(String collection, String shard) {
/* 1083 */       super(collection, shard);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public ForceLeader setCollectionName(String collection)
/*      */     {
/* 1089 */       this.collection = collection;
/* 1090 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public ForceLeader setShardName(String shard)
/*      */     {
/* 1096 */       this.shard = shard;
/* 1097 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class RequestStatusResponse
/*      */     extends CollectionAdminResponse
/*      */   {
/*      */     public RequestStatusState getRequestStatus()
/*      */     {
/* 1108 */       NamedList innerResponse = (NamedList)getResponse().get("status");
/* 1109 */       return RequestStatusState.fromKey((String)innerResponse.get("state"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static RequestStatus requestStatus(String requestId)
/*      */   {
/* 1120 */     return new RequestStatus(requestId, null);
/*      */   }
/*      */   
/*      */   public static void waitForAsyncRequest(String requestId, SolrClient client, long timeout) throws SolrServerException, InterruptedException, IOException {
/* 1124 */     requestStatus(requestId).waitFor(client, timeout);
/*      */   }
/*      */   
/*      */   public static class RequestStatus
/*      */     extends CollectionAdminRequest<CollectionAdminRequest.RequestStatusResponse>
/*      */   {
/* 1130 */     protected String requestId = null;
/*      */     
/*      */     private RequestStatus(String requestId) {
/* 1133 */       super();
/* 1134 */       this.requestId = requestId;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public RequestStatus()
/*      */     {
/* 1142 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public RequestStatus setRequestId(String requestId) {
/* 1147 */       this.requestId = requestId;
/* 1148 */       return this;
/*      */     }
/*      */     
/*      */     public String getRequestId() {
/* 1152 */       return this.requestId;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1157 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/* 1158 */       if (this.requestId == null)
/* 1159 */         throw new IllegalArgumentException("You must call setRequestId() on this request");
/* 1160 */       params.set("requestid", new String[] { this.requestId });
/* 1161 */       return params;
/*      */     }
/*      */     
/*      */     protected CollectionAdminRequest.RequestStatusResponse createResponse(SolrClient client)
/*      */     {
/* 1166 */       return new CollectionAdminRequest.RequestStatusResponse();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public RequestStatusState waitFor(SolrClient client, long timeoutSeconds)
/*      */       throws IOException, SolrServerException, InterruptedException
/*      */     {
/* 1177 */       long finishTime = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds);
/* 1178 */       RequestStatusState state = RequestStatusState.NOT_FOUND;
/* 1179 */       while (System.nanoTime() < finishTime) {
/* 1180 */         state = ((CollectionAdminRequest.RequestStatusResponse)process(client)).getRequestStatus();
/* 1181 */         if ((state == RequestStatusState.COMPLETED) || (state == RequestStatusState.FAILED)) {
/* 1182 */           deleteAsyncId(this.requestId).process(client);
/* 1183 */           return state;
/*      */         }
/* 1185 */         TimeUnit.SECONDS.sleep(1L);
/*      */       }
/* 1187 */       return state;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static DeleteStatus deleteAsyncId(String requestId)
/*      */   {
/* 1195 */     return new DeleteStatus(requestId, null);
/*      */   }
/*      */   
/*      */   public static DeleteStatus deleteAllAsyncIds() {
/* 1199 */     return new DeleteStatus().setFlush(Boolean.valueOf(true));
/*      */   }
/*      */   
/*      */   public static class DeleteStatus
/*      */     extends CollectionAdminRequest<CollectionAdminResponse>
/*      */   {
/* 1205 */     protected String requestId = null;
/* 1206 */     protected Boolean flush = null;
/*      */     
/*      */     private DeleteStatus(String requestId) {
/* 1209 */       super();
/* 1210 */       this.requestId = requestId;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public DeleteStatus()
/*      */     {
/* 1218 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteStatus setRequestId(String requestId) {
/* 1223 */       this.requestId = requestId;
/* 1224 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteStatus setFlush(Boolean flush) {
/* 1229 */       this.flush = flush;
/* 1230 */       return this;
/*      */     }
/*      */     
/*      */     public String getRequestId() {
/* 1234 */       return this.requestId;
/*      */     }
/*      */     
/*      */     public Boolean getFlush() {
/* 1238 */       return this.flush;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1243 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/* 1244 */       if ((this.requestId == null) && (this.flush == null))
/* 1245 */         throw new IllegalArgumentException("Either requestid or flush parameter must be specified.");
/* 1246 */       if ((this.requestId != null) && (this.flush != null))
/* 1247 */         throw new IllegalArgumentException("Both requestid and flush parameters can not be specified together.");
/* 1248 */       if (this.requestId != null)
/* 1249 */         params.set("requestid", new String[] { this.requestId });
/* 1250 */       if (this.flush != null)
/* 1251 */         params.set("flush", this.flush.booleanValue());
/* 1252 */       return params;
/*      */     }
/*      */     
/*      */     protected CollectionAdminResponse createResponse(SolrClient client)
/*      */     {
/* 1257 */       return new CollectionAdminResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static CreateAlias createAlias(String aliasName, String aliasedCollections)
/*      */   {
/* 1268 */     return new CreateAlias(aliasName, aliasedCollections, null);
/*      */   }
/*      */   
/*      */   public static class CreateAlias extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String aliasName;
/*      */     protected String aliasedCollections;
/*      */     
/*      */     private CreateAlias(String aliasName, String aliasedCollections)
/*      */     {
/* 1278 */       super();
/* 1279 */       this.aliasName = SolrIdentifierValidator.validateAliasName(aliasName);
/* 1280 */       this.aliasedCollections = aliasedCollections;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public CreateAlias()
/*      */     {
/* 1288 */       super();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public CreateAlias setAliasName(String aliasName)
/*      */     {
/* 1300 */       this.aliasName = SolrIdentifierValidator.validateAliasName(aliasName);
/* 1301 */       return this;
/*      */     }
/*      */     
/*      */     public String getAliasName() {
/* 1305 */       return this.aliasName;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public CreateAlias setAliasedCollections(String alias) {
/* 1310 */       this.aliasedCollections = alias;
/* 1311 */       return this;
/*      */     }
/*      */     
/*      */     public String getAliasedCollections() {
/* 1315 */       return this.aliasedCollections;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public CreateAlias setAsyncId(String id)
/*      */     {
/* 1321 */       this.asyncId = id;
/* 1322 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1327 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/* 1328 */       params.set("name", new String[] { this.aliasName });
/* 1329 */       params.set("collections", new String[] { this.aliasedCollections });
/* 1330 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DeleteAlias deleteAlias(String aliasName)
/*      */   {
/* 1339 */     return new DeleteAlias(aliasName, null);
/*      */   }
/*      */   
/*      */   public static class DeleteAlias extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String aliasName;
/*      */     
/*      */     private DeleteAlias(String aliasName)
/*      */     {
/* 1348 */       super();
/* 1349 */       this.aliasName = aliasName;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public DeleteAlias()
/*      */     {
/* 1357 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteAlias setAliasName(String aliasName) {
/* 1362 */       this.aliasName = aliasName;
/* 1363 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteAlias setAsyncId(String id)
/*      */     {
/* 1369 */       this.asyncId = id;
/* 1370 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1375 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1376 */       params.set("name", new String[] { this.aliasName });
/* 1377 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AddReplica addReplicaToShard(String collection, String shard)
/*      */   {
/* 1387 */     return new AddReplica(collection, shard, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static AddReplica addReplicaByRouteKey(String collection, String routeKey)
/*      */   {
/* 1394 */     return new AddReplica(collection, null, routeKey, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class AddReplica
/*      */     extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     
/*      */     protected String shard;
/*      */     protected String node;
/*      */     protected String routeKey;
/*      */     protected String instanceDir;
/*      */     protected String dataDir;
/*      */     protected Properties properties;
/*      */     
/*      */     @Deprecated
/*      */     public AddReplica()
/*      */     {
/* 1413 */       super();
/*      */     }
/*      */     
/*      */     private AddReplica(String collection, String shard, String routeKey) {
/* 1417 */       super();
/* 1418 */       this.collection = collection;
/* 1419 */       this.shard = shard;
/* 1420 */       this.routeKey = routeKey;
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/* 1424 */       return this.properties;
/*      */     }
/*      */     
/*      */     public AddReplica setProperties(Properties properties) {
/* 1428 */       this.properties = properties;
/* 1429 */       return this;
/*      */     }
/*      */     
/*      */     public String getNode() {
/* 1433 */       return this.node;
/*      */     }
/*      */     
/*      */     public AddReplica setNode(String node) {
/* 1437 */       this.node = node;
/* 1438 */       return this;
/*      */     }
/*      */     
/*      */     public String getRouteKey() {
/* 1442 */       return this.routeKey;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplica setRouteKey(String routeKey) {
/* 1447 */       this.routeKey = routeKey;
/* 1448 */       return this;
/*      */     }
/*      */     
/*      */     public String getInstanceDir() {
/* 1452 */       return this.instanceDir;
/*      */     }
/*      */     
/*      */     public AddReplica setInstanceDir(String instanceDir) {
/* 1456 */       this.instanceDir = instanceDir;
/* 1457 */       return this;
/*      */     }
/*      */     
/*      */     public String getDataDir() {
/* 1461 */       return this.dataDir;
/*      */     }
/*      */     
/*      */     public AddReplica setDataDir(String dataDir) {
/* 1465 */       this.dataDir = dataDir;
/* 1466 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplica setCollectionName(String collection) {
/* 1471 */       this.collection = collection;
/* 1472 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplica setShardName(String shard) {
/* 1477 */       this.shard = shard;
/* 1478 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplica setAsyncId(String id)
/*      */     {
/* 1484 */       this.asyncId = id;
/* 1485 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1490 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1491 */       if (this.collection == null)
/* 1492 */         throw new IllegalArgumentException("You must call setCollection() on this request");
/* 1493 */       params.add("collection", new String[] { this.collection });
/* 1494 */       if ((this.shard == null) || (this.shard.isEmpty())) {
/* 1495 */         if (this.routeKey == null) {
/* 1496 */           throw new IllegalArgumentException("Either shard or routeKey must be provided");
/*      */         }
/* 1498 */         params.add("_route_", new String[] { this.routeKey });
/*      */       }
/*      */       else {
/* 1501 */         params.add("shard", new String[] { this.shard });
/*      */       }
/* 1503 */       if (this.node != null) {
/* 1504 */         params.add("node", new String[] { this.node });
/*      */       }
/* 1506 */       if (this.instanceDir != null) {
/* 1507 */         params.add("instanceDir", new String[] { this.instanceDir });
/*      */       }
/* 1509 */       if (this.dataDir != null) {
/* 1510 */         params.add("dataDir", new String[] { this.dataDir });
/*      */       }
/* 1512 */       if (this.properties != null) {
/* 1513 */         addProperties(params, this.properties);
/*      */       }
/* 1515 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DeleteReplica deleteReplica(String collection, String shard, String replica)
/*      */   {
/* 1524 */     return new DeleteReplica(collection, shard, replica, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class DeleteReplica
/*      */     extends CollectionAdminRequest.AsyncShardSpecificAdminRequest
/*      */   {
/*      */     protected String replica;
/*      */     
/*      */     protected Boolean onlyIfDown;
/*      */     private Boolean deleteDataDir;
/*      */     private Boolean deleteInstanceDir;
/*      */     private Boolean deleteIndexDir;
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplica()
/*      */     {
/* 1541 */       super(null, null);
/*      */     }
/*      */     
/*      */     private DeleteReplica(String collection, String shard, String replica) {
/* 1545 */       super(collection, shard);
/* 1546 */       this.replica = replica;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplica setReplica(String replica) {
/* 1551 */       this.replica = replica;
/* 1552 */       return this;
/*      */     }
/*      */     
/*      */     public String getReplica() {
/* 1556 */       return this.replica;
/*      */     }
/*      */     
/*      */     public DeleteReplica setOnlyIfDown(boolean onlyIfDown) {
/* 1560 */       this.onlyIfDown = Boolean.valueOf(onlyIfDown);
/* 1561 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getOnlyIfDown() {
/* 1565 */       return this.onlyIfDown;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplica setCollectionName(String collection)
/*      */     {
/* 1571 */       this.collection = collection;
/* 1572 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplica setShardName(String shard)
/*      */     {
/* 1578 */       this.shard = shard;
/* 1579 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplica setAsyncId(String id)
/*      */     {
/* 1585 */       this.asyncId = id;
/* 1586 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1591 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1592 */       params.set("replica", new String[] { this.replica });
/*      */       
/* 1594 */       if (this.onlyIfDown != null) {
/* 1595 */         params.set("onlyIfDown", this.onlyIfDown.booleanValue());
/*      */       }
/* 1597 */       if (this.deleteDataDir != null) {
/* 1598 */         params.set("deleteDataDir", this.deleteDataDir.booleanValue());
/*      */       }
/* 1600 */       if (this.deleteInstanceDir != null) {
/* 1601 */         params.set("deleteInstanceDir", this.deleteInstanceDir.booleanValue());
/*      */       }
/* 1603 */       if (this.deleteIndexDir != null) {
/* 1604 */         params.set("deleteIndex", this.deleteIndexDir.booleanValue());
/*      */       }
/* 1606 */       return params;
/*      */     }
/*      */     
/*      */     public Boolean getDeleteDataDir() {
/* 1610 */       return this.deleteDataDir;
/*      */     }
/*      */     
/*      */     public DeleteReplica setDeleteDataDir(Boolean deleteDataDir) {
/* 1614 */       this.deleteDataDir = deleteDataDir;
/* 1615 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getDeleteInstanceDir() {
/* 1619 */       return this.deleteInstanceDir;
/*      */     }
/*      */     
/*      */     public DeleteReplica setDeleteInstanceDir(Boolean deleteInstanceDir) {
/* 1623 */       this.deleteInstanceDir = deleteInstanceDir;
/* 1624 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static ClusterProp setClusterProperty(String propertyName, String propertyValue)
/*      */   {
/* 1632 */     return new ClusterProp(propertyName, propertyValue, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class ClusterProp
/*      */     extends CollectionAdminRequest<CollectionAdminResponse>
/*      */   {
/*      */     private String propertyName;
/*      */     
/*      */     private String propertyValue;
/*      */     
/*      */     @Deprecated
/*      */     public ClusterProp()
/*      */     {
/* 1646 */       super();
/*      */     }
/*      */     
/*      */     private ClusterProp(String propertyName, String propertyValue) {
/* 1650 */       super();
/* 1651 */       this.propertyName = propertyName;
/* 1652 */       this.propertyValue = propertyValue;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public ClusterProp setPropertyName(String propertyName) {
/* 1657 */       this.propertyName = propertyName;
/* 1658 */       return this;
/*      */     }
/*      */     
/*      */     public String getPropertyName() {
/* 1662 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public ClusterProp setPropertyValue(String propertyValue) {
/* 1667 */       this.propertyValue = propertyValue;
/* 1668 */       return this;
/*      */     }
/*      */     
/*      */     public String getPropertyValue() {
/* 1672 */       return this.propertyValue;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1677 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1678 */       params.add("name", new String[] { this.propertyName });
/* 1679 */       params.add("val", new String[] { this.propertyValue });
/*      */       
/* 1681 */       return params;
/*      */     }
/*      */     
/*      */     protected CollectionAdminResponse createResponse(SolrClient client)
/*      */     {
/* 1686 */       return new CollectionAdminResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Migrate migrateData(String collection, String targetCollection, String splitKey)
/*      */   {
/* 1696 */     return new Migrate(collection, targetCollection, splitKey, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class Migrate
/*      */     extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     private String collection;
/*      */     
/*      */     private String targetCollection;
/*      */     private String splitKey;
/*      */     private Integer forwardTimeout;
/*      */     private Properties properties;
/*      */     
/*      */     @Deprecated
/*      */     public Migrate()
/*      */     {
/* 1713 */       super();
/*      */     }
/*      */     
/*      */     private Migrate(String collection, String targetCollection, String splitKey) {
/* 1717 */       super();
/* 1718 */       this.collection = collection;
/* 1719 */       this.targetCollection = targetCollection;
/* 1720 */       this.splitKey = splitKey;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Migrate setCollectionName(String collection) {
/* 1725 */       this.collection = collection;
/* 1726 */       return this;
/*      */     }
/*      */     
/*      */     public String getCollectionName() {
/* 1730 */       return this.collection;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Migrate setTargetCollection(String targetCollection) {
/* 1735 */       this.targetCollection = targetCollection;
/* 1736 */       return this;
/*      */     }
/*      */     
/*      */     public String getTargetCollection() {
/* 1740 */       return this.targetCollection;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Migrate setSplitKey(String splitKey) {
/* 1745 */       this.splitKey = splitKey;
/* 1746 */       return this;
/*      */     }
/*      */     
/*      */     public String getSplitKey() {
/* 1750 */       return this.splitKey;
/*      */     }
/*      */     
/*      */     public Migrate setForwardTimeout(int forwardTimeout) {
/* 1754 */       this.forwardTimeout = Integer.valueOf(forwardTimeout);
/* 1755 */       return this;
/*      */     }
/*      */     
/*      */     public Integer getForwardTimeout() {
/* 1759 */       return this.forwardTimeout;
/*      */     }
/*      */     
/*      */     public Migrate setProperties(Properties properties) {
/* 1763 */       this.properties = properties;
/* 1764 */       return this;
/*      */     }
/*      */     
/*      */     public Properties getProperties() {
/* 1768 */       return this.properties;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Migrate setAsyncId(String id)
/*      */     {
/* 1774 */       this.asyncId = id;
/* 1775 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1780 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 1781 */       params.set("collection", new String[] { this.collection });
/* 1782 */       params.set("target.collection", new String[] { this.targetCollection });
/* 1783 */       params.set("split.key", new String[] { this.splitKey });
/* 1784 */       if (this.forwardTimeout != null) {
/* 1785 */         params.set("forward.timeout", this.forwardTimeout.intValue());
/*      */       }
/* 1787 */       if (this.properties != null) {
/* 1788 */         addProperties(params, this.properties);
/*      */       }
/*      */       
/* 1791 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AddRole addRole(String node, String role)
/*      */   {
/* 1801 */     return new AddRole(node, role, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class AddRole
/*      */     extends CollectionAdminRequest.CollectionAdminRoleRequest
/*      */   {
/*      */     @Deprecated
/*      */     public AddRole()
/*      */     {
/* 1812 */       super(null, null);
/*      */     }
/*      */     
/*      */     private AddRole(String node, String role) {
/* 1816 */       super(node, role);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddRole setNode(String node)
/*      */     {
/* 1822 */       this.node = node;
/* 1823 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddRole setRole(String role)
/*      */     {
/* 1829 */       this.role = role;
/* 1830 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static RemoveRole removeRole(String node, String role)
/*      */   {
/* 1838 */     return new RemoveRole(node, role, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class RemoveRole
/*      */     extends CollectionAdminRequest.CollectionAdminRoleRequest
/*      */   {
/*      */     @Deprecated
/*      */     public RemoveRole()
/*      */     {
/* 1849 */       super(null, null);
/*      */     }
/*      */     
/*      */     private RemoveRole(String node, String role) {
/* 1853 */       super(node, role);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public RemoveRole setNode(String node)
/*      */     {
/* 1859 */       this.node = node;
/* 1860 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public RemoveRole setRole(String role)
/*      */     {
/* 1866 */       this.role = role;
/* 1867 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static OverseerStatus getOverseerStatus()
/*      */   {
/* 1875 */     return new OverseerStatus();
/*      */   }
/*      */   
/*      */   public static class OverseerStatus extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     public OverseerStatus()
/*      */     {
/* 1882 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public OverseerStatus setAsyncId(String id)
/*      */     {
/* 1888 */       this.asyncId = id;
/* 1889 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static ClusterStatus getClusterStatus()
/*      */   {
/* 1897 */     return new ClusterStatus();
/*      */   }
/*      */   
/*      */   public static class ClusterStatus
/*      */     extends CollectionAdminRequest<CollectionAdminResponse>
/*      */   {
/* 1903 */     protected String shardName = null;
/* 1904 */     protected String collection = null;
/* 1905 */     protected String routeKey = null;
/*      */     
/*      */     public ClusterStatus() {
/* 1908 */       super();
/*      */     }
/*      */     
/*      */     public ClusterStatus setCollectionName(String collectionName) {
/* 1912 */       this.collection = collectionName;
/* 1913 */       return this;
/*      */     }
/*      */     
/*      */     public String getCollectionName() {
/* 1917 */       return this.collection;
/*      */     }
/*      */     
/*      */     public ClusterStatus setShardName(String shard) {
/* 1921 */       this.shardName = shard;
/* 1922 */       return this;
/*      */     }
/*      */     
/*      */     public String getShardName() {
/* 1926 */       return this.shardName;
/*      */     }
/*      */     
/*      */     public String getRouteKey() {
/* 1930 */       return this.routeKey;
/*      */     }
/*      */     
/*      */     public ClusterStatus setRouteKey(String routeKey) {
/* 1934 */       this.routeKey = routeKey;
/* 1935 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 1940 */       ModifiableSolrParams params = (ModifiableSolrParams)super.getParams();
/* 1941 */       if (this.collection != null) {
/* 1942 */         params.set("collection", new String[] { this.collection });
/*      */       }
/* 1944 */       if (this.shardName != null) {
/* 1945 */         params.set("shard", new String[] { this.shardName });
/*      */       }
/* 1947 */       if (this.routeKey != null) {
/* 1948 */         params.set("_route_", new String[] { this.routeKey });
/*      */       }
/* 1950 */       return params;
/*      */     }
/*      */     
/*      */     protected CollectionAdminResponse createResponse(SolrClient client)
/*      */     {
/* 1955 */       return new CollectionAdminResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List listCollections()
/*      */   {
/* 1964 */     return new List();
/*      */   }
/*      */   
/*      */   public static class List extends CollectionAdminRequest<CollectionAdminResponse>
/*      */   {
/*      */     public List() {
/* 1970 */       super();
/*      */     }
/*      */     
/*      */     protected CollectionAdminResponse createResponse(SolrClient client)
/*      */     {
/* 1975 */       return new CollectionAdminResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static AddReplicaProp addReplicaProperty(String collection, String shard, String replica, String propertyName, String propertyValue)
/*      */   {
/* 1984 */     return new AddReplicaProp(collection, shard, replica, propertyName, propertyValue, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class AddReplicaProp
/*      */     extends CollectionAdminRequest.AsyncShardSpecificAdminRequest
/*      */   {
/*      */     private String replica;
/*      */     
/*      */     private String propertyName;
/*      */     private String propertyValue;
/*      */     private Boolean shardUnique;
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp()
/*      */     {
/* 2000 */       super(null, null);
/*      */     }
/*      */     
/*      */     private AddReplicaProp(String collection, String shard, String replica, String propertyName, String propertyValue) {
/* 2004 */       super(collection, shard);
/* 2005 */       this.replica = replica;
/* 2006 */       this.propertyName = propertyName;
/* 2007 */       this.propertyValue = propertyValue;
/*      */     }
/*      */     
/*      */     public String getReplica() {
/* 2011 */       return this.replica;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setReplica(String replica) {
/* 2016 */       this.replica = replica;
/* 2017 */       return this;
/*      */     }
/*      */     
/*      */     public String getPropertyName() {
/* 2021 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setPropertyName(String propertyName) {
/* 2026 */       this.propertyName = propertyName;
/* 2027 */       return this;
/*      */     }
/*      */     
/*      */     public String getPropertyValue() {
/* 2031 */       return this.propertyValue;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setPropertyValue(String propertyValue) {
/* 2036 */       this.propertyValue = propertyValue;
/* 2037 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getShardUnique() {
/* 2041 */       return this.shardUnique;
/*      */     }
/*      */     
/*      */     public AddReplicaProp setShardUnique(Boolean shardUnique) {
/* 2045 */       this.shardUnique = shardUnique;
/* 2046 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setCollectionName(String collection)
/*      */     {
/* 2052 */       this.collection = collection;
/* 2053 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setShardName(String shard)
/*      */     {
/* 2059 */       this.shard = shard;
/* 2060 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public AddReplicaProp setAsyncId(String id)
/*      */     {
/* 2066 */       this.asyncId = id;
/* 2067 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 2072 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 2073 */       params.set("replica", new String[] { this.replica });
/* 2074 */       params.set("property", new String[] { this.propertyName });
/* 2075 */       params.set("property.value", new String[] { this.propertyValue });
/*      */       
/* 2077 */       if (this.shardUnique != null) {
/* 2078 */         params.set("shardUnique", this.shardUnique.booleanValue());
/*      */       }
/*      */       
/* 2081 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DeleteReplicaProp deleteReplicaProperty(String collection, String shard, String replica, String propertyName)
/*      */   {
/* 2091 */     return new DeleteReplicaProp(collection, shard, replica, propertyName, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public static class DeleteReplicaProp
/*      */     extends CollectionAdminRequest.AsyncShardSpecificAdminRequest
/*      */   {
/*      */     private String replica;
/*      */     
/*      */     private String propertyName;
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp()
/*      */     {
/* 2105 */       super(null, null);
/*      */     }
/*      */     
/*      */     private DeleteReplicaProp(String collection, String shard, String replica, String propertyName) {
/* 2109 */       super(collection, shard);
/* 2110 */       this.replica = replica;
/* 2111 */       this.propertyName = propertyName;
/*      */     }
/*      */     
/*      */     public String getReplica() {
/* 2115 */       return this.replica;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp setReplica(String replica) {
/* 2120 */       this.replica = replica;
/* 2121 */       return this;
/*      */     }
/*      */     
/*      */     public String getPropertyName() {
/* 2125 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp setPropertyName(String propertyName) {
/* 2130 */       this.propertyName = propertyName;
/* 2131 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp setCollectionName(String collection)
/*      */     {
/* 2137 */       this.collection = collection;
/* 2138 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp setShardName(String shard)
/*      */     {
/* 2144 */       this.shard = shard;
/* 2145 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public DeleteReplicaProp setAsyncId(String id)
/*      */     {
/* 2151 */       this.asyncId = id;
/* 2152 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 2157 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 2158 */       params.set("replica", new String[] { this.replica });
/* 2159 */       params.set("property", new String[] { this.propertyName });
/* 2160 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static MigrateClusterState migrateCollectionFormat(String collection)
/*      */   {
/* 2172 */     return new MigrateClusterState(collection, null);
/*      */   }
/*      */   
/*      */   public static class MigrateClusterState extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     
/*      */     private MigrateClusterState(String collection)
/*      */     {
/* 2181 */       super();
/* 2182 */       this.collection = collection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public MigrateClusterState()
/*      */     {
/* 2190 */       super();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public MigrateClusterState setCollectionName(String collection) {
/* 2195 */       this.collection = collection;
/* 2196 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public MigrateClusterState setAsyncId(String id)
/*      */     {
/* 2202 */       this.asyncId = id;
/* 2203 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 2208 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 2209 */       if (this.collection == null)
/* 2210 */         throw new IllegalArgumentException("You must call setCollection() on this request");
/* 2211 */       params.set("collection", new String[] { this.collection });
/* 2212 */       return params;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static BalanceShardUnique balanceReplicaProperty(String collection, String propertyName)
/*      */   {
/* 2220 */     return new BalanceShardUnique(collection, propertyName, null);
/*      */   }
/*      */   
/*      */   public static class BalanceShardUnique extends CollectionAdminRequest.AsyncCollectionAdminRequest
/*      */   {
/*      */     protected String collection;
/*      */     protected String propertyName;
/*      */     protected Boolean onlyActiveNodes;
/*      */     protected Boolean shardUnique;
/*      */     
/*      */     private BalanceShardUnique(String collection, String propertyName)
/*      */     {
/* 2232 */       super();
/* 2233 */       this.collection = collection;
/* 2234 */       this.propertyName = propertyName;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public BalanceShardUnique()
/*      */     {
/* 2242 */       super();
/*      */     }
/*      */     
/*      */     public String getPropertyName() {
/* 2246 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public BalanceShardUnique setPropertyName(String propertyName) {
/* 2251 */       this.propertyName = propertyName;
/* 2252 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getOnlyActiveNodes() {
/* 2256 */       return this.onlyActiveNodes;
/*      */     }
/*      */     
/*      */     public BalanceShardUnique setOnlyActiveNodes(Boolean onlyActiveNodes) {
/* 2260 */       this.onlyActiveNodes = onlyActiveNodes;
/* 2261 */       return this;
/*      */     }
/*      */     
/*      */     public Boolean getShardUnique() {
/* 2265 */       return this.shardUnique;
/*      */     }
/*      */     
/*      */     public BalanceShardUnique setShardUnique(Boolean shardUnique) {
/* 2269 */       this.shardUnique = shardUnique;
/* 2270 */       return this;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public BalanceShardUnique setCollection(String collection) {
/* 2275 */       this.collection = collection;
/* 2276 */       return this;
/*      */     }
/*      */     
/*      */     public String getCollection() {
/* 2280 */       return this.collection;
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public BalanceShardUnique setAsyncId(String id)
/*      */     {
/* 2286 */       this.asyncId = id;
/* 2287 */       return this;
/*      */     }
/*      */     
/*      */     public SolrParams getParams()
/*      */     {
/* 2292 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 2293 */       params.set("collection", new String[] { this.collection });
/* 2294 */       params.set("property", new String[] { this.propertyName });
/* 2295 */       if (this.onlyActiveNodes != null)
/* 2296 */         params.set("onlyactivenodes", this.onlyActiveNodes.booleanValue());
/* 2297 */       if (this.shardUnique != null)
/* 2298 */         params.set("shardUnique", this.shardUnique.booleanValue());
/* 2299 */       return params;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\CollectionAdminRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */