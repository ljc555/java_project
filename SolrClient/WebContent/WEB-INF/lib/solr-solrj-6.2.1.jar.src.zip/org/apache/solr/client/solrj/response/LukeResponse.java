/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.solr.common.luke.FieldFlag;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LukeResponse
/*     */   extends SolrResponseBase
/*     */ {
/*     */   private NamedList<Object> indexInfo;
/*     */   private Map<String, FieldInfo> fieldInfo;
/*     */   private Map<String, FieldTypeInfo> fieldTypeInfo;
/*     */   
/*     */   public static class FieldTypeInfo
/*     */     implements Serializable
/*     */   {
/*     */     String name;
/*     */     String className;
/*     */     boolean tokenized;
/*     */     String analyzer;
/*     */     List<String> fields;
/*     */     
/*     */     public FieldTypeInfo(String name)
/*     */     {
/*  43 */       this.name = name;
/*  44 */       this.fields = Collections.emptyList();
/*     */     }
/*     */     
/*     */     public String getAnalyzer()
/*     */     {
/*  49 */       return this.analyzer;
/*     */     }
/*     */     
/*     */     public String getClassName() {
/*  53 */       return this.className;
/*     */     }
/*     */     
/*     */     public List<String> getFields() {
/*  57 */       return this.fields;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  61 */       return this.name;
/*     */     }
/*     */     
/*     */     public boolean isTokenized() {
/*  65 */       return this.tokenized;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void read(NamedList<Object> nl)
/*     */     {
/*  89 */       for (Map.Entry<String, Object> entry : nl) {
/*  90 */         String key = (String)entry.getKey();
/*  91 */         if (("fields".equals(key)) && (entry.getValue() != null)) {
/*  92 */           List<String> theFields = (List)entry.getValue();
/*  93 */           this.fields = new ArrayList(theFields);
/*  94 */         } else if ("tokenized".equals(key) == true) {
/*  95 */           this.tokenized = Boolean.parseBoolean(entry.getValue().toString());
/*  96 */         } else if ("analyzer".equals(key) == true) {
/*  97 */           this.analyzer = entry.getValue().toString();
/*  98 */         } else if ("className".equals(key) == true) {
/*  99 */           this.className = entry.getValue().toString();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FieldInfo implements Serializable {
/*     */     String name;
/*     */     String type;
/*     */     String schema;
/*     */     int docs;
/*     */     int distinct;
/*     */     EnumSet<FieldFlag> flags;
/*     */     boolean cacheableFaceting;
/*     */     NamedList<Integer> topTerms;
/*     */     
/*     */     public FieldInfo(String n) {
/* 116 */       this.name = n;
/*     */     }
/*     */     
/*     */     public void read(NamedList<Object> nl)
/*     */     {
/* 121 */       for (Map.Entry<String, Object> entry : nl) {
/* 122 */         if ("type".equals(entry.getKey())) {
/* 123 */           this.type = ((String)entry.getValue());
/*     */         }
/* 125 */         if ("flags".equals(entry.getKey())) {
/* 126 */           this.flags = parseFlags((String)entry.getValue());
/* 127 */         } else if ("schema".equals(entry.getKey())) {
/* 128 */           this.schema = ((String)entry.getValue());
/* 129 */         } else if ("docs".equals(entry.getKey())) {
/* 130 */           this.docs = ((Integer)entry.getValue()).intValue();
/* 131 */         } else if ("distinct".equals(entry.getKey())) {
/* 132 */           this.distinct = ((Integer)entry.getValue()).intValue();
/* 133 */         } else if ("cacheableFaceting".equals(entry.getKey())) {
/* 134 */           this.cacheableFaceting = ((Boolean)entry.getValue()).booleanValue();
/* 135 */         } else if ("topTerms".equals(entry.getKey())) {
/* 136 */           this.topTerms = ((NamedList)entry.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public static EnumSet<FieldFlag> parseFlags(String flagStr) {
/* 142 */       EnumSet<FieldFlag> result = EnumSet.noneOf(FieldFlag.class);
/* 143 */       char[] chars = flagStr.toCharArray();
/* 144 */       for (int i = 0; i < chars.length; i++) {
/* 145 */         if (chars[i] != '-') {
/* 146 */           FieldFlag flag = FieldFlag.getFlag(chars[i]);
/* 147 */           result.add(flag);
/*     */         }
/*     */       }
/* 150 */       return result;
/*     */     }
/*     */     
/*     */     public EnumSet<FieldFlag> getFlags() {
/* 154 */       return this.flags;
/*     */     }
/*     */     
/*     */     public boolean isCacheableFaceting() {
/* 158 */       return this.cacheableFaceting;
/*     */     }
/*     */     
/*     */     public String getType() {
/* 162 */       return this.type;
/*     */     }
/*     */     
/*     */     public int getDistinct() {
/* 166 */       return this.distinct;
/*     */     }
/*     */     
/*     */     public int getDocs() {
/* 170 */       return this.docs;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 174 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getSchema() {
/* 178 */       return this.schema;
/*     */     }
/*     */     
/*     */     public NamedList<Integer> getTopTerms() {
/* 182 */       return this.topTerms;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(NamedList<Object> res)
/*     */   {
/* 193 */     super.setResponse(res);
/*     */     
/*     */ 
/* 196 */     this.indexInfo = ((NamedList)res.get("index"));
/*     */     
/* 198 */     NamedList<Object> schema = (NamedList)res.get("schema");
/* 199 */     NamedList<Object> flds = (NamedList)res.get("fields");
/* 200 */     if ((flds == null) && (schema != null))
/* 201 */       flds = (NamedList)schema.get("fields");
/*     */     Iterator localIterator;
/* 203 */     if (flds != null) {
/* 204 */       this.fieldInfo = new HashMap();
/* 205 */       for (localIterator = flds.iterator(); localIterator.hasNext();) { field = (Map.Entry)localIterator.next();
/* 206 */         FieldInfo f = new FieldInfo((String)field.getKey());
/* 207 */         f.read((NamedList)field.getValue());
/* 208 */         this.fieldInfo.put(field.getKey(), f);
/*     */       }
/*     */     }
/*     */     Map.Entry<String, Object> field;
/* 212 */     if (schema != null) {
/* 213 */       Object fldTypes = (NamedList)schema.get("types");
/* 214 */       if (fldTypes != null) {
/* 215 */         this.fieldTypeInfo = new HashMap();
/* 216 */         for (Map.Entry<String, Object> fieldType : (NamedList)fldTypes) {
/* 217 */           FieldTypeInfo ft = new FieldTypeInfo((String)fieldType.getKey());
/* 218 */           ft.read((NamedList)fieldType.getValue());
/* 219 */           this.fieldTypeInfo.put(fieldType.getKey(), ft);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getIndexDirectory()
/*     */   {
/* 229 */     if (this.indexInfo == null) return null;
/* 230 */     return (String)this.indexInfo.get("directory");
/*     */   }
/*     */   
/*     */   public Integer getNumDocs() {
/* 234 */     if (this.indexInfo == null) return null;
/* 235 */     return (Integer)this.indexInfo.get("numDocs");
/*     */   }
/*     */   
/*     */   public Integer getMaxDoc() {
/* 239 */     if (this.indexInfo == null) return null;
/* 240 */     return (Integer)this.indexInfo.get("maxDoc");
/*     */   }
/*     */   
/*     */   public Integer getNumTerms() {
/* 244 */     if (this.indexInfo == null) return null;
/* 245 */     return (Integer)this.indexInfo.get("numTerms");
/*     */   }
/*     */   
/*     */   public Map<String, FieldTypeInfo> getFieldTypeInfo() {
/* 249 */     return this.fieldTypeInfo;
/*     */   }
/*     */   
/*     */   public FieldTypeInfo getFieldTypeInfo(String name) {
/* 253 */     return (FieldTypeInfo)this.fieldTypeInfo.get(name);
/*     */   }
/*     */   
/*     */   public NamedList<Object> getIndexInfo() {
/* 257 */     return this.indexInfo;
/*     */   }
/*     */   
/*     */   public Map<String, FieldInfo> getFieldInfo() {
/* 261 */     return this.fieldInfo;
/*     */   }
/*     */   
/*     */   public FieldInfo getFieldInfo(String f) {
/* 265 */     return (FieldInfo)this.fieldInfo.get(f);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\LukeResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */