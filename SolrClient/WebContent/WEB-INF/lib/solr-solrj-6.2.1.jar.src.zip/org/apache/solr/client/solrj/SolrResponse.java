/*    */ package org.apache.solr.client.solrj;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SolrResponse
/*    */   implements Serializable
/*    */ {
/*    */   public abstract long getElapsedTime();
/*    */   
/*    */   public abstract void setResponse(NamedList<Object> paramNamedList);
/*    */   
/*    */   public abstract void setElapsedTime(long paramLong);
/*    */   
/*    */   public abstract NamedList<Object> getResponse();
/*    */   
/*    */   public static byte[] serializable(SolrResponse response)
/*    */   {
/*    */     try
/*    */     {
/* 46 */       ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/* 47 */       ObjectOutputStream outputStream = new ObjectOutputStream(byteStream);
/* 48 */       outputStream.writeObject(response);
/* 49 */       return byteStream.toByteArray();
/*    */     } catch (Exception e) {
/* 51 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, e);
/*    */     }
/*    */   }
/*    */   
/*    */   public static SolrResponse deserialize(byte[] bytes) {
/*    */     try {
/* 57 */       ByteArrayInputStream byteStream = new ByteArrayInputStream(bytes);
/* 58 */       ObjectInputStream inputStream = new ObjectInputStream(byteStream);
/* 59 */       return (SolrResponse)inputStream.readObject();
/*    */     } catch (Exception e) {
/* 61 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\SolrResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */