/*    */ package org.apache.solr.client.solrj.request.schema;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldTypeDefinition
/*    */ {
/*    */   private Map<String, Object> attributes;
/*    */   private AnalyzerDefinition analyzer;
/*    */   private AnalyzerDefinition indexAnalyzer;
/*    */   private AnalyzerDefinition queryAnalyzer;
/*    */   private AnalyzerDefinition multiTermAnalyzer;
/*    */   private Map<String, Object> similarity;
/*    */   
/*    */   public Map<String, Object> getAttributes()
/*    */   {
/* 38 */     return this.attributes;
/*    */   }
/*    */   
/*    */   public void setAttributes(Map<String, Object> attributes) {
/* 42 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getSimilarity() {
/* 46 */     return this.similarity;
/*    */   }
/*    */   
/*    */   public void setSimilarity(Map<String, Object> similarity) {
/* 50 */     this.similarity = similarity;
/*    */   }
/*    */   
/*    */   public AnalyzerDefinition getAnalyzer() {
/* 54 */     return this.analyzer;
/*    */   }
/*    */   
/*    */   public void setAnalyzer(AnalyzerDefinition analyzer) {
/* 58 */     this.analyzer = analyzer;
/*    */   }
/*    */   
/*    */   public AnalyzerDefinition getIndexAnalyzer() {
/* 62 */     return this.indexAnalyzer;
/*    */   }
/*    */   
/*    */   public void setIndexAnalyzer(AnalyzerDefinition indexAnalyzer) {
/* 66 */     this.indexAnalyzer = indexAnalyzer;
/*    */   }
/*    */   
/*    */   public AnalyzerDefinition getQueryAnalyzer() {
/* 70 */     return this.queryAnalyzer;
/*    */   }
/*    */   
/*    */   public void setQueryAnalyzer(AnalyzerDefinition queryAnalyzer) {
/* 74 */     this.queryAnalyzer = queryAnalyzer;
/*    */   }
/*    */   
/*    */   public AnalyzerDefinition getMultiTermAnalyzer() {
/* 78 */     return this.multiTermAnalyzer;
/*    */   }
/*    */   
/*    */   public void setMultiTermAnalyzer(AnalyzerDefinition multiTermAnalyzer) {
/* 82 */     this.multiTermAnalyzer = multiTermAnalyzer;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\schema\FieldTypeDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */