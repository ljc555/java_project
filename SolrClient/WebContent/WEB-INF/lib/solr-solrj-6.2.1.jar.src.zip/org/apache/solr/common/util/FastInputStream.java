/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastInputStream
/*     */   extends DataInputInputStream
/*     */ {
/*     */   protected final InputStream in;
/*     */   protected final byte[] buf;
/*     */   protected int pos;
/*     */   protected int end;
/*     */   protected long readFromStream;
/*     */   
/*     */   public FastInputStream(InputStream in)
/*     */   {
/*  34 */     this(in, new byte[' '], 0, 0);
/*     */   }
/*     */   
/*     */   public FastInputStream(InputStream in, byte[] tempBuffer, int start, int end) {
/*  38 */     this.in = in;
/*  39 */     this.buf = tempBuffer;
/*  40 */     this.pos = start;
/*  41 */     this.end = end;
/*     */   }
/*     */   
/*     */   public static FastInputStream wrap(InputStream in)
/*     */   {
/*  46 */     return (in instanceof FastInputStream) ? (FastInputStream)in : new FastInputStream(in);
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/*  51 */     if (this.pos >= this.end) {
/*  52 */       refill();
/*  53 */       if (this.pos >= this.end) return -1;
/*     */     }
/*  55 */     return this.buf[(this.pos++)] & 0xFF;
/*     */   }
/*     */   
/*     */   public int peek() throws IOException {
/*  59 */     if (this.pos >= this.end) {
/*  60 */       refill();
/*  61 */       if (this.pos >= this.end) return -1;
/*     */     }
/*  63 */     return this.buf[this.pos] & 0xFF;
/*     */   }
/*     */   
/*     */   public int readUnsignedByte()
/*     */     throws IOException
/*     */   {
/*  69 */     if (this.pos >= this.end) {
/*  70 */       refill();
/*  71 */       if (this.pos >= this.end) {
/*  72 */         throw new EOFException();
/*     */       }
/*     */     }
/*  75 */     return this.buf[(this.pos++)] & 0xFF;
/*     */   }
/*     */   
/*     */   public int readWrappedStream(byte[] target, int offset, int len) throws IOException {
/*  79 */     return this.in.read(target, offset, len);
/*     */   }
/*     */   
/*     */   public long position() {
/*  83 */     return this.readFromStream - (this.end - this.pos);
/*     */   }
/*     */   
/*     */   public void refill() throws IOException
/*     */   {
/*  88 */     this.end = readWrappedStream(this.buf, 0, this.buf.length);
/*  89 */     if (this.end > 0) this.readFromStream += this.end;
/*  90 */     this.pos = 0;
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/*  95 */     return this.end - this.pos;
/*     */   }
/*     */   
/*     */   public byte[] getBuffer()
/*     */   {
/* 100 */     return this.buf;
/*     */   }
/*     */   
/*     */   public int getPositionInBuffer()
/*     */   {
/* 105 */     return this.pos;
/*     */   }
/*     */   
/*     */   public int getEndInBuffer()
/*     */   {
/* 110 */     return this.end;
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 115 */     int r = 0;
/*     */     
/*     */ 
/* 118 */     if (this.end - this.pos > 0) {
/* 119 */       r = Math.min(this.end - this.pos, len);
/* 120 */       System.arraycopy(this.buf, this.pos, b, off, r);
/* 121 */       this.pos += r;
/*     */     }
/*     */     
/* 124 */     if (r == len) { return r;
/*     */     }
/*     */     
/* 127 */     if (len - r >= this.buf.length) {
/* 128 */       int ret = readWrappedStream(b, off + r, len - r);
/* 129 */       if (ret >= 0) {
/* 130 */         this.readFromStream += ret;
/* 131 */         r += ret;
/* 132 */         return r;
/*     */       }
/*     */       
/* 135 */       return r > 0 ? r : -1;
/*     */     }
/*     */     
/*     */ 
/* 139 */     refill();
/*     */     
/*     */ 
/* 142 */     if (this.end - this.pos > 0) {
/* 143 */       int toRead = Math.min(this.end - this.pos, len - r);
/* 144 */       System.arraycopy(this.buf, this.pos, b, off + r, toRead);
/* 145 */       this.pos += toRead;
/* 146 */       r += toRead;
/* 147 */       return r;
/*     */     }
/*     */     
/* 150 */     return r > 0 ? r : -1;
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 155 */     this.in.close();
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException
/*     */   {
/* 160 */     readFully(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException
/*     */   {
/* 165 */     while (len > 0) {
/* 166 */       int ret = read(b, off, len);
/* 167 */       if (ret == -1) {
/* 168 */         throw new EOFException();
/*     */       }
/* 170 */       off += ret;
/* 171 */       len -= ret;
/*     */     }
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException
/*     */   {
/* 177 */     if (this.end - this.pos >= n) {
/* 178 */       this.pos += n;
/* 179 */       return n;
/*     */     }
/*     */     
/* 182 */     if (this.end - this.pos < 0) { return -1;
/*     */     }
/* 184 */     int r = this.end - this.pos;
/* 185 */     this.pos = this.end;
/*     */     
/* 187 */     while (r < n) {
/* 188 */       refill();
/* 189 */       if (this.end - this.pos <= 0) return r;
/* 190 */       int toRead = Math.min(this.end - this.pos, n - r);
/* 191 */       r += toRead;
/* 192 */       this.pos += toRead;
/*     */     }
/*     */     
/* 195 */     return r;
/*     */   }
/*     */   
/*     */   public boolean readBoolean() throws IOException
/*     */   {
/* 200 */     return readByte() == 1;
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException
/*     */   {
/* 205 */     if (this.pos >= this.end) {
/* 206 */       refill();
/* 207 */       if (this.pos >= this.end) throw new EOFException();
/*     */     }
/* 209 */     return this.buf[(this.pos++)];
/*     */   }
/*     */   
/*     */   public short readShort()
/*     */     throws IOException
/*     */   {
/* 215 */     return (short)(readUnsignedByte() << 8 | readUnsignedByte());
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException
/*     */   {
/* 220 */     return readUnsignedByte() << 8 | readUnsignedByte();
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException
/*     */   {
/* 225 */     return (char)(readUnsignedByte() << 8 | readUnsignedByte());
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException
/*     */   {
/* 230 */     return 
/*     */     
/*     */ 
/* 233 */       readUnsignedByte() << 24 | readUnsignedByte() << 16 | readUnsignedByte() << 8 | readUnsignedByte();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException
/*     */   {
/* 238 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */       readUnsignedByte() << 56 | readUnsignedByte() << 48 | readUnsignedByte() << 40 | readUnsignedByte() << 32 | readUnsignedByte() << 24 | readUnsignedByte() << 16 | readUnsignedByte() << 8 | readUnsignedByte();
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException
/*     */   {
/* 250 */     return Float.intBitsToFloat(readInt());
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException
/*     */   {
/* 255 */     return Double.longBitsToDouble(readLong());
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException
/*     */   {
/* 260 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String readUTF() throws IOException
/*     */   {
/* 265 */     return new DataInputStream(this).readUTF();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\FastInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */