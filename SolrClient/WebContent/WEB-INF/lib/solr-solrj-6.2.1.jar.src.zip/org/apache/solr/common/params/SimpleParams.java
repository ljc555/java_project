package org.apache.solr.common.params;

public abstract interface SimpleParams
{
  public static final String QF = "qf";
  public static final String QO = "q.operators";
  public static final String AND_OPERATOR = "AND";
  public static final String NOT_OPERATOR = "NOT";
  public static final String OR_OPERATOR = "OR";
  public static final String PREFIX_OPERATOR = "PREFIX";
  public static final String PHRASE_OPERATOR = "PHRASE";
  public static final String PRECEDENCE_OPERATORS = "PRECEDENCE";
  public static final String ESCAPE_OPERATOR = "ESCAPE";
  public static final String WHITESPACE_OPERATOR = "WHITESPACE";
  public static final String FUZZY_OPERATOR = "FUZZY";
  public static final String NEAR_OPERATOR = "NEAR";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\SimpleParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */