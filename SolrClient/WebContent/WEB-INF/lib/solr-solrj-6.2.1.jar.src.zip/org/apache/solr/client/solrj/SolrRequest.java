/*     */ package org.apache.solr.client.solrj;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SolrRequest<T extends SolrResponse>
/*     */   implements Serializable
/*     */ {
/*     */   public static enum METHOD
/*     */   {
/*  36 */     GET, 
/*  37 */     POST, 
/*  38 */     PUT;
/*     */     
/*     */     private METHOD() {} }
/*  41 */   private METHOD method = METHOD.GET;
/*  42 */   private String path = null;
/*     */   private ResponseParser responseParser;
/*     */   private StreamingResponseCallback callback;
/*     */   private Set<String> queryParams;
/*     */   private String basicAuthUser;
/*     */   private String basicAuthPwd;
/*     */   
/*     */   public SolrRequest setBasicAuthCredentials(String user, String password)
/*     */   {
/*  51 */     this.basicAuthUser = user;
/*  52 */     this.basicAuthPwd = password;
/*  53 */     return this;
/*     */   }
/*     */   
/*     */   public String getBasicAuthUser() {
/*  57 */     return this.basicAuthUser;
/*     */   }
/*     */   
/*  60 */   public String getBasicAuthPassword() { return this.basicAuthPwd; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SolrRequest(METHOD m, String path)
/*     */   {
/*  68 */     this.method = m;
/*  69 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public METHOD getMethod()
/*     */   {
/*  76 */     return this.method;
/*     */   }
/*     */   
/*  79 */   public void setMethod(METHOD method) { this.method = method; }
/*     */   
/*     */   public String getPath()
/*     */   {
/*  83 */     return this.path;
/*     */   }
/*     */   
/*  86 */   public void setPath(String path) { this.path = path; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseParser getResponseParser()
/*     */   {
/*  94 */     return this.responseParser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponseParser(ResponseParser responseParser)
/*     */   {
/* 103 */     this.responseParser = responseParser;
/*     */   }
/*     */   
/*     */   public StreamingResponseCallback getStreamingResponseCallback() {
/* 107 */     return this.callback;
/*     */   }
/*     */   
/*     */   public void setStreamingResponseCallback(StreamingResponseCallback callback) {
/* 111 */     this.callback = callback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<String> getQueryParams()
/*     */   {
/* 118 */     return this.queryParams;
/*     */   }
/*     */   
/*     */   public void setQueryParams(Set<String> queryParams) {
/* 122 */     this.queryParams = queryParams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract SolrParams getParams();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Collection<ContentStream> getContentStreams()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract T createResponse(SolrClient paramSolrClient);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T process(SolrClient client, String collection)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 147 */     long startTime = TimeUnit.MILLISECONDS.convert(System.nanoTime(), TimeUnit.NANOSECONDS);
/* 148 */     T res = createResponse(client);
/* 149 */     res.setResponse(client.request(this, collection));
/* 150 */     long endTime = TimeUnit.MILLISECONDS.convert(System.nanoTime(), TimeUnit.NANOSECONDS);
/* 151 */     res.setElapsedTime(endTime - startTime);
/* 152 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T process(SolrClient client)
/*     */     throws SolrServerException, IOException
/*     */   {
/* 166 */     return process(client, null);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\SolrRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */