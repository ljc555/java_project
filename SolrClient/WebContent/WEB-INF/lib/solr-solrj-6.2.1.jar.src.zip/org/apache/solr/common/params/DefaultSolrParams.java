/*    */ package org.apache.solr.common.params;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSolrParams
/*    */   extends SolrParams
/*    */ {
/*    */   protected final SolrParams params;
/*    */   protected final SolrParams defaults;
/*    */   
/*    */   protected DefaultSolrParams(SolrParams params, SolrParams defaults)
/*    */   {
/* 31 */     assert ((params != null) && (defaults != null));
/* 32 */     this.params = params;
/* 33 */     this.defaults = defaults;
/*    */   }
/*    */   
/*    */   public String get(String param)
/*    */   {
/* 38 */     String val = this.params.get(param);
/* 39 */     return val != null ? val : this.defaults.get(param);
/*    */   }
/*    */   
/*    */   public String[] getParams(String param)
/*    */   {
/* 44 */     String[] vals = this.params.getParams(param);
/* 45 */     return vals != null ? vals : this.defaults.getParams(param);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Iterator<String> getParameterNamesIterator()
/*    */   {
/* 53 */     LinkedHashSet<String> allKeys = new LinkedHashSet();
/* 54 */     for (SolrParams p : new SolrParams[] { this.params, this.defaults }) {
/* 55 */       Iterator<String> localKeys = p.getParameterNamesIterator();
/* 56 */       while (localKeys.hasNext()) {
/* 57 */         allKeys.add(localKeys.next());
/*    */       }
/*    */     }
/* 60 */     return allKeys.iterator();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 65 */     return "{params(" + this.params + "),defaults(" + this.defaults + ")}";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\DefaultSolrParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */