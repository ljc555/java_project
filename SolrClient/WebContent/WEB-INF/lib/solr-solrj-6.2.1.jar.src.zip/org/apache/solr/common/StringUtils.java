/*    */ package org.apache.solr.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtils
/*    */ {
/*    */   public static boolean isEmpty(String s)
/*    */   {
/* 22 */     return (s == null) || (s.isEmpty());
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\StringUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */