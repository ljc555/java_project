/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodHandles.Lookup;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.zookeeper.Watcher;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultConnectionStrategy
/*    */   extends ZkClientConnectionStrategy
/*    */ {
/* 33 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*    */   
/*    */   public void connect(String serverAddress, int timeout, Watcher watcher, ZkClientConnectionStrategy.ZkUpdate updater) throws IOException, InterruptedException, TimeoutException
/*    */   {
/* 37 */     SolrZooKeeper zk = createSolrZooKeeper(serverAddress, timeout, watcher);
/* 38 */     boolean success = false;
/*    */     try {
/* 40 */       updater.update(zk);
/* 41 */       success = true;
/*    */     } finally {
/* 43 */       if (!success) {
/* 44 */         zk.close();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void reconnect(String serverAddress, int zkClientTimeout, Watcher watcher, ZkClientConnectionStrategy.ZkUpdate updater)
/*    */     throws IOException
/*    */   {
/* 52 */     log.warn("Connection expired - starting a new one...");
/* 53 */     SolrZooKeeper zk = createSolrZooKeeper(serverAddress, zkClientTimeout, watcher);
/* 54 */     boolean success = false;
/*    */     try
/*    */     {
/* 57 */       updater.update(zk);
/* 58 */       success = true;
/* 59 */       log.info("Reconnected to ZooKeeper"); return;
/*    */     } catch (Exception e) {
/* 61 */       SolrException.log(log, "Reconnect to ZooKeeper failed", e);
/* 62 */       log.warn("Reconnect to ZooKeeper failed");
/*    */     } finally {
/* 64 */       if (!success) {
/*    */         try {
/* 66 */           zk.close();
/*    */         } catch (InterruptedException e) {
/* 68 */           Thread.currentThread().interrupt();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\DefaultConnectionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */