/*    */ package org.apache.solr.client.solrj.io.stream.metrics;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.apache.solr.client.solrj.io.Tuple;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*    */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MeanMetric
/*    */   extends Metric
/*    */ {
/*    */   private String columnName;
/*    */   private double doubleSum;
/*    */   private long longSum;
/*    */   private long count;
/*    */   
/*    */   public MeanMetric(String columnName)
/*    */   {
/* 40 */     init("avg", columnName);
/*    */   }
/*    */   
/*    */   public MeanMetric(StreamExpression expression, StreamFactory factory) throws IOException
/*    */   {
/* 45 */     String functionName = expression.getFunctionName();
/* 46 */     String columnName = factory.getValueOperand(expression, 0);
/*    */     
/*    */ 
/* 49 */     if (null == columnName) {
/* 50 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expected %s(columnName)", new Object[] { expression, functionName }));
/*    */     }
/* 52 */     if (1 != expression.getParameters().size()) {
/* 53 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*    */     }
/*    */     
/* 56 */     init(functionName, columnName);
/*    */   }
/*    */   
/*    */   private void init(String functionName, String columnName) {
/* 60 */     this.columnName = columnName;
/* 61 */     setFunctionName(functionName);
/* 62 */     setIdentifier(new String[] { functionName, "(", columnName, ")" });
/*    */   }
/*    */   
/*    */   public void update(Tuple tuple) {
/* 66 */     this.count += 1L;
/* 67 */     Object o = tuple.get(this.columnName);
/* 68 */     if ((o instanceof Double)) {
/* 69 */       Double d = (Double)tuple.get(this.columnName);
/* 70 */       this.doubleSum += d.doubleValue();
/*    */     } else {
/* 72 */       Long l = (Long)tuple.get(this.columnName);
/* 73 */       this.longSum += l.longValue();
/*    */     }
/*    */   }
/*    */   
/*    */   public Metric newInstance() {
/* 78 */     return new MeanMetric(this.columnName);
/*    */   }
/*    */   
/*    */   public String[] getColumns() {
/* 82 */     return new String[] { this.columnName };
/*    */   }
/*    */   
/*    */   public Double getValue() {
/* 86 */     double dcount = this.count;
/* 87 */     if (this.longSum == 0L) {
/* 88 */       return Double.valueOf(this.doubleSum / dcount);
/*    */     }
/*    */     
/* 91 */     return Double.valueOf(this.longSum / dcount);
/*    */   }
/*    */   
/*    */   public StreamExpressionParameter toExpression(StreamFactory factory)
/*    */     throws IOException
/*    */   {
/* 97 */     return new StreamExpression(getFunctionName()).withParameter(this.columnName);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\metrics\MeanMetric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */