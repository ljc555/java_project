/*    */ package org.apache.solr.client.solrj.io;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassificationEvaluation
/*    */ {
/*    */   private long truePositive;
/*    */   private long falsePositive;
/*    */   private long trueNegative;
/*    */   private long falseNegative;
/*    */   
/*    */   public void count(int actual, int predicted)
/*    */   {
/* 30 */     if (predicted == 1) {
/* 31 */       if (actual == 1) this.truePositive += 1L; else {
/* 32 */         this.falsePositive += 1L;
/*    */       }
/* 34 */     } else if (actual == 0) this.trueNegative += 1L; else {
/* 35 */       this.falseNegative += 1L;
/*    */     }
/*    */   }
/*    */   
/*    */   public void putToMap(Map map) {
/* 40 */     map.put("truePositive_i", Long.valueOf(this.truePositive));
/* 41 */     map.put("trueNegative_i", Long.valueOf(this.trueNegative));
/* 42 */     map.put("falsePositive_i", Long.valueOf(this.falsePositive));
/* 43 */     map.put("falseNegative_i", Long.valueOf(this.falseNegative));
/*    */   }
/*    */   
/*    */   public Map toMap() {
/* 47 */     HashMap map = new HashMap();
/* 48 */     putToMap(map);
/* 49 */     return map;
/*    */   }
/*    */   
/*    */   public static ClassificationEvaluation create(Map map) {
/* 53 */     ClassificationEvaluation evaluation = new ClassificationEvaluation();
/* 54 */     evaluation.addEvaluation(map);
/* 55 */     return evaluation;
/*    */   }
/*    */   
/*    */   public void addEvaluation(Map map) {
/* 59 */     this.truePositive += ((Long)map.get("truePositive_i")).longValue();
/* 60 */     this.trueNegative += ((Long)map.get("trueNegative_i")).longValue();
/* 61 */     this.falsePositive += ((Long)map.get("falsePositive_i")).longValue();
/* 62 */     this.falseNegative += ((Long)map.get("falseNegative_i")).longValue();
/*    */   }
/*    */   
/*    */   public double getPrecision() {
/* 66 */     if (this.truePositive + this.falsePositive == 0L) return 0.0D;
/* 67 */     return this.truePositive / (this.truePositive + this.falsePositive);
/*    */   }
/*    */   
/*    */   public double getRecall() {
/* 71 */     if (this.truePositive + this.falseNegative == 0L) return 0.0D;
/* 72 */     return this.truePositive / (this.truePositive + this.falseNegative);
/*    */   }
/*    */   
/*    */   public double getF1() {
/* 76 */     double precision = getPrecision();
/* 77 */     double recall = getRecall();
/* 78 */     if (precision + recall == 0.0D) return 0.0D;
/* 79 */     return 2.0D * (precision * recall) / (precision + recall);
/*    */   }
/*    */   
/*    */   public double getAccuracy() {
/* 83 */     return (this.truePositive + this.trueNegative) / (this.truePositive + this.trueNegative + this.falseNegative + this.falsePositive);
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ClassificationEvaluation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */