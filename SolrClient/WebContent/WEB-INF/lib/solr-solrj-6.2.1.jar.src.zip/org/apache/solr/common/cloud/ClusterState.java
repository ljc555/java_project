/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.util.Utils;
/*     */ import org.noggit.JSONWriter;
/*     */ import org.noggit.JSONWriter.Writable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterState
/*     */   implements JSONWriter.Writable
/*     */ {
/*     */   private final Integer znodeVersion;
/*     */   private final Map<String, CollectionRef> collectionStates;
/*     */   private final Map<String, CollectionRef> immutableCollectionStates;
/*     */   private Set<String> liveNodes;
/*     */   
/*     */   public ClusterState(Integer znodeVersion, Set<String> liveNodes, Map<String, DocCollection> collectionStates)
/*     */   {
/*  51 */     this(liveNodes, getRefMap(collectionStates), znodeVersion);
/*     */   }
/*     */   
/*     */   private static Map<String, CollectionRef> getRefMap(Map<String, DocCollection> collectionStates) {
/*  55 */     Map<String, CollectionRef> collRefs = new LinkedHashMap(collectionStates.size());
/*  56 */     for (Map.Entry<String, DocCollection> entry : collectionStates.entrySet()) {
/*  57 */       DocCollection c = (DocCollection)entry.getValue();
/*  58 */       collRefs.put(entry.getKey(), new CollectionRef(c));
/*     */     }
/*  60 */     return collRefs;
/*     */   }
/*     */   
/*     */ 
/*     */   public ClusterState(Set<String> liveNodes, Map<String, CollectionRef> collectionStates, Integer znodeVersion)
/*     */   {
/*  66 */     this.znodeVersion = znodeVersion;
/*  67 */     this.liveNodes = new HashSet(liveNodes.size());
/*  68 */     this.liveNodes.addAll(liveNodes);
/*  69 */     this.collectionStates = new LinkedHashMap(collectionStates);
/*  70 */     this.immutableCollectionStates = Collections.unmodifiableMap(collectionStates);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClusterState copyWith(String collectionName, DocCollection collection)
/*     */   {
/*  82 */     ClusterState result = new ClusterState(this.liveNodes, new LinkedHashMap(this.collectionStates), this.znodeVersion);
/*  83 */     if (collection == null) {
/*  84 */       result.collectionStates.remove(collectionName);
/*     */     } else {
/*  86 */       result.collectionStates.put(collectionName, new CollectionRef(collection));
/*     */     }
/*  88 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Replica getLeader(String collection, String sliceName)
/*     */   {
/*  98 */     DocCollection coll = getCollectionOrNull(collection);
/*  99 */     if (coll == null) return null;
/* 100 */     Slice slice = coll.getSlice(sliceName);
/* 101 */     if (slice == null) return null;
/* 102 */     return slice.getLeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasCollection(String collectionName)
/*     */   {
/* 114 */     return getCollectionOrNull(collectionName) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Replica getReplica(String collection, String coreNodeName)
/*     */   {
/* 126 */     DocCollection coll = getCollectionOrNull(collection);
/* 127 */     if (coll == null) return null;
/* 128 */     for (Slice slice : coll.getSlices()) {
/* 129 */       Replica replica = slice.getReplica(coreNodeName);
/* 130 */       if (replica != null) return replica;
/*     */     }
/* 132 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Slice getSlice(String collection, String sliceName)
/*     */   {
/* 142 */     DocCollection coll = getCollectionOrNull(collection);
/* 143 */     if (coll == null) return null;
/* 144 */     return coll.getSlice(sliceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Map<String, Slice> getSlicesMap(String collection)
/*     */   {
/* 152 */     DocCollection coll = getCollectionOrNull(collection);
/* 153 */     if (coll == null) return null;
/* 154 */     return coll.getSlicesMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Map<String, Slice> getActiveSlicesMap(String collection)
/*     */   {
/* 162 */     DocCollection coll = getCollectionOrNull(collection);
/* 163 */     if (coll == null) return null;
/* 164 */     return coll.getActiveSlicesMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Collection<Slice> getSlices(String collection)
/*     */   {
/* 172 */     DocCollection coll = getCollectionOrNull(collection);
/* 173 */     if (coll == null) return null;
/* 174 */     return coll.getSlices();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Collection<Slice> getActiveSlices(String collection)
/*     */   {
/* 182 */     DocCollection coll = getCollectionOrNull(collection);
/* 183 */     if (coll == null) return null;
/* 184 */     return coll.getActiveSlices();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocCollection getCollection(String collection)
/*     */   {
/* 192 */     DocCollection coll = getCollectionOrNull(collection);
/* 193 */     if (coll == null) throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Could not find collection : " + collection);
/* 194 */     return coll;
/*     */   }
/*     */   
/*     */   public CollectionRef getCollectionRef(String coll) {
/* 198 */     return (CollectionRef)this.collectionStates.get(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocCollection getCollectionOrNull(String collectionName)
/*     */   {
/* 211 */     CollectionRef ref = (CollectionRef)this.collectionStates.get(collectionName);
/* 212 */     return ref == null ? null : ref.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Set<String> getCollections()
/*     */   {
/* 227 */     Set<String> result = new HashSet();
/* 228 */     for (Map.Entry<String, CollectionRef> entry : this.collectionStates.entrySet()) {
/* 229 */       if (((CollectionRef)entry.getValue()).get() != null) {
/* 230 */         result.add(entry.getKey());
/*     */       }
/*     */     }
/* 233 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, DocCollection> getCollectionsMap()
/*     */   {
/* 247 */     Map<String, DocCollection> result = new HashMap(this.collectionStates.size());
/* 248 */     for (Map.Entry<String, CollectionRef> entry : this.collectionStates.entrySet()) {
/* 249 */       DocCollection collection = ((CollectionRef)entry.getValue()).get();
/* 250 */       if (collection != null) {
/* 251 */         result.put(entry.getKey(), collection);
/*     */       }
/*     */     }
/* 254 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<String> getLiveNodes()
/*     */   {
/* 261 */     return Collections.unmodifiableSet(this.liveNodes);
/*     */   }
/*     */   
/*     */   public String getShardId(String nodeName, String coreName) {
/* 265 */     return getShardId(null, nodeName, coreName);
/*     */   }
/*     */   
/*     */   public String getShardId(String collectionName, String nodeName, String coreName) {
/* 269 */     Collection<CollectionRef> states = this.collectionStates.values();
/* 270 */     CollectionRef c; if (collectionName != null) {
/* 271 */       c = (CollectionRef)this.collectionStates.get(collectionName);
/* 272 */       if (c != null) { states = Collections.singletonList(c);
/*     */       }
/*     */     }
/* 275 */     for (CollectionRef ref : states) {
/* 276 */       DocCollection coll = ref.get();
/* 277 */       if (coll != null)
/* 278 */         for (localIterator1 = coll.getSlices().iterator(); localIterator1.hasNext();) { slice = (Slice)localIterator1.next();
/* 279 */           for (Replica replica : slice.getReplicas())
/*     */           {
/* 281 */             String rnodeName = replica.getStr("node_name");
/* 282 */             String rcore = replica.getStr("core");
/* 283 */             if ((nodeName.equals(rnodeName)) && (coreName.equals(rcore)))
/* 284 */               return slice.getName();
/*     */           }
/*     */         } }
/*     */     Iterator localIterator1;
/*     */     Slice slice;
/* 289 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean liveNodesContain(String name)
/*     */   {
/* 296 */     return this.liveNodes.contains(name);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 301 */     StringBuilder sb = new StringBuilder();
/* 302 */     sb.append("live nodes:" + this.liveNodes);
/* 303 */     sb.append("collections:" + this.collectionStates);
/* 304 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static ClusterState load(Integer version, byte[] bytes, Set<String> liveNodes) {
/* 308 */     return load(version, bytes, liveNodes, "/clusterstate.json");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClusterState load(Integer version, byte[] bytes, Set<String> liveNodes, String znode)
/*     */   {
/* 320 */     if ((bytes == null) || (bytes.length == 0)) {
/* 321 */       return new ClusterState(version, liveNodes, Collections.emptyMap());
/*     */     }
/* 323 */     Map<String, Object> stateMap = (Map)Utils.fromJSON(bytes);
/* 324 */     Map<String, CollectionRef> collections = new LinkedHashMap(stateMap.size());
/* 325 */     for (Map.Entry<String, Object> entry : stateMap.entrySet()) {
/* 326 */       String collectionName = (String)entry.getKey();
/* 327 */       DocCollection coll = collectionFromObjects(collectionName, (Map)entry.getValue(), version, znode);
/* 328 */       collections.put(collectionName, new CollectionRef(coll));
/*     */     }
/*     */     
/* 331 */     return new ClusterState(liveNodes, collections, version);
/*     */   }
/*     */   
/*     */   public static Aliases load(byte[] bytes)
/*     */   {
/* 336 */     if ((bytes == null) || (bytes.length == 0)) {
/* 337 */       return new Aliases();
/*     */     }
/* 339 */     Map<String, Map<String, String>> aliasMap = (Map)Utils.fromJSON(bytes);
/*     */     
/* 341 */     return new Aliases(aliasMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static DocCollection collectionFromObjects(String name, Map<String, Object> objs, Integer version, String znode)
/*     */   {
/* 349 */     Map<String, Object> sliceObjs = (Map)objs.get("shards");
/* 350 */     Map<String, Object> props; Map<String, Slice> slices; Map<String, Object> props; if (sliceObjs == null)
/*     */     {
/* 352 */       Map<String, Slice> slices = Slice.loadAllFromMap(objs);
/* 353 */       props = Collections.emptyMap();
/*     */     } else {
/* 355 */       slices = Slice.loadAllFromMap(sliceObjs);
/* 356 */       props = new HashMap(objs);
/* 357 */       objs.remove("shards");
/*     */     }
/*     */     
/* 360 */     Object routerObj = props.get("router");
/*     */     DocRouter router;
/* 362 */     DocRouter router; if (routerObj == null) {
/* 363 */       router = DocRouter.DEFAULT; } else { DocRouter router;
/* 364 */       if ((routerObj instanceof String))
/*     */       {
/* 366 */         router = DocRouter.getDocRouter((String)routerObj);
/*     */       } else {
/* 368 */         Map routerProps = (Map)routerObj;
/* 369 */         router = DocRouter.getDocRouter((String)routerProps.get("name"));
/*     */       }
/*     */     }
/* 372 */     return new DocCollection(name, slices, props, router, version.intValue(), znode);
/*     */   }
/*     */   
/*     */   public void write(JSONWriter jsonWriter)
/*     */   {
/* 377 */     LinkedHashMap<String, DocCollection> map = new LinkedHashMap();
/* 378 */     for (Map.Entry<String, CollectionRef> e : this.collectionStates.entrySet())
/*     */     {
/* 380 */       if (((CollectionRef)e.getValue()).getClass() == CollectionRef.class)
/*     */       {
/* 382 */         DocCollection coll = ((CollectionRef)e.getValue()).get();
/* 383 */         if (coll.getStateFormat() == 1) {
/* 384 */           map.put(coll.getName(), coll);
/*     */         }
/*     */       }
/*     */     }
/* 388 */     jsonWriter.write(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Integer getZkClusterStateVersion()
/*     */   {
/* 399 */     return this.znodeVersion;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 404 */     int prime = 31;
/* 405 */     int result = 1;
/*     */     
/* 407 */     result = 31 * result + (this.znodeVersion == null ? 0 : this.znodeVersion.hashCode());
/* 408 */     result = 31 * result + (this.liveNodes == null ? 0 : this.liveNodes.hashCode());
/* 409 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 414 */     if (this == obj) return true;
/* 415 */     if (obj == null) return false;
/* 416 */     if (getClass() != obj.getClass()) return false;
/* 417 */     ClusterState other = (ClusterState)obj;
/* 418 */     if (this.znodeVersion == null) {
/* 419 */       if (other.znodeVersion != null) return false;
/* 420 */     } else if (!this.znodeVersion.equals(other.znodeVersion)) return false;
/* 421 */     if (this.liveNodes == null) {
/* 422 */       if (other.liveNodes != null) return false;
/* 423 */     } else if (!this.liveNodes.equals(other.liveNodes)) return false;
/* 424 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setLiveNodes(Set<String> liveNodes)
/*     */   {
/* 433 */     this.liveNodes = liveNodes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, CollectionRef> getCollectionStates()
/*     */   {
/* 441 */     return this.immutableCollectionStates;
/*     */   }
/*     */   
/*     */   public static class CollectionRef {
/*     */     private final DocCollection coll;
/*     */     
/*     */     public CollectionRef(DocCollection coll) {
/* 448 */       this.coll = coll;
/*     */     }
/*     */     
/*     */     public DocCollection get() {
/* 452 */       return this.coll;
/*     */     }
/*     */     
/* 455 */     public boolean isLazilyLoaded() { return false; }
/*     */     
/*     */     public String toString()
/*     */     {
/* 459 */       if (this.coll != null) {
/* 460 */         return this.coll.toString();
/*     */       }
/* 462 */       return "null DocCollection ref";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ClusterState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */