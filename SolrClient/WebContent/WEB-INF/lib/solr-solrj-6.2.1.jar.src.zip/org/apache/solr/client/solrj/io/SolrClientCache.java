/*    */ package org.apache.solr.client.solrj.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodHandles.Lookup;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.solr.client.solrj.SolrClient;
/*    */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*    */ import org.apache.solr.client.solrj.impl.CloudSolrClient.Builder;
/*    */ import org.apache.solr.client.solrj.impl.HttpSolrClient;
/*    */ import org.apache.solr.client.solrj.impl.HttpSolrClient.Builder;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrClientCache
/*    */   implements Serializable
/*    */ {
/* 38 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*    */   
/* 40 */   private final Map<String, SolrClient> solrClients = new HashMap();
/*    */   
/*    */   public synchronized CloudSolrClient getCloudSolrClient(String zkHost) { CloudSolrClient client;
/*    */     CloudSolrClient client;
/* 44 */     if (this.solrClients.containsKey(zkHost)) {
/* 45 */       client = (CloudSolrClient)this.solrClients.get(zkHost);
/*    */     }
/*    */     else
/*    */     {
/* 49 */       client = new CloudSolrClient.Builder().withZkHost(zkHost).build();
/* 50 */       client.connect();
/* 51 */       this.solrClients.put(zkHost, client);
/*    */     }
/*    */     
/* 54 */     return client;
/*    */   }
/*    */   
/*    */   public synchronized HttpSolrClient getHttpSolrClient(String host) { HttpSolrClient client;
/*    */     HttpSolrClient client;
/* 59 */     if (this.solrClients.containsKey(host)) {
/* 60 */       client = (HttpSolrClient)this.solrClients.get(host);
/*    */     }
/*    */     else {
/* 63 */       client = new HttpSolrClient.Builder(host).build();
/* 64 */       this.solrClients.put(host, client);
/*    */     }
/* 66 */     return client;
/*    */   }
/*    */   
/*    */   public synchronized void close() {
/* 70 */     for (Map.Entry<String, SolrClient> entry : this.solrClients.entrySet()) {
/*    */       try {
/* 72 */         ((SolrClient)entry.getValue()).close();
/*    */       } catch (IOException e) {
/* 74 */         log.error("Error closing SolrClient for " + (String)entry.getKey(), e);
/*    */       }
/*    */     }
/* 77 */     this.solrClients.clear();
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\SolrClientCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */