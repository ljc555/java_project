/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.noggit.CharArr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteUtils
/*     */ {
/*     */   public static final int MAX_UTF8_BYTES_PER_CHAR = 3;
/*     */   
/*     */   public static int UTF8toUTF16(byte[] utf8, int offset, int len, char[] out, int out_offset)
/*     */   {
/*  35 */     int out_start = out_offset;
/*  36 */     int limit = offset + len;
/*  37 */     while (offset < limit) {
/*  38 */       int b = utf8[(offset++)] & 0xFF;
/*     */       
/*  40 */       if (b < 192) {
/*  41 */         assert (b < 128);
/*  42 */         out[(out_offset++)] = ((char)b);
/*  43 */       } else if (b < 224) {
/*  44 */         out[(out_offset++)] = ((char)(((b & 0x1F) << 6) + (utf8[(offset++)] & 0x3F)));
/*  45 */       } else if (b < 240) {
/*  46 */         out[(out_offset++)] = ((char)(((b & 0xF) << 12) + ((utf8[offset] & 0x3F) << 6) + (utf8[(offset + 1)] & 0x3F)));
/*  47 */         offset += 2;
/*     */       } else {
/*  49 */         assert (b < 248);
/*  50 */         int ch = ((b & 0x7) << 18) + ((utf8[offset] & 0x3F) << 12) + ((utf8[(offset + 1)] & 0x3F) << 6) + (utf8[(offset + 2)] & 0x3F);
/*  51 */         offset += 3;
/*  52 */         if (ch < 65535) {
/*  53 */           out[(out_offset++)] = ((char)ch);
/*     */         } else {
/*  55 */           int chHalf = ch - 65536;
/*  56 */           out[(out_offset++)] = ((char)((chHalf >> 10) + 55296));
/*  57 */           out[(out_offset++)] = ((char)(int)((chHalf & 0x3FF) + 56320L));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  62 */     return out_offset - out_start;
/*     */   }
/*     */   
/*     */ 
/*     */   public static void UTF8toUTF16(byte[] utf8, int offset, int len, CharArr out)
/*     */   {
/*  68 */     out.reserve(len);
/*  69 */     int n = UTF8toUTF16(utf8, offset, len, out.getArray(), out.getEnd());
/*  70 */     out.setEnd(out.getEnd() + n);
/*     */   }
/*     */   
/*     */   public static String UTF8toUTF16(byte[] utf8, int offset, int len)
/*     */   {
/*  75 */     char[] out = new char[len];
/*  76 */     int n = UTF8toUTF16(utf8, offset, len, out, 0);
/*  77 */     return new String(out, 0, n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int UTF16toUTF8(CharSequence s, int offset, int len, byte[] result, int resultOffset)
/*     */   {
/*  87 */     int end = offset + len;
/*     */     
/*  89 */     int upto = resultOffset;
/*  90 */     for (int i = offset; i < end; i++) {
/*  91 */       int code = s.charAt(i);
/*     */       
/*  93 */       if (code < 128) {
/*  94 */         result[(upto++)] = ((byte)code);
/*  95 */       } else if (code < 2048) {
/*  96 */         result[(upto++)] = ((byte)(0xC0 | code >> 6));
/*  97 */         result[(upto++)] = ((byte)(0x80 | code & 0x3F));
/*  98 */       } else if ((code < 55296) || (code > 57343)) {
/*  99 */         result[(upto++)] = ((byte)(0xE0 | code >> 12));
/* 100 */         result[(upto++)] = ((byte)(0x80 | code >> 6 & 0x3F));
/* 101 */         result[(upto++)] = ((byte)(0x80 | code & 0x3F));
/*     */       }
/*     */       else
/*     */       {
/* 105 */         if ((code < 56320) && (i < end - 1)) {
/* 106 */           int utf32 = s.charAt(i + 1);
/*     */           
/* 108 */           if ((utf32 >= 56320) && (utf32 <= 57343)) {
/* 109 */             utf32 = (code - 55232 << 10) + (utf32 & 0x3FF);
/* 110 */             i++;
/* 111 */             result[(upto++)] = ((byte)(0xF0 | utf32 >> 18));
/* 112 */             result[(upto++)] = ((byte)(0x80 | utf32 >> 12 & 0x3F));
/* 113 */             result[(upto++)] = ((byte)(0x80 | utf32 >> 6 & 0x3F));
/* 114 */             result[(upto++)] = ((byte)(0x80 | utf32 & 0x3F));
/* 115 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 120 */         result[(upto++)] = -17;
/* 121 */         result[(upto++)] = -65;
/* 122 */         result[(upto++)] = -67;
/*     */       }
/*     */     }
/*     */     
/* 126 */     return upto - resultOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeUTF16toUTF8(CharSequence s, int offset, int len, OutputStream fos, byte[] scratch)
/*     */     throws IOException
/*     */   {
/* 136 */     int end = offset + len;
/*     */     
/* 138 */     int upto = 0;int totalBytes = 0;
/* 139 */     for (int i = offset; i < end; i++) {
/* 140 */       int code = s.charAt(i);
/*     */       
/* 142 */       if (upto > scratch.length - 4)
/*     */       {
/* 144 */         totalBytes += upto;
/* 145 */         fos.write(scratch, 0, upto);
/* 146 */         upto = 0;
/*     */       }
/*     */       
/* 149 */       if (code < 128) {
/* 150 */         scratch[(upto++)] = ((byte)code);
/* 151 */       } else if (code < 2048) {
/* 152 */         scratch[(upto++)] = ((byte)(0xC0 | code >> 6));
/* 153 */         scratch[(upto++)] = ((byte)(0x80 | code & 0x3F));
/* 154 */       } else if ((code < 55296) || (code > 57343)) {
/* 155 */         scratch[(upto++)] = ((byte)(0xE0 | code >> 12));
/* 156 */         scratch[(upto++)] = ((byte)(0x80 | code >> 6 & 0x3F));
/* 157 */         scratch[(upto++)] = ((byte)(0x80 | code & 0x3F));
/*     */       }
/*     */       else
/*     */       {
/* 161 */         if ((code < 56320) && (i < end - 1)) {
/* 162 */           int utf32 = s.charAt(i + 1);
/*     */           
/* 164 */           if ((utf32 >= 56320) && (utf32 <= 57343)) {
/* 165 */             utf32 = (code - 55232 << 10) + (utf32 & 0x3FF);
/* 166 */             i++;
/* 167 */             scratch[(upto++)] = ((byte)(0xF0 | utf32 >> 18));
/* 168 */             scratch[(upto++)] = ((byte)(0x80 | utf32 >> 12 & 0x3F));
/* 169 */             scratch[(upto++)] = ((byte)(0x80 | utf32 >> 6 & 0x3F));
/* 170 */             scratch[(upto++)] = ((byte)(0x80 | utf32 & 0x3F));
/* 171 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 176 */         scratch[(upto++)] = -17;
/* 177 */         scratch[(upto++)] = -65;
/* 178 */         scratch[(upto++)] = -67;
/*     */       }
/*     */     }
/*     */     
/* 182 */     totalBytes += upto;
/* 183 */     fos.write(scratch, 0, upto);
/*     */     
/* 185 */     return totalBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int calcUTF16toUTF8Length(CharSequence s, int offset, int len)
/*     */   {
/* 194 */     int end = offset + len;
/*     */     
/* 196 */     int res = 0;
/* 197 */     for (int i = offset; i < end; i++) {
/* 198 */       int code = s.charAt(i);
/*     */       
/* 200 */       if (code < 128) {
/* 201 */         res++;
/* 202 */       } else if (code < 2048) {
/* 203 */         res += 2;
/* 204 */       } else if ((code < 55296) || (code > 57343)) {
/* 205 */         res += 3;
/*     */       }
/*     */       else
/*     */       {
/* 209 */         if ((code < 56320) && (i < end - 1)) {
/* 210 */           int utf32 = s.charAt(i + 1);
/*     */           
/* 212 */           if ((utf32 >= 56320) && (utf32 <= 57343)) {
/* 213 */             i++;
/* 214 */             res += 4;
/* 215 */             continue;
/*     */           }
/*     */         }
/* 218 */         res += 3;
/*     */       }
/*     */     }
/*     */     
/* 222 */     return res;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\ByteUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */