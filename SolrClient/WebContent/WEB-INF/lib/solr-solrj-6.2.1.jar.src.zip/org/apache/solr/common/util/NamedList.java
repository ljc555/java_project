/*     */ package org.apache.solr.common.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedList<T>
/*     */   implements Cloneable, Serializable, Iterable<Map.Entry<String, T>>
/*     */ {
/*     */   private static final long serialVersionUID = 1957981902839867821L;
/*     */   protected final List<Object> nvPairs;
/*     */   
/*     */   public NamedList()
/*     */   {
/*  65 */     this.nvPairs = new ArrayList();
/*     */   }
/*     */   
/*     */   public NamedList(int sz)
/*     */   {
/*  70 */     this.nvPairs = new ArrayList(sz << 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedList(Map.Entry<String, ? extends T>[] nameValuePairs)
/*     */   {
/*  88 */     this.nvPairs = nameValueMapToList(nameValuePairs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedList(Map<String, ? extends T> nameValueMap)
/*     */   {
/* 105 */     if (null == nameValueMap) {
/* 106 */       this.nvPairs = new ArrayList();
/*     */     } else {
/* 108 */       this.nvPairs = new ArrayList(nameValueMap.size());
/* 109 */       for (Map.Entry<String, ? extends T> ent : nameValueMap.entrySet()) {
/* 110 */         this.nvPairs.add(ent.getKey());
/* 111 */         this.nvPairs.add(ent.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public NamedList(List<Object> nameValuePairs)
/*     */   {
/* 130 */     this.nvPairs = nameValuePairs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   private List<Object> nameValueMapToList(Map.Entry<String, ? extends T>[] nameValuePairs)
/*     */   {
/* 145 */     List<Object> result = new ArrayList();
/* 146 */     for (Map.Entry<String, ?> ent : nameValuePairs) {
/* 147 */       result.add(ent.getKey());
/* 148 */       result.add(ent.getValue());
/*     */     }
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 155 */     return this.nvPairs.size() >> 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName(int idx)
/*     */   {
/* 164 */     return (String)this.nvPairs.get(idx << 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T getVal(int idx)
/*     */   {
/* 174 */     return (T)this.nvPairs.get((idx << 1) + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void add(String name, T val)
/*     */   {
/* 181 */     this.nvPairs.add(name);
/* 182 */     this.nvPairs.add(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setName(int idx, String name)
/*     */   {
/* 189 */     this.nvPairs.set(idx << 1, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T setVal(int idx, T val)
/*     */   {
/* 198 */     int index = (idx << 1) + 1;
/*     */     
/* 200 */     T old = this.nvPairs.get(index);
/* 201 */     this.nvPairs.set(index, val);
/* 202 */     return old;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T remove(int idx)
/*     */   {
/* 211 */     int index = idx << 1;
/* 212 */     this.nvPairs.remove(index);
/*     */     
/* 214 */     T result = this.nvPairs.remove(index);
/* 215 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(String name, int start)
/*     */   {
/* 227 */     int sz = size();
/* 228 */     for (int i = start; i < sz; i++) {
/* 229 */       String n = getName(i);
/* 230 */       if (name == null) {
/* 231 */         if (n == null) return i;
/* 232 */       } else if (name.equals(n)) {
/* 233 */         return i;
/*     */       }
/*     */     }
/* 236 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T get(String name)
/*     */   {
/* 253 */     return (T)get(name, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T get(String name, int start)
/*     */   {
/* 268 */     int sz = size();
/* 269 */     for (int i = start; i < sz; i++) {
/* 270 */       String n = getName(i);
/* 271 */       if (name == null) {
/* 272 */         if (n == null) return (T)getVal(i);
/* 273 */       } else if (name.equals(n)) {
/* 274 */         return (T)getVal(i);
/*     */       }
/*     */     }
/* 277 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<T> getAll(String name)
/*     */   {
/* 287 */     List<T> result = new ArrayList();
/* 288 */     int sz = size();
/* 289 */     for (int i = 0; i < sz; i++) {
/* 290 */       String n = getName(i);
/* 291 */       if ((name == n) || ((name != null) && (name.equals(n)))) {
/* 292 */         result.add(getVal(i));
/*     */       }
/*     */     }
/* 295 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void killAll(String name)
/*     */   {
/* 304 */     int sz = size();
/*     */     
/* 306 */     for (int i = sz - 1; i >= 0; i--) {
/* 307 */       String n = getName(i);
/* 308 */       if ((name == n) || ((name != null) && (name.equals(n)))) {
/* 309 */         remove(i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object findRecursive(String... args)
/*     */   {
/* 340 */     NamedList<?> currentList = null;
/* 341 */     Object value = null;
/* 342 */     for (int i = 0; i < args.length; i++) {
/* 343 */       String key = args[i];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 359 */       if (currentList == null) {
/* 360 */         currentList = this;
/*     */       }
/* 362 */       else if ((value instanceof NamedList)) {
/* 363 */         currentList = (NamedList)value;
/*     */       } else {
/* 365 */         value = null;
/* 366 */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 374 */       value = currentList.get(key, 0);
/*     */     }
/* 376 */     return value;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 381 */     StringBuilder sb = new StringBuilder();
/* 382 */     sb.append('{');
/* 383 */     int sz = size();
/* 384 */     for (int i = 0; i < sz; i++) {
/* 385 */       if (i != 0) sb.append(',');
/* 386 */       sb.append(getName(i));
/* 387 */       sb.append('=');
/* 388 */       sb.append(getVal(i));
/*     */     }
/* 390 */     sb.append('}');
/*     */     
/* 392 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public NamedList getImmutableCopy() {
/* 396 */     NamedList copy = clone();
/* 397 */     return new NamedList(Collections.unmodifiableList(copy.nvPairs));
/*     */   }
/*     */   
/*     */   public Map<String, T> asShallowMap() {
/* 401 */     new Map()
/*     */     {
/*     */       public int size() {
/* 404 */         return NamedList.this.size();
/*     */       }
/*     */       
/*     */       public boolean isEmpty()
/*     */       {
/* 409 */         return size() == 0;
/*     */       }
/*     */       
/*     */       public boolean containsKey(Object key) {
/* 413 */         return NamedList.this.get((String)key) != null;
/*     */       }
/*     */       
/*     */       public boolean containsValue(Object value)
/*     */       {
/* 418 */         return false;
/*     */       }
/*     */       
/*     */       public T get(Object key)
/*     */       {
/* 423 */         return (T)NamedList.this.get((String)key);
/*     */       }
/*     */       
/*     */       public T put(String key, T value)
/*     */       {
/* 428 */         NamedList.this.add(key, value);
/* 429 */         return null;
/*     */       }
/*     */       
/*     */       public T remove(Object key)
/*     */       {
/* 434 */         return (T)NamedList.this.remove((String)key);
/*     */       }
/*     */       
/*     */       public void putAll(Map m)
/*     */       {
/* 439 */         NamedList.this.addAll(m);
/*     */       }
/*     */       
/*     */ 
/*     */       public void clear()
/*     */       {
/* 445 */         NamedList.this.clear();
/*     */       }
/*     */       
/*     */ 
/*     */       public Set<String> keySet()
/*     */       {
/* 451 */         return NamedList.this.asMap(1).keySet();
/*     */       }
/*     */       
/*     */ 
/*     */       public Collection values()
/*     */       {
/* 457 */         return NamedList.this.asMap(1).values();
/*     */       }
/*     */       
/*     */ 
/*     */       public Set<Map.Entry<String, T>> entrySet()
/*     */       {
/* 463 */         return NamedList.this.asMap(1).entrySet();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public Map asMap(int maxDepth) {
/* 469 */     LinkedHashMap result = new LinkedHashMap();
/* 470 */     for (int i = 0; i < size(); i++) {
/* 471 */       Object val = getVal(i);
/* 472 */       if (((val instanceof NamedList)) && (maxDepth > 0))
/*     */       {
/* 474 */         val = ((NamedList)val).asMap(maxDepth - 1);
/*     */       }
/* 476 */       Object old = result.put(getName(i), val);
/* 477 */       if (old != null) {
/* 478 */         if ((old instanceof List)) {
/* 479 */           List list = (List)old;
/* 480 */           list.add(val);
/* 481 */           result.put(getName(i), old);
/*     */         } else {
/* 483 */           ArrayList l = new ArrayList();
/* 484 */           l.add(old);
/* 485 */           l.add(val);
/* 486 */           result.put(getName(i), l);
/*     */         }
/*     */       }
/*     */     }
/* 490 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public static final class NamedListEntry<T>
/*     */     implements Map.Entry<String, T>
/*     */   {
/*     */     private String key;
/*     */     
/*     */     private T value;
/*     */     
/*     */     public NamedListEntry() {}
/*     */     
/*     */     public NamedListEntry(String _key, T _value)
/*     */     {
/* 505 */       this.key = _key;
/* 506 */       this.value = _value;
/*     */     }
/*     */     
/*     */     public String getKey()
/*     */     {
/* 511 */       return this.key;
/*     */     }
/*     */     
/*     */     public T getValue()
/*     */     {
/* 516 */       return (T)this.value;
/*     */     }
/*     */     
/*     */     public T setValue(T _value)
/*     */     {
/* 521 */       T oldValue = this.value;
/* 522 */       this.value = _value;
/* 523 */       return oldValue;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addAll(Map<String, T> args)
/*     */   {
/* 535 */     for (Map.Entry<String, T> entry : args.entrySet()) {
/* 536 */       add((String)entry.getKey(), entry.getValue());
/*     */     }
/* 538 */     return args.size() > 0;
/*     */   }
/*     */   
/*     */   public boolean addAll(NamedList<T> nl)
/*     */   {
/* 543 */     this.nvPairs.addAll(nl.nvPairs);
/* 544 */     return nl.size() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedList<T> clone()
/*     */   {
/* 552 */     ArrayList<Object> newList = new ArrayList(this.nvPairs.size());
/* 553 */     newList.addAll(this.nvPairs);
/* 554 */     return new NamedList(newList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Map.Entry<String, T>> iterator()
/*     */   {
/* 567 */     final NamedList<T> list = this;
/*     */     
/* 569 */     Iterator<Map.Entry<String, T>> iter = new Iterator()
/*     */     {
/* 571 */       int idx = 0;
/*     */       
/*     */       public boolean hasNext()
/*     */       {
/* 575 */         return this.idx < list.size();
/*     */       }
/*     */       
/*     */       public Map.Entry<String, T> next()
/*     */       {
/* 580 */         final int index = this.idx++;
/* 581 */         Map.Entry<String, T> nv = new Map.Entry()
/*     */         {
/*     */           public String getKey() {
/* 584 */             return NamedList.2.this.val$list.getName(index);
/*     */           }
/*     */           
/*     */           public T getValue()
/*     */           {
/* 589 */             return (T)NamedList.2.this.val$list.getVal(index);
/*     */           }
/*     */           
/*     */           public String toString()
/*     */           {
/* 594 */             return getKey() + "=" + getValue();
/*     */           }
/*     */           
/*     */           public T setValue(T value)
/*     */           {
/* 599 */             return (T)NamedList.2.this.val$list.setVal(index, value);
/*     */           }
/* 601 */         };
/* 602 */         return nv;
/*     */       }
/*     */       
/*     */       public void remove()
/*     */       {
/* 607 */         throw new UnsupportedOperationException();
/*     */       }
/* 609 */     };
/* 610 */     return iter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T remove(String name)
/*     */   {
/* 619 */     int idx = indexOf(name, 0);
/* 620 */     if (idx != -1) return (T)remove(idx);
/* 621 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<T> removeAll(String name)
/*     */   {
/* 635 */     List<T> result = new ArrayList();
/* 636 */     result = getAll(name);
/* 637 */     if (result.size() > 0) {
/* 638 */       killAll(name);
/* 639 */       return result;
/*     */     }
/* 641 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean removeBooleanArg(String name)
/*     */   {
/* 662 */     Boolean bool = getBooleanArg(name);
/* 663 */     if (null != bool) {
/* 664 */       remove(name);
/*     */     }
/* 666 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getBooleanArg(String name)
/*     */   {
/* 687 */     List<T> values = getAll(name);
/* 688 */     if (0 == values.size()) {
/* 689 */       return null;
/*     */     }
/* 691 */     if (values.size() > 1) {
/* 692 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "Only one '" + name + "' is allowed");
/*     */     }
/*     */     
/* 695 */     Object o = get(name);
/* 696 */     Boolean bool; if ((o instanceof Boolean)) {
/* 697 */       bool = (Boolean)o; } else { Boolean bool;
/* 698 */       if ((o instanceof CharSequence)) {
/* 699 */         bool = Boolean.valueOf(Boolean.parseBoolean(o.toString()));
/*     */       }
/*     */       else
/* 702 */         throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "'" + name + "' must have type Boolean or CharSequence; found " + o.getClass()); }
/*     */     Boolean bool;
/* 704 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> removeConfigArgs(String name)
/*     */     throws SolrException
/*     */   {
/* 731 */     List<T> objects = getAll(name);
/* 732 */     List<String> collection = new ArrayList(size() / 2);
/* 733 */     String err = "init arg '" + name + "' must be a string (ie: 'str'), or an array (ie: 'arr') containing strings; found: ";
/*     */     
/*     */ 
/* 736 */     for (Object o : objects) {
/* 737 */       if ((o instanceof String)) {
/* 738 */         collection.add((String)o);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 743 */         if ((o instanceof Object[])) {
/* 744 */           o = Arrays.asList((Object[])o);
/*     */         }
/*     */         
/*     */ 
/* 748 */         if ((o instanceof Collection)) {
/* 749 */           for (Object item : (Collection)o) {
/* 750 */             if (!(item instanceof String)) {
/* 751 */               throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, err + item.getClass());
/*     */             }
/* 753 */             collection.add((String)item);
/*     */           }
/*     */           
/*     */         } else
/* 757 */           throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, err + o.getClass());
/*     */       }
/*     */     }
/* 760 */     if (collection.size() > 0) {
/* 761 */       killAll(name);
/*     */     }
/*     */     
/* 764 */     return collection;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 768 */     this.nvPairs.clear();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 773 */     return this.nvPairs.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 778 */     if (!(obj instanceof NamedList)) return false;
/* 779 */     NamedList<?> nl = (NamedList)obj;
/* 780 */     return this.nvPairs.equals(nl.nvPairs);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\NamedList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */