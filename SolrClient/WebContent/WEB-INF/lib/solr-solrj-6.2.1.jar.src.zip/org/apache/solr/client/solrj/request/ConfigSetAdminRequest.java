/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.solr.client.solrj.SolrClient;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.response.ConfigSetAdminResponse;
/*     */ import org.apache.solr.client.solrj.response.ConfigSetAdminResponse.List;
/*     */ import org.apache.solr.common.params.ConfigSetParams.ConfigSetAction;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConfigSetAdminRequest<Q extends ConfigSetAdminRequest<Q, R>, R extends ConfigSetAdminResponse>
/*     */   extends SolrRequest<R>
/*     */ {
/*  44 */   protected ConfigSetParams.ConfigSetAction action = null;
/*     */   
/*     */   protected ConfigSetAdminRequest setAction(ConfigSetParams.ConfigSetAction action) {
/*  47 */     this.action = action;
/*  48 */     return this;
/*     */   }
/*     */   
/*     */   public ConfigSetAdminRequest() {
/*  52 */     super(SolrRequest.METHOD.GET, "/admin/configs");
/*     */   }
/*     */   
/*     */   public ConfigSetAdminRequest(String path) {
/*  56 */     super(SolrRequest.METHOD.GET, path);
/*     */   }
/*     */   
/*     */   protected abstract Q getThis();
/*     */   
/*     */   public SolrParams getParams()
/*     */   {
/*  63 */     if (this.action == null) {
/*  64 */       throw new RuntimeException("no action specified!");
/*     */     }
/*  66 */     ModifiableSolrParams params = new ModifiableSolrParams();
/*  67 */     params.set("action", new String[] { this.action.toString() });
/*  68 */     return params;
/*     */   }
/*     */   
/*     */   public Collection<ContentStream> getContentStreams() throws IOException
/*     */   {
/*  73 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract R createResponse(SolrClient paramSolrClient);
/*     */   
/*     */   protected static abstract class ConfigSetSpecificAdminRequest<T extends ConfigSetAdminRequest<T, ConfigSetAdminResponse>>
/*     */     extends ConfigSetAdminRequest<T, ConfigSetAdminResponse>
/*     */   {
/*  82 */     protected String configSetName = null;
/*     */     
/*     */     public final T setConfigSetName(String configSetName) {
/*  85 */       this.configSetName = configSetName;
/*  86 */       return getThis();
/*     */     }
/*     */     
/*     */     public final String getConfigSetName() {
/*  90 */       return this.configSetName;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/*  95 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/*  96 */       if (this.configSetName == null) {
/*  97 */         throw new RuntimeException("no ConfigSet specified!");
/*     */       }
/*  99 */       params.set("name", new String[] { this.configSetName });
/* 100 */       return params;
/*     */     }
/*     */     
/*     */     protected ConfigSetAdminResponse createResponse(SolrClient client)
/*     */     {
/* 105 */       return new ConfigSetAdminResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Create extends ConfigSetAdminRequest.ConfigSetSpecificAdminRequest<Create>
/*     */   {
/* 111 */     protected static String PROPERTY_PREFIX = "configSetProp";
/*     */     protected String baseConfigSetName;
/*     */     protected Properties properties;
/*     */     
/*     */     public Create() {
/* 116 */       this.action = ConfigSetParams.ConfigSetAction.CREATE;
/*     */     }
/*     */     
/*     */     protected Create getThis()
/*     */     {
/* 121 */       return this;
/*     */     }
/*     */     
/*     */     public final Create setBaseConfigSetName(String baseConfigSetName) {
/* 125 */       this.baseConfigSetName = baseConfigSetName;
/* 126 */       return getThis();
/*     */     }
/*     */     
/*     */     public final String getBaseConfigSetName() {
/* 130 */       return this.baseConfigSetName;
/*     */     }
/*     */     
/*     */     public final Create setNewConfigSetProperties(Properties properties) {
/* 134 */       this.properties = properties;
/* 135 */       return getThis();
/*     */     }
/*     */     
/*     */     public final Properties getNewConfigSetProperties() {
/* 139 */       return this.properties;
/*     */     }
/*     */     
/*     */     public SolrParams getParams()
/*     */     {
/* 144 */       ModifiableSolrParams params = new ModifiableSolrParams(super.getParams());
/* 145 */       if (this.baseConfigSetName == null) {
/* 146 */         throw new RuntimeException("no Base ConfigSet specified!");
/*     */       }
/* 148 */       params.set("baseConfigSet", new String[] { this.baseConfigSetName });
/* 149 */       if (this.properties != null) {
/* 150 */         for (Map.Entry entry : this.properties.entrySet()) {
/* 151 */           params.set(PROPERTY_PREFIX + "." + entry.getKey().toString(), new String[] {entry
/* 152 */             .getValue().toString() });
/*     */         }
/*     */       }
/* 155 */       return params;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Delete extends ConfigSetAdminRequest.ConfigSetSpecificAdminRequest<Delete>
/*     */   {
/*     */     public Delete() {
/* 162 */       this.action = ConfigSetParams.ConfigSetAction.DELETE;
/*     */     }
/*     */     
/*     */     protected Delete getThis()
/*     */     {
/* 167 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class List extends ConfigSetAdminRequest<List, ConfigSetAdminResponse.List>
/*     */   {
/*     */     public List() {
/* 174 */       this.action = ConfigSetParams.ConfigSetAction.LIST;
/*     */     }
/*     */     
/*     */     protected List getThis()
/*     */     {
/* 179 */       return this;
/*     */     }
/*     */     
/*     */     protected ConfigSetAdminResponse.List createResponse(SolrClient client)
/*     */     {
/* 184 */       return new ConfigSetAdminResponse.List();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\ConfigSetAdminRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */