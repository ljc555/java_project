package org.apache.solr.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

public abstract interface ContentStream
{
  public abstract String getName();
  
  public abstract String getSourceInfo();
  
  public abstract String getContentType();
  
  public abstract Long getSize();
  
  public abstract InputStream getStream()
    throws IOException;
  
  public abstract Reader getReader()
    throws IOException;
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\ContentStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */