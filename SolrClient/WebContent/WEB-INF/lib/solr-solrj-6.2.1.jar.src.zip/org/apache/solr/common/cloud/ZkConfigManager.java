/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.zookeeper.KeeperException;
/*     */ import org.apache.zookeeper.KeeperException.NoNodeException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZkConfigManager
/*     */ {
/*  39 */   private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   public static final String CONFIGS_ZKNODE = "/configs";
/*     */   
/*     */   public static final String UPLOAD_FILENAME_EXCLUDE_REGEX = "^\\..*$";
/*     */   
/*  45 */   public static final Pattern UPLOAD_FILENAME_EXCLUDE_PATTERN = Pattern.compile("^\\..*$");
/*     */   
/*     */ 
/*     */   private final SolrZkClient zkClient;
/*     */   
/*     */ 
/*     */   public ZkConfigManager(SolrZkClient zkClient)
/*     */   {
/*  53 */     this.zkClient = zkClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void uploadConfigDir(Path dir, String configName)
/*     */     throws IOException
/*     */   {
/*  65 */     this.zkClient.uploadToZK(dir, "/configs/" + configName, UPLOAD_FILENAME_EXCLUDE_PATTERN);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void uploadConfigDir(Path dir, String configName, Pattern filenameExclusions)
/*     */     throws IOException
/*     */   {
/*  78 */     this.zkClient.uploadToZK(dir, "/configs/" + configName, filenameExclusions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void downloadConfigDir(String configName, Path dir)
/*     */     throws IOException
/*     */   {
/*  89 */     this.zkClient.downloadFromZK("/configs/" + configName, dir);
/*     */   }
/*     */   
/*     */   public List<String> listConfigs() throws IOException {
/*     */     try {
/*  94 */       return this.zkClient.getChildren("/configs", null, true);
/*     */     }
/*     */     catch (KeeperException.NoNodeException e) {
/*  97 */       return Collections.emptyList();
/*     */     }
/*     */     catch (KeeperException|InterruptedException e) {
/* 100 */       throw new IOException("Error listing configs", SolrZkClient.checkInterrupted(e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean configExists(String configName)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 113 */       return this.zkClient.exists("/configs/" + configName, true);
/*     */     }
/*     */     catch (KeeperException|InterruptedException e) {
/* 116 */       throw new IOException("Error checking whether config exists", SolrZkClient.checkInterrupted(e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteConfigDir(String configName)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 128 */       this.zkClient.clean("/configs/" + configName);
/*     */     }
/*     */     catch (KeeperException|InterruptedException e) {
/* 131 */       throw new IOException("Error checking whether config exists", SolrZkClient.checkInterrupted(e));
/*     */     }
/*     */   }
/*     */   
/*     */   private void copyConfigDirFromZk(String fromZkPath, String toZkPath, Set<String> copiedToZkPaths) throws IOException {
/*     */     try {
/* 137 */       List<String> files = this.zkClient.getChildren(fromZkPath, null, true);
/* 138 */       for (String file : files) {
/* 139 */         List<String> children = this.zkClient.getChildren(fromZkPath + "/" + file, null, true);
/* 140 */         if (children.size() == 0) {
/* 141 */           String toZkFilePath = toZkPath + "/" + file;
/* 142 */           logger.info("Copying zk node {} to {}", fromZkPath + "/" + file, toZkFilePath);
/*     */           
/* 144 */           byte[] data = this.zkClient.getData(fromZkPath + "/" + file, null, null, true);
/* 145 */           this.zkClient.makePath(toZkFilePath, data, true);
/* 146 */           if (copiedToZkPaths != null) copiedToZkPaths.add(toZkFilePath);
/*     */         } else {
/* 148 */           copyConfigDirFromZk(fromZkPath + "/" + file, toZkPath + "/" + file, copiedToZkPaths);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KeeperException|InterruptedException e) {
/* 153 */       throw new IOException("Error copying nodes from zookeeper path " + fromZkPath + " to " + toZkPath, SolrZkClient.checkInterrupted(e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyConfigDir(String fromConfig, String toConfig)
/*     */     throws IOException
/*     */   {
/* 165 */     copyConfigDir("/configs/" + fromConfig, "/configs/" + toConfig, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyConfigDir(String fromConfig, String toConfig, Set<String> copiedToZkPaths)
/*     */     throws IOException
/*     */   {
/* 178 */     copyConfigDirFromZk("/configs/" + fromConfig, "/configs/" + toConfig, copiedToZkPaths);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Path getConfigsetPath(String confDir, String configSetDir)
/*     */     throws IOException
/*     */   {
/* 195 */     Path ret = Paths.get(confDir, new String[] { "solrconfig.xml" }).normalize();
/* 196 */     if (Files.exists(ret, new LinkOption[0])) {
/* 197 */       return Paths.get(confDir, new String[0]).normalize();
/*     */     }
/*     */     
/*     */ 
/* 201 */     ret = Paths.get(confDir, new String[] { "conf", "solrconfig.xml" }).normalize();
/* 202 */     if (Files.exists(ret, new LinkOption[0])) {
/* 203 */       return Paths.get(confDir, new String[] { "conf" }).normalize();
/*     */     }
/*     */     
/*     */ 
/* 207 */     ret = Paths.get(configSetDir, new String[] { confDir, "conf", "solrconfig.xml" }).normalize();
/* 208 */     if (Files.exists(ret, new LinkOption[0])) {
/* 209 */       return Paths.get(configSetDir, new String[] { confDir, "conf" }).normalize();
/*     */     }
/*     */     
/*     */ 
/* 213 */     throw new IllegalArgumentException(String.format(Locale.ROOT, "Could not find solrconfig.xml at %s, %s or %s", new Object[] {
/*     */     
/* 215 */       Paths.get(configSetDir, new String[] { "solrconfig.xml" }).normalize().toAbsolutePath().toString(), 
/* 216 */       Paths.get(configSetDir, new String[] { "conf", "solrconfig.xml" }).normalize().toAbsolutePath().toString(), 
/* 217 */       Paths.get(configSetDir, new String[] { confDir, "conf", "solrconfig.xml" }).normalize().toAbsolutePath().toString() }));
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkConfigManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */