package org.apache.solr.common;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract class SolrDocumentBase<T, K>
  implements Map<String, T>, Serializable
{
  public abstract Collection<String> getFieldNames();
  
  public abstract void setField(String paramString, Object paramObject);
  
  public abstract void addField(String paramString, Object paramObject);
  
  public abstract Object getFieldValue(String paramString);
  
  public abstract Collection getFieldValues(String paramString);
  
  public abstract void addChildDocument(K paramK);
  
  public abstract void addChildDocuments(Collection<K> paramCollection);
  
  public abstract List<K> getChildDocuments();
  
  public abstract boolean hasChildDocuments();
  
  public abstract int getChildDocumentCount();
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrDocumentBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */