/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.zookeeper.Watcher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ZkClientConnectionStrategy
/*     */ {
/*  35 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   private volatile ZkCredentialsProvider zkCredentialsToAddAutomatically;
/*     */   
/*     */   private volatile boolean zkCredentialsToAddAutomaticallyUsed;
/*  40 */   private List<DisconnectedListener> disconnectedListeners = new ArrayList();
/*  41 */   private List<ConnectedListener> connectedListeners = new ArrayList();
/*     */   
/*     */   public abstract void connect(String paramString, int paramInt, Watcher paramWatcher, ZkUpdate paramZkUpdate) throws IOException, InterruptedException, TimeoutException;
/*     */   
/*     */   public abstract void reconnect(String paramString, int paramInt, Watcher paramWatcher, ZkUpdate paramZkUpdate) throws IOException, InterruptedException, TimeoutException;
/*     */   
/*  47 */   public ZkClientConnectionStrategy() { this.zkCredentialsToAddAutomaticallyUsed = false; }
/*     */   
/*     */   public synchronized void disconnected()
/*     */   {
/*  51 */     for (DisconnectedListener listener : this.disconnectedListeners) {
/*     */       try {
/*  53 */         listener.disconnected();
/*     */       } catch (Exception e) {
/*  55 */         SolrException.log(log, "", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void connected() {
/*  61 */     for (ConnectedListener listener : this.connectedListeners) {
/*     */       try {
/*  63 */         listener.connected();
/*     */       } catch (Exception e) {
/*  65 */         SolrException.log(log, "", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addDisconnectedListener(DisconnectedListener listener)
/*     */   {
/*  80 */     this.disconnectedListeners.add(listener);
/*     */   }
/*     */   
/*     */   public synchronized void addConnectedListener(ConnectedListener listener) {
/*  84 */     this.connectedListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setZkCredentialsToAddAutomatically(ZkCredentialsProvider zkCredentialsToAddAutomatically)
/*     */   {
/*  92 */     if ((this.zkCredentialsToAddAutomaticallyUsed) || (zkCredentialsToAddAutomatically == null))
/*  93 */       throw new RuntimeException("Cannot change zkCredentialsToAddAutomatically after it has been (connect or reconnect was called) used or to null");
/*  94 */     this.zkCredentialsToAddAutomatically = zkCredentialsToAddAutomatically;
/*     */   }
/*     */   
/*     */   public boolean hasZkCredentialsToAddAutomatically() {
/*  98 */     return this.zkCredentialsToAddAutomatically != null;
/*     */   }
/*     */   
/* 101 */   public ZkCredentialsProvider getZkCredentialsToAddAutomatically() { return this.zkCredentialsToAddAutomatically; }
/*     */   
/*     */   protected SolrZooKeeper createSolrZooKeeper(String serverAddress, int zkClientTimeout, Watcher watcher) throws IOException
/*     */   {
/* 105 */     SolrZooKeeper result = new SolrZooKeeper(serverAddress, zkClientTimeout, watcher);
/*     */     
/* 107 */     this.zkCredentialsToAddAutomaticallyUsed = true;
/* 108 */     for (ZkCredentialsProvider.ZkCredentials zkCredentials : this.zkCredentialsToAddAutomatically.getCredentials()) {
/* 109 */       result.addAuthInfo(zkCredentials.getScheme(), zkCredentials.getAuth());
/*     */     }
/*     */     
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   public static abstract class ZkUpdate
/*     */   {
/*     */     public abstract void update(SolrZooKeeper paramSolrZooKeeper)
/*     */       throws InterruptedException, TimeoutException, IOException;
/*     */   }
/*     */   
/*     */   public static abstract interface ConnectedListener
/*     */   {
/*     */     public abstract void connected();
/*     */   }
/*     */   
/*     */   public static abstract interface DisconnectedListener
/*     */   {
/*     */     public abstract void disconnected();
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkClientConnectionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */