package org.apache.solr.client.solrj.io.ops;

import org.apache.solr.client.solrj.io.Tuple;

public abstract interface ReduceOperation
  extends StreamOperation
{
  public abstract Tuple reduce();
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\ops\ReduceOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */