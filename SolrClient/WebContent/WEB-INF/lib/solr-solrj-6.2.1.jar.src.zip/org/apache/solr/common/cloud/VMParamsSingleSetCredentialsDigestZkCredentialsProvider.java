/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.apache.solr.common.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VMParamsSingleSetCredentialsDigestZkCredentialsProvider
/*    */   extends DefaultZkCredentialsProvider
/*    */ {
/*    */   public static final String DEFAULT_DIGEST_USERNAME_VM_PARAM_NAME = "zkDigestUsername";
/*    */   public static final String DEFAULT_DIGEST_PASSWORD_VM_PARAM_NAME = "zkDigestPassword";
/*    */   final String zkDigestUsernameVMParamName;
/*    */   final String zkDigestPasswordVMParamName;
/*    */   
/*    */   public VMParamsSingleSetCredentialsDigestZkCredentialsProvider()
/*    */   {
/* 35 */     this("zkDigestUsername", "zkDigestPassword");
/*    */   }
/*    */   
/*    */   public VMParamsSingleSetCredentialsDigestZkCredentialsProvider(String zkDigestUsernameVMParamName, String zkDigestPasswordVMParamName) {
/* 39 */     this.zkDigestUsernameVMParamName = zkDigestUsernameVMParamName;
/* 40 */     this.zkDigestPasswordVMParamName = zkDigestPasswordVMParamName;
/*    */   }
/*    */   
/*    */   protected Collection<ZkCredentialsProvider.ZkCredentials> createCredentials()
/*    */   {
/* 45 */     List<ZkCredentialsProvider.ZkCredentials> result = new ArrayList();
/* 46 */     String digestUsername = System.getProperty(this.zkDigestUsernameVMParamName);
/* 47 */     String digestPassword = System.getProperty(this.zkDigestPasswordVMParamName);
/* 48 */     if ((!StringUtils.isEmpty(digestUsername)) && (!StringUtils.isEmpty(digestPassword))) {
/*    */       try {
/* 50 */         result.add(new ZkCredentialsProvider.ZkCredentials("digest", (digestUsername + ":" + digestPassword).getBytes("UTF-8")));
/*    */       } catch (UnsupportedEncodingException e) {
/* 52 */         throw new RuntimeException(e);
/*    */       }
/*    */     }
/* 55 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\VMParamsSingleSetCredentialsDigestZkCredentialsProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */