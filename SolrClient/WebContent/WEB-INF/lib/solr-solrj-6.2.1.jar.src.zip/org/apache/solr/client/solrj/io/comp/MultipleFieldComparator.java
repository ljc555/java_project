/*     */ package org.apache.solr.client.solrj.io.comp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleFieldComparator
/*     */   implements StreamComparator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   private UUID comparatorNodeId = UUID.randomUUID();
/*     */   private StreamComparator[] comps;
/*     */   
/*     */   public MultipleFieldComparator(StreamComparator... comps)
/*     */   {
/*  44 */     this.comps = comps;
/*     */   }
/*     */   
/*     */   public StreamComparator[] getComps() {
/*  48 */     return this.comps;
/*     */   }
/*     */   
/*     */   public int compare(Tuple t1, Tuple t2) {
/*  52 */     for (StreamComparator comp : this.comps) {
/*  53 */       int i = comp.compare(t1, t2);
/*  54 */       if (i != 0) {
/*  55 */         return i;
/*     */       }
/*     */     }
/*     */     
/*  59 */     return 0;
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*     */   {
/*  64 */     StringBuilder sb = new StringBuilder();
/*  65 */     for (StreamComparator comp : this.comps) {
/*  66 */       if ((comp instanceof Expressible)) {
/*  67 */         if (sb.length() > 0) sb.append(",");
/*  68 */         sb.append(comp.toExpression(factory));
/*     */       }
/*     */       else {
/*  71 */         throw new IOException("This MultiComp contains a non-expressible comparator - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     
/*  75 */     return new StreamExpressionValue(sb.toString());
/*     */   }
/*     */   
/*     */   public boolean isDerivedFrom(StreamComparator base)
/*     */   {
/*  80 */     if (null == base) return false;
/*  81 */     if ((base instanceof MultipleFieldComparator)) {
/*  82 */       MultipleFieldComparator baseComp = (MultipleFieldComparator)base;
/*     */       
/*  84 */       if (baseComp.comps.length >= this.comps.length) {
/*  85 */         for (int idx = 0; idx < this.comps.length; idx++) {
/*  86 */           if (!this.comps[idx].isDerivedFrom(baseComp.comps[idx])) {
/*  87 */             return false;
/*     */           }
/*     */         }
/*     */         
/*  91 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/* 100 */     return 
/*     */     
/*     */ 
/* 103 */       new Explanation(this.comparatorNodeId.toString()).withExpressionType("sorter").withImplementingClass(getClass().getName()).withExpression(toExpression(factory).toString());
/*     */   }
/*     */   
/*     */   public MultipleFieldComparator copyAliased(Map<String, String> aliases)
/*     */   {
/* 108 */     StreamComparator[] aliasedComps = new StreamComparator[this.comps.length];
/*     */     
/* 110 */     for (int idx = 0; idx < this.comps.length; idx++) {
/* 111 */       aliasedComps[idx] = this.comps[idx].copyAliased(aliases);
/*     */     }
/*     */     
/* 114 */     return new MultipleFieldComparator(aliasedComps);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\comp\MultipleFieldComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */