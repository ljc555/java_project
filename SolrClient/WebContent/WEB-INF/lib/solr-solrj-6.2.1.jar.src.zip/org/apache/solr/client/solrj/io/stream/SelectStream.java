/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.ops.StreamOperation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private TupleStream stream;
/*     */   private Map<String, String> selectedFields;
/*     */   private List<StreamOperation> operations;
/*     */   
/*     */   public SelectStream(TupleStream stream, List<String> selectedFields)
/*     */     throws IOException
/*     */   {
/*  53 */     this.stream = stream;
/*  54 */     this.selectedFields = new HashMap();
/*  55 */     for (String selectedField : selectedFields) {
/*  56 */       this.selectedFields.put(selectedField, selectedField);
/*     */     }
/*  58 */     this.operations = new ArrayList();
/*     */   }
/*     */   
/*     */   public SelectStream(TupleStream stream, Map<String, String> selectedFields) throws IOException {
/*  62 */     this.stream = stream;
/*  63 */     this.selectedFields = selectedFields;
/*  64 */     this.operations = new ArrayList();
/*     */   }
/*     */   
/*     */   public SelectStream(StreamExpression expression, StreamFactory factory) throws IOException
/*     */   {
/*  69 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  70 */     List<StreamExpressionParameter> selectFieldsExpressions = factory.getOperandsOfType(expression, new Class[] { StreamExpressionValue.class });
/*  71 */     List<StreamExpression> operationExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { StreamOperation.class });
/*     */     
/*     */ 
/*  74 */     if (expression.getParameters().size() != streamExpressions.size() + selectFieldsExpressions.size() + operationExpressions.size()) {
/*  75 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*  78 */     if (1 != streamExpressions.size()) {
/*  79 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single stream but found %d (must be TupleStream types)", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  82 */     if (0 == selectFieldsExpressions.size()) {
/*  83 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting at least one select field but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/*     */     
/*  86 */     this.stream = factory.constructStream((StreamExpression)streamExpressions.get(0));
/*     */     
/*  88 */     this.selectedFields = new HashMap(selectFieldsExpressions.size());
/*  89 */     for (StreamExpressionParameter parameter : selectFieldsExpressions) {
/*  90 */       StreamExpressionValue selectField = (StreamExpressionValue)parameter;
/*  91 */       String value = selectField.getValue().trim();
/*     */       
/*     */ 
/*  94 */       if ((value.length() > 2) && (value.startsWith("\"")) && (value.endsWith("\""))) {
/*  95 */         value = value.substring(1, value.length() - 1);
/*     */       }
/*  97 */       if (value.toLowerCase(Locale.ROOT).contains(" as ")) {
/*  98 */         String[] parts = value.split("(?i) as ");
/*  99 */         if (2 != parts.length) {
/* 100 */           throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting select field of form 'fieldA' or 'fieldA as alias' but found %s", new Object[] { expression, value }));
/*     */         }
/* 102 */         this.selectedFields.put(parts[0].trim(), parts[1].trim());
/*     */       }
/*     */       else {
/* 105 */         this.selectedFields.put(value, value);
/*     */       }
/*     */     }
/*     */     
/* 109 */     this.operations = new ArrayList();
/* 110 */     for (StreamExpression expr : operationExpressions) {
/* 111 */       this.operations.add(factory.constructOperation(expr));
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 117 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 122 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/* 124 */     if (includeStreams)
/*     */     {
/* 126 */       if ((this.stream instanceof Expressible)) {
/* 127 */         expression.addParameter(((Expressible)this.stream).toExpression(factory));
/*     */       }
/*     */       else {
/* 130 */         throw new IOException("This SelectStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     else {
/* 134 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 138 */     for (Map.Entry<String, String> selectField : this.selectedFields.entrySet()) {
/* 139 */       if (((String)selectField.getKey()).equals(selectField.getValue())) {
/* 140 */         expression.addParameter((String)selectField.getKey());
/*     */       }
/*     */       else {
/* 143 */         expression.addParameter(String.format(Locale.ROOT, "%s as %s", new Object[] { selectField.getKey(), selectField.getValue() }));
/*     */       }
/*     */     }
/*     */     
/* 147 */     for (StreamOperation operation : this.operations) {
/* 148 */       expression.addParameter(operation.toExpression(factory));
/*     */     }
/*     */     
/* 151 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 164 */     Explanation explanation = new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.stream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString());
/*     */     
/* 166 */     for (StreamOperation operation : this.operations) {
/* 167 */       explanation.addHelper(operation.toExplanation(factory));
/*     */     }
/*     */     
/* 170 */     return explanation;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 174 */     this.stream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 178 */     List<TupleStream> l = new ArrayList();
/* 179 */     l.add(this.stream);
/* 180 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 184 */     this.stream.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 188 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException {
/* 192 */     Tuple original = this.stream.read();
/*     */     
/* 194 */     if (original.EOF) {
/* 195 */       return original;
/*     */     }
/*     */     
/*     */ 
/* 199 */     Tuple working = new Tuple(new HashMap());
/* 200 */     for (Object fieldName : original.fields.keySet()) {
/* 201 */       if (this.selectedFields.containsKey(fieldName)) {
/* 202 */         working.put(this.selectedFields.get(fieldName), original.get(fieldName));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 207 */     for (StreamOperation operation : this.operations) {
/* 208 */       operation.operate(working);
/*     */     }
/*     */     
/* 211 */     return working;
/*     */   }
/*     */   
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 217 */     return this.stream.getStreamSort().copyAliased(this.selectedFields);
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 221 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\SelectStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */