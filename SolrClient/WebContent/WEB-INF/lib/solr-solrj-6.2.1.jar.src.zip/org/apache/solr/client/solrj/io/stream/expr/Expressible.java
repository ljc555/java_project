package org.apache.solr.client.solrj.io.stream.expr;

import java.io.IOException;

public abstract interface Expressible
{
  public abstract StreamExpressionParameter toExpression(StreamFactory paramStreamFactory)
    throws IOException;
  
  public abstract Explanation toExplanation(StreamFactory paramStreamFactory)
    throws IOException;
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\expr\Expressible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */