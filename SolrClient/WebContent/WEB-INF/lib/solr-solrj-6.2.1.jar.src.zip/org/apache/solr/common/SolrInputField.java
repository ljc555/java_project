/*     */ package org.apache.solr.common;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SolrInputField
/*     */   implements Iterable<Object>, Serializable
/*     */ {
/*     */   String name;
/*  31 */   Object value = null;
/*  32 */   float boost = 1.0F;
/*     */   
/*     */   public SolrInputField(String n)
/*     */   {
/*  36 */     this.name = n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object v, float b)
/*     */   {
/*  48 */     this.boost = b;
/*     */     
/*  50 */     if ((v instanceof Object[])) {
/*  51 */       Object[] arr = (Object[])v;
/*  52 */       Collection<Object> c = new ArrayList(arr.length);
/*  53 */       for (Object o : arr) {
/*  54 */         c.add(o);
/*     */       }
/*  56 */       this.value = c;
/*     */     }
/*     */     else {
/*  59 */       this.value = v;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addValue(Object v, float b)
/*     */   {
/*     */     Object localObject1;
/*     */     
/*  69 */     if (this.value == null) {
/*  70 */       if ((v instanceof Collection)) {
/*  71 */         Collection<Object> c = new ArrayList(3);
/*  72 */         for (localObject1 = ((Collection)v).iterator(); ((Iterator)localObject1).hasNext();) { Object o = ((Iterator)localObject1).next();
/*  73 */           c.add(o);
/*     */         }
/*  75 */         setValue(c, b);
/*     */       } else {
/*  77 */         setValue(v, b);
/*     */       }
/*     */       
/*  80 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */     this.boost *= b;
/*     */     
/*  89 */     Collection<Object> vals = null;
/*  90 */     if ((this.value instanceof Collection)) {
/*  91 */       vals = (Collection)this.value;
/*     */     }
/*     */     else {
/*  94 */       vals = new ArrayList(3);
/*  95 */       vals.add(this.value);
/*  96 */       this.value = vals;
/*     */     }
/*     */     
/*     */     Object o;
/* 100 */     if ((v instanceof Iterable)) {
/* 101 */       for (localObject1 = ((Iterable)v).iterator(); ((Iterator)localObject1).hasNext();) { o = ((Iterator)localObject1).next();
/* 102 */         vals.add(o);
/*     */       }
/*     */     }
/* 105 */     else if ((v instanceof Object[])) {
/* 106 */       localObject1 = (Object[])v;o = localObject1.length; for (Object localObject2 = 0; localObject2 < o; localObject2++) { Object o = localObject1[localObject2];
/* 107 */         vals.add(o);
/*     */       }
/*     */     }
/*     */     else {
/* 111 */       vals.add(v);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getFirstValue()
/*     */   {
/* 120 */     if ((this.value instanceof Collection)) {
/* 121 */       Collection c = (Collection)this.value;
/* 122 */       if (c.size() > 0) {
/* 123 */         return c.iterator().next();
/*     */       }
/* 125 */       return null;
/*     */     }
/* 127 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 135 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<Object> getValues()
/*     */   {
/* 144 */     if ((this.value instanceof Collection)) {
/* 145 */       return (Collection)this.value;
/*     */     }
/* 147 */     if (this.value != null) {
/* 148 */       Collection<Object> vals = new ArrayList(1);
/* 149 */       vals.add(this.value);
/* 150 */       return vals;
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getValueCount()
/*     */   {
/* 159 */     if ((this.value instanceof Collection)) {
/* 160 */       return ((Collection)this.value).size();
/*     */     }
/* 162 */     return this.value == null ? 0 : 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public float getBoost()
/*     */   {
/* 169 */     return this.boost;
/*     */   }
/*     */   
/*     */   public void setBoost(float boost) {
/* 173 */     this.boost = boost;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 177 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 181 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator<Object> iterator()
/*     */   {
/* 187 */     if ((this.value instanceof Collection)) {
/* 188 */       return ((Collection)this.value).iterator();
/*     */     }
/* 190 */     new Iterator() {
/* 191 */       boolean nxt = SolrInputField.this.value != null;
/*     */       
/*     */       public boolean hasNext()
/*     */       {
/* 195 */         return this.nxt;
/*     */       }
/*     */       
/*     */       public Object next()
/*     */       {
/* 200 */         this.nxt = false;
/* 201 */         return SolrInputField.this.value;
/*     */       }
/*     */       
/*     */       public void remove()
/*     */       {
/* 206 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 214 */     return this.name + (this.boost == 1.0D ? "=" : new StringBuilder().append("(").append(this.boost).append(")=").toString()) + this.value;
/*     */   }
/*     */   
/*     */   public SolrInputField deepCopy() {
/* 218 */     SolrInputField clone = new SolrInputField(this.name);
/* 219 */     clone.boost = this.boost;
/*     */     
/* 221 */     if ((this.value instanceof Collection)) {
/* 222 */       Collection<Object> values = (Collection)this.value;
/* 223 */       Collection<Object> cloneValues = new ArrayList(values.size());
/* 224 */       cloneValues.addAll(values);
/* 225 */       clone.value = cloneValues;
/*     */     } else {
/* 227 */       clone.value = this.value;
/*     */     }
/* 229 */     return clone;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrInputField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */