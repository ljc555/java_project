/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrjNamedThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/* 23 */   private static final AtomicInteger poolNumber = new AtomicInteger(1);
/*    */   private final ThreadGroup group;
/* 25 */   private final AtomicInteger threadNumber = new AtomicInteger(1);
/*    */   private final String prefix;
/*    */   
/*    */   public SolrjNamedThreadFactory(String namePrefix) {
/* 29 */     SecurityManager s = System.getSecurityManager();
/*    */     
/* 31 */     this.group = (s != null ? s.getThreadGroup() : Thread.currentThread().getThreadGroup());
/*    */     
/* 33 */     this.prefix = (namePrefix + "-" + poolNumber.getAndIncrement() + "-thread-");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Thread newThread(Runnable r)
/*    */   {
/* 40 */     Thread t = new Thread(this.group, r, this.prefix + this.threadNumber.getAndIncrement(), 0L);
/*    */     
/*    */ 
/* 43 */     t.setDaemon(false);
/*    */     
/* 45 */     if (t.getPriority() != 5)
/* 46 */       t.setPriority(5);
/* 47 */     return t;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\SolrjNamedThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */