/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ import org.apache.solr.client.solrj.SolrResponse;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrResponseBase
/*    */   extends SolrResponse
/*    */ {
/* 29 */   private long elapsedTime = -1L;
/* 30 */   private NamedList<Object> response = null;
/* 31 */   private String requestUrl = null;
/*    */   
/*    */   public long getElapsedTime()
/*    */   {
/* 35 */     return this.elapsedTime;
/*    */   }
/*    */   
/*    */   public void setElapsedTime(long elapsedTime) {
/* 39 */     this.elapsedTime = elapsedTime;
/*    */   }
/*    */   
/*    */   public NamedList<Object> getResponse()
/*    */   {
/* 44 */     return this.response;
/*    */   }
/*    */   
/*    */   public void setResponse(NamedList<Object> response)
/*    */   {
/* 49 */     this.response = response;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 54 */     return this.response.toString();
/*    */   }
/*    */   
/*    */   public NamedList getResponseHeader() {
/* 58 */     return (NamedList)this.response.get("responseHeader");
/*    */   }
/*    */   
/*    */   public int getStatus()
/*    */   {
/* 63 */     NamedList header = getResponseHeader();
/* 64 */     if (header != null) {
/* 65 */       return ((Integer)header.get("status")).intValue();
/*    */     }
/*    */     
/* 68 */     return 0;
/*    */   }
/*    */   
/*    */   public int getQTime()
/*    */   {
/* 73 */     NamedList header = getResponseHeader();
/* 74 */     if (header != null) {
/* 75 */       return ((Integer)header.get("QTime")).intValue();
/*    */     }
/*    */     
/* 78 */     return 0;
/*    */   }
/*    */   
/*    */   public String getRequestUrl()
/*    */   {
/* 83 */     return this.requestUrl;
/*    */   }
/*    */   
/*    */   public void setRequestUrl(String requestUrl) {
/* 87 */     this.requestUrl = requestUrl;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\SolrResponseBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */