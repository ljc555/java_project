/*    */ package org.apache.solr.common;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrDocumentList
/*    */   extends ArrayList<SolrDocument>
/*    */ {
/* 31 */   private long numFound = 0L;
/* 32 */   private long start = 0L;
/* 33 */   private Float maxScore = null;
/*    */   
/*    */   public Float getMaxScore() {
/* 36 */     return this.maxScore;
/*    */   }
/*    */   
/*    */   public void setMaxScore(Float maxScore) {
/* 40 */     this.maxScore = maxScore;
/*    */   }
/*    */   
/*    */   public long getNumFound() {
/* 44 */     return this.numFound;
/*    */   }
/*    */   
/*    */   public void setNumFound(long numFound) {
/* 48 */     this.numFound = numFound;
/*    */   }
/*    */   
/*    */   public long getStart() {
/* 52 */     return this.start;
/*    */   }
/*    */   
/*    */   public void setStart(long start) {
/* 56 */     this.start = start;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 61 */     return 
/*    */     
/*    */ 
/* 64 */       "{numFound=" + this.numFound + ",start=" + this.start + (this.maxScore != null ? ",maxScore=" + this.maxScore : "") + ",docs=" + super.toString() + "}";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\SolrDocumentList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */