/*    */ package org.apache.solr.client.solrj.impl;
/*    */ 
/*    */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*    */ import org.apache.http.impl.client.DefaultHttpClient;
/*    */ import org.apache.solr.common.params.SolrParams;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpClientConfigurer
/*    */ {
/*    */   public void configure(DefaultHttpClient httpClient, SolrParams config)
/*    */   {
/* 32 */     if (config.get("maxConnections") != null) {
/* 33 */       HttpClientUtil.setMaxConnections(httpClient, config
/* 34 */         .getInt("maxConnections").intValue());
/*    */     }
/*    */     
/* 37 */     if (config.get("maxConnectionsPerHost") != null) {
/* 38 */       HttpClientUtil.setMaxConnectionsPerHost(httpClient, config
/* 39 */         .getInt("maxConnectionsPerHost").intValue());
/*    */     }
/*    */     
/* 42 */     if (config.get("connTimeout") != null) {
/* 43 */       HttpClientUtil.setConnectionTimeout(httpClient, config
/* 44 */         .getInt("connTimeout").intValue());
/*    */     }
/*    */     
/* 47 */     if (config.get("socketTimeout") != null) {
/* 48 */       HttpClientUtil.setSoTimeout(httpClient, config
/* 49 */         .getInt("socketTimeout").intValue());
/*    */     }
/*    */     
/* 52 */     if (config.get("followRedirects") != null) {
/* 53 */       HttpClientUtil.setFollowRedirects(httpClient, config
/* 54 */         .getBool("followRedirects").booleanValue());
/*    */     }
/*    */     
/*    */ 
/* 58 */     HttpClientUtil.setUseRetry(httpClient, config
/* 59 */       .getBool("retry", true));
/*    */     
/*    */ 
/* 62 */     String basicAuthUser = config.get("httpBasicAuthUser");
/*    */     
/* 64 */     String basicAuthPass = config.get("httpBasicAuthPassword");
/* 65 */     HttpClientUtil.setBasicAuth(httpClient, basicAuthUser, basicAuthPass);
/*    */     
/* 67 */     if (config.get("allowCompression") != null) {
/* 68 */       HttpClientUtil.setAllowCompression(httpClient, config
/* 69 */         .getBool("allowCompression").booleanValue());
/*    */     }
/*    */     
/* 72 */     boolean sslCheckPeerName = toBooleanDefaultIfNull(
/* 73 */       toBooleanObject(System.getProperty("solr.ssl.checkPeerName")), true);
/* 74 */     if (!sslCheckPeerName) {
/* 75 */       HttpClientUtil.setHostNameVerifier(httpClient, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean toBooleanDefaultIfNull(Boolean bool, boolean valueIfNull) {
/* 80 */     if (bool == null) {
/* 81 */       return valueIfNull;
/*    */     }
/* 83 */     return bool.booleanValue();
/*    */   }
/*    */   
/*    */   public static Boolean toBooleanObject(String str) {
/* 87 */     if ("true".equalsIgnoreCase(str))
/* 88 */       return Boolean.TRUE;
/* 89 */     if ("false".equalsIgnoreCase(str)) {
/* 90 */       return Boolean.FALSE;
/*    */     }
/*    */     
/* 93 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\HttpClientConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */