/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.zookeeper.WatchedEvent;
/*     */ import org.apache.zookeeper.Watcher;
/*     */ import org.apache.zookeeper.Watcher.Event.KeeperState;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionManager
/*     */   implements Watcher
/*     */ {
/*  36 */   private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
/*     */   
/*     */   private final String name;
/*     */   
/*  40 */   private volatile boolean connected = false;
/*     */   
/*     */ 
/*     */   private final ZkClientConnectionStrategy connectionStrategy;
/*     */   
/*     */   private final String zkServerAddress;
/*     */   
/*     */   private final SolrZkClient client;
/*     */   
/*     */   private final OnReconnect onReconnect;
/*     */   
/*     */   private final BeforeReconnect beforeReconnect;
/*     */   
/*  53 */   private volatile boolean isClosed = false;
/*     */   
/*     */   private static class LikelyExpiredState
/*     */   {
/*  57 */     private static LikelyExpiredState NOT_EXPIRED = new LikelyExpiredState(StateType.NOT_EXPIRED, 0L);
/*  58 */     private static LikelyExpiredState EXPIRED = new LikelyExpiredState(StateType.EXPIRED, 0L);
/*     */     private StateType stateType;
/*     */     
/*  61 */     public static enum StateType { NOT_EXPIRED, 
/*  62 */       EXPIRED, 
/*  63 */       TRACKING_TIME;
/*     */       
/*     */       private StateType() {}
/*     */     }
/*     */     
/*     */     private long lastDisconnectTime;
/*  69 */     public LikelyExpiredState(StateType stateType, long lastDisconnectTime) { this.stateType = stateType;
/*  70 */       this.lastDisconnectTime = lastDisconnectTime;
/*     */     }
/*     */     
/*     */     public boolean isLikelyExpired(long timeToExpire) {
/*  74 */       return (this.stateType == StateType.EXPIRED) || ((this.stateType == StateType.TRACKING_TIME) && 
/*  75 */         (System.nanoTime() - this.lastDisconnectTime > TimeUnit.NANOSECONDS.convert(timeToExpire, TimeUnit.MILLISECONDS)));
/*     */     }
/*     */   }
/*     */   
/*  79 */   private volatile LikelyExpiredState likelyExpiredState = LikelyExpiredState.EXPIRED;
/*     */   
/*     */   public ConnectionManager(String name, SolrZkClient client, String zkServerAddress, ZkClientConnectionStrategy strat, OnReconnect onConnect, BeforeReconnect beforeReconnect) {
/*  82 */     this.name = name;
/*  83 */     this.client = client;
/*  84 */     this.connectionStrategy = strat;
/*  85 */     this.zkServerAddress = zkServerAddress;
/*  86 */     this.onReconnect = onConnect;
/*  87 */     this.beforeReconnect = beforeReconnect;
/*     */   }
/*     */   
/*     */   private synchronized void connected() {
/*  91 */     this.connected = true;
/*  92 */     this.likelyExpiredState = LikelyExpiredState.NOT_EXPIRED;
/*  93 */     notifyAll();
/*     */   }
/*     */   
/*     */   private synchronized void disconnected() {
/*  97 */     this.connected = false;
/*     */     
/*  99 */     if (!this.likelyExpiredState.isLikelyExpired(0L)) {
/* 100 */       this.likelyExpiredState = new LikelyExpiredState(ConnectionManager.LikelyExpiredState.StateType.TRACKING_TIME, System.nanoTime());
/*     */     }
/* 102 */     notifyAll();
/*     */   }
/*     */   
/*     */   public void process(WatchedEvent event)
/*     */   {
/* 107 */     if ((event.getState() == Watcher.Event.KeeperState.AuthFailed) || (event.getState() == Watcher.Event.KeeperState.Disconnected) || (event.getState() == Watcher.Event.KeeperState.Expired)) {
/* 108 */       log.warn("Watcher " + this + " name:" + this.name + " got event " + event + " path:" + event
/* 109 */         .getPath() + " type:" + event.getType());
/* 110 */     } else if (log.isInfoEnabled()) {
/* 111 */       log.info("Watcher " + this + " name:" + this.name + " got event " + event + " path:" + event
/* 112 */         .getPath() + " type:" + event.getType());
/*     */     }
/*     */     
/* 115 */     if (this.isClosed) {
/* 116 */       log.info("Client->ZooKeeper status change trigger but we are already closed");
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     Watcher.Event.KeeperState state = event.getState();
/*     */     
/* 122 */     if (state == Watcher.Event.KeeperState.SyncConnected) {
/* 123 */       connected();
/* 124 */       this.connectionStrategy.connected();
/* 125 */     } else if (state == Watcher.Event.KeeperState.Expired)
/*     */     {
/* 127 */       this.connected = false;
/* 128 */       this.likelyExpiredState = LikelyExpiredState.EXPIRED;
/*     */       
/* 130 */       log.warn("Our previous ZooKeeper session was expired. Attempting to reconnect to recover relationship with ZooKeeper...");
/*     */       
/* 132 */       if (this.beforeReconnect != null) {
/*     */         try {
/* 134 */           this.beforeReconnect.command();
/*     */         } catch (Exception e) {
/* 136 */           log.warn("Exception running beforeReconnect command", e);
/*     */         }
/*     */       }
/*     */       
/*     */       do
/*     */       {
/*     */         try
/*     */         {
/* 144 */           this.connectionStrategy.reconnect(this.zkServerAddress, this.client
/* 145 */             .getZkClientTimeout(), this, new ZkClientConnectionStrategy.ZkUpdate()
/*     */             {
/*     */               public void update(SolrZooKeeper keeper)
/*     */               {
/*     */                 try {
/* 150 */                   ConnectionManager.this.waitForConnected(Long.MAX_VALUE);
/*     */                 } catch (Exception e1) {
/* 152 */                   ConnectionManager.this.closeKeeper(keeper);
/* 153 */                   throw new RuntimeException(e1);
/*     */                 }
/*     */                 
/* 156 */                 ConnectionManager.log.info("Connection with ZooKeeper reestablished.");
/*     */                 try {
/* 158 */                   ConnectionManager.this.client.updateKeeper(keeper);
/*     */                 } catch (InterruptedException e) {
/* 160 */                   ConnectionManager.this.closeKeeper(keeper);
/* 161 */                   Thread.currentThread().interrupt();
/*     */                   
/* 163 */                   throw new RuntimeException(e);
/*     */                 } catch (Exception t) {
/* 165 */                   ConnectionManager.this.closeKeeper(keeper);
/* 166 */                   throw new RuntimeException(t);
/*     */                 }
/*     */                 
/* 169 */                 if (ConnectionManager.this.onReconnect != null) {
/* 170 */                   ConnectionManager.this.onReconnect.command();
/*     */                 }
/*     */                 
/*     */               }
/*     */             });
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 178 */           SolrException.log(log, "", e);
/* 179 */           log.info("Could not connect due to error, sleeping for 5s and trying agian");
/* 180 */           waitSleep(1000L);
/*     */         }
/*     */         
/* 183 */       } while (!this.isClosed);
/* 184 */       log.info("Connected:" + this.connected);
/* 185 */     } else if (state == Watcher.Event.KeeperState.Disconnected) {
/* 186 */       log.warn("zkClient has disconnected");
/* 187 */       disconnected();
/* 188 */       this.connectionStrategy.disconnected();
/* 189 */     } else if (state == Watcher.Event.KeeperState.AuthFailed) {
/* 190 */       log.warn("zkClient received AuthFailed");
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean isConnected() {
/* 195 */     return (!this.isClosed) && (this.connected);
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */   {
/* 201 */     this.isClosed = true;
/* 202 */     this.likelyExpiredState = LikelyExpiredState.EXPIRED;
/*     */   }
/*     */   
/*     */   public boolean isLikelyExpired() {
/* 206 */     return (this.isClosed) || (this.likelyExpiredState.isLikelyExpired((this.client.getZkClientTimeout() * 0.9D)));
/*     */   }
/*     */   
/*     */   public synchronized void waitSleep(long waitFor) {
/*     */     try {
/* 211 */       wait(waitFor);
/*     */     } catch (InterruptedException e) {
/* 213 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void waitForConnected(long waitForConnection) throws TimeoutException
/*     */   {
/* 219 */     log.info("Waiting for client to connect to ZooKeeper");
/* 220 */     long expire = System.nanoTime() + TimeUnit.NANOSECONDS.convert(waitForConnection, TimeUnit.MILLISECONDS);
/* 221 */     long left = 1L;
/* 222 */     while ((!this.connected) && (left > 0L) && 
/* 223 */       (!this.isClosed))
/*     */     {
/*     */       try
/*     */       {
/* 227 */         wait(500L);
/*     */       } catch (InterruptedException e) {
/* 229 */         Thread.currentThread().interrupt();
/* 230 */         break;
/*     */       }
/* 232 */       left = expire - System.nanoTime();
/*     */     }
/* 234 */     if (!this.connected) {
/* 235 */       throw new TimeoutException("Could not connect to ZooKeeper " + this.zkServerAddress + " within " + waitForConnection + " ms");
/*     */     }
/* 237 */     log.info("Client is connected to ZooKeeper");
/*     */   }
/*     */   
/*     */   public synchronized void waitForDisconnected(long timeout) throws InterruptedException, TimeoutException
/*     */   {
/* 242 */     long expire = System.nanoTime() + TimeUnit.NANOSECONDS.convert(timeout, TimeUnit.MILLISECONDS);
/* 243 */     long left = timeout;
/* 244 */     while ((this.connected) && (left > 0L)) {
/* 245 */       wait(left);
/* 246 */       left = expire - System.nanoTime();
/*     */     }
/* 248 */     if (this.connected) {
/* 249 */       throw new TimeoutException("Did not disconnect");
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeKeeper(SolrZooKeeper keeper) {
/*     */     try {
/* 255 */       keeper.close();
/*     */     }
/*     */     catch (InterruptedException e) {
/* 258 */       Thread.currentThread().interrupt();
/* 259 */       log.error("", e);
/* 260 */       throw new ZooKeeperException(SolrException.ErrorCode.SERVER_ERROR, "", e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ConnectionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */