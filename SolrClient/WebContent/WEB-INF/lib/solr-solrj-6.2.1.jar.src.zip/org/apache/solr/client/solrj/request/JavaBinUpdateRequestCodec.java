/*     */ package org.apache.solr.client.solrj.request;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.DataInputInputStream;
/*     */ import org.apache.solr.common.util.JavaBinCodec;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaBinUpdateRequestCodec
/*     */ {
/*     */   public void marshal(UpdateRequest updateRequest, OutputStream os)
/*     */     throws IOException
/*     */   {
/*  55 */     NamedList nl = new NamedList();
/*  56 */     NamedList params = solrParamsToNamedList(updateRequest.getParams());
/*  57 */     if (updateRequest.getCommitWithin() != -1) {
/*  58 */       params.add("commitWithin", Integer.valueOf(updateRequest.getCommitWithin()));
/*     */     }
/*  60 */     Iterator<SolrInputDocument> docIter = null;
/*     */     
/*  62 */     if (updateRequest.getDocIterator() != null) {
/*  63 */       docIter = updateRequest.getDocIterator();
/*     */     }
/*     */     
/*  66 */     Map<SolrInputDocument, Map<String, Object>> docMap = updateRequest.getDocumentsMap();
/*     */     
/*  68 */     nl.add("params", params);
/*  69 */     if (updateRequest.getDeleteByIdMap() != null) {
/*  70 */       nl.add("delByIdMap", updateRequest.getDeleteByIdMap());
/*     */     }
/*  72 */     nl.add("delByQ", updateRequest.getDeleteQuery());
/*     */     
/*  74 */     if (docMap != null) {
/*  75 */       nl.add("docsMap", docMap.entrySet().iterator());
/*     */     } else {
/*  77 */       if (updateRequest.getDocuments() != null) {
/*  78 */         docIter = updateRequest.getDocuments().iterator();
/*     */       }
/*  80 */       nl.add("docs", docIter);
/*     */     }
/*  82 */     JavaBinCodec codec = new JavaBinCodec();
/*  83 */     codec.marshal(nl, os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UpdateRequest unmarshal(InputStream is, final StreamingUpdateHandler handler)
/*     */     throws IOException
/*     */   {
/*  98 */     final UpdateRequest updateRequest = new UpdateRequest();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     final NamedList[] namedList = new NamedList[1];
/* 105 */     JavaBinCodec codec = new JavaBinCodec()
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 110 */       private boolean seenOuterMostDocIterator = false;
/*     */       
/*     */       public NamedList readNamedList(DataInputInputStream dis) throws IOException
/*     */       {
/* 114 */         int sz = readSize(dis);
/* 115 */         NamedList nl = new NamedList();
/* 116 */         if (namedList[0] == null) {
/* 117 */           namedList[0] = nl;
/*     */         }
/* 119 */         for (int i = 0; i < sz; i++) {
/* 120 */           String name = (String)readVal(dis);
/* 121 */           Object val = readVal(dis);
/* 122 */           nl.add(name, val);
/*     */         }
/* 124 */         return nl;
/*     */       }
/*     */       
/*     */       public List readIterator(DataInputInputStream fis)
/*     */         throws IOException
/*     */       {
/* 130 */         if (this.seenOuterMostDocIterator) { return super.readIterator(fis);
/*     */         }
/*     */         
/*     */ 
/* 134 */         this.seenOuterMostDocIterator = true;
/* 135 */         return readOuterMostDocIterator(fis);
/*     */       }
/*     */       
/*     */       private List readOuterMostDocIterator(DataInputInputStream fis) throws IOException {
/* 139 */         NamedList params = (NamedList)namedList[0].get("params");
/* 140 */         updateRequest.setParams(new ModifiableSolrParams(SolrParams.toSolrParams(params)));
/* 141 */         if (handler == null) return super.readIterator(fis);
/* 142 */         Integer commitWithin = null;
/* 143 */         Boolean overwrite = null;
/* 144 */         Object o = null;
/*     */         for (;;) {
/* 146 */           if (o == null) {
/* 147 */             o = readVal(fis);
/*     */           }
/*     */           
/* 150 */           if (o == END_OBJ) {
/*     */             break;
/*     */           }
/*     */           
/* 154 */           SolrInputDocument sdoc = null;
/* 155 */           if ((o instanceof List)) {
/* 156 */             sdoc = JavaBinUpdateRequestCodec.this.listToSolrInputDocument((List)o);
/* 157 */           } else if ((o instanceof NamedList)) {
/* 158 */             UpdateRequest req = new UpdateRequest();
/* 159 */             req.setParams(new ModifiableSolrParams(SolrParams.toSolrParams((NamedList)o)));
/* 160 */             handler.update(null, req, null, null);
/* 161 */           } else if ((o instanceof Map.Entry)) {
/* 162 */             sdoc = (SolrInputDocument)((Map.Entry)o).getKey();
/* 163 */             Map p = (Map)((Map.Entry)o).getValue();
/* 164 */             if (p != null) {
/* 165 */               commitWithin = (Integer)p.get("cw");
/* 166 */               overwrite = (Boolean)p.get("ow");
/*     */             }
/*     */           } else {
/* 169 */             sdoc = (SolrInputDocument)o;
/*     */           }
/*     */           
/*     */ 
/* 173 */           o = readVal(fis);
/* 174 */           if (o == END_OBJ)
/*     */           {
/* 176 */             updateRequest.lastDocInBatch();
/*     */           }
/*     */           
/* 179 */           handler.update(sdoc, updateRequest, commitWithin, overwrite);
/*     */         }
/* 181 */         return Collections.EMPTY_LIST;
/*     */       }
/*     */       
/*     */ 
/* 185 */     };
/* 186 */     codec.unmarshal(is);
/*     */     
/*     */ 
/*     */ 
/* 190 */     if (updateRequest.getParams() == null) {
/* 191 */       NamedList params = (NamedList)namedList[0].get("params");
/* 192 */       if (params != null) {
/* 193 */         updateRequest.setParams(new ModifiableSolrParams(SolrParams.toSolrParams(params)));
/*     */       }
/*     */     }
/* 196 */     List<String> delById = (List)namedList[0].get("delById");
/* 197 */     Map<String, Map<String, Object>> delByIdMap = (Map)namedList[0].get("delByIdMap");
/* 198 */     List<String> delByQ = (List)namedList[0].get("delByQ");
/* 199 */     List<List<NamedList>> doclist = (List)namedList[0].get("docs");
/* 200 */     Object docsMapObj = namedList[0].get("docsMap");
/*     */     List<Map.Entry<SolrInputDocument, Map<Object, Object>>> docMap;
/* 202 */     List<Map.Entry<SolrInputDocument, Map<Object, Object>>> docMap; if ((docsMapObj instanceof Map)) {
/* 203 */       docMap = new ArrayList(((Map)docsMapObj).entrySet());
/*     */     } else {
/* 205 */       docMap = (List)docsMapObj;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */     if (delById != null) {
/* 213 */       for (String s : delById) {
/* 214 */         updateRequest.deleteById(s);
/*     */       }
/*     */     }
/* 217 */     if (delByIdMap != null) {
/* 218 */       for (Map.Entry<String, Map<String, Object>> entry : delByIdMap.entrySet()) {
/* 219 */         Map<String, Object> params = (Map)entry.getValue();
/* 220 */         if (params != null) {
/* 221 */           Long version = (Long)params.get("ver");
/* 222 */           if (params.containsKey("_route_")) {
/* 223 */             updateRequest.deleteById((String)entry.getKey(), (String)params.get("_route_"));
/*     */           } else
/* 225 */             updateRequest.deleteById((String)entry.getKey(), version);
/*     */         } else {
/* 227 */           updateRequest.deleteById((String)entry.getKey());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 232 */     if (delByQ != null) {
/* 233 */       for (String s : delByQ) {
/* 234 */         updateRequest.deleteByQuery(s);
/*     */       }
/*     */     }
/*     */     
/* 238 */     return updateRequest;
/*     */   }
/*     */   
/*     */   private SolrInputDocument listToSolrInputDocument(List<NamedList> namedList) {
/* 242 */     SolrInputDocument doc = new SolrInputDocument(new String[0]);
/* 243 */     for (int i = 0; i < namedList.size(); i++) {
/* 244 */       NamedList nl = (NamedList)namedList.get(i);
/* 245 */       if (i == 0) {
/* 246 */         doc.setDocumentBoost(nl.getVal(0) == null ? 1.0F : ((Float)nl.getVal(0)).floatValue());
/*     */       } else {
/* 248 */         doc.addField((String)nl.getVal(0), nl
/* 249 */           .getVal(1), nl
/* 250 */           .getVal(2) == null ? 1.0F : ((Float)nl.getVal(2)).floatValue());
/*     */       }
/*     */     }
/* 253 */     return doc;
/*     */   }
/*     */   
/*     */   private NamedList solrParamsToNamedList(SolrParams params) {
/* 257 */     if (params == null) return new NamedList();
/* 258 */     return params.toNamedList();
/*     */   }
/*     */   
/*     */   public static abstract interface StreamingUpdateHandler
/*     */   {
/*     */     public abstract void update(SolrInputDocument paramSolrInputDocument, UpdateRequest paramUpdateRequest, Integer paramInteger, Boolean paramBoolean);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\request\JavaBinUpdateRequestCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */