/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RangeFacet<B, G>
/*     */ {
/*     */   private final String name;
/*  28 */   private final List<Count> counts = new ArrayList();
/*     */   
/*     */   private final B start;
/*     */   private final B end;
/*     */   private final G gap;
/*     */   private final Number before;
/*     */   private final Number after;
/*     */   private final Number between;
/*     */   
/*     */   protected RangeFacet(String name, B start, B end, G gap, Number before, Number after, Number between)
/*     */   {
/*  39 */     this.name = name;
/*  40 */     this.start = start;
/*  41 */     this.end = end;
/*  42 */     this.gap = gap;
/*  43 */     this.before = before;
/*  44 */     this.after = after;
/*  45 */     this.between = between;
/*     */   }
/*     */   
/*     */   public void addCount(String value, int count) {
/*  49 */     this.counts.add(new Count(value, count, this));
/*     */   }
/*     */   
/*     */   public String getName() {
/*  53 */     return this.name;
/*     */   }
/*     */   
/*     */   public List<Count> getCounts() {
/*  57 */     return this.counts;
/*     */   }
/*     */   
/*     */   public B getStart() {
/*  61 */     return (B)this.start;
/*     */   }
/*     */   
/*     */   public B getEnd() {
/*  65 */     return (B)this.end;
/*     */   }
/*     */   
/*     */   public G getGap() {
/*  69 */     return (G)this.gap;
/*     */   }
/*     */   
/*     */   public Number getBefore() {
/*  73 */     return this.before;
/*     */   }
/*     */   
/*     */   public Number getAfter() {
/*  77 */     return this.after;
/*     */   }
/*     */   
/*     */   public Number getBetween() {
/*  81 */     return this.between;
/*     */   }
/*     */   
/*     */   public static class Numeric extends RangeFacet<Number, Number>
/*     */   {
/*     */     public Numeric(String name, Number start, Number end, Number gap, Number before, Number after, Number between) {
/*  87 */       super(start, end, gap, before, after, between);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Date extends RangeFacet<Date, String>
/*     */   {
/*     */     public Date(String name, Date start, Date end, String gap, Number before, Number after, Number between)
/*     */     {
/*  95 */       super(start, end, gap, before, after, between);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Count
/*     */   {
/*     */     private final String value;
/*     */     private final int count;
/*     */     private final RangeFacet rangeFacet;
/*     */     
/*     */     public Count(String value, int count, RangeFacet rangeFacet)
/*     */     {
/* 107 */       this.value = value;
/* 108 */       this.count = count;
/* 109 */       this.rangeFacet = rangeFacet;
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 113 */       return this.value;
/*     */     }
/*     */     
/*     */     public int getCount() {
/* 117 */       return this.count;
/*     */     }
/*     */     
/*     */     public RangeFacet getRangeFacet() {
/* 121 */       return this.rangeFacet;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\RangeFacet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */