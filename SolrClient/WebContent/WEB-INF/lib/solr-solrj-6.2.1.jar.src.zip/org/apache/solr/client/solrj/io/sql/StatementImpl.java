/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.io.stream.SolrStream;
/*     */ import org.apache.solr.common.cloud.ClusterState;
/*     */ import org.apache.solr.common.cloud.Replica;
/*     */ import org.apache.solr.common.cloud.Slice;
/*     */ import org.apache.solr.common.cloud.ZkCoreNodeProps;
/*     */ import org.apache.solr.common.cloud.ZkStateReader;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StatementImpl
/*     */   implements Statement
/*     */ {
/*     */   private final ConnectionImpl connection;
/*     */   private boolean closed;
/*     */   private String currentSQL;
/*     */   private ResultSetImpl currentResultSet;
/*     */   private SQLWarning currentWarning;
/*     */   private int maxRows;
/*     */   
/*     */   StatementImpl(ConnectionImpl connection)
/*     */   {
/*  50 */     this.connection = connection;
/*     */   }
/*     */   
/*     */   private void checkClosed() throws SQLException {
/*  54 */     if (isClosed()) {
/*  55 */       throw new SQLException("Statement is closed.");
/*     */     }
/*     */   }
/*     */   
/*     */   private ResultSet executeQueryImpl(String sql) throws SQLException {
/*     */     try {
/*  61 */       if (this.currentResultSet != null) {
/*  62 */         this.currentResultSet.close();
/*  63 */         this.currentResultSet = null;
/*     */       }
/*     */       
/*  66 */       if ((this.maxRows > 0) && (!containsLimit(sql))) {
/*  67 */         sql = sql + " limit " + Integer.toString(this.maxRows);
/*     */       }
/*     */       
/*  70 */       this.closed = false;
/*  71 */       this.currentResultSet = new ResultSetImpl(this, constructStream(sql));
/*  72 */       return this.currentResultSet;
/*     */     } catch (Exception e) {
/*  74 */       throw new SQLException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected SolrStream constructStream(String sql) throws IOException {
/*     */     try {
/*  80 */       ZkStateReader zkStateReader = this.connection.getClient().getZkStateReader();
/*  81 */       ClusterState clusterState = zkStateReader.getClusterState();
/*  82 */       Collection<Slice> slices = clusterState.getActiveSlices(this.connection.getCollection());
/*     */       
/*  84 */       if (slices == null) {
/*  85 */         throw new Exception("Collection not found:" + this.connection.getCollection());
/*     */       }
/*     */       
/*  88 */       List<Replica> shuffler = new ArrayList();
/*  89 */       for (Iterator localIterator1 = slices.iterator(); localIterator1.hasNext();) { slice = (Slice)localIterator1.next();
/*  90 */         Collection<Replica> replicas = slice.getReplicas();
/*  91 */         for (Replica replica : replicas) {
/*  92 */           shuffler.add(replica);
/*     */         }
/*     */       }
/*     */       Slice slice;
/*  96 */       Collections.shuffle(shuffler, new Random());
/*     */       
/*  98 */       ModifiableSolrParams params = new ModifiableSolrParams();
/*  99 */       params.set("qt", new String[] { "/sql" });
/* 100 */       params.set("stmt", new String[] { sql });
/* 101 */       for (String propertyName : this.connection.getProperties().stringPropertyNames()) {
/* 102 */         params.set(propertyName, new String[] { this.connection.getProperties().getProperty(propertyName) });
/*     */       }
/*     */       
/* 105 */       Replica rep = (Replica)shuffler.get(0);
/* 106 */       ZkCoreNodeProps zkProps = new ZkCoreNodeProps(rep);
/* 107 */       String url = zkProps.getCoreUrl();
/* 108 */       return new SolrStream(url, params);
/*     */     } catch (Exception e) {
/* 110 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery(String sql) throws SQLException
/*     */   {
/* 116 */     return executeQueryImpl(sql);
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql) throws SQLException
/*     */   {
/* 121 */     return 0;
/*     */   }
/*     */   
/*     */   public void close() throws SQLException
/*     */   {
/* 126 */     if (this.closed) {
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     this.closed = true;
/*     */     
/* 132 */     if (this.currentResultSet != null) {
/* 133 */       this.currentResultSet.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getMaxFieldSize() throws SQLException
/*     */   {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setMaxFieldSize(int max) throws SQLException
/*     */   {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getMaxRows() throws SQLException
/*     */   {
/* 149 */     return this.maxRows;
/*     */   }
/*     */   
/*     */   public void setMaxRows(int max) throws SQLException
/*     */   {
/* 154 */     this.maxRows = max;
/*     */   }
/*     */   
/*     */   public void setEscapeProcessing(boolean enable) throws SQLException
/*     */   {
/* 159 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getQueryTimeout() throws SQLException
/*     */   {
/* 164 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setQueryTimeout(int seconds) throws SQLException
/*     */   {
/* 169 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void cancel() throws SQLException
/*     */   {
/* 174 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException
/*     */   {
/* 179 */     checkClosed();
/*     */     
/* 181 */     return this.currentWarning;
/*     */   }
/*     */   
/*     */   public void clearWarnings() throws SQLException
/*     */   {
/* 186 */     checkClosed();
/*     */     
/* 188 */     this.currentWarning = null;
/*     */   }
/*     */   
/*     */   public void setCursorName(String name) throws SQLException
/*     */   {
/* 193 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 199 */     if (this.currentResultSet != null) {
/* 200 */       this.currentResultSet.close();
/* 201 */       this.currentResultSet = null;
/*     */     }
/*     */     
/*     */ 
/* 205 */     this.currentSQL = sql;
/* 206 */     return true;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet() throws SQLException
/*     */   {
/* 211 */     return executeQueryImpl(this.currentSQL);
/*     */   }
/*     */   
/*     */   public int getUpdateCount() throws SQLException
/*     */   {
/* 216 */     checkClosed();
/*     */     
/*     */ 
/* 219 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean getMoreResults() throws SQLException
/*     */   {
/* 224 */     checkClosed();
/*     */     
/*     */ 
/* 227 */     this.currentResultSet.close();
/* 228 */     return false;
/*     */   }
/*     */   
/*     */   public void setFetchDirection(int direction) throws SQLException
/*     */   {
/* 233 */     checkClosed();
/*     */     
/* 235 */     if (direction != 1000) {
/* 236 */       throw new SQLException("Direction must be ResultSet.FETCH_FORWARD currently");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFetchDirection() throws SQLException
/*     */   {
/* 242 */     checkClosed();
/*     */     
/* 244 */     return 1000;
/*     */   }
/*     */   
/*     */   public void setFetchSize(int rows) throws SQLException
/*     */   {
/* 249 */     checkClosed();
/*     */     
/* 251 */     if (rows < 0) {
/* 252 */       throw new SQLException("Rows must be >= 0");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFetchSize() throws SQLException
/*     */   {
/* 258 */     checkClosed();
/*     */     
/* 260 */     return 0;
/*     */   }
/*     */   
/*     */   public int getResultSetConcurrency() throws SQLException
/*     */   {
/* 265 */     checkClosed();
/*     */     
/* 267 */     return 1007;
/*     */   }
/*     */   
/*     */   public int getResultSetType() throws SQLException
/*     */   {
/* 272 */     checkClosed();
/*     */     
/* 274 */     return 1003;
/*     */   }
/*     */   
/*     */   public void addBatch(String sql) throws SQLException
/*     */   {
/* 279 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clearBatch() throws SQLException
/*     */   {
/* 284 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int[] executeBatch() throws SQLException
/*     */   {
/* 289 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException
/*     */   {
/* 294 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean getMoreResults(int current) throws SQLException
/*     */   {
/* 299 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public ResultSet getGeneratedKeys() throws SQLException
/*     */   {
/* 304 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 309 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 314 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 319 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, int autoGeneratedKeys) throws SQLException
/*     */   {
/* 324 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, int[] columnIndexes) throws SQLException
/*     */   {
/* 329 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, String[] columnNames) throws SQLException
/*     */   {
/* 334 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int getResultSetHoldability() throws SQLException
/*     */   {
/* 339 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isClosed() throws SQLException
/*     */   {
/* 344 */     return this.closed;
/*     */   }
/*     */   
/*     */   public void setPoolable(boolean poolable) throws SQLException
/*     */   {
/* 349 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isPoolable() throws SQLException
/*     */   {
/* 354 */     return true;
/*     */   }
/*     */   
/*     */   public void closeOnCompletion() throws SQLException
/*     */   {
/* 359 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isCloseOnCompletion() throws SQLException
/*     */   {
/* 364 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException
/*     */   {
/* 369 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*     */   {
/* 374 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   private boolean containsLimit(String sql) {
/* 378 */     String[] tokens = sql.split("\\s+");
/* 379 */     String secondToLastToken = tokens[(tokens.length - 2)];
/* 380 */     return "limit".equalsIgnoreCase(secondToLastToken);
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\StatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */