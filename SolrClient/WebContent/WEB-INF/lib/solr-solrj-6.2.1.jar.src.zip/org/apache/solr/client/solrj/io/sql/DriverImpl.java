/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Logger;
/*     */ import org.apache.http.NameValuePair;
/*     */ import org.apache.http.client.utils.URLEncodedUtils;
/*     */ import org.apache.solr.common.util.SuppressForbidden;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverImpl
/*     */   implements Driver
/*     */ {
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  44 */       DriverManager.registerDriver(new DriverImpl());
/*     */     } catch (SQLException e) {
/*  46 */       throw new RuntimeException("Can't register driver!", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection connect(String url, Properties props) throws SQLException {
/*  51 */     if (!acceptsURL(url)) {
/*  52 */       return null;
/*     */     }
/*     */     
/*  55 */     URI uri = processUrl(url);
/*     */     
/*  57 */     loadParams(uri, props);
/*     */     
/*  59 */     if (!props.containsKey("collection")) {
/*  60 */       throw new SQLException("The connection url has no connection properties. At a mininum the collection must be specified.");
/*     */     }
/*  62 */     String collection = (String)props.remove("collection");
/*     */     
/*  64 */     if (!props.containsKey("aggregationMode")) {
/*  65 */       props.setProperty("aggregationMode", "facet");
/*     */     }
/*     */     
/*     */ 
/*  69 */     props.setProperty("includeMetadata", "true");
/*     */     
/*  71 */     String zkHost = uri.getAuthority() + uri.getPath();
/*     */     
/*  73 */     return new ConnectionImpl(url, zkHost, collection, props);
/*     */   }
/*     */   
/*     */   public Connection connect(String url) throws SQLException {
/*  77 */     return connect(url, new Properties());
/*     */   }
/*     */   
/*     */   public int getMajorVersion() {
/*  81 */     return 1;
/*     */   }
/*     */   
/*     */   public int getMinorVersion() {
/*  85 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean acceptsURL(String url) {
/*  89 */     return (url != null) && (url.startsWith("jdbc:solr"));
/*     */   }
/*     */   
/*     */   public boolean jdbcCompliant() {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   @SuppressForbidden(reason="Required by jdbc")
/*     */   public Logger getParentLogger()
/*     */   {
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) {
/* 104 */     return null;
/*     */   }
/*     */   
/*     */   protected URI processUrl(String url) throws SQLException
/*     */   {
/*     */     try {
/* 110 */       uri = new URI(url.replaceFirst("jdbc:", ""));
/*     */     } catch (URISyntaxException e) { URI uri;
/* 112 */       throw new SQLException(e);
/*     */     }
/*     */     URI uri;
/* 115 */     if (uri.getAuthority() == null) {
/* 116 */       throw new SQLException("The zkHost must not be null");
/*     */     }
/*     */     
/* 119 */     return uri;
/*     */   }
/*     */   
/*     */   private void loadParams(URI uri, Properties props) throws SQLException {
/* 123 */     List<NameValuePair> parsedParams = URLEncodedUtils.parse(uri, "UTF-8");
/* 124 */     for (NameValuePair pair : parsedParams) {
/* 125 */       if (pair.getValue() != null) {
/* 126 */         props.put(pair.getName(), pair.getValue());
/*     */       } else {
/* 128 */         props.put(pair.getName(), "");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\DriverImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */