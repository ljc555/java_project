/*     */ package org.apache.solr.common.cloud;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.solr.common.SolrException;
/*     */ import org.apache.solr.common.SolrException.ErrorCode;
/*     */ import org.apache.solr.common.SolrInputDocument;
/*     */ import org.apache.solr.common.params.SolrParams;
/*     */ import org.apache.solr.common.util.Hash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeIdRouter
/*     */   extends HashBasedRouter
/*     */ {
/*     */   public static final String NAME = "compositeId";
/*     */   public static final String SEPARATOR = "!";
/*     */   public static final int bitsSeparator = 47;
/*  42 */   private int bits = 16;
/*     */   
/*     */   public int sliceHash(String id, SolrInputDocument doc, SolrParams params, DocCollection collection)
/*     */   {
/*  46 */     String shardFieldName = getRouteField(collection);
/*  47 */     if ((shardFieldName != null) && (doc != null)) {
/*  48 */       Object o = doc.getFieldValue(shardFieldName);
/*  49 */       if (o == null)
/*  50 */         throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "No value for :" + shardFieldName + ". Unable to identify shard");
/*  51 */       id = o.toString();
/*     */     }
/*  53 */     if (id.indexOf("!") < 0) {
/*  54 */       return Hash.murmurhash3_x86_32(id, 0, id.length(), 0);
/*     */     }
/*     */     
/*  57 */     return new KeyParser(id).getHash();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocRouter.Range keyHashRange(String routeKey)
/*     */   {
/*  68 */     if (routeKey.indexOf("!") < 0) {
/*  69 */       int hash = sliceHash(routeKey, null, null, null);
/*  70 */       return new DocRouter.Range(hash, hash);
/*     */     }
/*     */     
/*  73 */     return new KeyParser(routeKey).getRange();
/*     */   }
/*     */   
/*     */   public Collection<Slice> getSearchSlicesSingle(String shardKey, SolrParams params, DocCollection collection)
/*     */   {
/*  78 */     if (shardKey == null)
/*     */     {
/*     */ 
/*  81 */       return collection.getActiveSlices();
/*     */     }
/*  83 */     String id = shardKey;
/*     */     
/*  85 */     if (shardKey.indexOf("!") < 0)
/*     */     {
/*  87 */       return Collections.singletonList(hashToSlice(Hash.murmurhash3_x86_32(id, 0, id.length(), 0), collection));
/*     */     }
/*     */     
/*  90 */     DocRouter.Range completeRange = new KeyParser(id).getRange();
/*     */     
/*  92 */     List<Slice> targetSlices = new ArrayList(1);
/*  93 */     for (Slice slice : collection.getActiveSlices()) {
/*  94 */       DocRouter.Range range = slice.getRange();
/*  95 */       if ((range != null) && (range.overlaps(completeRange))) {
/*  96 */         targetSlices.add(slice);
/*     */       }
/*     */     }
/*     */     
/* 100 */     return targetSlices;
/*     */   }
/*     */   
/*     */   public List<DocRouter.Range> partitionRangeByKey(String key, DocRouter.Range range) {
/* 104 */     List<DocRouter.Range> result = new ArrayList(3);
/* 105 */     DocRouter.Range keyRange = keyHashRange(key);
/* 106 */     if (!keyRange.overlaps(range)) {
/* 107 */       throw new IllegalArgumentException("Key range does not overlap given range");
/*     */     }
/* 109 */     if (keyRange.equals(range))
/* 110 */       return Collections.singletonList(keyRange);
/* 111 */     if (keyRange.isSubsetOf(range)) {
/* 112 */       result.add(new DocRouter.Range(range.min, keyRange.min - 1));
/* 113 */       result.add(keyRange);
/* 114 */       result.add(new DocRouter.Range(keyRange.max + 1, range.max));
/* 115 */     } else if (range.includes(keyRange.max)) {
/* 116 */       result.add(new DocRouter.Range(range.min, keyRange.max));
/* 117 */       result.add(new DocRouter.Range(keyRange.max + 1, range.max));
/*     */     } else {
/* 119 */       result.add(new DocRouter.Range(range.min, keyRange.min - 1));
/* 120 */       result.add(new DocRouter.Range(keyRange.min, range.max));
/*     */     }
/* 122 */     return result;
/*     */   }
/*     */   
/*     */   public List<DocRouter.Range> partitionRange(int partitions, DocRouter.Range range)
/*     */   {
/* 127 */     int min = range.min;
/* 128 */     int max = range.max;
/*     */     
/* 130 */     assert (max >= min);
/* 131 */     if (partitions == 0) return Collections.EMPTY_LIST;
/* 132 */     long rangeSize = max - min;
/* 133 */     long rangeStep = Math.max(1L, rangeSize / partitions);
/*     */     
/* 135 */     List<DocRouter.Range> ranges = new ArrayList(partitions);
/*     */     
/* 137 */     long start = min;
/* 138 */     long end = start;
/*     */     
/*     */ 
/* 141 */     long targetStart = min;
/* 142 */     long targetEnd = targetStart;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     int mask = 65535;
/* 148 */     boolean round = rangeStep >= (1 << this.bits) * 16;
/*     */     
/* 150 */     while (end < max) {
/* 151 */       targetEnd = targetStart + rangeStep;
/* 152 */       end = targetEnd;
/*     */       
/* 154 */       if ((round) && ((end & mask) != mask))
/*     */       {
/* 156 */         int increment = 1 << this.bits;
/* 157 */         long roundDown = (end | mask) - increment;
/* 158 */         long roundUp = (end | mask) + increment;
/* 159 */         if ((end - roundDown < roundUp - end) && (roundDown > start)) {
/* 160 */           end = roundDown;
/*     */         } else {
/* 162 */           end = roundUp;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 167 */       if (ranges.size() == partitions - 1) {
/* 168 */         end = max;
/*     */       }
/* 170 */       ranges.add(new DocRouter.Range((int)start, (int)end));
/* 171 */       start = end + 1L;
/* 172 */       targetStart = targetEnd + 1L;
/*     */     }
/*     */     
/* 175 */     return ranges;
/*     */   }
/*     */   
/*     */ 
/*     */   static class KeyParser
/*     */   {
/*     */     String key;
/*     */     int[] numBits;
/*     */     int[] hashes;
/*     */     int[] masks;
/*     */     boolean triLevel;
/*     */     int pieces;
/*     */     
/*     */     public KeyParser(String key)
/*     */     {
/* 190 */       this.key = key;
/* 191 */       List<String> partsList = new ArrayList(3);
/* 192 */       int firstSeparatorPos = key.indexOf("!");
/* 193 */       if (-1 == firstSeparatorPos) {
/* 194 */         partsList.add(key);
/*     */       } else {
/* 196 */         partsList.add(key.substring(0, firstSeparatorPos));
/* 197 */         int lastPos = key.length() - 1;
/*     */         
/* 199 */         if (firstSeparatorPos < lastPos) {
/* 200 */           int secondSeparatorPos = key.indexOf("!", firstSeparatorPos + 1);
/* 201 */           if (-1 == secondSeparatorPos) {
/* 202 */             partsList.add(key.substring(firstSeparatorPos + 1));
/* 203 */           } else if (secondSeparatorPos == lastPos)
/*     */           {
/*     */ 
/*     */ 
/* 207 */             if (firstSeparatorPos < secondSeparatorPos - 1) {
/* 208 */               partsList.add(key.substring(firstSeparatorPos + 1, secondSeparatorPos));
/*     */             }
/*     */           } else {
/* 211 */             partsList.add(key.substring(firstSeparatorPos + 1, secondSeparatorPos));
/* 212 */             partsList.add(key.substring(secondSeparatorPos + 1));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 217 */       this.pieces = partsList.size();
/* 218 */       String[] parts = (String[])partsList.toArray(new String[this.pieces]);
/* 219 */       this.numBits = new int[2];
/* 220 */       if ((key.endsWith("!")) && (this.pieces < 3))
/* 221 */         this.pieces += 1;
/* 222 */       this.hashes = new int[this.pieces];
/*     */       
/* 224 */       if (this.pieces == 3) {
/* 225 */         this.numBits[0] = 8;
/* 226 */         this.numBits[1] = 8;
/* 227 */         this.triLevel = true;
/*     */       } else {
/* 229 */         this.numBits[0] = 16;
/* 230 */         this.triLevel = false;
/*     */       }
/*     */       
/* 233 */       for (int i = 0; i < this.pieces; i++) {
/* 234 */         if (i < this.pieces - 1) {
/* 235 */           int commaIdx = parts[i].indexOf('/');
/*     */           
/* 237 */           if (commaIdx > 0) {
/* 238 */             this.numBits[i] = getNumBits(parts[i], commaIdx);
/* 239 */             parts[i] = parts[i].substring(0, commaIdx);
/*     */           }
/*     */         }
/*     */         
/* 243 */         if (i >= parts.length) {
/* 244 */           this.hashes[i] = Hash.murmurhash3_x86_32("", 0, "".length(), 0);
/*     */         } else
/* 246 */           this.hashes[i] = Hash.murmurhash3_x86_32(parts[i], 0, parts[i].length(), 0);
/*     */       }
/* 248 */       this.masks = getMasks();
/*     */     }
/*     */     
/*     */     DocRouter.Range getRange() {
/*     */       int upperBound;
/*     */       int lowerBound;
/*     */       int upperBound;
/* 255 */       if (this.triLevel) {
/* 256 */         int lowerBound = this.hashes[0] & this.masks[0] | this.hashes[1] & this.masks[1];
/* 257 */         upperBound = lowerBound | this.masks[2];
/*     */       } else {
/* 259 */         lowerBound = this.hashes[0] & this.masks[0];
/* 260 */         upperBound = lowerBound | this.masks[1];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 265 */       if (((this.masks[0] == 0) && (!this.triLevel)) || ((this.masks[0] == 0) && (this.masks[1] == 0) && (this.triLevel)))
/*     */       {
/*     */ 
/* 268 */         lowerBound = Integer.MIN_VALUE;
/* 269 */         upperBound = Integer.MAX_VALUE;
/*     */       }
/* 271 */       DocRouter.Range r = new DocRouter.Range(lowerBound, upperBound);
/* 272 */       return r;
/*     */     }
/*     */     
/*     */ 
/*     */     private int[] getMasks()
/*     */     {
/*     */       int[] masks;
/*     */       int[] masks;
/* 280 */       if (this.triLevel) {
/* 281 */         masks = getBitMasks(this.numBits[0], this.numBits[1]);
/*     */       } else {
/* 283 */         masks = getBitMasks(this.numBits[0]);
/*     */       }
/* 285 */       return masks;
/*     */     }
/*     */     
/*     */     private int[] getBitMasks(int firstBits, int secondBits)
/*     */     {
/* 290 */       int[] masks = new int[3];
/* 291 */       masks[0] = (firstBits == 0 ? 0 : -1 << 32 - firstBits);
/* 292 */       masks[1] = (firstBits + secondBits == 0 ? 0 : -1 << 32 - firstBits - secondBits);
/* 293 */       masks[1] = (masks[0] ^ masks[1]);
/* 294 */       masks[2] = (firstBits + secondBits == 32 ? 0 : (masks[0] | masks[1]) ^ 0xFFFFFFFF);
/* 295 */       return masks;
/*     */     }
/*     */     
/*     */     private int getNumBits(String firstPart, int commaIdx) {
/* 299 */       int v = 0;
/* 300 */       for (int idx = commaIdx + 1; idx < firstPart.length(); idx++) {
/* 301 */         char ch = firstPart.charAt(idx);
/* 302 */         if ((ch < '0') || (ch > '9')) return -1;
/* 303 */         v = v * 10 + (ch - '0');
/*     */       }
/* 305 */       return v > 32 ? -1 : v;
/*     */     }
/*     */     
/*     */ 
/*     */     private int[] getBitMasks(int firstBits)
/*     */     {
/* 311 */       int[] masks = new int[2];
/* 312 */       masks[0] = (firstBits == 0 ? 0 : -1 << 32 - firstBits);
/* 313 */       masks[1] = (firstBits == 32 ? 0 : -1 >>> firstBits);
/* 314 */       return masks;
/*     */     }
/*     */     
/*     */     int getHash() {
/* 318 */       int result = this.hashes[0] & this.masks[0];
/*     */       
/* 320 */       for (int i = 1; i < this.pieces; i++)
/* 321 */         result |= this.hashes[i] & this.masks[i];
/* 322 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\CompositeIdRouter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */