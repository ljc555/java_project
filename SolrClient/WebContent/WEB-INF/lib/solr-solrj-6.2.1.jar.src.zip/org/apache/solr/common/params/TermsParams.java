/*     */ package org.apache.solr.common.params;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface TermsParams
/*     */ {
/*     */   public static final String TERMS = "terms";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_PREFIX = "terms.";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_FIELD = "terms.fl";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_LIST = "terms.list";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_STATS = "terms.stats";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_LOWER = "terms.lower";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_UPPER = "terms.upper";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_UPPER_INCLUSIVE = "terms.upper.incl";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_LOWER_INCLUSIVE = "terms.lower.incl";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_LIMIT = "terms.limit";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_PREFIX_STR = "terms.prefix";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_REGEXP_STR = "terms.regex";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_REGEXP_FLAG = "terms.regex.flag";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_MINCOUNT = "terms.mincount";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_MAXCOUNT = "terms.maxcount";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_RAW = "terms.raw";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_SORT = "terms.sort";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_SORT_COUNT = "count";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TERMS_SORT_INDEX = "index";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum TermsRegexpFlag
/*     */   {
/*  88 */     UNIX_LINES(1), 
/*  89 */     CASE_INSENSITIVE(2), 
/*  90 */     COMMENTS(4), 
/*  91 */     MULTILINE(8), 
/*  92 */     LITERAL(16), 
/*  93 */     DOTALL(32), 
/*  94 */     UNICODE_CASE(64), 
/*  95 */     CANON_EQ(128);
/*     */     
/*     */     int value;
/*     */     
/*     */     private TermsRegexpFlag(int value) {
/* 100 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 104 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\TermsParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */