/*    */ package org.apache.solr.client.solrj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SolrServerException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3371703521752000294L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SolrServerException(String message, Throwable cause)
/*    */   {
/* 29 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public SolrServerException(String message) {
/* 33 */     super(message);
/*    */   }
/*    */   
/*    */   public SolrServerException(Throwable cause) {
/* 37 */     super(cause);
/*    */   }
/*    */   
/*    */   public Throwable getRootCause() {
/* 41 */     Throwable t = this;
/*    */     for (;;) {
/* 43 */       Throwable cause = t.getCause();
/* 44 */       if (cause == null) break;
/* 45 */       t = cause;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 50 */     return t;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\SolrServerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */