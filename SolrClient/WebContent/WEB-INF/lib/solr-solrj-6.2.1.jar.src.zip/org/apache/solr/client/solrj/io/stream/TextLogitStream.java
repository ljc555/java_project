/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.solr.client.solrj.SolrRequest.METHOD;
/*     */ import org.apache.solr.client.solrj.impl.CloudSolrClient;
/*     */ import org.apache.solr.client.solrj.impl.HttpSolrClient;
/*     */ import org.apache.solr.client.solrj.io.ClassificationEvaluation;
/*     */ import org.apache.solr.client.solrj.io.SolrClientCache;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ import org.apache.solr.client.solrj.request.QueryRequest;
/*     */ import org.apache.solr.client.solrj.response.QueryResponse;
/*     */ import org.apache.solr.common.cloud.ClusterState;
/*     */ import org.apache.solr.common.cloud.Replica;
/*     */ import org.apache.solr.common.cloud.Replica.State;
/*     */ import org.apache.solr.common.cloud.Slice;
/*     */ import org.apache.solr.common.cloud.ZkCoreNodeProps;
/*     */ import org.apache.solr.common.cloud.ZkStateReader;
/*     */ import org.apache.solr.common.params.ModifiableSolrParams;
/*     */ import org.apache.solr.common.util.ExecutorUtil;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ import org.apache.solr.common.util.SolrjNamedThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextLogitStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected String zkHost;
/*     */   protected String collection;
/*     */   protected Map<String, String> params;
/*     */   protected String field;
/*     */   protected String name;
/*     */   protected String outcome;
/*     */   protected int positiveLabel;
/*     */   protected double threshold;
/*     */   protected List<Double> weights;
/*     */   protected int maxIterations;
/*     */   protected int iteration;
/*     */   protected double error;
/*     */   protected List<Double> idfs;
/*     */   protected ClassificationEvaluation evaluation;
/*     */   protected transient SolrClientCache cache;
/*     */   protected transient boolean isCloseCache;
/*     */   protected transient CloudSolrClient cloudSolrClient;
/*     */   protected transient StreamContext streamContext;
/*     */   protected ExecutorService executorService;
/*     */   protected TupleStream termsStream;
/*     */   private List<String> terms;
/*  91 */   private double learningRate = 0.01D;
/*  92 */   private double lastError = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextLogitStream(String zkHost, String collectionName, Map params, String name, String field, TupleStream termsStream, List<Double> weights, String outcome, int positiveLabel, double threshold, int maxIterations)
/*     */     throws IOException
/*     */   {
/* 106 */     init(collectionName, zkHost, params, name, field, termsStream, weights, outcome, positiveLabel, threshold, maxIterations, this.iteration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextLogitStream(StreamExpression expression, StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 115 */     String collectionName = factory.getValueOperand(expression, 0);
/* 116 */     List<StreamExpressionNamedParameter> namedParams = factory.getNamedOperands(expression);
/* 117 */     StreamExpressionNamedParameter zkHostExpression = factory.getNamedOperand(expression, "zkHost");
/* 118 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*     */     
/*     */ 
/* 121 */     if (expression.getParameters().size() != 1 + namedParams.size() + streamExpressions.size()) {
/* 122 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (null == collectionName) {
/* 127 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - collectionName expected as first operand", new Object[] { expression }));
/*     */     }
/*     */     
/*     */ 
/* 131 */     if (0 == namedParams.size()) {
/* 132 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - at least one named parameter expected. eg. 'q=*:*'", new Object[] { expression }));
/*     */     }
/*     */     
/* 135 */     Map<String, String> params = new HashMap();
/* 136 */     for (StreamExpressionNamedParameter namedParam : namedParams) {
/* 137 */       if (!namedParam.getName().equals("zkHost")) {
/* 138 */         params.put(namedParam.getName(), namedParam.getParameter().toString().trim());
/*     */       }
/*     */     }
/*     */     
/* 142 */     String name = (String)params.get("name");
/* 143 */     if (name != null) {
/* 144 */       params.remove("name");
/*     */     } else {
/* 146 */       throw new IOException("name param cannot be null for TextLogitStream");
/*     */     }
/*     */     
/* 149 */     String feature = (String)params.get("field");
/* 150 */     if (feature != null) {
/* 151 */       params.remove("field");
/*     */     } else {
/* 153 */       throw new IOException("field param cannot be null for TextLogitStream");
/*     */     }
/*     */     
/* 156 */     TupleStream stream = null;
/*     */     
/* 158 */     if (streamExpressions.size() > 0) {
/* 159 */       stream = factory.constructStream((StreamExpression)streamExpressions.get(0));
/*     */     } else {
/* 161 */       throw new IOException("features must be present for TextLogitStream");
/*     */     }
/*     */     
/* 164 */     String maxIterationsParam = (String)params.get("maxIterations");
/* 165 */     int maxIterations = 0;
/* 166 */     if (maxIterationsParam != null) {
/* 167 */       maxIterations = Integer.parseInt(maxIterationsParam);
/* 168 */       params.remove("maxIterations");
/*     */     } else {
/* 170 */       throw new IOException("maxIterations param cannot be null for TextLogitStream");
/*     */     }
/*     */     
/* 173 */     String outcomeParam = (String)params.get("outcome");
/*     */     
/* 175 */     if (outcomeParam != null) {
/* 176 */       params.remove("outcome");
/*     */     } else {
/* 178 */       throw new IOException("outcome param cannot be null for TextLogitStream");
/*     */     }
/*     */     
/* 181 */     String positiveLabelParam = (String)params.get("positiveLabel");
/* 182 */     int positiveLabel = 1;
/* 183 */     if (positiveLabelParam != null) {
/* 184 */       positiveLabel = Integer.parseInt(positiveLabelParam);
/* 185 */       params.remove("positiveLabel");
/*     */     }
/*     */     
/* 188 */     String thresholdParam = (String)params.get("threshold");
/* 189 */     double threshold = 0.5D;
/* 190 */     if (thresholdParam != null) {
/* 191 */       threshold = Double.parseDouble(thresholdParam);
/* 192 */       params.remove("threshold");
/*     */     }
/*     */     
/* 195 */     int iteration = 0;
/* 196 */     String iterationParam = (String)params.get("iteration");
/* 197 */     if (iterationParam != null) {
/* 198 */       iteration = Integer.parseInt(iterationParam);
/* 199 */       params.remove("iteration");
/*     */     }
/*     */     
/* 202 */     List<Double> weights = null;
/* 203 */     String weightsParam = (String)params.get("weights");
/* 204 */     if (weightsParam != null) {
/* 205 */       weights = new ArrayList();
/* 206 */       String[] weightsArray = weightsParam.split(",");
/* 207 */       for (String weightString : weightsArray) {
/* 208 */         weights.add(Double.valueOf(Double.parseDouble(weightString)));
/*     */       }
/* 210 */       params.remove("weights");
/*     */     }
/*     */     
/*     */ 
/* 214 */     String zkHost = null;
/* 215 */     if (null == zkHostExpression) {
/* 216 */       zkHost = factory.getCollectionZkHost(collectionName);
/*     */     }
/* 218 */     else if ((zkHostExpression.getParameter() instanceof StreamExpressionValue)) {
/* 219 */       zkHost = ((StreamExpressionValue)zkHostExpression.getParameter()).getValue();
/*     */     }
/* 221 */     if (null == zkHost) {
/* 222 */       throw new IOException(String.format(Locale.ROOT, "invalid expression %s - zkHost not found for collection '%s'", new Object[] { expression, collectionName }));
/*     */     }
/*     */     
/*     */ 
/* 226 */     init(collectionName, zkHost, params, name, feature, stream, weights, outcomeParam, positiveLabel, threshold, maxIterations, iteration);
/*     */   }
/*     */   
/*     */   public StreamExpressionParameter toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 231 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 236 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 239 */     expression.addParameter(this.collection);
/*     */     
/* 241 */     if ((includeStreams) && (!(this.termsStream instanceof TermsStream))) {
/* 242 */       if ((this.termsStream instanceof Expressible)) {
/* 243 */         expression.addParameter(((Expressible)this.termsStream).toExpression(factory));
/*     */       } else {
/* 245 */         throw new IOException("This TextLogitStream contains a non-expressible TupleStream - it cannot be converted to an expression");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 250 */     for (Map.Entry<String, String> param : this.params.entrySet()) {
/* 251 */       expression.addParameter(new StreamExpressionNamedParameter((String)param.getKey(), (String)param.getValue()));
/*     */     }
/*     */     
/* 254 */     expression.addParameter(new StreamExpressionNamedParameter("field", this.field));
/* 255 */     expression.addParameter(new StreamExpressionNamedParameter("name", this.name));
/* 256 */     if ((this.termsStream instanceof TermsStream)) {
/* 257 */       loadTerms();
/* 258 */       expression.addParameter(new StreamExpressionNamedParameter("terms", toString(this.terms)));
/*     */     }
/*     */     
/* 261 */     expression.addParameter(new StreamExpressionNamedParameter("outcome", this.outcome));
/* 262 */     if (this.weights != null) {
/* 263 */       expression.addParameter(new StreamExpressionNamedParameter("weights", toString(this.weights)));
/*     */     }
/* 265 */     expression.addParameter(new StreamExpressionNamedParameter("maxIterations", Integer.toString(this.maxIterations)));
/*     */     
/* 267 */     if (this.iteration > 0) {
/* 268 */       expression.addParameter(new StreamExpressionNamedParameter("iteration", Integer.toString(this.iteration)));
/*     */     }
/*     */     
/* 271 */     expression.addParameter(new StreamExpressionNamedParameter("positiveLabel", Integer.toString(this.positiveLabel)));
/* 272 */     expression.addParameter(new StreamExpressionNamedParameter("threshold", Double.toString(this.threshold)));
/*     */     
/*     */ 
/* 275 */     expression.addParameter(new StreamExpressionNamedParameter("zkHost", this.zkHost));
/*     */     
/* 277 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(String collectionName, String zkHost, Map params, String name, String feature, TupleStream termsStream, List<Double> weights, String outcome, int positiveLabel, double threshold, int maxIterations, int iteration)
/*     */     throws IOException
/*     */   {
/* 292 */     this.zkHost = zkHost;
/* 293 */     this.collection = collectionName;
/* 294 */     this.params = params;
/* 295 */     this.name = name;
/* 296 */     this.field = feature;
/* 297 */     this.termsStream = termsStream;
/* 298 */     this.outcome = outcome;
/* 299 */     this.positiveLabel = positiveLabel;
/* 300 */     this.threshold = threshold;
/* 301 */     this.weights = weights;
/* 302 */     this.maxIterations = maxIterations;
/* 303 */     this.iteration = iteration;
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context) {
/* 307 */     this.cache = context.getSolrClientCache();
/* 308 */     this.streamContext = context;
/* 309 */     this.termsStream.setStreamContext(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws IOException
/*     */   {
/* 317 */     if (this.cache == null) {
/* 318 */       this.isCloseCache = true;
/* 319 */       this.cache = new SolrClientCache();
/*     */     } else {
/* 321 */       this.isCloseCache = false;
/*     */     }
/*     */     
/* 324 */     this.cloudSolrClient = this.cache.getCloudSolrClient(this.zkHost);
/* 325 */     this.executorService = ExecutorUtil.newMDCAwareCachedThreadPool(new SolrjNamedThreadFactory("TextLogitSolrStream"));
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 329 */     List<TupleStream> l = new ArrayList();
/* 330 */     l.add(this.termsStream);
/* 331 */     return l;
/*     */   }
/*     */   
/*     */   protected List<String> getShardUrls() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 338 */       ZkStateReader zkStateReader = this.cloudSolrClient.getZkStateReader();
/* 339 */       ClusterState clusterState = zkStateReader.getClusterState();
/* 340 */       Set<String> liveNodes = clusterState.getLiveNodes();
/*     */       
/* 342 */       Collection<Slice> slices = clusterState.getActiveSlices(this.collection);
/* 343 */       List baseUrls = new ArrayList();
/*     */       
/* 345 */       for (Slice slice : slices) {
/* 346 */         Collection<Replica> replicas = slice.getReplicas();
/* 347 */         List<Replica> shuffler = new ArrayList();
/* 348 */         for (Replica replica : replicas) {
/* 349 */           if ((replica.getState() == Replica.State.ACTIVE) && (liveNodes.contains(replica.getNodeName()))) {
/* 350 */             shuffler.add(replica);
/*     */           }
/*     */         }
/*     */         
/* 354 */         Collections.shuffle(shuffler, new Random());
/* 355 */         Replica rep = (Replica)shuffler.get(0);
/* 356 */         ZkCoreNodeProps zkProps = new ZkCoreNodeProps(rep);
/* 357 */         String url = zkProps.getCoreUrl();
/* 358 */         baseUrls.add(url);
/*     */       }
/*     */       
/* 361 */       return baseUrls;
/*     */     }
/*     */     catch (Exception e) {
/* 364 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Future<Tuple>> callShards(List<String> baseUrls) throws IOException
/*     */   {
/* 370 */     List<Future<Tuple>> futures = new ArrayList();
/* 371 */     for (String baseUrl : baseUrls) {
/* 372 */       LogitCall lc = new LogitCall(baseUrl, this.params, this.field, this.terms, this.weights, this.outcome, this.positiveLabel, this.learningRate, this.iteration);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 382 */       Future<Tuple> future = this.executorService.submit(lc);
/* 383 */       futures.add(future);
/*     */     }
/*     */     
/* 386 */     return futures;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 390 */     if (this.isCloseCache) {
/* 391 */       this.cache.close();
/*     */     }
/*     */     
/* 394 */     this.executorService.shutdown();
/* 395 */     this.termsStream.close();
/*     */   }
/*     */   
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 400 */     return null;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory) throws IOException
/*     */   {
/* 405 */     StreamExplanation explanation = new StreamExplanation(getStreamNodeId().toString());
/* 406 */     explanation.setFunctionName(factory.getFunctionName(getClass()));
/* 407 */     explanation.setImplementingClass(getClass().getName());
/* 408 */     explanation.setExpressionType("ml-model");
/* 409 */     explanation.setExpression(toExpression(factory).toString());
/*     */     
/* 411 */     explanation.addChild(this.termsStream.toExplanation(factory));
/*     */     
/* 413 */     return explanation;
/*     */   }
/*     */   
/*     */   public void loadTerms() throws IOException {
/* 417 */     if (this.terms == null) {
/* 418 */       this.termsStream.open();
/* 419 */       this.terms = new ArrayList();
/* 420 */       this.idfs = new ArrayList();
/*     */       for (;;)
/*     */       {
/* 423 */         Tuple termTuple = this.termsStream.read();
/* 424 */         if (termTuple.EOF) {
/*     */           break;
/*     */         }
/* 427 */         this.terms.add(termTuple.getString("term_s"));
/* 428 */         this.idfs.add(termTuple.getDouble("idf_d"));
/*     */       }
/*     */       
/* 431 */       this.termsStream.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*     */     try {
/* 438 */       if (++this.iteration > this.maxIterations) {
/* 439 */         Map map = new HashMap();
/* 440 */         map.put("EOF", Boolean.valueOf(true));
/* 441 */         return new Tuple(map);
/*     */       }
/*     */       
/* 444 */       if (this.idfs == null) {
/* 445 */         loadTerms();
/*     */         
/* 447 */         if ((this.weights != null) && (this.terms.size() + 1 != this.weights.size())) {
/* 448 */           throw new IOException(String.format(Locale.ROOT, "invalid expression %s - the number of weights must be %d, found %d", new Object[] { Integer.valueOf(this.terms.size() + 1), Integer.valueOf(this.weights.size()) }));
/*     */         }
/*     */       }
/*     */       
/* 452 */       List<List<Double>> allWeights = new ArrayList();
/* 453 */       this.evaluation = new ClassificationEvaluation();
/*     */       
/* 455 */       this.error = 0.0D;
/* 456 */       for (Future<Tuple> logitCall : callShards(getShardUrls()))
/*     */       {
/* 458 */         Tuple tuple = (Tuple)logitCall.get();
/* 459 */         List<Double> shardWeights = (List)tuple.get("weights");
/* 460 */         allWeights.add(shardWeights);
/* 461 */         this.error += tuple.getDouble("error").doubleValue();
/* 462 */         Map shardEvaluation = (Map)tuple.get("evaluation");
/* 463 */         this.evaluation.addEvaluation(shardEvaluation);
/*     */       }
/*     */       
/* 466 */       this.weights = averageWeights(allWeights);
/* 467 */       Object map = new HashMap();
/* 468 */       ((Map)map).put("id", this.name + "_" + this.iteration);
/* 469 */       ((Map)map).put("name_s", this.name);
/* 470 */       ((Map)map).put("field_s", this.field);
/* 471 */       ((Map)map).put("terms_ss", this.terms);
/* 472 */       ((Map)map).put("iteration_i", Integer.valueOf(this.iteration));
/*     */       
/* 474 */       if (this.weights != null) {
/* 475 */         ((Map)map).put("weights_ds", this.weights);
/*     */       }
/*     */       
/* 478 */       ((Map)map).put("error_d", Double.valueOf(this.error));
/* 479 */       this.evaluation.putToMap((Map)map);
/* 480 */       ((Map)map).put("alpha_d", Double.valueOf(this.learningRate));
/* 481 */       ((Map)map).put("idfs_ds", this.idfs);
/*     */       
/* 483 */       if (this.iteration != 1) {
/* 484 */         if (this.lastError <= this.error) {
/* 485 */           this.learningRate *= 0.5D;
/*     */         } else {
/* 487 */           this.learningRate *= 1.05D;
/*     */         }
/*     */       }
/*     */       
/* 491 */       this.lastError = this.error;
/*     */       
/* 493 */       return new Tuple((Map)map);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 497 */       throw new IOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Double> averageWeights(List<List<Double>> allWeights) {
/* 502 */     double[] working = new double[((List)allWeights.get(0)).size()];
/* 503 */     for (Iterator localIterator = allWeights.iterator(); localIterator.hasNext();) { shardWeights = (List)localIterator.next();
/* 504 */       for (i = 0; i < working.length; i++)
/* 505 */         working[i] += ((Double)shardWeights.get(i)).doubleValue();
/*     */     }
/*     */     List<Double> shardWeights;
/*     */     int i;
/* 509 */     for (int i = 0; i < working.length; i++) {
/* 510 */       working[i] /= allWeights.size();
/*     */     }
/*     */     
/* 513 */     Object ave = new ArrayList();
/* 514 */     for (double d : working) {
/* 515 */       ((List)ave).add(Double.valueOf(d));
/*     */     }
/*     */     
/* 518 */     return (List<Double>)ave;
/*     */   }
/*     */   
/*     */   static String toString(List items) {
/* 522 */     StringBuilder buf = new StringBuilder();
/* 523 */     for (Object item : items) {
/* 524 */       if (buf.length() > 0) {
/* 525 */         buf.append(",");
/*     */       }
/*     */       
/* 528 */       buf.append(item.toString());
/*     */     }
/*     */     
/* 531 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected class TermsStream extends TupleStream
/*     */   {
/*     */     private List<String> terms;
/*     */     private Iterator<String> it;
/*     */     
/*     */     public TermsStream() {
/* 540 */       this.terms = terms;
/*     */     }
/*     */     
/*     */     public void setStreamContext(StreamContext context) {}
/*     */     
/*     */     public List<TupleStream> children()
/*     */     {
/* 547 */       return new ArrayList();
/*     */     }
/*     */     
/* 550 */     public void open() throws IOException { this.it = this.terms.iterator(); }
/*     */     
/*     */     public void close() throws IOException
/*     */     {}
/*     */     
/*     */     public Tuple read() throws IOException
/*     */     {
/* 557 */       HashMap map = new HashMap();
/* 558 */       if (this.it.hasNext()) {
/* 559 */         map.put("term_s", this.it.next());
/* 560 */         map.put("score_f", Double.valueOf(1.0D));
/* 561 */         return new Tuple(map);
/*     */       }
/* 563 */       map.put("EOF", Boolean.valueOf(true));
/* 564 */       return new Tuple(map);
/*     */     }
/*     */     
/*     */     public StreamComparator getStreamSort()
/*     */     {
/* 569 */       return null;
/*     */     }
/*     */     
/*     */     public Explanation toExplanation(StreamFactory factory) throws IOException {
/* 573 */       return 
/*     */       
/*     */ 
/*     */ 
/* 577 */         new StreamExplanation(getStreamNodeId().toString()).withFunctionName("non-expressible").withImplementingClass(getClass().getName()).withExpressionType("stream-source").withExpression("non-expressible");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected class LogitCall
/*     */     implements Callable<Tuple>
/*     */   {
/*     */     private String baseUrl;
/*     */     
/*     */     private String feature;
/*     */     
/*     */     private List<String> terms;
/*     */     
/*     */     private List<Double> weights;
/*     */     
/*     */     private int iteration;
/*     */     
/*     */     private String outcome;
/*     */     
/*     */     private int positiveLabel;
/*     */     private double learningRate;
/*     */     private Map<String, String> paramsMap;
/*     */     
/*     */     public LogitCall(Map<String, String> baseUrl, String paramsMap, List<String> feature, List<Double> terms, String weights, int outcome, double positiveLabel, int arg10)
/*     */     {
/* 603 */       this.baseUrl = baseUrl;
/* 604 */       this.feature = feature;
/* 605 */       this.terms = terms;
/* 606 */       this.weights = weights;
/* 607 */       this.iteration = iteration;
/* 608 */       this.outcome = outcome;
/* 609 */       this.positiveLabel = positiveLabel;
/* 610 */       this.learningRate = learningRate;
/* 611 */       this.paramsMap = paramsMap;
/*     */     }
/*     */     
/*     */     public Tuple call() throws Exception {
/* 615 */       ModifiableSolrParams params = new ModifiableSolrParams();
/* 616 */       HttpSolrClient solrClient = TextLogitStream.this.cache.getHttpSolrClient(this.baseUrl);
/*     */       
/* 618 */       params.add("distrib", new String[] { "false" });
/* 619 */       params.add("fq", new String[] { "{!tlogit}" });
/* 620 */       params.add("feature", new String[] { this.feature });
/* 621 */       params.add("terms", new String[] { TextLogitStream.toString(this.terms) });
/* 622 */       params.add("idfs", new String[] { TextLogitStream.toString(TextLogitStream.this.idfs) });
/*     */       
/* 624 */       for (String key : this.paramsMap.keySet()) {
/* 625 */         params.add(key, new String[] { (String)this.paramsMap.get(key) });
/*     */       }
/*     */       
/* 628 */       if (this.weights != null) {
/* 629 */         params.add("weights", new String[] { TextLogitStream.toString(this.weights) });
/*     */       }
/*     */       
/* 632 */       params.add("iteration", new String[] { Integer.toString(this.iteration) });
/* 633 */       params.add("outcome", new String[] { this.outcome });
/* 634 */       params.add("positiveLabel", new String[] { Integer.toString(this.positiveLabel) });
/* 635 */       params.add("threshold", new String[] { Double.toString(TextLogitStream.this.threshold) });
/* 636 */       params.add("alpha", new String[] { Double.toString(this.learningRate) });
/*     */       
/* 638 */       QueryRequest request = new QueryRequest(params, SolrRequest.METHOD.POST);
/* 639 */       QueryResponse response = (QueryResponse)request.process(solrClient);
/* 640 */       NamedList res = response.getResponse();
/*     */       
/* 642 */       NamedList logit = (NamedList)res.get("logit");
/*     */       
/* 644 */       List<Double> shardWeights = (List)logit.get("weights");
/* 645 */       double shardError = ((Double)logit.get("error")).doubleValue();
/*     */       
/* 647 */       Map map = new HashMap();
/*     */       
/* 649 */       map.put("error", Double.valueOf(shardError));
/* 650 */       map.put("weights", shardWeights);
/* 651 */       map.put("evaluation", logit.get("evaluation"));
/*     */       
/* 653 */       return new Tuple(map);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\TextLogitStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */