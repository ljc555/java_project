/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ZkCredentialsProvider
/*    */ {
/*    */   public abstract Collection<ZkCredentials> getCredentials();
/*    */   
/*    */   public static class ZkCredentials
/*    */   {
/*    */     String scheme;
/*    */     byte[] auth;
/*    */     
/*    */     public ZkCredentials(String scheme, byte[] auth)
/*    */     {
/* 29 */       this.scheme = scheme;
/* 30 */       this.auth = auth;
/*    */     }
/*    */     
/*    */     public String getScheme() {
/* 34 */       return this.scheme;
/*    */     }
/*    */     
/*    */     public byte[] getAuth() {
/* 38 */       return this.auth;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\ZkCredentialsProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */