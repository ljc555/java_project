package org.apache.solr.common.util;

import java.io.DataInput;
import java.io.InputStream;

public abstract class DataInputInputStream
  extends InputStream
  implements DataInput
{}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\DataInputInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */