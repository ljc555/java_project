/*    */ package org.apache.solr.common.util;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLUtil
/*    */ {
/* 24 */   public static final Pattern URL_PREFIX = Pattern.compile("^([a-z]*?://).*");
/*    */   
/*    */   public static String removeScheme(String url) {
/* 27 */     Matcher matcher = URL_PREFIX.matcher(url);
/* 28 */     if (matcher.matches()) {
/* 29 */       return url.substring(matcher.group(1).length());
/*    */     }
/*    */     
/* 32 */     return url;
/*    */   }
/*    */   
/*    */   public static boolean hasScheme(String url) {
/* 36 */     Matcher matcher = URL_PREFIX.matcher(url);
/* 37 */     return matcher.matches();
/*    */   }
/*    */   
/*    */   public static String getScheme(String url) {
/* 41 */     Matcher matcher = URL_PREFIX.matcher(url);
/* 42 */     if (matcher.matches()) {
/* 43 */       return matcher.group(1);
/*    */     }
/*    */     
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\util\URLUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */