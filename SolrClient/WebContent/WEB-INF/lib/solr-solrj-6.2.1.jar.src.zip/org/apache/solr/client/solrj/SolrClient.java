/*      */ package org.apache.solr.client.solrj;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.apache.solr.client.solrj.beans.DocumentObjectBinder;
/*      */ import org.apache.solr.client.solrj.impl.StreamingBinaryResponseParser;
/*      */ import org.apache.solr.client.solrj.request.AbstractUpdateRequest;
/*      */ import org.apache.solr.client.solrj.request.AbstractUpdateRequest.ACTION;
/*      */ import org.apache.solr.client.solrj.request.QueryRequest;
/*      */ import org.apache.solr.client.solrj.request.SolrPing;
/*      */ import org.apache.solr.client.solrj.request.UpdateRequest;
/*      */ import org.apache.solr.client.solrj.response.QueryResponse;
/*      */ import org.apache.solr.client.solrj.response.SolrPingResponse;
/*      */ import org.apache.solr.client.solrj.response.UpdateResponse;
/*      */ import org.apache.solr.common.SolrDocument;
/*      */ import org.apache.solr.common.SolrDocumentList;
/*      */ import org.apache.solr.common.SolrInputDocument;
/*      */ import org.apache.solr.common.StringUtils;
/*      */ import org.apache.solr.common.params.ModifiableSolrParams;
/*      */ import org.apache.solr.common.params.SolrParams;
/*      */ import org.apache.solr.common.util.NamedList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SolrClient
/*      */   implements Serializable, Closeable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private DocumentObjectBinder binder;
/*      */   
/*      */   public UpdateResponse add(String collection, Collection<SolrInputDocument> docs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*   71 */     return add(collection, docs, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(Collection<SolrInputDocument> docs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*   85 */     return add(null, docs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(String collection, Collection<SolrInputDocument> docs, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  103 */     UpdateRequest req = new UpdateRequest();
/*  104 */     req.add(docs);
/*  105 */     req.setCommitWithin(commitWithinMs);
/*  106 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(Collection<SolrInputDocument> docs, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  123 */     return add(null, docs, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(String collection, SolrInputDocument doc)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  138 */     return add(collection, doc, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(SolrInputDocument doc)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  152 */     return add(null, doc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(String collection, SolrInputDocument doc, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  170 */     UpdateRequest req = new UpdateRequest();
/*  171 */     req.add(doc);
/*  172 */     req.setCommitWithin(commitWithinMs);
/*  173 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(SolrInputDocument doc, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  190 */     return add(null, doc, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(String collection, Iterator<SolrInputDocument> docIterator)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  207 */     UpdateRequest req = new UpdateRequest();
/*  208 */     req.setDocIterator(docIterator);
/*  209 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse add(Iterator<SolrInputDocument> docIterator)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  224 */     return add(null, docIterator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBean(String collection, Object obj)
/*      */     throws IOException, SolrServerException
/*      */   {
/*  242 */     return addBean(collection, obj, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBean(Object obj)
/*      */     throws IOException, SolrServerException
/*      */   {
/*  259 */     return addBean(null, obj, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBean(String collection, Object obj, int commitWithinMs)
/*      */     throws IOException, SolrServerException
/*      */   {
/*  277 */     return add(collection, getBinder().toSolrInputDocument(obj), commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBean(Object obj, int commitWithinMs)
/*      */     throws IOException, SolrServerException
/*      */   {
/*  294 */     return add(null, getBinder().toSolrInputDocument(obj), commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(String collection, Collection<?> beans)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  312 */     return addBeans(collection, beans, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(Collection<?> beans)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  329 */     return addBeans(null, beans, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(String collection, Collection<?> beans, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  352 */     DocumentObjectBinder binder = getBinder();
/*  353 */     ArrayList<SolrInputDocument> docs = new ArrayList(beans.size());
/*  354 */     for (Object bean : beans) {
/*  355 */       docs.add(binder.toSolrInputDocument(bean));
/*      */     }
/*  357 */     return add(collection, docs, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(Collection<?> beans, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  379 */     return addBeans(null, beans, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(String collection, final Iterator<?> beanIterator)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  396 */     UpdateRequest req = new UpdateRequest();
/*  397 */     req.setDocIterator(new Iterator()
/*      */     {
/*      */       public boolean hasNext()
/*      */       {
/*  401 */         return beanIterator.hasNext();
/*      */       }
/*      */       
/*      */       public SolrInputDocument next()
/*      */       {
/*  406 */         Object o = beanIterator.next();
/*  407 */         if (o == null) return null;
/*  408 */         return SolrClient.this.getBinder().toSolrInputDocument(o);
/*      */       }
/*      */       
/*      */       public void remove()
/*      */       {
/*  413 */         beanIterator.remove();
/*      */       }
/*  415 */     });
/*  416 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse addBeans(Iterator<?> beanIterator)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  431 */     return addBeans(null, beanIterator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit(String collection)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  448 */     return commit(collection, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit()
/*      */     throws SolrServerException, IOException
/*      */   {
/*  463 */     return commit(null, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit(String collection, boolean waitFlush, boolean waitSearcher)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  482 */     return 
/*      */     
/*  484 */       (UpdateResponse)new UpdateRequest().setAction(AbstractUpdateRequest.ACTION.COMMIT, waitFlush, waitSearcher).process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit(boolean waitFlush, boolean waitSearcher)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  501 */     return commit(null, waitFlush, waitSearcher);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit(String collection, boolean waitFlush, boolean waitSearcher, boolean softCommit)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  522 */     return 
/*      */     
/*  524 */       (UpdateResponse)new UpdateRequest().setAction(AbstractUpdateRequest.ACTION.COMMIT, waitFlush, waitSearcher, softCommit).process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse commit(boolean waitFlush, boolean waitSearcher, boolean softCommit)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  544 */     return commit(null, waitFlush, waitSearcher, softCommit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize(String collection)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  563 */     return optimize(collection, true, true, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize()
/*      */     throws SolrServerException, IOException
/*      */   {
/*  580 */     return optimize(null, true, true, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize(String collection, boolean waitFlush, boolean waitSearcher)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  600 */     return optimize(collection, waitFlush, waitSearcher, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize(boolean waitFlush, boolean waitSearcher)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  619 */     return optimize(null, waitFlush, waitSearcher);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize(String collection, boolean waitFlush, boolean waitSearcher, int maxSegments)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  641 */     return 
/*      */     
/*  643 */       (UpdateResponse)new UpdateRequest().setAction(AbstractUpdateRequest.ACTION.OPTIMIZE, waitFlush, waitSearcher, maxSegments).process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse optimize(boolean waitFlush, boolean waitSearcher, int maxSegments)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  664 */     return optimize(null, waitFlush, waitSearcher, maxSegments);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse rollback(String collection)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  683 */     return (UpdateResponse)new UpdateRequest().rollback().process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse rollback()
/*      */     throws SolrServerException, IOException
/*      */   {
/*  700 */     return rollback(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String collection, String id)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  716 */     return deleteById(collection, id, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String id)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  731 */     return deleteById(null, id);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String collection, String id, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  750 */     UpdateRequest req = new UpdateRequest();
/*  751 */     req.deleteById(id);
/*  752 */     req.setCommitWithin(commitWithinMs);
/*  753 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String id, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  771 */     return deleteById(null, id, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String collection, List<String> ids)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  787 */     return deleteById(collection, ids, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(List<String> ids)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  802 */     return deleteById(null, ids);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(String collection, List<String> ids, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  821 */     UpdateRequest req = new UpdateRequest();
/*  822 */     req.deleteById(ids);
/*  823 */     req.setCommitWithin(commitWithinMs);
/*  824 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteById(List<String> ids, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  842 */     return deleteById(null, ids, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteByQuery(String collection, String query)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  858 */     return deleteByQuery(collection, query, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteByQuery(String query)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  873 */     return deleteByQuery(null, query);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteByQuery(String collection, String query, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  892 */     UpdateRequest req = new UpdateRequest();
/*  893 */     req.deleteByQuery(query);
/*  894 */     req.setCommitWithin(commitWithinMs);
/*  895 */     return (UpdateResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UpdateResponse deleteByQuery(String query, int commitWithinMs)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  913 */     return deleteByQuery(null, query, commitWithinMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrPingResponse ping()
/*      */     throws SolrServerException, IOException
/*      */   {
/*  926 */     return (SolrPingResponse)new SolrPing().process(this, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse query(String collection, SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  942 */     return (QueryResponse)new QueryRequest(params).process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse query(SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  957 */     return query(null, params);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse query(String collection, SolrParams params, SolrRequest.METHOD method)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  974 */     return (QueryResponse)new QueryRequest(params, method).process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse query(SolrParams params, SolrRequest.METHOD method)
/*      */     throws SolrServerException, IOException
/*      */   {
/*  990 */     return query(null, params, method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse queryAndStreamResponse(String collection, SolrParams params, StreamingResponseCallback callback)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1016 */     ResponseParser parser = new StreamingBinaryResponseParser(callback);
/* 1017 */     QueryRequest req = new QueryRequest(params);
/* 1018 */     req.setStreamingResponseCallback(callback);
/* 1019 */     req.setResponseParser(parser);
/* 1020 */     return (QueryResponse)req.process(this, collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryResponse queryAndStreamResponse(SolrParams params, StreamingResponseCallback callback)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1045 */     return queryAndStreamResponse(null, params, callback);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocument getById(String collection, String id)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1060 */     return getById(collection, id, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocument getById(String id)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1073 */     return getById(null, id, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocument getById(String collection, String id, SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1090 */     SolrDocumentList docs = getById(collection, Collections.singletonList(id), params);
/* 1091 */     if (!docs.isEmpty()) {
/* 1092 */       return (SolrDocument)docs.get(0);
/*      */     }
/* 1094 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocument getById(String id, SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1110 */     return getById(null, id, params);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocumentList getById(String collection, Collection<String> ids)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1127 */     return getById(collection, ids, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocumentList getById(Collection<String> ids)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1143 */     return getById(null, ids);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocumentList getById(String collection, Collection<String> ids, SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1163 */     if ((ids == null) || (ids.isEmpty())) {
/* 1164 */       throw new IllegalArgumentException("Must provide an identifier of a document to retrieve.");
/*      */     }
/*      */     
/* 1167 */     ModifiableSolrParams reqParams = new ModifiableSolrParams(params);
/* 1168 */     if (StringUtils.isEmpty(reqParams.get("qt"))) {
/* 1169 */       reqParams.set("qt", new String[] { "/get" });
/*      */     }
/* 1171 */     reqParams.set("ids", (String[])ids.toArray(new String[ids.size()]));
/*      */     
/* 1173 */     return query(collection, reqParams).getResults();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SolrDocumentList getById(Collection<String> ids, SolrParams params)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1191 */     return getById(null, ids, params);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract NamedList<Object> request(SolrRequest paramSolrRequest, String paramString)
/*      */     throws SolrServerException, IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final NamedList<Object> request(SolrRequest request)
/*      */     throws SolrServerException, IOException
/*      */   {
/* 1219 */     return request(request, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DocumentObjectBinder getBinder()
/*      */   {
/* 1231 */     if (this.binder == null) {
/* 1232 */       this.binder = new DocumentObjectBinder();
/*      */     }
/* 1234 */     return this.binder;
/*      */   }
/*      */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\SolrClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */