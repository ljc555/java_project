/*    */ package org.apache.solr.common.cloud;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.zookeeper.ZooDefs.Ids;
/*    */ import org.apache.zookeeper.data.ACL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultZkACLProvider
/*    */   implements ZkACLProvider
/*    */ {
/*    */   private List<ACL> globalACLsToAdd;
/*    */   
/*    */   public List<ACL> getACLsToAdd(String zNodePath)
/*    */   {
/* 31 */     if (this.globalACLsToAdd == null) {
/* 32 */       synchronized (this) {
/* 33 */         if (this.globalACLsToAdd == null) this.globalACLsToAdd = createGlobalACLsToAdd();
/*    */       }
/*    */     }
/* 36 */     return this.globalACLsToAdd;
/*    */   }
/*    */   
/*    */   protected List<ACL> createGlobalACLsToAdd()
/*    */   {
/* 41 */     return ZooDefs.Ids.OPEN_ACL_UNSAFE;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\cloud\DefaultZkACLProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */