package org.apache.solr.common.params;

public abstract interface SpatialParams
{
  public static final String POINT = "pt";
  public static final String DISTANCE = "d";
  public static final String FIELD = "sfield";
  public static final String UNITS = "units";
  public static final String MEASURE = "meas";
  public static final String SPHERE_RADIUS = "sphere_radius";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\SpatialParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */