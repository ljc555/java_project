/*     */ package org.apache.solr.client.solrj.impl;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.solr.client.solrj.SolrRequest;
/*     */ import org.apache.solr.client.solrj.request.JavaBinUpdateRequestCodec;
/*     */ import org.apache.solr.client.solrj.request.RequestWriter;
/*     */ import org.apache.solr.client.solrj.request.RequestWriter.LazyContentStream;
/*     */ import org.apache.solr.client.solrj.request.UpdateRequest;
/*     */ import org.apache.solr.common.util.ContentStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryRequestWriter
/*     */   extends RequestWriter
/*     */ {
/*     */   public Collection<ContentStream> getContentStreams(SolrRequest req)
/*     */     throws IOException
/*     */   {
/*  41 */     if ((req instanceof UpdateRequest)) {
/*  42 */       UpdateRequest updateRequest = (UpdateRequest)req;
/*  43 */       if ((isNull(updateRequest.getDocuments())) && 
/*  44 */         (isNull(updateRequest.getDeleteByIdMap())) && 
/*  45 */         (isNull(updateRequest.getDeleteQuery())) && 
/*  46 */         (updateRequest.getDocIterator() == null)) {
/*  47 */         return null;
/*     */       }
/*  49 */       List<ContentStream> l = new ArrayList();
/*  50 */       l.add(new RequestWriter.LazyContentStream(this, updateRequest));
/*  51 */       return l;
/*     */     }
/*  53 */     return super.getContentStreams(req);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUpdateContentType()
/*     */   {
/*  61 */     return "application/javabin";
/*     */   }
/*     */   
/*     */   public ContentStream getContentStream(UpdateRequest request) throws IOException
/*     */   {
/*  66 */     final BAOS baos = new BAOS();
/*  67 */     new JavaBinUpdateRequestCodec().marshal(request, baos);
/*     */     
/*  69 */     new ContentStream()
/*     */     {
/*     */       public String getName() {
/*  72 */         return null;
/*     */       }
/*     */       
/*     */       public String getSourceInfo()
/*     */       {
/*  77 */         return "javabin";
/*     */       }
/*     */       
/*     */       public String getContentType()
/*     */       {
/*  82 */         return "application/javabin";
/*     */       }
/*     */       
/*     */ 
/*     */       public Long getSize()
/*     */       {
/*  88 */         return new Long(baos.size());
/*     */       }
/*     */       
/*     */       public InputStream getStream()
/*     */       {
/*  93 */         return new ByteArrayInputStream(baos.getbuf(), 0, baos.size());
/*     */       }
/*     */       
/*     */       public Reader getReader()
/*     */       {
/*  98 */         throw new RuntimeException("No reader available . this is a binarystream");
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public void write(SolrRequest request, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 106 */     if ((request instanceof UpdateRequest)) {
/* 107 */       UpdateRequest updateRequest = (UpdateRequest)request;
/* 108 */       new JavaBinUpdateRequestCodec().marshal(updateRequest, os);
/*     */     }
/*     */   }
/*     */   
/*     */   class BAOS extends ByteArrayOutputStream
/*     */   {
/*     */     BAOS() {}
/*     */     
/*     */     byte[] getbuf() {
/* 117 */       return this.buf;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\BinaryRequestWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */