/*    */ package org.apache.solr.client.solrj.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.List;
/*    */ import org.apache.solr.client.solrj.StreamingResponseCallback;
/*    */ import org.apache.solr.common.SolrDocument;
/*    */ import org.apache.solr.common.SolrDocumentList;
/*    */ import org.apache.solr.common.SolrException;
/*    */ import org.apache.solr.common.SolrException.ErrorCode;
/*    */ import org.apache.solr.common.util.DataInputInputStream;
/*    */ import org.apache.solr.common.util.JavaBinCodec;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamingBinaryResponseParser
/*    */   extends BinaryResponseParser
/*    */ {
/*    */   final StreamingResponseCallback callback;
/*    */   
/*    */   public StreamingBinaryResponseParser(StreamingResponseCallback cb)
/*    */   {
/* 43 */     this.callback = cb;
/*    */   }
/*    */   
/*    */   public NamedList<Object> processResponse(InputStream body, String encoding)
/*    */   {
/*    */     try {
/* 49 */       JavaBinCodec codec = new JavaBinCodec()
/*    */       {
/*    */         public SolrDocument readSolrDocument(DataInputInputStream dis) throws IOException
/*    */         {
/* 53 */           SolrDocument doc = super.readSolrDocument(dis);
/* 54 */           StreamingBinaryResponseParser.this.callback.streamSolrDocument(doc);
/* 55 */           return null;
/*    */         }
/*    */         
/*    */         public SolrDocumentList readSolrDocumentList(DataInputInputStream dis) throws IOException
/*    */         {
/* 60 */           SolrDocumentList solrDocs = new SolrDocumentList();
/* 61 */           List list = (List)readVal(dis);
/* 62 */           solrDocs.setNumFound(((Long)list.get(0)).longValue());
/* 63 */           solrDocs.setStart(((Long)list.get(1)).longValue());
/* 64 */           solrDocs.setMaxScore((Float)list.get(2));
/*    */           
/* 66 */           StreamingBinaryResponseParser.this.callback.streamDocListInfo(solrDocs
/* 67 */             .getNumFound(), solrDocs
/* 68 */             .getStart(), solrDocs
/* 69 */             .getMaxScore());
/*    */           
/*    */ 
/* 72 */           this.tagByte = dis.readByte();
/* 73 */           if (this.tagByte >>> 5 != 134217724) {
/* 74 */             throw new RuntimeException("doclist must have an array");
/*    */           }
/* 76 */           int sz = readSize(dis);
/* 77 */           for (int i = 0; i < sz; i++)
/*    */           {
/* 79 */             readVal(dis);
/*    */           }
/* 81 */           return solrDocs;
/*    */         }
/*    */         
/* 84 */       };
/* 85 */       return (NamedList)codec.unmarshal(body);
/*    */     }
/*    */     catch (IOException e) {
/* 88 */       throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, "parsing error", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\impl\StreamingBinaryResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */