/*    */ package org.apache.solr.client.solrj.response;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Suggestion
/*    */ {
/*    */   private String term;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private long weight;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String payload;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Suggestion(String term, long weight, String payload)
/*    */   {
/* 28 */     this.term = term;
/* 29 */     this.weight = weight;
/* 30 */     this.payload = payload;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o)
/*    */   {
/* 35 */     if (this == o) return true;
/* 36 */     if (!(o instanceof Suggestion)) { return false;
/*    */     }
/* 38 */     Suggestion that = (Suggestion)o;
/*    */     
/* 40 */     return (this.payload.equals(that.payload)) && (this.term.equals(that.term));
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 46 */     int result = this.term.hashCode();
/* 47 */     result = 31 * result + this.payload.hashCode();
/* 48 */     return result;
/*    */   }
/*    */   
/*    */   public String getTerm() {
/* 52 */     return this.term;
/*    */   }
/*    */   
/*    */   public long getWeight() {
/* 56 */     return this.weight;
/*    */   }
/*    */   
/*    */   public String getPayload() {
/* 60 */     return this.payload;
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\Suggestion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */