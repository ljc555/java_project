package org.apache.solr.common.params;

public abstract interface SpellingParams
{
  public static final String SPELLCHECK_PREFIX = "spellcheck.";
  public static final String SPELLCHECK_DICT = "spellcheck.dictionary";
  public static final String SPELLCHECK_COUNT = "spellcheck.count";
  public static final String SPELLCHECK_ALTERNATIVE_TERM_COUNT = "spellcheck.alternativeTermCount";
  public static final String SPELLCHECK_MAX_RESULTS_FOR_SUGGEST = "spellcheck.maxResultsForSuggest";
  public static final String SPELLCHECK_MAX_RESULTS_FOR_SUGGEST_FQ = "spellcheck.maxResultsForSuggest.fq";
  public static final String SPELLCHECK_ONLY_MORE_POPULAR = "spellcheck.onlyMorePopular";
  public static final String SPELLCHECK_EXTENDED_RESULTS = "spellcheck.extendedResults";
  public static final String SPELLCHECK_Q = "spellcheck.q";
  public static final String SPELLCHECK_BUILD = "spellcheck.build";
  public static final String SPELLCHECK_RELOAD = "spellcheck.reload";
  public static final String SPELLCHECK_COLLATE = "spellcheck.collate";
  public static final String SPELLCHECK_MAX_COLLATIONS = "spellcheck.maxCollations";
  public static final String SPELLCHECK_MAX_COLLATION_TRIES = "spellcheck.maxCollationTries";
  public static final String SPELLCHECK_MAX_COLLATION_EVALUATIONS = "spellcheck.maxCollationEvaluations";
  public static final String SPELLCHECK_COLLATE_MAX_COLLECT_DOCS = "spellcheck.collateMaxCollectDocs";
  public static final String SPELLCHECK_COLLATE_EXTENDED_RESULTS = "spellcheck.collateExtendedResults";
  public static final String SPELLCHECK_COLLATE_PARAM_OVERRIDE = "spellcheck.collateParam.";
  public static final String SPELLCHECK_ACCURACY = "spellcheck.accuracy";
}


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\common\params\SpellingParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */