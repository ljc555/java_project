/*    */ package org.apache.solr.client.solrj;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.apache.solr.common.util.NamedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResponseParser
/*    */ {
/*    */   public abstract String getWriterType();
/*    */   
/*    */   public abstract NamedList<Object> processResponse(InputStream paramInputStream, String paramString);
/*    */   
/*    */   public abstract NamedList<Object> processResponse(Reader paramReader);
/*    */   
/*    */   public String getContentType()
/*    */   {
/* 42 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getVersion()
/*    */   {
/* 50 */     return "2.2";
/*    */   }
/*    */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\ResponseParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */