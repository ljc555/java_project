/*     */ package org.apache.solr.client.solrj.io.sql;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResultSetMetaDataImpl
/*     */   implements ResultSetMetaData
/*     */ {
/*     */   private final ResultSetImpl resultSet;
/*     */   private final Tuple metadataTuple;
/*     */   private final Tuple firstTuple;
/*     */   
/*     */   ResultSetMetaDataImpl(ResultSetImpl resultSet)
/*     */   {
/*  33 */     this.resultSet = resultSet;
/*  34 */     this.metadataTuple = this.resultSet.getMetadataTuple();
/*  35 */     this.firstTuple = this.resultSet.getFirstTuple();
/*     */   }
/*     */   
/*     */   private Class getColumnClass(int column) throws SQLException {
/*  39 */     Object o = this.firstTuple.get(getColumnLabel(column));
/*  40 */     if (o == null) {
/*  41 */       return String.class;
/*     */     }
/*  43 */     return o.getClass();
/*     */   }
/*     */   
/*     */   public int getColumnCount()
/*     */     throws SQLException
/*     */   {
/*  49 */     List<String> fields = this.metadataTuple.getStrings("fields");
/*  50 */     if (fields == null) {
/*  51 */       throw new SQLException("Unable to determine fields for column count");
/*     */     }
/*  53 */     return fields.size();
/*     */   }
/*     */   
/*     */   public boolean isAutoIncrement(int column) throws SQLException
/*     */   {
/*  58 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isCaseSensitive(int column) throws SQLException
/*     */   {
/*  63 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSearchable(int column) throws SQLException
/*     */   {
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isCurrency(int column) throws SQLException
/*     */   {
/*  73 */     return false;
/*     */   }
/*     */   
/*     */   public int isNullable(int column) throws SQLException
/*     */   {
/*  78 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isSigned(int column) throws SQLException
/*     */   {
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   public int getColumnDisplaySize(int column) throws SQLException
/*     */   {
/*  88 */     return getColumnLabel(column).length();
/*     */   }
/*     */   
/*     */   public String getColumnLabel(int column) throws SQLException
/*     */   {
/*  93 */     Map<String, String> aliases = (Map)this.metadataTuple.get("aliases");
/*  94 */     return (String)aliases.get(getColumnName(column));
/*     */   }
/*     */   
/*     */   public String getColumnName(int column) throws SQLException
/*     */   {
/*  99 */     List<String> columns = this.metadataTuple.getStrings("fields");
/* 100 */     if ((column < 1) || (column > columns.size())) {
/* 101 */       throw new SQLException("Column index " + column + " is not valid");
/*     */     }
/* 103 */     return (String)columns.get(column - 1);
/*     */   }
/*     */   
/*     */   public String getSchemaName(int column) throws SQLException
/*     */   {
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   public int getPrecision(int column) throws SQLException
/*     */   {
/* 113 */     return 0;
/*     */   }
/*     */   
/*     */   public int getScale(int column) throws SQLException
/*     */   {
/* 118 */     return 0;
/*     */   }
/*     */   
/*     */   public String getTableName(int column) throws SQLException
/*     */   {
/* 123 */     return null;
/*     */   }
/*     */   
/*     */   public String getCatalogName(int column) throws SQLException
/*     */   {
/* 128 */     return null;
/*     */   }
/*     */   
/*     */   public int getColumnType(int column) throws SQLException
/*     */   {
/* 133 */     switch (getColumnTypeName(column)) {
/*     */     case "String": 
/* 135 */       return 12;
/*     */     case "Integer": 
/* 137 */       return 4;
/*     */     case "Long": 
/* 139 */       return 8;
/*     */     case "Double": 
/* 141 */       return 8;
/*     */     }
/* 143 */     return 2000;
/*     */   }
/*     */   
/*     */   public String getColumnTypeName(int column)
/*     */     throws SQLException
/*     */   {
/* 149 */     return getColumnClass(column).getSimpleName();
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(int column) throws SQLException
/*     */   {
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isWritable(int column) throws SQLException
/*     */   {
/* 159 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDefinitelyWritable(int column) throws SQLException
/*     */   {
/* 164 */     return false;
/*     */   }
/*     */   
/*     */   public String getColumnClassName(int column) throws SQLException
/*     */   {
/* 169 */     return getColumnClass(column).getTypeName();
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException
/*     */   {
/* 174 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*     */   {
/* 179 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\sql\ResultSetMetaDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */