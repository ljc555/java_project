/*     */ package org.apache.solr.client.solrj.io.stream;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.apache.solr.client.solrj.io.Tuple;
/*     */ import org.apache.solr.client.solrj.io.comp.FieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.MultipleFieldComparator;
/*     */ import org.apache.solr.client.solrj.io.comp.StreamComparator;
/*     */ import org.apache.solr.client.solrj.io.eq.FieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.MultipleFieldEqualitor;
/*     */ import org.apache.solr.client.solrj.io.eq.StreamEqualitor;
/*     */ import org.apache.solr.client.solrj.io.ops.ReduceOperation;
/*     */ import org.apache.solr.client.solrj.io.ops.StreamOperation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Explanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.Expressible;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExplanation;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpression;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionNamedParameter;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamExpressionValue;
/*     */ import org.apache.solr.client.solrj.io.stream.expr.StreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReducerStream
/*     */   extends TupleStream
/*     */   implements Expressible
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PushBackStream stream;
/*     */   private StreamEqualitor eq;
/*     */   private ReduceOperation op;
/*     */   private boolean needsReduce;
/*     */   private transient Tuple currentGroupHead;
/*     */   
/*     */   public ReducerStream(TupleStream stream, StreamEqualitor eq, ReduceOperation op)
/*     */     throws IOException
/*     */   {
/*  69 */     init(stream, eq, op);
/*     */   }
/*     */   
/*     */   public ReducerStream(TupleStream stream, StreamComparator comp, ReduceOperation op) throws IOException {
/*  73 */     init(stream, convertToEqualitor(comp), op);
/*     */   }
/*     */   
/*     */   private StreamEqualitor convertToEqualitor(StreamComparator comp) {
/*  77 */     if ((comp instanceof MultipleFieldComparator)) {
/*  78 */       MultipleFieldComparator mComp = (MultipleFieldComparator)comp;
/*  79 */       StreamEqualitor[] eqs = new StreamEqualitor[mComp.getComps().length];
/*  80 */       for (int idx = 0; idx < mComp.getComps().length; idx++) {
/*  81 */         eqs[idx] = convertToEqualitor(mComp.getComps()[idx]);
/*     */       }
/*  83 */       return new MultipleFieldEqualitor(eqs);
/*     */     }
/*     */     
/*  86 */     FieldComparator fComp = (FieldComparator)comp;
/*  87 */     return new FieldEqualitor(fComp.getLeftFieldName(), fComp.getRightFieldName());
/*     */   }
/*     */   
/*     */   public ReducerStream(StreamExpression expression, StreamFactory factory)
/*     */     throws IOException
/*     */   {
/*  93 */     List<StreamExpression> streamExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { Expressible.class, TupleStream.class });
/*  94 */     StreamExpressionNamedParameter byExpression = factory.getNamedOperand(expression, "by");
/*  95 */     List<StreamExpression> operationExpressions = factory.getExpressionOperandsRepresentingTypes(expression, new Class[] { ReduceOperation.class });
/*     */     
/*     */ 
/*  98 */     if (expression.getParameters().size() != streamExpressions.size() + 2) {
/*  99 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - unknown operands found", new Object[] { expression }));
/*     */     }
/*     */     
/* 102 */     if (1 != streamExpressions.size()) {
/* 103 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting a single stream but found %d", new Object[] { expression, Integer.valueOf(streamExpressions.size()) }));
/*     */     }
/* 105 */     if ((null == byExpression) || (!(byExpression.getParameter() instanceof StreamExpressionValue))) {
/* 106 */       throw new IOException(String.format(Locale.ROOT, "Invalid expression %s - expecting single 'by' parameter listing fields to group by but didn't find one", new Object[] { expression }));
/*     */     }
/*     */     
/* 109 */     ReduceOperation reduceOperation = null;
/* 110 */     if ((operationExpressions != null) && (operationExpressions.size() == 1)) {
/* 111 */       StreamExpression ex = (StreamExpression)operationExpressions.get(0);
/* 112 */       StreamOperation operation = factory.constructOperation(ex);
/* 113 */       if ((operation instanceof ReduceOperation)) {
/* 114 */         reduceOperation = (ReduceOperation)operation;
/*     */       } else {
/* 116 */         throw new IOException("The ReducerStream requires a ReduceOperation. A StreamOperation was provided.");
/*     */       }
/*     */     } else {
/* 119 */       throw new IOException("The ReducerStream requires a ReduceOperation.");
/*     */     }
/*     */     
/* 122 */     init(factory.constructStream((StreamExpression)streamExpressions.get(0)), factory
/* 123 */       .constructEqualitor(((StreamExpressionValue)byExpression.getParameter()).getValue(), FieldEqualitor.class), reduceOperation);
/*     */   }
/*     */   
/*     */   private void init(TupleStream stream, StreamEqualitor eq, ReduceOperation op) throws IOException
/*     */   {
/* 128 */     this.stream = new PushBackStream(stream);
/* 129 */     this.eq = eq;
/* 130 */     this.op = op;
/*     */     
/* 132 */     if (!eq.isDerivedFrom(stream.getStreamSort())) {
/* 133 */       throw new IOException("Invalid ReducerStream - substream comparator (sort) must be a superset of this stream's comparator.");
/*     */     }
/*     */   }
/*     */   
/*     */   public StreamExpression toExpression(StreamFactory factory) throws IOException
/*     */   {
/* 139 */     return toExpression(factory, true);
/*     */   }
/*     */   
/*     */   private StreamExpression toExpression(StreamFactory factory, boolean includeStreams) throws IOException
/*     */   {
/* 144 */     StreamExpression expression = new StreamExpression(factory.getFunctionName(getClass()));
/*     */     
/*     */ 
/* 147 */     if (includeStreams) {
/* 148 */       expression.addParameter(this.stream.toExpression(factory));
/*     */     }
/*     */     else {
/* 151 */       expression.addParameter("<stream>");
/*     */     }
/*     */     
/*     */ 
/* 155 */     if ((this.eq instanceof Expressible)) {
/* 156 */       expression.addParameter(new StreamExpressionNamedParameter("by", this.eq.toExpression(factory)));
/*     */     }
/*     */     else {
/* 159 */       throw new IOException("This ReducerStream contains a non-expressible comparator - it cannot be converted to an expression");
/*     */     }
/*     */     
/* 162 */     if ((this.op instanceof Expressible)) {
/* 163 */       expression.addParameter(this.op.toExpression(factory));
/*     */     } else {
/* 165 */       throw new IOException("This ReducerStream contains a non-expressible operation - it cannot be converted to an expression");
/*     */     }
/*     */     
/* 168 */     return expression;
/*     */   }
/*     */   
/*     */   public Explanation toExplanation(StreamFactory factory)
/*     */     throws IOException
/*     */   {
/* 174 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */       new StreamExplanation(getStreamNodeId().toString()).withChildren(new Explanation[] { this.stream.toExplanation(factory) }).withFunctionName(factory.getFunctionName(getClass())).withImplementingClass(getClass().getName()).withExpressionType("stream-decorator").withExpression(toExpression(factory, false).toString()).withHelpers(new Explanation[] {this.eq
/* 183 */       .toExplanation(factory), this.op
/* 184 */       .toExplanation(factory) });
/*     */   }
/*     */   
/*     */   public void setStreamContext(StreamContext context)
/*     */   {
/* 189 */     this.stream.setStreamContext(context);
/*     */   }
/*     */   
/*     */   public List<TupleStream> children() {
/* 193 */     List<TupleStream> l = new ArrayList();
/* 194 */     l.add(this.stream);
/* 195 */     return l;
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 199 */     this.stream.open();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 203 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public Tuple read() throws IOException
/*     */   {
/*     */     for (;;) {
/* 209 */       Tuple t = this.stream.read();
/*     */       
/* 211 */       if (t.EOF) {
/* 212 */         if (this.needsReduce) {
/* 213 */           this.stream.pushBack(t);
/* 214 */           this.needsReduce = false;
/* 215 */           return this.op.reduce();
/*     */         }
/* 217 */         return t;
/*     */       }
/*     */       
/*     */ 
/* 221 */       if (this.currentGroupHead == null) {
/* 222 */         this.currentGroupHead = t;
/* 223 */         this.op.operate(t);
/* 224 */         this.needsReduce = true;
/*     */       }
/* 226 */       else if (this.eq.test(this.currentGroupHead, t)) {
/* 227 */         this.op.operate(t);
/* 228 */         this.needsReduce = true;
/*     */       } else {
/* 230 */         this.stream.pushBack(t);
/* 231 */         this.currentGroupHead = null;
/* 232 */         this.needsReduce = false;
/* 233 */         return this.op.reduce();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public StreamComparator getStreamSort()
/*     */   {
/* 241 */     return this.stream.getStreamSort();
/*     */   }
/*     */   
/*     */   public int getCost() {
/* 245 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\io\stream\ReducerStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */