/*     */ package org.apache.solr.client.solrj.response;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.solr.common.util.NamedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpellCheckResponse
/*     */ {
/*     */   private boolean correctlySpelled;
/*     */   private List<Collation> collations;
/*  34 */   private List<Suggestion> suggestions = new ArrayList();
/*  35 */   Map<String, Suggestion> suggestionMap = new LinkedHashMap();
/*     */   
/*     */   public SpellCheckResponse(NamedList<Object> spellInfo)
/*     */   {
/*  39 */     NamedList<Object> sugg = (NamedList)spellInfo.get("suggestions");
/*  40 */     if (sugg == null) {
/*  41 */       this.correctlySpelled = true;
/*  42 */       return;
/*     */     }
/*  44 */     for (int i = 0; i < sugg.size(); i++) {
/*  45 */       String n = sugg.getName(i);
/*     */       
/*  47 */       Suggestion s = new Suggestion(n, (NamedList)sugg.getVal(i));
/*  48 */       this.suggestionMap.put(n, s);
/*  49 */       this.suggestions.add(s);
/*     */     }
/*     */     
/*  52 */     Boolean correctlySpelled = (Boolean)spellInfo.get("correctlySpelled");
/*  53 */     if (correctlySpelled != null) {
/*  54 */       this.correctlySpelled = correctlySpelled.booleanValue();
/*     */     }
/*     */     
/*     */ 
/*  58 */     NamedList<Object> coll = (NamedList)spellInfo.get("collations");
/*  59 */     if (coll != null)
/*     */     {
/*  61 */       List<Object> collationInfo = coll.getAll("collation");
/*  62 */       this.collations = new ArrayList(collationInfo.size());
/*  63 */       for (Object o : collationInfo) {
/*  64 */         if ((o instanceof String)) {
/*  65 */           this.collations.add(new Collation()
/*  66 */             .setCollationQueryString((String)o));
/*  67 */         } else if ((o instanceof NamedList))
/*     */         {
/*  69 */           NamedList<Object> expandedCollation = (NamedList)o;
/*     */           
/*  71 */           String collationQuery = (String)expandedCollation.get("collationQuery");
/*  72 */           int hits = ((Integer)expandedCollation.get("hits")).intValue();
/*     */           
/*     */ 
/*  75 */           NamedList<String> misspellingsAndCorrections = (NamedList)expandedCollation.get("misspellingsAndCorrections");
/*     */           
/*  77 */           Collation collation = new Collation();
/*  78 */           collation.setCollationQueryString(collationQuery);
/*  79 */           collation.setNumberOfHits(hits);
/*     */           
/*  81 */           for (int ii = 0; ii < misspellingsAndCorrections.size(); ii++) {
/*  82 */             String misspelling = misspellingsAndCorrections.getName(ii);
/*  83 */             String correction = (String)misspellingsAndCorrections.getVal(ii);
/*  84 */             collation.addMisspellingsAndCorrection(new Correction(misspelling, correction));
/*     */           }
/*     */           
/*  87 */           this.collations.add(collation);
/*     */         } else {
/*  89 */           throw new AssertionError("Should get Lists of Strings or List of NamedLists here.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCorrectlySpelled()
/*     */   {
/*  97 */     return this.correctlySpelled;
/*     */   }
/*     */   
/*     */   public List<Suggestion> getSuggestions() {
/* 101 */     return this.suggestions;
/*     */   }
/*     */   
/*     */   public Map<String, Suggestion> getSuggestionMap() {
/* 105 */     return this.suggestionMap;
/*     */   }
/*     */   
/*     */   public Suggestion getSuggestion(String token) {
/* 109 */     return (Suggestion)this.suggestionMap.get(token);
/*     */   }
/*     */   
/*     */   public String getFirstSuggestion(String token) {
/* 113 */     Suggestion s = (Suggestion)this.suggestionMap.get(token);
/* 114 */     if ((s == null) || (s.getAlternatives().isEmpty())) return null;
/* 115 */     return (String)s.getAlternatives().get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCollatedResult()
/*     */   {
/* 125 */     return (this.collations == null) || (this.collations.size() == 0) ? null : ((Collation)this.collations.get(0)).collationQueryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Collation> getCollatedResults()
/*     */   {
/* 136 */     return this.collations;
/*     */   }
/*     */   
/*     */   public static class Suggestion {
/*     */     private String token;
/*     */     private int numFound;
/*     */     private int startOffset;
/*     */     private int endOffset;
/*     */     private int originalFrequency;
/* 145 */     private List<String> alternatives = new ArrayList();
/*     */     private List<Integer> alternativeFrequencies;
/*     */     
/*     */     public Suggestion(String token, NamedList<Object> suggestion) {
/* 149 */       this.token = token;
/* 150 */       for (int i = 0; i < suggestion.size(); i++) {
/* 151 */         String n = suggestion.getName(i);
/*     */         
/* 153 */         if ("numFound".equals(n)) {
/* 154 */           this.numFound = ((Integer)suggestion.getVal(i)).intValue();
/* 155 */         } else if ("startOffset".equals(n)) {
/* 156 */           this.startOffset = ((Integer)suggestion.getVal(i)).intValue();
/* 157 */         } else if ("endOffset".equals(n)) {
/* 158 */           this.endOffset = ((Integer)suggestion.getVal(i)).intValue();
/* 159 */         } else if ("origFreq".equals(n)) {
/* 160 */           this.originalFrequency = ((Integer)suggestion.getVal(i)).intValue();
/* 161 */         } else if ("suggestion".equals(n))
/*     */         {
/* 163 */           List list = (List)suggestion.getVal(i);
/* 164 */           if ((list.size() > 0) && ((list.get(0) instanceof NamedList)))
/*     */           {
/*     */ 
/* 167 */             List<NamedList> extended = list;
/* 168 */             this.alternativeFrequencies = new ArrayList();
/* 169 */             for (NamedList nl : extended) {
/* 170 */               this.alternatives.add((String)nl.get("word"));
/* 171 */               this.alternativeFrequencies.add((Integer)nl.get("freq"));
/*     */             }
/*     */           }
/*     */           else {
/* 175 */             List<String> alts = list;
/* 176 */             this.alternatives.addAll(alts);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public String getToken() {
/* 183 */       return this.token;
/*     */     }
/*     */     
/*     */     public int getNumFound() {
/* 187 */       return this.numFound;
/*     */     }
/*     */     
/*     */     public int getStartOffset() {
/* 191 */       return this.startOffset;
/*     */     }
/*     */     
/*     */     public int getEndOffset() {
/* 195 */       return this.endOffset;
/*     */     }
/*     */     
/*     */     public int getOriginalFrequency() {
/* 199 */       return this.originalFrequency;
/*     */     }
/*     */     
/*     */     public List<String> getAlternatives()
/*     */     {
/* 204 */       return this.alternatives;
/*     */     }
/*     */     
/*     */     public List<Integer> getAlternativeFrequencies()
/*     */     {
/* 209 */       return this.alternativeFrequencies;
/*     */     }
/*     */   }
/*     */   
/*     */   public class Collation
/*     */   {
/*     */     private String collationQueryString;
/* 216 */     private List<SpellCheckResponse.Correction> misspellingsAndCorrections = new ArrayList();
/*     */     
/*     */     public Collation() {}
/*     */     
/* 220 */     public long getNumberOfHits() { return this.numberOfHits; }
/*     */     
/*     */     private long numberOfHits;
/*     */     public void setNumberOfHits(long numberOfHits) {
/* 224 */       this.numberOfHits = numberOfHits;
/*     */     }
/*     */     
/*     */     public String getCollationQueryString() {
/* 228 */       return this.collationQueryString;
/*     */     }
/*     */     
/*     */     public Collation setCollationQueryString(String collationQueryString) {
/* 232 */       this.collationQueryString = collationQueryString;
/* 233 */       return this;
/*     */     }
/*     */     
/*     */     public List<SpellCheckResponse.Correction> getMisspellingsAndCorrections() {
/* 237 */       return this.misspellingsAndCorrections;
/*     */     }
/*     */     
/*     */     public Collation addMisspellingsAndCorrection(SpellCheckResponse.Correction correction) {
/* 241 */       this.misspellingsAndCorrections.add(correction);
/* 242 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public class Correction
/*     */   {
/*     */     private String original;
/*     */     private String correction;
/*     */     
/*     */     public Correction(String original, String correction) {
/* 252 */       this.original = original;
/* 253 */       this.correction = correction;
/*     */     }
/*     */     
/*     */     public String getOriginal() {
/* 257 */       return this.original;
/*     */     }
/*     */     
/*     */     public void setOriginal(String original) {
/* 261 */       this.original = original;
/*     */     }
/*     */     
/*     */     public String getCorrection() {
/* 265 */       return this.correction;
/*     */     }
/*     */     
/*     */     public void setCorrection(String correction) {
/* 269 */       this.correction = correction;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\website\java_project\SolrClient\WebContent\WEB-INF\lib\solr-solrj-6.2.1.jar!\org\apache\solr\client\solrj\response\SpellCheckResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */